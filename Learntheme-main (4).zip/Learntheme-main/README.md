# Axon Nursing Academy - Production LMS Frontend Architecture

Axon Nursing Academy is a production-grade online Nursing Education Learning Management System (LMS) designed specifically for competitive exam aspirants targeting **AIIMS NORCET, NCLEX-RN, M.Sc Nursing, CHO, State Staff Nurse, and B.Sc Nursing** academic foundations.

---

## Current Status: Phase 2 Completed (Real Firestore Database Foundation)

The project includes complete, real **Firestore Database Foundation** integrated with **Firebase Authentication**:
- **Identity Link**: Permanent student identity is anchored to `users/{uid}` with Firestore as authoritative profile storage.
- **Data Model**: `{ uid, fullName, email, role: 'student', isActive: true, createdAt, updatedAt }` with Firestore `serverTimestamp()`.
- **User Profile Service (`userService.ts`)**: Modular CRUD operations (`createUserProfile`, `getUserProfile`, `updateUserProfile`, `ensureUserProfile`) with input validation and security constraints.
- **`AuthContext` Integration**: Exposes `currentUser` (Firebase Auth User), `profile` (Firestore UserProfile), `loading`, `profileLoading`, `isAuthenticated`, `isAdmin`, `signUp`, `login`, `loginWithGoogle`, `logout`, `resetPassword`, `updateProfileName`, and `refreshProfile`.
- **Existing User & Google Auth Sync**: Auto-ensures Firestore profile creation for existing users or Google sign-in accounts.
- **Account Status Enforced (`isActive`)**: Disabled students are blocked from protected student routes with support contact screen.
- **Student Profile Page**: Real-time Firestore profile presentation with in-place full name editing.
- **Zero-Trust Security Rules (`firestore.rules`) & Blueprint (`firebase-blueprint.json`)**: Enforces document ownership (`request.auth.uid == userId`), immutable fields (`uid`, `role`, `isActive`, `createdAt`), and strict schema validation.

---

## Technology Stack

- **Framework**: React 19 + TypeScript
- **Bundler**: Vite 6
- **Routing**: React Router DOM (with route-based lazy loading & code splitting)
- **Styling**: Tailwind CSS v4 (with custom medical education design tokens)
- **Icons**: Lucide React
- **Firebase SDK**: Client SDK initialization layer (`firebase/app`, `firebase/auth`, `firebase/firestore`, `firebase/storage`)
- **Type Safety**: Full domain TypeScript typing (zero `any` pattern)

---

## Folder Architecture

```text
src/
├── assets/                    # Static images, icons, illustrations
├── components/
│   ├── common/                # ErrorBoundary, LoadingState, ErrorState, EmptyState
│   ├── layout/                # TopHeader, BottomNavigation, DrawerMenu, AdminSidebar, AdminHeader, PublicHeader, PublicFooter
│   └── ui/                    # Button, Card, Input, Modal, Badge, Skeleton, SectionHeader, CourseCard, BannerCard, CategoryCard, Avatar, TestimonialCard
├── config/
│   ├── routes.config.ts       # Centralized route paths
│   └── site.config.ts         # Academy metadata, support channels, target exam metadata
├── constants/
│   ├── navigation.constants.ts# Bottom nav & sidebar navigation items
│   └── theme.constants.ts     # Theme colors, typography, border radii, shadows
├── contexts/
│   └── AuthContext.tsx        # Auth state provider interface (ready for Firebase Auth in Phase 1)
├── data/
│   └── demoData.ts            # Isolated static showcase data for Phase 0 UI preview
├── hooks/
│   ├── useMediaQuery.ts       # Responsive viewport hook
│   └── useScrollLock.ts       # Body scroll lock for modals & drawers
├── layouts/
│   ├── AdminLayout/           # Admin CMS layout with collapsible sidebar
│   ├── PublicLayout/          # Public landing layout
│   └── StudentLayout/         # Mobile-first student learning shell with bottom nav
├── lib/
│   ├── firebase/              # Safe Firebase initialization, config, auth, firestore, storage layers
│   └── utils/                 # cn (classnames helper), formatters (INR currency, dates, duration)
├── pages/
│   ├── admin/                 # AdminDashboardPage, AdminCoursesPage, AdminStudentsPage
│   ├── public/                # HomePage, LoginPage, SignupPage, ForgotPasswordPage, NotFoundPage
│   └── student/               # StudentHomePage, StudentCoursesPage, StudentAllCoursesPage, StudentProfilePage, StudentChatsPage
├── routes/
│   ├── AdminRoute.tsx         # Admin authorization placeholder
│   ├── AppRoutes.tsx          # Central route declarations with React.lazy
│   └── ProtectedRoute.tsx     # Student authentication placeholder
├── services/
│   ├── api/                   # API endpoint constants
│   └── firebase/              # Firebase facade exports
├── types/                     # Comprehensive domain types (User, Course, Assessment, Payment, Content)
├── App.tsx                    # Root application component
├── index.css                  # Global Tailwind imports and base styles
└── main.tsx                   # React root entry point
```

---

## Routes Manifest

| Route | Layout | Purpose |
| :--- | :--- | :--- |
| `/` | `PublicLayout` | Public landing page showcasing academy features, courses, faculty, and results |
| `/login` | `PublicLayout` | Student / Staff login portal placeholder |
| `/signup` | `PublicLayout` | Student registration portal placeholder |
| `/forgot-password` | `PublicLayout` | Password recovery placeholder |
| `/student` | `StudentLayout` | Student Mobile-First Home (11 core sections) |
| `/student/courses` | `StudentLayout` | Active enrolled courses, lecture progress & notes |
| `/student/all-courses`| `StudentLayout` | Complete course catalog with filter chips & search |
| `/student/chats` | `StudentLayout` | Doubt Room & faculty peer discussion channel |
| `/student/profile` | `StudentLayout` | Student profile, contact records, statistics & settings |
| `/admin` | `AdminLayout` | Admin portal redirect |
| `/admin/dashboard` | `AdminLayout` | Academy KPIs, revenue, batch enrollment tracking |
| `/admin/courses` | `AdminLayout` | CMS batch and curriculum manager |
| `/admin/students` | `AdminLayout` | Student directory & enrollment monitoring |

---

## Student Home Shell (11 Mobile-First Sections)

1. **Top Header**: Academy logo, branding, search trigger, alert indicator, mobile drawer trigger.
2. **Promotional Banner**: High-yield crash course banners with interactive slide indicators.
3. **Featured Courses**: Multi-batch cards with ratings, lecture hours, and fee comparison.
4. **Purchased Courses (Active Learning)**: Progress tracker with resume lecture shortcut.
5. **Quick Actions**: Touch-optimized grid for Live Classes, Test Series, PDF Notes, PYQs, Doubt Room, and Exam Alerts.
6. **"What are you looking for?"**: Target exam selector and instant search prompt.
7. **Learning Category Cards**: NORCET, NCLEX-RN, M.Sc Nursing, CHO, B.Sc Academic, and Clinical Test Series.
8. **Recommended Courses**: Personalized high-yield suggestions.
9. **Testimonials**: Verified AIIMS & international exam ranker quotes.
10. **Social & Support Connect**: Official Telegram channel, YouTube live sessions, and 24/7 student counselor helpline.
11. **Bottom Navigation Bar**: Fixed 5-tab touch navigation (Home, My Courses, All Courses, Chats, My Profile).

---

## Environment Variables Configuration

Copy `.env.example` to `.env` when configuring Firebase credentials:

```env
# Firebase Web Client Configuration (Safe for client-side inclusion)
VITE_FIREBASE_API_KEY=
VITE_FIREBASE_AUTH_DOMAIN=
VITE_FIREBASE_PROJECT_ID=
VITE_FIREBASE_STORAGE_BUCKET=
VITE_FIREBASE_MESSAGING_SENDER_ID=
VITE_FIREBASE_APP_ID=
VITE_FIREBASE_MEASUREMENT_ID=

# Application Branding and Environment
VITE_APP_NAME="Axon Nursing Academy"
VITE_APP_ENV=development
```

> **Security Rule**: Never put server secrets, Razorpay secret keys, or service account private keys in `.env` or client files.

---

## Future Phase Roadmap

- **Phase 1: Authentication & Authorization**
  - Firebase Authentication (Email/Password, Phone OTP, Google Sign-In)
  - Role-based authorization (`student`, `admin`, `instructor`)
  - Activation of `ProtectedRoute` and `AdminRoute`

- **Phase 2: Course & Content Management (Firestore + Storage)**
  - Firestore data layer for courses, batches, subjects, chapters, lectures, and PDF notes
  - Course access control & expiration engine
  - PDF viewer & protected video player integration

- **Phase 3: Assessments & Interactive LMS**
  - MCQ Test Series engine with negative marking, timers, and instant AIIMS rationales
  - Live class scheduling & WebRTC / YouTube stream embedding
  - Doubt Room real-time discussions

- **Phase 4: Payments & Checkout**
  - Razorpay order creation and payment verification via backend server
  - Automated student enrollment upon payment success
  - Invoice generation
