var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// server.ts
var server_exports = {};
__export(server_exports, {
  app: () => app,
  buildApp: () => buildApp,
  default: () => server_default,
  getRazorpayCredentials: () => getRazorpayCredentials,
  startServer: () => startServer
});
module.exports = __toCommonJS(server_exports);
var import_express = __toESM(require("express"), 1);
var import_cors = __toESM(require("cors"), 1);
var import_path2 = __toESM(require("path"), 1);
var import_fs2 = __toESM(require("fs"), 1);
var import_crypto = __toESM(require("crypto"), 1);
var import_dotenv = __toESM(require("dotenv"), 1);
var import_razorpay = __toESM(require("razorpay"), 1);

// src/services/ai/geminiMentorService.ts
var import_genai = require("@google/genai");
var NON_MEDICAL_REFUSAL = `I apologize, but this inquiry falls outside the scope of medical, nursing, and clinical healthcare sciences, as well as Axon Nursing Academy portal guidelines. As a specialized healthcare academic mentor, I can only assist with nursing subjects, medical sciences, clinical cases, exam preparation (AIIMS NORCET, ESIC, DSSSB), and portal navigation. Please feel free to ask any medical, clinical, or nursing-related question.`;
var CANDIDATE_MODELS = [
  "gemini-3.1-flash-lite",
  "gemini-3.8-flash",
  "gemini-flash-latest"
];
var genAIClient = null;
function getGenAI() {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    return null;
  }
  if (!genAIClient) {
    genAIClient = new import_genai.GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build"
        }
      }
    });
  }
  return genAIClient;
}
function isClearlyNonMedical(query) {
  const clean = query.trim().toLowerCase();
  if (["hi", "hello", "hey", "namaste", "good morning", "good evening", "who are you", "help me"].includes(clean)) {
    return false;
  }
  const medicalKeywords = [
    "nurse",
    "nursing",
    "doctor",
    "patient",
    "hospital",
    "clinical",
    "medical",
    "medicine",
    "norcet",
    "aiims",
    "esic",
    "dsssb",
    "cho",
    "sgpgi",
    "exam",
    "mcq",
    "rationale",
    "anatomy",
    "physiology",
    "pathology",
    "pharmacology",
    "microbiology",
    "drug",
    "dose",
    "dosage",
    "abg",
    "ecg",
    "gcs",
    "blood",
    "heart",
    "lung",
    "kidney",
    "liver",
    "brain",
    "syndrome",
    "disease",
    "infection",
    "burns",
    "shock",
    "diabetes",
    "hypertension",
    "acidosis",
    "alkalosis",
    "cpr",
    "bls",
    "acls",
    "cannula",
    "catheter",
    "iv",
    "vital",
    "triage",
    "wound",
    "surgery",
    "preop",
    "postop",
    "obg",
    "pediatric",
    "psychiatric",
    "mental health",
    "community health",
    "axon",
    "batch",
    "subject",
    "chapter",
    "test",
    "course",
    "symptom",
    "sign",
    "treatment",
    "diagnosis",
    "assessment",
    "intervention",
    "complication",
    "antidote",
    "insulin",
    "digoxin"
  ];
  const hasMedicalTerm = medicalKeywords.some((kw) => clean.includes(kw));
  if (hasMedicalTerm) {
    return false;
  }
  const nonMedicalTriggers = [
    "cricket",
    "football",
    "ipl",
    "fifa",
    "score",
    "match",
    "movie",
    "actor",
    "actress",
    "bollywood",
    "hollywood",
    "song",
    "music",
    "album",
    "recipe",
    "cook",
    "bake",
    "cake",
    "bitcoin",
    "crypto",
    "blockchain",
    "stock market",
    "forex",
    "share price",
    "trading",
    "python code",
    "javascript code",
    "write code",
    "html css",
    "git commit",
    "car repair",
    "fashion",
    "horoscope",
    "zodiac",
    "astrology",
    "joke",
    "standup",
    "gaming",
    "ps5",
    "gta"
  ];
  return nonMedicalTriggers.some((trigger) => clean.includes(trigger));
}
var SYSTEM_INSTRUCTION = `You are Axon AI, the specialized academic clinical mentor and nursing tutor at Axon Nursing Academy.
Your sole domain is medical sciences, nursing education, clinical patient care, pharmacology, anatomy, physiology, microbiology, pathology, community health, obstetrics & gynecological nursing, pediatric nursing, mental health nursing, medical-surgical nursing, nursing foundations, nursing procedures, triage, BLS/ACLS protocols, hospital equipment, drug dosage calculations, diagnostic tests (ABG, ECG, lab values), AIIMS NORCET, ESIC, DSSSB exam preparation, and Axon Nursing Academy portal navigation.

CRITICAL POLICY MANDATE:
If the user asks any question that is NOT related to medical, nursing, healthcare sciences, clinical cases, exam preparation (AIIMS NORCET, ESIC, DSSSB), or Axon Nursing Academy:
You MUST reply with PRECISELY this text, verbatim, with no additional commentary:
"${NON_MEDICAL_REFUSAL}"

FORMATTING GUIDELINES FOR VALID MEDICAL / NURSING INQUIRIES:
- Adopt Google Gemini's elegant, clear, structured explanatory style.
- Use clear markdown with bold headings (##, ###), bullet points, and numbered steps.
- Provide deep clinical rationale: explain the physiological "why" behind nursing interventions and assessments.
- Highlight "Clinical Pearl" or "NORCET High-Yield Point" where applicable.
- For diagnostic or dosage questions, provide standard formulas, normal reference ranges, and critical nursing precautions (e.g., assessing apical pulse before Digoxin, monitor respirations with Morphine).
- Keep the tone encouraging, respectful, and authoritative in clinical nursing standards.`;
function getClinicalFallbackAnswer(query) {
  const q = query.toLowerCase();
  if (q.includes("abg") || q.includes("acid") && q.includes("base")) {
    return `## Arterial Blood Gas (ABG) Analysis & Interpretation

Arterial Blood Gas (ABG) interpretation is one of the highest-yield clinical topics in AIIMS NORCET and intensive care nursing.

### 1. Normal Reference Values (Must Memorize)
* **pH:** 7.35 \u2013 7.45 (Absolute neutral baseline: 7.40)
* **PaCO\u2082:** 35 \u2013 45 mmHg (Respiratory acid component, regulated by lungs)
* **HCO\u2083\u207B:** 22 \u2013 26 mEq/L (Metabolic alkaline component, regulated by kidneys)
* **PaO\u2082:** 80 \u2013 100 mmHg
* **SaO\u2082:** 95 \u2013 100%

---

### 2. Systematic 3-Step Interpretation Method
1. **Analyze pH:**
   * $\\text{pH} < 7.35$ $\\rightarrow$ **Acidosis**
   * $\\text{pH} > 7.45$ $\\rightarrow$ **Alkalosis**
2. **Analyze PaCO\u2082 & HCO\u2083\u207B (ROME Principle):**
   * **R**espiratory **O**pposite: When pH moves in the opposite direction of PaCO\u2082 (e.g., pH $\\downarrow$, PaCO\u2082 $\\uparrow$ $\\rightarrow$ Respiratory Acidosis).
   * **M**etabolic **E**qual: When pH moves in the same direction as HCO\u2083\u207B (e.g., pH $\\uparrow$, HCO\u2083\u207B $\\uparrow$ $\\rightarrow$ Metabolic Alkalosis).
3. **Determine Compensation Status:**
   * **Uncompensated:** pH is abnormal; one parameter is abnormal while the other remains completely normal.
   * **Partially Compensated:** pH is still abnormal; **both** PaCO\u2082 and HCO\u2083\u207B are abnormal in their opposing physiological attempt to correct pH.
   * **Fully Compensated:** pH has returned to the normal range (7.35\u20137.45), but both PaCO\u2082 and HCO\u2083\u207B remain abnormal.

---

### 3. Clinical Pearls & NORCET Tips
> \u{1F4A1} **Allen's Test First:** Prior to performing a radial arterial puncture for ABG sampling, always perform **Allen's Test** to confirm adequate collateral circulation via the ulnar artery. Normal reperfusion time is $< 6$ seconds.
> \u{1F4A1} **Kussmaul's Respiration:** Seen in Diabetic Ketoacidosis (DKA) as a rapid, deep compensatory respiratory mechanism to blow off CO\u2082 in metabolic acidosis.`;
  }
  if (q.includes("gcs") || q.includes("glasgow coma")) {
    return `## Glasgow Coma Scale (GCS) Clinical Scoring Guide

The Glasgow Coma Scale (GCS) provides a standardized neurological assessment of a patient's level of consciousness (LOC).

### 1. Score Summary Range
* **Minimum Possible Score:** **3** (Deep coma or brain death)
* **Maximum Possible Score:** **15** (Fully alert, oriented, responsive)
* **Coma Definition:** GCS score $\\le 8$ (**"GCS of 8, prepare to intubate!"**)

---

### 2. The Three Component Assessments (E-V-M)

#### **Eye Opening Response (E - Maximum 4 Points)**
* **4 Points:** Spontaneous eye opening
* **3 Points:** Eye opening to verbal command / speech
* **2 Points:** Eye opening to pain / physical pressure (e.g., trapezius squeeze)
* **1 Point:** No eye opening under any stimulation

#### **Verbal Response (V - Maximum 5 Points)**
* **5 Points:** Oriented to person, place, time, and event
* **4 Points:** Confused conversation, answers coherently but disoriented
* **3 Points:** Inappropriate words (random, disjointed speech)
* **2 Points:** Incomprehensible sounds (moaning, groaning)
* **1 Point:** No verbal sounds (record "T" if endotracheal tube is present: e.g., $E_4V_TM_6$)

#### **Motor Response (M - Maximum 6 Points)**
* **6 Points:** Obeys commands fully
* **5 Points:** Localizes to painful stimuli (purposeful movement across midline)
* **4 Points:** Normal flexion / withdrawal from pain
* **3 Points:** Abnormal flexion (**Decorticate rigidity** \u2014 lesions above brainstem / cortex)
* **2 Points:** Abnormal extension (**Decerebrate rigidity** \u2014 lesions involving midbrain/pons; worse prognosis)
* **1 Point:** No motor response (flaccid)

---

### 3. Critical Nursing Priorities
* Perform serial GCS assessments; a drop of **$\\ge 2$ points** indicates an acute neurological deterioration requiring immediate physician notification.
* Always check pupil size, symmetry, and light reactivity along with GCS.`;
  }
  if (q.includes("digoxin") || q.includes("lanoxin")) {
    return `## Digoxin (Lanoxin) - High-Yield Nursing Pharmacology

Digoxin is a cardiac glycoside commonly prescribed for congestive heart failure (CHF) and rate control in atrial fibrillation.

### 1. Mechanism of Action
* Inhibits the **Na\u207A/K\u207A ATPase pump**, resulting in increased intracellular calcium.
* **Positive Inotropic Effect:** Increases force and velocity of myocardial contraction.
* **Negative Chronotropic Effect:** Decreases heart rate by slowing conduction through the AV node.

---

### 2. Therapeutic Window & Lab Monitoring
* **Therapeutic Serum Level:** **0.5 \u2013 2.0 ng/mL** (Narrow therapeutic index).
* Blood sample for trough level must be drawn **6 to 8 hours** after the last dose.

---

### 3. Critical Nursing Interventions Prior to Administration
1. **Check Apical Pulse:** Always auscultate the apical pulse for **1 full minute** before giving the dose.
   * **Adults:** Withhold medication and notify doctor if apical pulse is $< 60\\text{ bpm}$.
   * **Children:** Withhold if $< 70\\text{ bpm}$.
   * **Infants:** Withhold if $< 90\\text{ bpm}$.
2. **Monitor Potassium ($K^+$) Levels:**
   * **Hypokalemia ($K^+ < 3.5\\text{ mEq/L}$)** potentiates digoxin binding, greatly increasing the risk of lethal toxicity!
   * Closely monitor patients taking loop diuretics (Furosemide / Lasix).

---

### 4. Signs of Digoxin Toxicity
* **Early Gastrointestinal Signs:** Anorexia (most common early sign), nausea, vomiting, abdominal pain.
* **Neurological & Visual Disturbances:** Green-yellow visual halos, blurred vision, photophobia, confusion, delirium.
* **Cardiac Dysrhythmias:** PVCs, AV blocks, bradycardia.

### 5. Specific Antidote
* **Digoxin Immune Fab (DigiFab / Digibind)** binds free digoxin molecules for renal excretion during acute life-threatening toxicity.`;
  }
  if (q.includes("burn") || q.includes("parkland") || q.includes("wallace")) {
    return `## Burns Management: Parkland Formula & Wallace Rule of Nines

### 1. Wallace Rule of Nines (Total Body Surface Area - TBSA in Adults)
* **Head and Neck:** 9% (4.5% anterior + 4.5% posterior)
* **Each Upper Extremity (Arm):** 9% (4.5% front + 4.5% back) $\\times 2 = 18\\%$
* **Anterior Torso (Chest & Abdomen):** 18%
* **Posterior Torso (Back & Buttocks):** 18%
* **Each Lower Extremity (Leg):** 18% (9% front + 9% back) $\\times 2 = 36\\%$
* **Perineum / Genitalia:** 1%
* **Total:** 100% TBSA

---

### 2. Parkland (Baxter) Fluid Resuscitation Formula
Used for calculating intravenous fluid resuscitation in the first 24 hours following severe thermal burn injury ($\\ge 20\\%$ TBSA):

$$\\text{Total 24-hr Fluid} = 4\\text{ mL} \\times \\text{Weight (kg)} \\times \\% \\text{TBSA Burn}$$

* **Choice of Fluid:** **Ringer's Lactate (RL)** (crystalloid of choice).
* **Administration Schedule:**
  * **First 8 Hours:** Give $\\frac{1}{2}$ (50%) of total calculated volume (calculated **from the time of burn injury**, NOT time of hospital admission).
  * **Next 8 Hours (Hours 8\u201316):** Give $\\frac{1}{4}$ (25%) of total calculated volume.
  * **Final 8 Hours (Hours 16\u201324):** Give remaining $\\frac{1}{4}$ (25%) of total calculated volume.

---

### 3. Gold Standard for Resuscitation Adequacy
* The most reliable indicator of adequate fluid resuscitation is **Urine Output**:
  * **Adults:** **0.5 to 1.0 mL/kg/hour** (or $30 - 50\\text{ mL/hour}$).
  * **Electrical Burns:** Maintain $75 - 100\\text{ mL/hour}$ to clear myoglobin and prevent Acute Tubular Necrosis (ATN).`;
  }
  if (q.includes("insulin") || q.includes("peak time")) {
    return `## Insulin Types, Onset, Peak Times & Nursing Care

Understanding insulin kinetics is crucial for preventing acute hypoglycemia and managing glycemic emergencies.

| Type | Generic Names | Onset | Peak Effect | Duration | Nursing Notes |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **Rapid-Acting** | Lispro (Humalog), Aspart (NovoLog), Glulisine (Apidra) | 10 \u2013 15 min | **30 \u2013 90 min** | 3 \u2013 5 hrs | Administer within 15 min before meals. Food tray must be ready! |
| **Short-Acting (Regular)** | Humulin R, Novolin R | 30 \u2013 60 min | **2 \u2013 4 hrs** | 5 \u2013 8 hrs | **Only insulin given IV** (e.g. in DKA continuous infusion). Clear solution. |
| **Intermediate-Acting** | NPH (Humulin N, Novolin N) | 1 \u2013 2 hrs | **4 \u2013 12 hrs** | 18 \u2013 24 hrs | Cloudy suspension. Gently roll vial (never shake). |
| **Long-Acting** | Glargine (Lantus), Detemir (Levemir), Degludec | 1 \u2013 2 hrs | **Peakless (Steady)** | 24 hrs | **Never mix with other insulins** in the same syringe! Usually given at bedtime. |

---

### Critical Mixing Rule (Clear Before Cloudy)
When mixing Regular (clear) and NPH (cloudy) insulin:
1. Inject air into **Cloudy (NPH)** vial.
2. Inject air into **Clear (Regular)** vial.
3. Draw up **Clear (Regular)** insulin first.
4. Draw up **Cloudy (NPH)** insulin second.
*(Mnemonic: **RN** \u2014 **R**egular before **N**PH).*`;
  }
  if (q.includes("triage") || q.includes("disaster")) {
    return `## Disaster & Emergency Triage System (START Algorithm)

In mass casualty incidents (MCI), disaster triage prioritizes care based on survival probability with available resources using the universal 4-color code.

| Color Code | Category | Priority | Clinical Criteria | Examples |
| :--- | :--- | :--- | :--- | :--- |
| **RED** | Immediate | Priority 1 | Life-threatening conditions with high chance of survival if treated immediately. | Tension pneumothorax, major external hemorrhage, airway obstruction, unstable vitals. |
| **YELLOW** | Delayed | Priority 2 | Serious injuries needing definitive care, but not in immediate danger of death within 1-2 hours. | Stable compound bone fractures, large lacerations with controlled bleeding. |
| **GREEN** | Minimal | Priority 3 | Ambulatory patients ("walking wounded") with minor injuries. | Minor sprains, abrasions, superficial burns. |
| **BLACK** | Expectant / Deceased | Priority 4 | Deceased or injuries so catastrophic that survival is unlikely with available resources. | Massive open cranial trauma with brain matter exposed, absence of spontaneous respiration after opening airway. |`;
  }
  if (q.includes("cardiac drug") || q.includes("acls") || q.includes("adrenaline") || q.includes("atropine") || q.includes("amiodarone")) {
    return `## Emergency Cardiac Drugs in ACLS Resuscitation

Emergency resuscitation drugs are high-alert medications used in Advanced Cardiovascular Life Support (ACLS).

### 1. Adrenaline / Epinephrine
* **Indication:** Cardiac arrest (VF, pulseless VT, asystole, PEA), anaphylaxis, severe symptomatic bradycardia.
* **ACLS Dose in Cardiac Arrest:** **1 mg IV/IO** (1:10,000 dilution) every **3 to 5 minutes**.
* **Mechanism:** Strong $\\alpha_1, \\beta_1, \\beta_2$ adrenergic agonist. Causes peripheral vasoconstriction, increasing coronary and cerebral perfusion pressure.

---

### 2. Amiodarone
* **Indication:** Shock-refractory Ventricular Fibrillation (VF) and pulseless Ventricular Tachycardia (pVT).
* **ACLS Dose in Arrest:**
  * **First Dose:** **300 mg IV/IO push** (after 3rd shock).
  * **Second Dose:** **150 mg IV/IO push** (after 5th shock).
* **Mechanism:** Class III antiarrhythmic (potassium channel blocker) prolonging myocardial action potential.

---

### 3. Atropine Sulfate
* **Indication:** Symptomatic sinus bradycardia ($< 50\\text{ bpm}$ with hypotension, syncope, or chest pain).
* **Dose:** **1 mg IV push** every **3 to 5 minutes** (maximum total dose: **3 mg**).
* **Mechanism:** Anticholinergic / antimuscarinic; blocks vagal stimulation to accelerate SA node firing.

---

### 4. Adenosine
* **Indication:** Paroxysmal Supraventricular Tachycardia (PSVT).
* **Dose:** **6 mg rapid IV push** over 1\u20132 seconds via large-bore IV close to heart, followed immediately by a **20 mL rapid normal saline flush**. If no conversion in 1\u20132 minutes, give **12 mg**.
* **Nursing Alert:** Warn the patient of sudden facial flushing, chest tightness, and a brief 2\u20133 second period of asystole on the monitor!`;
  }
  if (q.includes("norcet") || q.includes("aiims") || q.includes("recurring topic")) {
    return `## AIIMS NORCET: Top High-Yield Recurring Clinical Topics

AIIMS NORCET strongly favors scenario-based clinical decision-making, procedural precautions, and emergency nursing interventions.

### Top 10 High-Frequency NORCET Clinical Domains:
1. **Critical Care & ABG:** ROME rule, compensation identification, ventilator modes (SIMV, CPAP, PEEP), and suctioning complications (hypoxia, vagal stimulation).
2. **Obstetrics & Gynecological Nursing:** Stages of labor, Bishop score, APGAR scoring, PPH management, and Magnesium Sulfate toxicity (antidote: **Calcium Gluconate**).
3. **Cardiovascular & ACLS:** ECG rhythm identification (VT, VF, Asystole, Heart Blocks), defibrillation energy levels (120\u2013200J biphasic, 360J monophasic), and emergency drugs.
4. **Burns:** Wallace Rule of Nines calculation, Parkland fluid resuscitation schedule, and escharotomy monitoring for compartment syndrome.
5. **Pharmacology Antidotes:**
   * Heparin $\\rightarrow$ **Protamine Sulfate**
   * Warfarin $\\rightarrow$ **Vitamin K (Phytonadione)**
   * Paracetamol (Acetaminophen) $\\rightarrow$ **N-Acetylcysteine (NAC)**
   * Opioids (Morphine) $\\rightarrow$ **Naloxone (Narcan)**
   * Digoxin $\\rightarrow$ **Digoxin Immune Fab (DigiFab)**
6. **Infection Control & Biomedical Waste (BMW):** Yellow bag (anatomical/infectious), Red bag (tubings/catheters), White translucent (sharps), Blue (glassware/ampoules).
7. **Pediatric Milestones & Calculations:** Growth milestones, pediatric dehydration scale, and weight-based fluid maintenance (Holliday-Segar method).
8. **Neurology:** GCS assessment, signs of increased ICP (Cushing's triad: bradycardia, systolic hypertension with widened pulse pressure, irregular respirations).
9. **Fluid & Electrolyte Imbalances:** Hypokalemia vs Hyperkalemia ECG changes (peaked T waves vs U waves), Chvostek's & Trousseau's signs in hypocalcemia.
10. **Surgical Nursing:** Post-op wound dehiscence and evisceration management (cover with moist sterile saline gauze, position low Fowler's with knees bent, notify surgeon immediately).`;
  }
  return null;
}
async function handleAxonAIChat(messages, userPrompt) {
  const cleanPrompt = userPrompt.trim();
  if (isClearlyNonMedical(cleanPrompt)) {
    return {
      text: NON_MEDICAL_REFUSAL,
      source: "clinical_engine"
    };
  }
  const ai = getGenAI();
  if (ai) {
    const contents = messages.map((m) => ({
      role: m.role,
      parts: [{ text: m.text }]
    }));
    contents.push({
      role: "user",
      parts: [{ text: cleanPrompt }]
    });
    for (let i = 0; i < CANDIDATE_MODELS.length; i++) {
      const modelName = CANDIDATE_MODELS[i];
      try {
        const response = await ai.models.generateContent({
          model: modelName,
          contents,
          config: {
            systemInstruction: SYSTEM_INSTRUCTION,
            temperature: 0.6
          }
        });
        const answerText = response.text;
        if (answerText && answerText.trim().length > 0) {
          return {
            text: answerText,
            source: "gemini"
          };
        }
      } catch (err) {
        const errMsg = err?.message || String(err);
        const isTemporaryOverload = errMsg.includes("503") || errMsg.includes("high demand") || errMsg.includes("UNAVAILABLE") || errMsg.includes("429") || errMsg.includes("RESOURCE_EXHAUSTED") || errMsg.includes("quota");
        if (isTemporaryOverload && i < CANDIDATE_MODELS.length - 1) {
          await new Promise((resolve) => setTimeout(resolve, 250));
          continue;
        }
        break;
      }
    }
  }
  const directFallback = getClinicalFallbackAnswer(cleanPrompt);
  if (directFallback) {
    return {
      text: directFallback,
      source: "clinical_engine"
    };
  }
  const structuredClinicalResponse = `## Clinical Nursing Analysis: ${cleanPrompt}

### 1. Clinical Overview & Core Concepts
In medical-surgical and advanced nursing practice, addressing **${cleanPrompt}** requires a structured, patient-centered clinical assessment aligned with standard hospital protocols and national licensing standards (AIIMS NORCET, ESIC).

### 2. Key Nursing Assessments & Diagnostic Priorities
* **Primary Survey (Airway, Breathing, Circulation):** Assess hemodynamic stability, oxygen saturation, and baseline vital signs.
* **Targeted Clinical Evaluation:** Check relevant laboratory values (CBC, electrolytes, renal and hepatic profiles) and clinical manifestations.
* **Patient History:** Identify pre-existing comorbidities, medication history, allergies, and onset timeline.

### 3. Nursing Interventions & Rationale
1. **Safety & Positioning:** Maintain patient in an appropriate therapeutic posture (e.g., Semi-Fowler's to maximize diaphragmatic expansion, or elevated limb for venous return).
2. **Medication Administration & Monitoring:** Administer prescribed pharmacological therapy adhering strictly to the **10 Rights of Medication Administration**. Assess for expected therapeutic responses and adverse reactions.
3. **Patient & Family Education:** Provide clear, jargon-free instructions regarding post-discharge care, warning signs requiring immediate emergency evaluation, and dietary/activity modifications.

---

> \u{1F4A1} **NORCET Clinical Pearl:** Always prioritize interventions using **Maslow's Hierarchy of Needs** and the **ABC Rule (Airway > Breathing > Circulation)**. When faced with multiple clinically sound options, determine which condition poses the immediate threat to patient survival.`;
  return {
    text: structuredClinicalResponse,
    source: "clinical_engine"
  };
}

// server/firebaseAdmin.ts
var import_app = require("firebase-admin/app");
var import_firestore = require("firebase-admin/firestore");
var import_auth = require("firebase-admin/auth");
var import_path = __toESM(require("path"), 1);
var import_fs = __toESM(require("fs"), 1);
var adminApp = null;
var adminDb = null;
var adminAuth = null;
var initializationAttempted = false;
var initializationError = null;
function getProjectId() {
  const envProj = (process.env.FIREBASE_PROJECT_ID || process.env.GCLOUD_PROJECT || "").trim();
  if (envProj && !/^\d+$/.test(envProj)) {
    return envProj;
  }
  try {
    const configPath = import_path.default.join(process.cwd(), "firebase-applet-config.json");
    if (import_fs.default.existsSync(configPath)) {
      const raw = import_fs.default.readFileSync(configPath, "utf8");
      const parsed = JSON.parse(raw);
      if (parsed.projectId && !/^\d+$/.test(String(parsed.projectId))) {
        return parsed.projectId;
      }
    }
  } catch {
  }
  return "axon-nursing-institute";
}
function initFirebaseAdmin() {
  if (initializationAttempted) {
    return { app: adminApp, db: adminDb, auth: adminAuth };
  }
  initializationAttempted = true;
  const projectId = getProjectId();
  try {
    const existingApps = (0, import_app.getApps)();
    if (existingApps.length > 0) {
      adminApp = existingApps[0];
      adminDb = (0, import_firestore.getFirestore)(adminApp);
      adminAuth = (0, import_auth.getAuth)(adminApp);
      console.log("[firebaseAdmin] Re-using existing Firebase Admin instance.");
      return { app: adminApp, db: adminDb, auth: adminAuth };
    }
    let credential = void 0;
    const rawSaEnv = process.env.FIREBASE_SERVICE_ACCOUNT_KEY || process.env.FIREBASE_SERVICE_ACCOUNT;
    if (rawSaEnv) {
      try {
        const parsed = typeof rawSaEnv === "string" ? JSON.parse(rawSaEnv.trim().startsWith("{") ? rawSaEnv : Buffer.from(rawSaEnv, "base64").toString("utf8")) : rawSaEnv;
        credential = (0, import_app.cert)(parsed);
        console.log("[firebaseAdmin] Initialized with FIREBASE_SERVICE_ACCOUNT_KEY JSON credential.");
      } catch (err) {
        console.warn("[firebaseAdmin] Failed to parse FIREBASE_SERVICE_ACCOUNT_KEY JSON:", err?.message);
      }
    }
    if (!credential) {
      try {
        const kParts = [
          "MIIEvgIBADANBgkqhkiG9w0BAQEFAASCBKgwggSkAgEAAoIBAQDKVZ66Fgg8d2Jh",
          "u8tZl65B+T99+6POUg2xn/aFcD3ckcSbDVPfOUa1t/KumH2c76C4WqhGoanC1klT",
          "03IJs5tyQRSZljirMsKtP7/IZLZQZ3fNewv0V0LfO6CHbhm05rdQRrBDB2eYpeQ6",
          "dayiSpSuedlRrcUqCe6Ii/szROwj0+VJO3CT/fs+D31w1guekolHl3/f50wvMaHL",
          "6zYId4TVG0sbr79lYWEcHGlfOri/u+WLZLLG3LLoMeNu0oo4uXhNJapP9uhnVMsq",
          "fEJqNCIbFB0DZy2gBH835+DAmjW4rnJfldmqAyz8vZv+jlGYukIGBOCuxu1OlGTn",
          "pY54c6SpAgMBAAECggEAWsG5/2VHj3vLbORUC91eJCidgrCformqe8yxQtx8WxYl",
          "dpktUFj8LyGSIR+0ZHMWB+teRMRaBdOhs5CKO/DM3pxzlYrM43nS2exY5ZXLM1id",
          "49T4IUMM813nHShVLpA4lLEIeiB1pwJuU4yaAXfrpjFwudL0t+0ZijUj2bTmKREj",
          "2H8YMIGOnXxlNM8YtlV+kNmaujGrbARui/Fc/xdHA7T7bon08Spog8Wqw9js62OF",
          "GH84kjSKJJu+InRIF3/EUUwQbtQqfa/lehzAQT8NMkIyRwJBO3z4HajJmelXLihD",
          "1+PENRET1e4J1w0GctDqPDPqxzXNIzPsPqBpP0TQswKBgQDybOb3gQSMY6ZcX7vI",
          "M+KTgiF/GV9kvASZemoq6CTPS/B3lsvys8f+J0+4SUaVAy0BowXXEn2nhrQYtnGb",
          "40wRpyg09EbBrRwk/6FCiNGse7evsc+ZRqFi0P4QZoXe/8GDG33C7o3jSdAhSupL",
          "ZqQvZuF10SgJKHUXbOybMo7gEwKBgQDVqgaWMK+IDiS+bHKuRnZjjn//7rr08BIG",
          "3XoV/HafRKzAddetcBPbdFfNIsIFDb+Lfoq2tz1g7pnSjmHtfsfulnxPH9RHt3G6",
          "R5dy3iNU95r7/1BQyU6qsraP3RG0IUWAEeWxFn6aPVeK2LbMvhlAO0JOhdD6xguF",
          "jrYlsZvX0wKBgQDX/e1/QaViy/pSPT2a75eFI6Fik6Gpp9dVQ3tKRVFenONgOav2",
          "zvV2XWIq6KaJZ6320mAGssPfuiXGCu+IG+kPpWYuYCKWtvznfhcYp7xguE39rSgx",
          "AXwTBfAHfsDx4d9xR9IyFse2ZXKZ5xx/F7FbRofEqBjKqBBDUdoxoMcpnwKBgBCA",
          "z31uSUCTBxeGPN1lJ+PMr+pOwDYHDP1mwfVMyMTIgydicsQ8sevzcoyvsJi/VRor",
          "Lf+q65y/ETaINNwpPLwa94MNDFJ1wt0GhpYivkvjzB7Gu6dhxSe+Ige+pY1qPHoF",
          "593jxOeY8VgSIRxzWnPxn8982oVkIqOwQDVtIIJtAoGBAJk3d5xKn5+CA5UbUhnf",
          "HM+8/23p2r/GEn7m+NXopFB4uca5/S5CvruZZcQwDSDEfS2N6HSy8mD0n66poJOs",
          "ZhLx24Ytc5EG4hkXcE9Z9x0SjocJOon5TDmqqThKePJ7ri1m9yntvLLdBrglChcD",
          "zLKBZVjkxbxjZCfL6+f31zj6"
        ];
        credential = (0, import_app.cert)({
          projectId: "axon-nursing-institute",
          clientEmail: "firebase-adminsdk-fbsvc@axon-nursing-institute.iam.gserviceaccount.com",
          privateKey: `-----BEGIN PRIVATE KEY-----
${kParts.join("\n")}
-----END PRIVATE KEY-----
`
        });
      } catch (e) {
        console.warn("[firebaseAdmin] Built-in credential fallback notice:", e?.message);
      }
    }
    if (!credential && process.env.GOOGLE_APPLICATION_CREDENTIALS) {
      if (import_fs.default.existsSync(process.env.GOOGLE_APPLICATION_CREDENTIALS)) {
        try {
          credential = (0, import_app.applicationDefault)();
          console.log("[firebaseAdmin] Initialized with GOOGLE_APPLICATION_CREDENTIALS file path.");
        } catch (e) {
          console.warn("[firebaseAdmin] Could not load GOOGLE_APPLICATION_CREDENTIALS:", e?.message);
        }
      }
    }
    if (!credential) {
      try {
        credential = (0, import_app.applicationDefault)();
        console.log("[firebaseAdmin] Initialized with Application Default Credentials.");
      } catch {
        console.log(`[firebaseAdmin] Default credentials unavailable. Falling back to project ID configuration: ${projectId}`);
      }
    }
    adminApp = (0, import_app.initializeApp)({
      credential,
      projectId
    });
    adminDb = (0, import_firestore.getFirestore)(adminApp);
    adminAuth = (0, import_auth.getAuth)(adminApp);
    console.log(`[firebaseAdmin] Firebase Admin SDK successfully initialized for project '${projectId}'.`);
  } catch (err) {
    initializationError = err?.message || String(err);
    console.warn(`[firebaseAdmin] Notice: Firebase Admin initialization: ${initializationError}. Operations will use resilient fallback.`);
  }
  return { app: adminApp, db: adminDb, auth: adminAuth };
}
function getAdminFirestore() {
  if (!adminDb && !initializationAttempted) {
    initFirebaseAdmin();
  }
  return adminDb;
}
function getAdminAuth() {
  if (!adminAuth && !initializationAttempted) {
    initFirebaseAdmin();
  }
  return adminAuth;
}
async function verifyFirebaseToken(token) {
  if (!token || typeof token !== "string" || token.trim().length === 0) {
    return null;
  }
  const auth = getAdminAuth();
  if (auth) {
    try {
      const decoded = await auth.verifyIdToken(token.trim(), true);
      if (decoded && decoded.uid) {
        return {
          uid: decoded.uid,
          email: decoded.email || "",
          name: decoded.name || ""
        };
      }
    } catch (err) {
      console.warn("[firebaseAdmin] Cryptographic token verification failed:", err?.message);
      return null;
    }
  } else {
    console.error("[firebaseAdmin] Token verification failed: Firebase Admin Auth is not initialized.");
  }
  return null;
}
async function writeVerifiedPaymentRecord(paymentData) {
  const db = getAdminFirestore();
  if (!db) {
    console.error("[firebaseAdmin] Payment verification failed: Firestore Admin unavailable.");
    throw new Error("Payment verification failed: Database unavailable. Contact support.");
  }
  const paymentId = paymentData.id || `pay_${paymentData.paymentId || paymentData.orderId || Date.now()}`;
  const fullPayment = {
    ...paymentData,
    status: "paid",
    verifiedAt: paymentData.verifiedAt || (/* @__PURE__ */ new Date()).toISOString(),
    updatedAt: (/* @__PURE__ */ new Date()).toISOString()
  };
  try {
    await db.collection("payments").doc(paymentId).set({
      ...fullPayment,
      updatedAt: import_firestore.FieldValue.serverTimestamp()
    }, { merge: true });
    console.log(`[firebaseAdmin] Successfully wrote verified payment record ${paymentId} to Firestore.`);
    return true;
  } catch (err) {
    console.error("[firebaseAdmin] Error writing payment record to Firestore:", err?.message);
    throw new Error(`Payment verification failed: Failed to record payment in database (${err?.message || "Database error"}). Contact support.`);
  }
}
async function writePaidEnrollmentRecord(enrollmentData) {
  const db = getAdminFirestore();
  if (!db) {
    console.error("[firebaseAdmin] Enrollment activation failed: Firestore Admin unavailable.");
    throw new Error("Enrollment activation failed: Database unavailable. Contact support.");
  }
  const enrollmentId = enrollmentData.id || `enr_${enrollmentData.userId}_${enrollmentData.batchId}`;
  const fullEnrollment = {
    ...enrollmentData,
    status: "active",
    isFree: false,
    updatedAt: (/* @__PURE__ */ new Date()).toISOString()
  };
  try {
    await db.collection("enrollments").doc(enrollmentId).set({
      ...fullEnrollment,
      updatedAt: import_firestore.FieldValue.serverTimestamp()
    }, { merge: true });
    console.log(`[firebaseAdmin] Successfully wrote paid enrollment ${enrollmentId} to Firestore.`);
    return true;
  } catch (err) {
    console.error("[firebaseAdmin] Error writing enrollment to Firestore:", err?.message);
    throw new Error(`Enrollment activation failed: Failed to record enrollment in database (${err?.message || "Database error"}). Contact support.`);
  }
}
async function validateFirestoreCouponAdmin(couponCode, courseId, coursePrice) {
  if (!couponCode || !couponCode.trim()) {
    return { isValid: false, discountAmount: 0, finalPrice: coursePrice };
  }
  const cleanCode = couponCode.trim().toUpperCase().replace(/[^A-Z0-9_-]/g, "");
  const db = getAdminFirestore();
  if (!db) {
    return {
      isValid: false,
      discountAmount: 0,
      finalPrice: coursePrice,
      error: "Database service unavailable for coupon verification."
    };
  }
  try {
    let couponDoc = null;
    const directDoc = await db.collection("coupons").doc(cleanCode).get();
    if (directDoc.exists) {
      couponDoc = directDoc;
    } else {
      const snap = await db.collection("coupons").where("code", "==", cleanCode).limit(1).get();
      if (!snap.empty) {
        couponDoc = snap.docs[0];
      }
    }
    if (!couponDoc || !couponDoc.exists) {
      return {
        isValid: false,
        discountAmount: 0,
        finalPrice: coursePrice,
        error: `Coupon code "${cleanCode}" is invalid.`
      };
    }
    const data = couponDoc.data();
    if (!data.isActive) {
      return { isValid: false, discountAmount: 0, finalPrice: coursePrice, error: "This coupon is no longer active." };
    }
    const now = /* @__PURE__ */ new Date();
    if (data.validFrom && now < new Date(data.validFrom)) {
      return { isValid: false, discountAmount: 0, finalPrice: coursePrice, error: "This coupon is not yet active." };
    }
    if (data.validUntil && now > new Date(data.validUntil)) {
      return { isValid: false, discountAmount: 0, finalPrice: coursePrice, error: "This coupon has expired." };
    }
    const usageLimit = Number(data.usageLimit ?? data.maxUsage ?? 0);
    const usedCount = Number(data.usedCount ?? 0);
    if (usageLimit > 0 && usedCount >= usageLimit) {
      return { isValid: false, discountAmount: 0, finalPrice: coursePrice, error: "This coupon has reached its maximum usage limit." };
    }
    const applicableCourses = Array.isArray(data.applicableCourseIds) ? data.applicableCourseIds : ["all"];
    if (!applicableCourses.includes("all") && !applicableCourses.includes(courseId)) {
      return { isValid: false, discountAmount: 0, finalPrice: coursePrice, error: "This coupon is not valid for this course." };
    }
    const discountVal = Number(data.discountValue) || 0;
    let discountAmount = 0;
    if (data.discountType === "percentage") {
      discountAmount = Math.round(coursePrice * Math.min(100, Math.max(0, discountVal)) / 100);
    } else {
      discountAmount = Math.min(coursePrice, Math.max(0, discountVal));
    }
    const finalPrice = Math.max(0, coursePrice - discountAmount);
    return {
      isValid: true,
      couponId: couponDoc.id,
      code: data.code || cleanCode,
      discountAmount,
      finalPrice
    };
  } catch (err) {
    console.error("[firebaseAdmin] Error validating coupon in Firestore:", err);
    return { isValid: false, discountAmount: 0, finalPrice: coursePrice, error: "Failed to validate coupon." };
  }
}
async function incrementCouponUsageAdmin(couponId) {
  const db = getAdminFirestore();
  if (!db || !couponId) return false;
  try {
    await db.collection("coupons").doc(couponId).update({
      usedCount: import_firestore.FieldValue.increment(1),
      updatedAt: import_firestore.FieldValue.serverTimestamp()
    });
    return true;
  } catch (err) {
    console.warn(`[firebaseAdmin] Could not increment coupon ${couponId} usage:`, err?.message);
    return false;
  }
}

// src/services/fallback/fallbackLmsData.ts
var FALLBACK_BATCHES = [];
var FALLBACK_SUBJECTS = [];
var FALLBACK_CHAPTERS = [];
var FALLBACK_CLASSES = [];
var FALLBACK_PDF_NOTES = [];
var FALLBACK_WEEKLY_WARRIOR_TESTS = [];
var FALLBACK_WEEKLY_WARRIOR_QUESTIONS = [];
var FALLBACK_UNIT_TESTS = [];
var FALLBACK_UNIT_TEST_QUESTIONS = [];

// server.ts
import_dotenv.default.config({ override: true });
initFirebaseAdmin();
var BUILT_IN_ADMIN_EMAILS = [
  "pmgautamjaipur@gmail.com",
  "axonnursingaccadmy@gmail.com"
];
var CONFIG_ADMIN_EMAILS = Array.from(
  /* @__PURE__ */ new Set([
    ...BUILT_IN_ADMIN_EMAILS.map((e) => e.toLowerCase()),
    ...(process.env.ADMIN_EMAILS || process.env.ADMIN_EMAIL || "").split(",").map((e) => e.trim().toLowerCase()).filter(Boolean)
  ])
);
function isSuperAdminEmail(email) {
  if (!email) return false;
  const clean = email.trim().toLowerCase();
  return clean === "pmgautamjaipur@gmail.com" || clean === "axonnursingaccadmy@gmail.com" || CONFIG_ADMIN_EMAILS.includes(clean);
}
var ACTIVE_RAZORPAY_KEY_ID = "rzp_live_Tdojh1s9rBMIgh";
var ACTIVE_RAZORPAY_KEY_SECRET = "YGTfQ0RXzmZgsnsF58I1m0BI";
function getRazorpayCredentials() {
  let keyId = (process.env.RAZORPAY_KEY_ID || process.env.VITE_RAZORPAY_KEY_ID || "").trim();
  let keySecret = (process.env.RAZORPAY_KEY_SECRET || "").trim();
  if (!keyId || keyId === "rzp_live_TW3QgNQBZ71vE3") {
    keyId = ACTIVE_RAZORPAY_KEY_ID;
  }
  if (!keySecret || keyId === ACTIVE_RAZORPAY_KEY_ID) {
    keySecret = ACTIVE_RAZORPAY_KEY_SECRET;
  }
  return { keyId, keySecret };
}
var razorpayClient = null;
var activeKeyId = null;
var activeKeySecret = null;
function getRazorpay() {
  const { keyId, keySecret } = getRazorpayCredentials();
  if (!keyId || !keySecret) {
    return null;
  }
  if (!razorpayClient || activeKeyId !== keyId || activeKeySecret !== keySecret) {
    razorpayClient = new import_razorpay.default({
      key_id: keyId,
      key_secret: keySecret
    });
    activeKeyId = keyId;
    activeKeySecret = keySecret;
  }
  return razorpayClient;
}
async function getVerifiedUser(req) {
  const authHeader = req.headers.authorization;
  if (authHeader && authHeader.startsWith("Bearer ")) {
    const token = authHeader.split("Bearer ")[1]?.trim();
    if (token) {
      const verified = await verifyFirebaseToken(token);
      if (verified) return verified;
    }
  }
  return null;
}
async function getCourseById(courseId) {
  if (!courseId) return null;
  const db = getAdminFirestore();
  if (db) {
    try {
      const docSnap = await db.collection("batches").doc(courseId).get();
      if (docSnap.exists) {
        return { id: docSnap.id, ...docSnap.data() };
      }
      const querySnap = await db.collection("batches").where("slug", "==", courseId).limit(1).get();
      if (!querySnap.empty) {
        const d = querySnap.docs[0];
        return { id: d.id, ...d.data() };
      }
    } catch (err) {
      console.warn(`[server.ts] Error fetching course ${courseId} from Firestore:`, err);
    }
  }
  const fallback = FALLBACK_BATCHES.find((b) => b.id === courseId || b.slug === courseId);
  if (fallback) {
    return { ...fallback };
  }
  return null;
}
function buildApp() {
  const app2 = (0, import_express.default)();
  const PROD_ALLOWED_ORIGINS = [
    "https://axonacadmy.vercel.app",
    "https://axonacademy.vercel.app",
    "https://axonnursing.vercel.app",
    "https://ais-dev-xrbfva6tlovgjed3dvempp-375810688787.asia-southeast1.run.app",
    "https://ais-pre-xrbfva6tlovgjed3dvempp-375810688787.asia-southeast1.run.app",
    ...process.env.APP_URL ? [process.env.APP_URL.replace(/\/$/, "")] : [],
    ...process.env.ALLOWED_ORIGINS ? process.env.ALLOWED_ORIGINS.split(",").map((s) => s.trim().replace(/\/$/, "")) : []
  ];
  const LOCAL_DEV_ORIGINS = [
    "http://localhost:3000",
    "http://localhost:5173",
    "http://127.0.0.1:3000",
    "http://127.0.0.1:5173"
  ];
  const corsOptions = {
    origin: (origin, callback) => {
      if (!origin) {
        return callback(null, true);
      }
      const cleanOrigin = origin.replace(/\/$/, "");
      const isAllowed = PROD_ALLOWED_ORIGINS.includes(cleanOrigin) || LOCAL_DEV_ORIGINS.includes(cleanOrigin) || cleanOrigin.endsWith(".vercel.app") || cleanOrigin.endsWith(".run.app");
      if (isAllowed) {
        callback(null, true);
      } else {
        callback(null, false);
      }
    },
    methods: ["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"],
    allowedHeaders: ["Content-Type", "Authorization", "X-Requested-With", "Accept", "Origin", "x-razorpay-signature"],
    credentials: false,
    optionsSuccessStatus: 204
  };
  app2.use((0, import_cors.default)(corsOptions));
  app2.use(import_express.default.json({ limit: "50mb" }));
  app2.use(import_express.default.urlencoded({ extended: true, limit: "50mb" }));
  app2.get(["/health", "/api/health"], (_req, res) => {
    res.json({
      status: "ok",
      service: "Axon Nursing Academy API",
      timestamp: (/* @__PURE__ */ new Date()).toISOString()
    });
  });
  const CATALOG_FILE = "/tmp/axon_cloud_catalog_v4.json";
  try {
    if (import_fs2.default.existsSync("/tmp/axon_cloud_catalog_v2.json")) {
      import_fs2.default.unlinkSync("/tmp/axon_cloud_catalog_v2.json");
    }
  } catch {
  }
  let cloudCatalog = {
    batches: [...FALLBACK_BATCHES],
    subjects: [...FALLBACK_SUBJECTS],
    chapters: [...FALLBACK_CHAPTERS],
    classes: [...FALLBACK_CLASSES],
    pdfNotes: [...FALLBACK_PDF_NOTES],
    weeklyWarriorTests: [...FALLBACK_WEEKLY_WARRIOR_TESTS],
    weeklyWarriorQuestions: [...FALLBACK_WEEKLY_WARRIOR_QUESTIONS],
    unitTests: [...FALLBACK_UNIT_TESTS],
    unitTestQuestions: [...FALLBACK_UNIT_TEST_QUESTIONS],
    deletedIds: [],
    updatedAt: (/* @__PURE__ */ new Date()).toISOString()
  };
  try {
    if (import_fs2.default.existsSync(CATALOG_FILE)) {
      const saved = JSON.parse(import_fs2.default.readFileSync(CATALOG_FILE, "utf8"));
      if (saved && Array.isArray(saved.batches)) {
        cloudCatalog = { ...cloudCatalog, ...saved };
      }
    }
  } catch {
  }
  function persistCloudCatalog() {
    try {
      cloudCatalog.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
      import_fs2.default.writeFileSync(CATALOG_FILE, JSON.stringify(cloudCatalog), "utf8");
    } catch {
    }
  }
  app2.get("/api/catalog/state", async (_req, res) => {
    const db = getAdminFirestore();
    if (db) {
      try {
        const [bSnap, sSnap, cSnap, clSnap, pSnap, wwSnap, wwqSnap, utSnap, utqSnap] = await Promise.all([
          db.collection("batches").get().catch(() => null),
          db.collection("subjects").get().catch(() => null),
          db.collection("chapters").get().catch(() => null),
          db.collection("classes").get().catch(() => null),
          db.collection("pdfNotes").get().catch(() => null),
          db.collection("weeklyWarriorTests").get().catch(() => null),
          db.collection("weeklyWarriorQuestions").get().catch(() => null),
          db.collection("unitTests").get().catch(() => null),
          db.collection("unitTestQuestions").get().catch(() => null)
        ]);
        if (bSnap) cloudCatalog.batches = bSnap.docs.map((d) => ({ id: d.id, ...d.data() }));
        if (sSnap) cloudCatalog.subjects = sSnap.docs.map((d) => ({ id: d.id, ...d.data() }));
        if (cSnap) cloudCatalog.chapters = cSnap.docs.map((d) => ({ id: d.id, ...d.data() }));
        if (clSnap) cloudCatalog.classes = clSnap.docs.map((d) => ({ id: d.id, ...d.data() }));
        if (pSnap) cloudCatalog.pdfNotes = pSnap.docs.map((d) => ({ id: d.id, ...d.data() }));
        if (wwSnap) cloudCatalog.weeklyWarriorTests = wwSnap.docs.map((d) => ({ id: d.id, ...d.data() }));
        if (wwqSnap) cloudCatalog.weeklyWarriorQuestions = wwqSnap.docs.map((d) => ({ id: d.id, ...d.data() }));
        if (utSnap) cloudCatalog.unitTests = utSnap.docs.map((d) => ({ id: d.id, ...d.data() }));
        if (utqSnap) cloudCatalog.unitTestQuestions = utqSnap.docs.map((d) => ({ id: d.id, ...d.data() }));
        persistCloudCatalog();
      } catch {
      }
    }
    return res.json(cloudCatalog);
  });
  app2.post("/api/catalog/state", async (req, res) => {
    try {
      const body = req.body || {};
      const deletedSet = /* @__PURE__ */ new Set([
        ...cloudCatalog.deletedIds || [],
        ...Array.isArray(body.deletedIds) ? body.deletedIds : []
      ]);
      const mergeCollection = (existingList, incomingList) => {
        const map = /* @__PURE__ */ new Map();
        (existingList || []).forEach((item) => {
          if (item && item.id && !deletedSet.has(item.id)) {
            map.set(item.id, item);
          }
        });
        if (Array.isArray(incomingList)) {
          incomingList.forEach((item) => {
            if (item && item.id) {
              deletedSet.delete(item.id);
              map.set(item.id, { ...map.get(item.id) || {}, ...item });
            }
          });
        }
        return Array.from(map.values()).filter((item) => !deletedSet.has(item.id));
      };
      if (body.replaceAll === true) {
        cloudCatalog = {
          batches: Array.isArray(body.batches) ? body.batches : [],
          subjects: Array.isArray(body.subjects) ? body.subjects : [],
          chapters: Array.isArray(body.chapters) ? body.chapters : [],
          classes: Array.isArray(body.classes) ? body.classes : [],
          pdfNotes: Array.isArray(body.pdfNotes) ? body.pdfNotes : [],
          weeklyWarriorTests: Array.isArray(body.weeklyWarriorTests) ? body.weeklyWarriorTests : [],
          weeklyWarriorQuestions: Array.isArray(body.weeklyWarriorQuestions) ? body.weeklyWarriorQuestions : [],
          unitTests: Array.isArray(body.unitTests) ? body.unitTests : [],
          unitTestQuestions: Array.isArray(body.unitTestQuestions) ? body.unitTestQuestions : [],
          deletedIds: Array.from(deletedSet),
          updatedAt: (/* @__PURE__ */ new Date()).toISOString()
        };
      } else {
        cloudCatalog.batches = mergeCollection(cloudCatalog.batches, body.batches);
        cloudCatalog.subjects = mergeCollection(cloudCatalog.subjects, body.subjects);
        cloudCatalog.chapters = mergeCollection(cloudCatalog.chapters, body.chapters);
        cloudCatalog.classes = mergeCollection(cloudCatalog.classes, body.classes);
        cloudCatalog.pdfNotes = mergeCollection(cloudCatalog.pdfNotes, body.pdfNotes);
        cloudCatalog.weeklyWarriorTests = mergeCollection(cloudCatalog.weeklyWarriorTests, body.weeklyWarriorTests);
        cloudCatalog.weeklyWarriorQuestions = mergeCollection(cloudCatalog.weeklyWarriorQuestions, body.weeklyWarriorQuestions);
        cloudCatalog.unitTests = mergeCollection(cloudCatalog.unitTests, body.unitTests);
        cloudCatalog.unitTestQuestions = mergeCollection(cloudCatalog.unitTestQuestions, body.unitTestQuestions);
        cloudCatalog.deletedIds = Array.from(deletedSet);
      }
      persistCloudCatalog();
      const db = getAdminFirestore();
      if (db) {
        const writeColl = async (colName, items) => {
          if (!Array.isArray(items) || items.length === 0) return;
          const batch = db.batch();
          let count = 0;
          for (const item of items) {
            if (item && item.id && !deletedSet.has(item.id)) {
              batch.set(db.collection(colName).doc(String(item.id)), item, { merge: true });
              count++;
            }
          }
          if (count > 0) await batch.commit().catch(() => {
          });
        };
        await Promise.all([
          writeColl("batches", cloudCatalog.batches),
          writeColl("subjects", cloudCatalog.subjects),
          writeColl("chapters", cloudCatalog.chapters),
          writeColl("classes", cloudCatalog.classes),
          writeColl("pdfNotes", cloudCatalog.pdfNotes),
          writeColl("weeklyWarriorTests", cloudCatalog.weeklyWarriorTests),
          writeColl("weeklyWarriorQuestions", cloudCatalog.weeklyWarriorQuestions),
          writeColl("unitTests", cloudCatalog.unitTests),
          writeColl("unitTestQuestions", cloudCatalog.unitTestQuestions)
        ]).catch(() => {
        });
      }
      return res.json({ success: true, state: cloudCatalog });
    } catch (err) {
      return res.status(500).json({ error: err?.message || "State sync failed." });
    }
  });
  app2.get("/api/catalog/batches", async (_req, res) => {
    try {
      const db = getAdminFirestore();
      if (db) {
        try {
          const snap = await db.collection("batches").get();
          const fsBatches = snap.docs.map((d) => ({ id: d.id, ...d.data() }));
          cloudCatalog.batches = fsBatches;
          persistCloudCatalog();
          return res.json({ batches: fsBatches });
        } catch (err) {
          console.warn("[server.ts] Firestore batches read notice:", err);
        }
      }
      const deletedSet = new Set(cloudCatalog.deletedIds || []);
      return res.json({
        batches: (cloudCatalog.batches || []).filter((b) => b && b.id && !deletedSet.has(b.id))
      });
    } catch (err) {
      return res.json({ batches: [] });
    }
  });
  app2.post("/api/catalog/batches/sync", async (req, res) => {
    try {
      const { action, batch } = req.body || {};
      if (!batch || !batch.id) {
        return res.status(400).json({ error: "Batch ID is required." });
      }
      const db = getAdminFirestore();
      if (action === "delete") {
        cloudCatalog.batches = (cloudCatalog.batches || []).filter((b) => b.id !== batch.id);
        if (!cloudCatalog.deletedIds.includes(batch.id)) {
          cloudCatalog.deletedIds.push(batch.id);
        }
        persistCloudCatalog();
        if (db) {
          await db.collection("batches").doc(batch.id).delete().catch(() => {
          });
        }
        return res.json({ success: true });
      }
      cloudCatalog.deletedIds = (cloudCatalog.deletedIds || []).filter((id) => id !== batch.id);
      const idx = (cloudCatalog.batches || []).findIndex((b) => b.id === batch.id);
      const updated = {
        ...idx >= 0 ? cloudCatalog.batches[idx] : {},
        ...batch,
        updatedAt: (/* @__PURE__ */ new Date()).toISOString()
      };
      if (idx >= 0) {
        cloudCatalog.batches[idx] = updated;
      } else {
        cloudCatalog.batches.push(updated);
      }
      persistCloudCatalog();
      if (db) {
        await db.collection("batches").doc(batch.id).set(updated, { merge: true }).catch(() => {
        });
      }
      return res.json({ success: true, batch: updated });
    } catch (err) {
      return res.status(500).json({ error: err?.message || "Catalog sync failed." });
    }
  });
  const memoryFileMeta = /* @__PURE__ */ new Map();
  const memoryFileChunks = /* @__PURE__ */ new Map();
  app2.post("/api/storage/chunk", async (req, res) => {
    try {
      const {
        fileId,
        chunkIndex,
        totalChunks,
        data,
        fileName,
        contentType,
        fileSizeBytes,
        batchId,
        chapterId
      } = req.body || {};
      if (!fileId || typeof chunkIndex !== "number" || typeof data !== "string") {
        return res.status(400).json({ error: "Invalid chunk payload." });
      }
      const chunkDocId = `${fileId}_chunk_${chunkIndex}`;
      memoryFileChunks.set(chunkDocId, data);
      if (chunkIndex === 0 || fileName) {
        const meta = {
          fileId,
          fileName: fileName || `${fileId}.pdf`,
          contentType: contentType || "application/pdf",
          fileSizeBytes: Number(fileSizeBytes) || 0,
          totalChunks: Number(totalChunks) || 1,
          batchId: batchId || "",
          chapterId: chapterId || "",
          updatedAt: (/* @__PURE__ */ new Date()).toISOString()
        };
        memoryFileMeta.set(fileId, meta);
      }
      const db = getAdminFirestore();
      if (db) {
        await db.collection("stored_file_chunks").doc(chunkDocId).set({
          fileId,
          chunkIndex,
          data,
          updatedAt: (/* @__PURE__ */ new Date()).toISOString()
        }).catch((e) => console.warn("[server.ts] Chunk Firestore write warning:", e?.message));
        if (chunkIndex === 0 || chunkIndex === (Number(totalChunks) || 1) - 1) {
          const meta = memoryFileMeta.get(fileId) || {
            fileId,
            fileName: fileName || `${fileId}.pdf`,
            contentType: contentType || "application/pdf",
            fileSizeBytes: Number(fileSizeBytes) || 0,
            totalChunks: Number(totalChunks) || 1,
            batchId: batchId || "",
            chapterId: chapterId || "",
            updatedAt: (/* @__PURE__ */ new Date()).toISOString()
          };
          await db.collection("stored_files").doc(fileId).set(meta, { merge: true }).catch((e) => console.warn("[server.ts] File meta Firestore write warning:", e?.message));
        }
      }
      return res.json({
        success: true,
        fileId,
        chunkIndex,
        downloadUrl: `/api/storage/pdf/${fileId}`
      });
    } catch (err) {
      return res.status(500).json({ error: err?.message || "Failed to store file chunk." });
    }
  });
  app2.get(["/api/storage/pdf/:fileId", "/api/storage/file/:fileId"], async (req, res) => {
    try {
      const { fileId } = req.params;
      if (!fileId) {
        return res.status(400).send("File ID is required.");
      }
      const db = getAdminFirestore();
      let meta = memoryFileMeta.get(fileId) || null;
      if (!meta && db) {
        const metaDoc = await db.collection("stored_files").doc(fileId).get().catch(() => null);
        if (metaDoc && metaDoc.exists) {
          meta = metaDoc.data();
          memoryFileMeta.set(fileId, meta);
        }
      }
      const totalChunks = Number(meta?.totalChunks) || 1;
      const chunkStrings = [];
      for (let i = 0; i < totalChunks; i++) {
        const chunkDocId = `${fileId}_chunk_${i}`;
        let chunkData = memoryFileChunks.get(chunkDocId);
        if (!chunkData && db) {
          const cDoc = await db.collection("stored_file_chunks").doc(chunkDocId).get().catch(() => null);
          if (cDoc && cDoc.exists) {
            chunkData = cDoc.data()?.data || "";
            if (chunkData) {
              memoryFileChunks.set(chunkDocId, chunkData);
            }
          }
        }
        if (typeof chunkData !== "string") {
          return res.status(404).send("Requested document chunk not found.");
        }
        chunkStrings.push(chunkData);
      }
      const fullBase64 = chunkStrings.join("");
      if (!fullBase64) {
        return res.status(404).send("Document is empty or not found.");
      }
      const cleanBase64 = fullBase64.includes(",") ? fullBase64.split(",")[1] : fullBase64;
      const fileBuffer = Buffer.from(cleanBase64, "base64");
      const contentType = meta?.contentType || "application/pdf";
      const safeFileName = String(meta?.fileName || `${fileId}.pdf`).replace(/[^a-zA-Z0-9._-]/g, "_");
      const disposition = req.query.download === "1" ? "attachment" : "inline";
      res.setHeader("Content-Type", contentType);
      res.setHeader("Content-Length", fileBuffer.length);
      res.setHeader("Content-Disposition", `${disposition}; filename="${safeFileName}"`);
      res.setHeader("Cache-Control", "public, max-age=31536000, immutable");
      return res.send(fileBuffer);
    } catch (err) {
      console.error("[server.ts] Error serving stored file:", err);
      return res.status(500).send("Failed to stream document.");
    }
  });
  app2.delete("/api/storage/file/:fileId", async (req, res) => {
    try {
      const { fileId } = req.params;
      const meta = memoryFileMeta.get(fileId);
      memoryFileMeta.delete(fileId);
      const db = getAdminFirestore();
      let totalChunks = Number(meta?.totalChunks) || 20;
      if (db) {
        const snap = await db.collection("stored_files").doc(fileId).get().catch(() => null);
        if (snap && snap.exists) {
          totalChunks = Number(snap.data()?.totalChunks) || totalChunks;
        }
        await db.collection("stored_files").doc(fileId).delete().catch(() => {
        });
        for (let i = 0; i < totalChunks; i++) {
          const cid = `${fileId}_chunk_${i}`;
          memoryFileChunks.delete(cid);
          await db.collection("stored_file_chunks").doc(cid).delete().catch(() => {
          });
        }
      }
      return res.json({ success: true });
    } catch (err) {
      return res.status(500).json({ error: err?.message || "Delete failed" });
    }
  });
  app2.post(["/api/axon-ai/chat", "/api/chat"], async (req, res) => {
    try {
      const { prompt, messages = [] } = req.body;
      if (!prompt || typeof prompt !== "string" || prompt.trim().length === 0) {
        return res.status(400).json({
          error: "A non-empty prompt is required."
        });
      }
      const verified = await getVerifiedUser(req);
      const studentName = verified?.name || "Aspirant";
      const historyList = Array.isArray(messages) ? messages.filter((m) => m && (m.role === "user" || m.role === "model") && typeof m.text === "string").map((m) => ({
        role: m.role,
        text: m.text
      })) : [];
      const result = await handleAxonAIChat(historyList, prompt);
      return res.json({
        success: true,
        text: result.text,
        source: result.source,
        timestamp: (/* @__PURE__ */ new Date()).toISOString()
      });
    } catch (err) {
      console.error("[server.ts] Error in /api/axon-ai/chat:", err);
      return res.status(500).json({
        success: false,
        error: "Failed to process AI mentor request.",
        fallback: NON_MEDICAL_REFUSAL
      });
    }
  });
  app2.get("/api/payments/config", (_req, res) => {
    const { keyId, keySecret } = getRazorpayCredentials();
    const isConfigured = Boolean(keyId && keySecret);
    const isLiveMode = Boolean(keyId && keyId.startsWith("rzp_live_"));
    res.json({
      configured: isConfigured,
      keyId: isConfigured ? keyId : null,
      isLiveMode
    });
  });
  app2.get("/api/payments/test-connection", async (_req, res) => {
    const { keyId, keySecret } = getRazorpayCredentials();
    if (!keyId || !keySecret) {
      return res.json({
        success: false,
        error: "Razorpay Key ID or Key Secret is missing from server environment (.env).",
        code: "KEYS_MISSING"
      });
    }
    try {
      const auth = Buffer.from(`${keyId}:${keySecret}`).toString("base64");
      const response = await fetch("https://api.razorpay.com/v1/orders", {
        method: "POST",
        headers: {
          Authorization: `Basic ${auth}`,
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          amount: 100,
          // 1 INR probe in paise
          currency: "INR",
          receipt: `probe_${Date.now().toString().slice(-6)}`,
          notes: { diagnostic: "test_connection" }
        })
      });
      const data = await response.json();
      if (response.ok && data.id) {
        return res.json({
          success: true,
          message: "Razorpay API credentials verified successfully! Live orders can be created.",
          keyId,
          isLiveMode: keyId.startsWith("rzp_live_")
        });
      }
      const statusCode = response.status;
      const desc = data?.error?.description || "Authentication or API error";
      const code = data?.error?.code || "ERROR";
      let explanation = desc;
      if (statusCode === 401 || desc.toLowerCase().includes("authentication failed")) {
        explanation = "Authentication failed (401): The Key Secret does not match Key ID or has been regenerated/expired in your Razorpay Dashboard. Please generate a new Key Secret from Razorpay Dashboard (Settings > API Keys) and update your .env file.";
      }
      return res.json({
        success: false,
        statusCode,
        code,
        error: explanation,
        rawDescription: desc,
        keyId,
        isLiveMode: keyId.startsWith("rzp_live_")
      });
    } catch (err) {
      return res.json({
        success: false,
        error: err?.message || "Network connection to Razorpay API failed."
      });
    }
  });
  app2.post("/api/payments/create-order", async (req, res) => {
    try {
      const user = await getVerifiedUser(req);
      if (!user) {
        return res.status(401).json({
          error: "Unauthorized: Valid student authentication token required."
        });
      }
      const razorpay = getRazorpay();
      if (!razorpay) {
        return res.status(503).json({
          error: "Payment service is not configured."
        });
      }
      const { courseId, couponCode, studentDetails } = req.body;
      if (!courseId) {
        return res.status(400).json({ error: "Course identifier (courseId) is required." });
      }
      const course = await getCourseById(courseId);
      if (!course) {
        return res.status(404).json({ error: "Course not found." });
      }
      if (course.isFree) {
        return res.status(400).json({
          error: "This course is free. Please use the free enrollment option."
        });
      }
      let finalPrice = Math.max(0, course.price);
      let appliedCouponId = null;
      let appliedCouponCode = null;
      let discountAmount = 0;
      if (couponCode && typeof couponCode === "string" && couponCode.trim()) {
        const couponVal = await validateFirestoreCouponAdmin(couponCode, course.id, course.price);
        if (!couponVal.isValid) {
          return res.status(400).json({
            error: couponVal.error || "Invalid or expired coupon code."
          });
        }
        discountAmount = couponVal.discountAmount;
        finalPrice = couponVal.finalPrice;
        appliedCouponId = couponVal.couponId || null;
        appliedCouponCode = couponVal.code || couponCode.trim().toUpperCase();
      }
      if (finalPrice <= 0) {
        return res.status(400).json({
          error: "Course price with 100% discount requires zero-rupee direct registration."
        });
      }
      const amountInPaise = Math.round(finalPrice * 100);
      const receiptId = `rcpt_${Date.now().toString().slice(-8)}_${user.uid.slice(0, 4)}`;
      const order = await razorpay.orders.create({
        amount: amountInPaise,
        currency: "INR",
        receipt: receiptId,
        notes: {
          courseId: course.id,
          courseTitle: course.title,
          studentUid: user.uid,
          studentEmail: user.email || studentDetails?.email || "",
          couponCode: appliedCouponCode || ""
        }
      });
      const db = getAdminFirestore();
      const paymentRecord = {
        id: `pay_ord_${order.id}`,
        userId: user.uid,
        studentEmail: user.email || studentDetails?.email || "",
        studentName: user.name || studentDetails?.name || "",
        courseId: course.id,
        courseTitle: course.title,
        orderId: order.id,
        paymentId: null,
        amount: finalPrice,
        amountInPaise,
        originalAmount: course.price,
        discountAmount,
        couponId: appliedCouponId,
        couponCode: appliedCouponCode,
        currency: "INR",
        status: "created",
        createdAt: (/* @__PURE__ */ new Date()).toISOString(),
        updatedAt: (/* @__PURE__ */ new Date()).toISOString()
      };
      if (db) {
        try {
          await db.collection("payments").doc(`pay_ord_${order.id}`).set(paymentRecord);
        } catch (dbErr) {
          console.warn("[server.ts] Note: Storing pending payment in memory cache:", dbErr);
        }
      }
      await writeVerifiedPaymentRecord(paymentRecord);
      const { keyId } = getRazorpayCredentials();
      const isLiveMode = Boolean(keyId && keyId.startsWith("rzp_live_"));
      return res.json({
        success: true,
        orderId: order.id,
        amount: amountInPaise,
        currency: "INR",
        keyId,
        isLiveMode,
        courseTitle: course.title,
        courseDescription: course.shortDescription || course.description || "",
        studentName: user.name || studentDetails?.name || "",
        studentEmail: user.email || studentDetails?.email || "",
        paymentRecord
      });
    } catch (err) {
      console.error("[server.ts] Error creating Razorpay order:", err);
      const statusCode = err?.statusCode || 500;
      const desc = err?.error?.description || err?.message || "Failed to create payment order.";
      const isAuthFailed = statusCode === 401 || typeof desc === "string" && desc.toLowerCase().includes("authentication failed");
      const userMessage = isAuthFailed ? "Razorpay Authentication Failed (401): The configured Razorpay Key ID and Key Secret do not match or have expired/been regenerated in your Razorpay Dashboard. Please verify the API Key and Secret in your Razorpay Dashboard." : desc;
      return res.status(statusCode).json({
        error: userMessage,
        details: err?.error || null,
        statusCode
      });
    }
  });
  app2.post(["/api/payments/verify", "/api/payments/verify-payment"], async (req, res) => {
    try {
      const user = await getVerifiedUser(req);
      if (!user) {
        return res.status(401).json({
          error: "Unauthorized: Valid student authentication token required."
        });
      }
      const { keySecret } = getRazorpayCredentials();
      if (!keySecret) {
        return res.status(503).json({
          error: "Payment service is not configured."
        });
      }
      const { razorpay_order_id, razorpay_payment_id, razorpay_signature, courseId } = req.body;
      if (!razorpay_order_id || !razorpay_payment_id || !razorpay_signature || !courseId) {
        return res.status(400).json({
          error: "Missing required payment verification parameters."
        });
      }
      const text = `${razorpay_order_id}|${razorpay_payment_id}`;
      const expectedSignature = import_crypto.default.createHmac("sha256", keySecret).update(text).digest("hex");
      if (expectedSignature !== razorpay_signature) {
        console.warn(`[server.ts] Signature verification failed for order ${razorpay_order_id}`);
        return res.status(400).json({
          error: "Invalid payment signature. Verification failed."
        });
      }
      const razorpay = getRazorpay();
      if (!razorpay) {
        return res.status(503).json({ error: "Razorpay service is unavailable." });
      }
      let rzpPayment = null;
      try {
        rzpPayment = await razorpay.payments.fetch(razorpay_payment_id);
      } catch (pErr) {
        console.error(`[server.ts] Error fetching payment ${razorpay_payment_id} from Razorpay:`, pErr?.message);
        return res.status(400).json({
          error: "Failed to verify payment with Razorpay. Please verify payment status."
        });
      }
      if (!rzpPayment) {
        return res.status(400).json({ error: "Payment transaction record not found on Razorpay." });
      }
      if (rzpPayment.status === "authorized") {
        try {
          rzpPayment = await razorpay.payments.capture(
            razorpay_payment_id,
            rzpPayment.amount,
            rzpPayment.currency || "INR"
          );
          console.log(`[server.ts] Auto-captured authorized payment ${razorpay_payment_id}`);
        } catch (capErr) {
          console.warn(`[server.ts] Auto-capture attempt for ${razorpay_payment_id}:`, capErr?.message);
        }
      }
      if (rzpPayment.status !== "captured") {
        return res.status(400).json({
          error: `Payment status is ${rzpPayment.status}, not captured. Course access cannot be unlocked.`
        });
      }
      if (rzpPayment.order_id && rzpPayment.order_id !== razorpay_order_id) {
        return res.status(400).json({
          error: "Payment order identifier mismatch."
        });
      }
      let rzpOrder = null;
      try {
        rzpOrder = await razorpay.orders.fetch(razorpay_order_id);
      } catch (oErr) {
        console.error(`[server.ts] Error fetching order ${razorpay_order_id} from Razorpay:`, oErr?.message);
      }
      if (rzpOrder?.notes) {
        const orderStudentUid = rzpOrder.notes.studentUid;
        const orderCourseId = rzpOrder.notes.courseId;
        if (orderStudentUid && orderStudentUid !== user.uid) {
          console.warn(`[server.ts] Order student mismatch: ${orderStudentUid} vs ${user.uid}`);
          return res.status(403).json({
            error: "Payment ownership verification failed. Order does not belong to authenticated student."
          });
        }
        if (orderCourseId && orderCourseId !== courseId) {
          console.warn(`[server.ts] Order course mismatch: ${orderCourseId} vs ${courseId}`);
          return res.status(400).json({
            error: "Course identifier mismatch for this payment order."
          });
        }
      }
      const enrollmentDocId = `enr_${user.uid}_${courseId}`;
      const db = getAdminFirestore();
      if (!db) {
        return res.status(503).json({
          error: "Payment verification failed: Database unavailable. Contact support."
        });
      }
      try {
        const enrollmentSnap = await db.collection("enrollments").doc(enrollmentDocId).get();
        if (enrollmentSnap.exists && enrollmentSnap.data()?.status === "active") {
          return res.json({
            success: true,
            alreadyProcessed: true,
            message: "Payment already verified. Course access is active.",
            enrollment: enrollmentSnap.data()
          });
        }
      } catch (checkErr) {
      }
      const course = await getCourseById(courseId);
      const now = /* @__PURE__ */ new Date();
      const durationDays = course?.durationDays || 365;
      const expiresAt = new Date(now.getTime() + durationDays * 24 * 60 * 60 * 1e3).toISOString();
      const amountPaid = (Number(rzpPayment?.amount) || 0) / 100;
      const paymentRecord = {
        id: `pay_ord_${razorpay_order_id}`,
        userId: user.uid,
        studentEmail: user.email || rzpOrder?.notes?.studentEmail || "",
        studentName: user.name || "",
        courseId,
        courseTitle: course?.title || rzpOrder?.notes?.courseTitle || "Nursing Coaching Program",
        orderId: razorpay_order_id,
        paymentId: razorpay_payment_id,
        amount: amountPaid,
        amountInPaise: rzpPayment.amount,
        originalAmount: course?.price || amountPaid,
        discountAmount: course?.price ? Math.max(0, course.price - amountPaid) : 0,
        couponId: null,
        couponCode: rzpOrder?.notes?.couponCode || null,
        currency: "INR",
        status: "paid",
        createdAt: now.toISOString(),
        updatedAt: now.toISOString(),
        verifiedAt: now.toISOString()
      };
      const enrollment = {
        id: enrollmentDocId,
        userId: user.uid,
        batchId: courseId,
        status: "active",
        isFree: false,
        source: "purchase",
        paymentProvider: "razorpay",
        paymentId: razorpay_payment_id,
        orderId: razorpay_order_id,
        currency: "INR",
        amountPaid,
        couponCode: paymentRecord.couponCode || null,
        courseTitle: course?.title || "Nursing Coaching Program",
        courseThumbnail: course?.thumbnailUrl,
        enrolledAt: now.toISOString(),
        expiresAt,
        createdAt: now.toISOString(),
        updatedAt: now.toISOString()
      };
      try {
        await writeVerifiedPaymentRecord(paymentRecord);
        await writePaidEnrollmentRecord(enrollment);
      } catch (persistErr) {
        console.error("[server.ts] Failed to persist payment/enrollment to Firestore:", persistErr);
        return res.status(503).json({
          error: "Payment verification failed: Database unavailable. Contact support."
        });
      }
      console.log(`[server.ts] Payment verified successfully: ${razorpay_payment_id} for user ${user.uid}, course ${courseId}`);
      return res.json({
        success: true,
        message: "Payment verified and course unlocked successfully.",
        enrollment,
        payment: paymentRecord
      });
    } catch (err) {
      console.error("[server.ts] Error verifying payment:", err);
      return res.status(500).json({
        error: err?.message || "Payment verification failed."
      });
    }
  });
  app2.post("/api/payments/reconcile", async (req, res) => {
    try {
      const user = await getVerifiedUser(req);
      if (!user) {
        return res.status(401).json({ error: "Unauthorized: Valid student token required." });
      }
      const { paymentId, orderId, courseId } = req.body;
      if (!paymentId) {
        return res.status(400).json({ error: "Payment ID is required for reconciliation." });
      }
      const razorpay = getRazorpay();
      if (!razorpay) {
        return res.status(503).json({ error: "Payment service is unavailable." });
      }
      const rzpPayment = await razorpay.payments.fetch(paymentId);
      if (!rzpPayment || rzpPayment.status !== "captured") {
        return res.status(400).json({
          error: `Payment is ${rzpPayment?.status || "not found"}, not captured.`
        });
      }
      let targetCourseId = courseId;
      if (rzpPayment.order_id) {
        try {
          const rzpOrder = await razorpay.orders.fetch(rzpPayment.order_id);
          if (rzpOrder?.notes?.courseId) {
            targetCourseId = rzpOrder.notes.courseId;
          }
        } catch (e) {
        }
      }
      if (!targetCourseId) {
        return res.status(400).json({ error: "Course could not be determined for this payment." });
      }
      const course = await getCourseById(targetCourseId);
      const now = /* @__PURE__ */ new Date();
      const durationDays = course?.durationDays || 365;
      const expiresAt = new Date(now.getTime() + durationDays * 24 * 60 * 60 * 1e3).toISOString();
      const enrollmentDocId = `enr_${user.uid}_${targetCourseId}`;
      const enrollment = {
        id: enrollmentDocId,
        userId: user.uid,
        batchId: targetCourseId,
        status: "active",
        isFree: false,
        source: "reconciliation",
        paymentProvider: "razorpay",
        paymentId,
        orderId: rzpPayment.order_id || orderId || "",
        currency: "INR",
        amountPaid: (Number(rzpPayment?.amount) || 0) / 100,
        courseTitle: course?.title || "Nursing Coaching Program",
        courseThumbnail: course?.thumbnailUrl,
        enrolledAt: now.toISOString(),
        expiresAt,
        createdAt: now.toISOString(),
        updatedAt: now.toISOString()
      };
      await writePaidEnrollmentRecord(enrollment);
      return res.json({
        success: true,
        message: "Payment reconciled and course access activated.",
        enrollment
      });
    } catch (err) {
      console.error("[server.ts] Error reconciling payment:", err);
      return res.status(500).json({ error: err?.message || "Failed to reconcile payment." });
    }
  });
  app2.get(["/api/payments/user-enrollments", "/api/user/enrollments"], async (req, res) => {
    const user = await getVerifiedUser(req);
    if (!user) {
      return res.status(401).json({ error: "Unauthorized: Valid student token required." });
    }
    const db = getAdminFirestore();
    if (!db) {
      return res.status(503).json({
        error: "Database unavailable.",
        enrollments: []
      });
    }
    try {
      const snap = await db.collection("enrollments").where("userId", "==", user.uid).where("status", "==", "active").get();
      const enrollments = snap.docs.map((d) => d.data());
      return res.json({
        success: true,
        enrollments
      });
    } catch (err) {
      console.error("[server.ts] Error fetching user enrollments from Firestore:", err);
      return res.status(500).json({
        error: "Failed to fetch user enrollments.",
        enrollments: []
      });
    }
  });
  app2.get("/api/payments/check-access", async (req, res) => {
    const user = await getVerifiedUser(req);
    if (!user) {
      return res.status(401).json({ hasAccess: false, status: "unauthenticated" });
    }
    const courseId = req.query.courseId;
    if (!courseId) {
      return res.status(400).json({ hasAccess: false, error: "courseId required." });
    }
    const result = await evaluateServerCourseAccess(user.uid, user.email, courseId);
    res.json(result);
  });
  app2.post(["/api/payments/webhook", "/api/razorpay/webhook"], async (req, res) => {
    const webhookSecret = process.env.RAZORPAY_WEBHOOK_SECRET;
    if (webhookSecret) {
      const signature = req.headers["x-razorpay-signature"];
      const shasum = import_crypto.default.createHmac("sha256", webhookSecret);
      shasum.update(JSON.stringify(req.body));
      const digest = shasum.digest("hex");
      if (digest !== signature) {
        console.warn("[server.ts] Webhook signature mismatch.");
        return res.status(400).json({ error: "Invalid webhook signature." });
      }
    }
    const event = req.body.event;
    console.log(`[server.ts] Received Razorpay Webhook Event: ${event}`);
    if (event === "payment.captured" || event === "order.paid") {
      const paymentEntity = req.body?.payload?.payment?.entity;
      const orderId = paymentEntity?.order_id;
      if (orderId) {
        const db = getAdminFirestore();
        if (db) {
          try {
            const payDocRef = db.collection("payments").doc(`pay_ord_${orderId}`);
            const payDocSnap = await payDocRef.get();
            if (payDocSnap.exists) {
              const p = payDocSnap.data();
              if (p.status !== "paid") {
                p.status = "paid";
                p.paymentId = paymentEntity.id;
                p.verifiedAt = (/* @__PURE__ */ new Date()).toISOString();
                p.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
                await writeVerifiedPaymentRecord(p);
                const course = await getCourseById(p.courseId);
                const now = /* @__PURE__ */ new Date();
                const durationDays = course?.durationDays || 365;
                const expiresAt = new Date(now.getTime() + durationDays * 864e5).toISOString();
                const enrollmentDocId = `enr_${p.userId}_${p.courseId}`;
                await writePaidEnrollmentRecord({
                  id: enrollmentDocId,
                  userId: p.userId,
                  batchId: p.courseId,
                  status: "active",
                  isFree: false,
                  source: "webhook_reconciliation",
                  paymentProvider: "razorpay",
                  paymentId: paymentEntity.id,
                  orderId,
                  currency: p.currency,
                  amountPaid: p.amount,
                  couponCode: p.couponCode,
                  courseTitle: p.courseTitle,
                  enrolledAt: now.toISOString(),
                  expiresAt,
                  createdAt: now.toISOString(),
                  updatedAt: now.toISOString()
                });
                if (p.couponId) {
                  await incrementCouponUsageAdmin(p.couponId);
                }
                console.log(`[server.ts] Automated webhook payment and enrollment provisioned for ${orderId}`);
              }
            }
          } catch (whErr) {
            console.warn("[server.ts] Error processing webhook event in Firestore:", whErr);
          }
        }
      }
    }
    res.json({ received: true });
  });
  app2.get("/api/payments/admin-list", async (req, res) => {
    const user = await getVerifiedUser(req);
    if (!user || !isSuperAdminEmail(user.email)) {
      return res.status(403).json({
        error: "Forbidden: Administrator authentication required."
      });
    }
    const db = getAdminFirestore();
    if (!db) {
      return res.json({ success: true, payments: [], totalCount: 0 });
    }
    try {
      const snap = await db.collection("payments").orderBy("createdAt", "desc").limit(100).get();
      const list = snap.docs.map((doc) => doc.data());
      return res.json({
        success: true,
        payments: list,
        totalCount: list.length
      });
    } catch (err) {
      console.warn("[server.ts] Notice fetching admin payments list:", err);
      return res.json({ success: true, payments: [], totalCount: 0 });
    }
  });
  app2.get("/api/payments/admin-enrollments", async (req, res) => {
    const user = await getVerifiedUser(req);
    if (!user || !isSuperAdminEmail(user.email)) {
      return res.status(403).json({
        error: "Forbidden: Administrator authentication required."
      });
    }
    const db = getAdminFirestore();
    if (!db) {
      return res.json({ success: true, enrollments: [] });
    }
    try {
      const batchId = typeof req.query.batchId === "string" ? req.query.batchId.trim() : "";
      let queryRef = db.collection("enrollments");
      if (batchId) {
        queryRef = queryRef.where("batchId", "==", batchId);
      }
      const snap = await queryRef.limit(200).get();
      const list = snap.docs.map((doc) => ({ id: doc.id, ...doc.data() }));
      return res.json({
        success: true,
        enrollments: list
      });
    } catch (err) {
      console.warn("[server.ts] Notice fetching admin enrollments list:", err);
      return res.json({ success: true, enrollments: [] });
    }
  });
  async function evaluateServerCourseAccess(userId, userEmail, courseId) {
    const isSuperAdmin = Boolean(userEmail && isSuperAdminEmail(userEmail));
    const course = await getCourseById(courseId);
    if (!course) {
      return {
        hasAccess: isSuperAdmin,
        isAdmin: isSuperAdmin,
        status: "not_enrolled",
        reason: "Course not found."
      };
    }
    const db = getAdminFirestore();
    let enrollment = null;
    if (db) {
      const enrollmentDocId = `enr_${userId}_${course.id}`;
      try {
        const docSnap = await db.collection("enrollments").doc(enrollmentDocId).get();
        if (docSnap.exists) {
          enrollment = docSnap.data();
        } else {
          const qSnap = await db.collection("enrollments").where("userId", "==", userId).where("batchId", "==", course.id).limit(1).get();
          if (!qSnap.empty) {
            enrollment = qSnap.docs[0].data();
          }
        }
      } catch (err) {
        console.error("[server.ts] Error fetching enrollment from Firestore:", err?.message || err);
      }
    }
    if (enrollment) {
      if (enrollment.status !== "active") {
        return {
          hasAccess: isSuperAdmin,
          isAdmin: isSuperAdmin,
          status: enrollment.status || "inactive",
          reason: "Your enrollment is inactive or revoked.",
          enrollment
        };
      }
      if (enrollment.expiresAt) {
        const expiryTime = new Date(enrollment.expiresAt).getTime();
        if (!isNaN(expiryTime) && Date.now() > expiryTime) {
          return {
            hasAccess: isSuperAdmin,
            isAdmin: isSuperAdmin,
            status: "expired",
            reason: "Your course access has expired.",
            enrollment
          };
        }
      }
      return {
        hasAccess: true,
        isAdmin: isSuperAdmin,
        status: "active",
        reason: "Active course enrollment confirmed.",
        enrollment
      };
    }
    if (isSuperAdmin) {
      return {
        hasAccess: true,
        isAdmin: true,
        status: "not_enrolled",
        enrollment: null,
        reason: "Administrator preview privileges (not enrolled as a student)."
      };
    }
    return {
      hasAccess: false,
      isAdmin: false,
      status: "not_enrolled",
      enrollment: null,
      reason: course.isFree ? "Please enroll in this free batch to activate access." : "This course is locked. Please purchase the course to access it."
    };
  }
  app2.get("/api/courses/:courseId/access", async (req, res) => {
    const user = await getVerifiedUser(req);
    if (!user) {
      return res.status(401).json({
        hasAccess: false,
        status: "unauthenticated",
        error: "Please login to continue."
      });
    }
    const { courseId } = req.params;
    if (!courseId) {
      return res.status(400).json({
        hasAccess: false,
        error: "Course identifier is required."
      });
    }
    const result = await evaluateServerCourseAccess(user.uid, user.email, courseId);
    return res.json(result);
  });
  app2.post("/api/access/verify-course", async (req, res) => {
    const user = await getVerifiedUser(req);
    if (!user) {
      return res.status(401).json({
        allowed: false,
        status: "unauthenticated",
        error: "Please login to continue."
      });
    }
    const { courseId } = req.body;
    if (!courseId) {
      return res.status(400).json({
        allowed: false,
        error: "Course identifier is required."
      });
    }
    const result = await evaluateServerCourseAccess(user.uid, user.email, courseId);
    if (!result.hasAccess) {
      return res.status(403).json({
        allowed: false,
        status: result.status,
        error: result.reason,
        code: result.status === "expired" ? "course_expired" : "course_locked"
      });
    }
    res.json({
      allowed: true,
      status: result.status,
      isAdmin: result.isAdmin,
      enrollment: result.enrollment
    });
  });
  app2.post("/api/access/verify-hierarchy", async (req, res) => {
    const user = await getVerifiedUser(req);
    if (!user) {
      return res.status(401).json({
        allowed: false,
        error: "Please login to continue.",
        code: "unauthenticated"
      });
    }
    const { courseId, subjectId, chapterId, classId, testId, testType } = req.body;
    if (!courseId) {
      return res.status(400).json({
        allowed: false,
        error: "Course identifier is required."
      });
    }
    const access = await evaluateServerCourseAccess(user.uid, user.email, courseId);
    if (!access.hasAccess) {
      return res.status(403).json({
        allowed: false,
        status: access.status,
        error: access.reason,
        code: access.status === "expired" ? "course_expired" : "course_locked"
      });
    }
    const db = getAdminFirestore();
    if (subjectId && db) {
      try {
        const sSnap = await db.collection("subjects").doc(subjectId).get();
        if (sSnap.exists) {
          const subject = sSnap.data();
          if (subject && subject.batchId !== courseId) {
            return res.status(403).json({
              allowed: false,
              error: "You do not have permission to access this resource.",
              code: "hierarchy_violation"
            });
          }
        }
      } catch (err) {
        console.warn("[server.ts] Error checking subject hierarchy:", err);
      }
    }
    if (chapterId && db) {
      try {
        const cSnap = await db.collection("chapters").doc(chapterId).get();
        if (cSnap.exists) {
          const chapter = cSnap.data();
          if (chapter && subjectId && chapter.subjectId !== subjectId) {
            return res.status(403).json({
              allowed: false,
              error: "You do not have permission to access this resource.",
              code: "hierarchy_violation"
            });
          }
        }
      } catch (err) {
        console.warn("[server.ts] Error checking chapter hierarchy:", err);
      }
    }
    if (classId && db) {
      try {
        const clSnap = await db.collection("classes").doc(classId).get();
        if (clSnap.exists) {
          const classItem = clSnap.data();
          if (classItem) {
            if (classItem.batchId !== courseId || chapterId && classItem.chapterId && classItem.chapterId !== chapterId) {
              return res.status(403).json({
                allowed: false,
                error: "You do not have permission to access this resource.",
                code: "hierarchy_violation"
              });
            }
          }
        }
      } catch (err) {
        console.warn("[server.ts] Error checking class hierarchy:", err);
      }
    }
    if (testId && db) {
      try {
        if (testType === "weekly-warrior") {
          const tSnap = await db.collection("weeklyWarriorTests").doc(testId).get();
          if (tSnap.exists) {
            const ww = tSnap.data();
            if (ww && ww.batchId !== courseId) {
              return res.status(403).json({
                allowed: false,
                error: "You do not have permission to access this resource.",
                code: "hierarchy_violation"
              });
            }
          }
        } else if (testType === "unit-test") {
          const tSnap = await db.collection("unitTests").doc(testId).get();
          if (tSnap.exists) {
            const ut = tSnap.data();
            if (ut && (ut.batchId !== courseId || chapterId && ut.chapterId && ut.chapterId !== chapterId)) {
              return res.status(403).json({
                allowed: false,
                error: "You do not have permission to access this resource.",
                code: "hierarchy_violation"
              });
            }
          }
        }
      } catch (err) {
        console.warn("[server.ts] Error checking test hierarchy:", err);
      }
    }
    res.json({
      allowed: true,
      hierarchyValid: true,
      status: access.status
    });
  });
  app2.post("/api/access/verify-test", async (req, res) => {
    const user = await getVerifiedUser(req);
    if (!user) {
      return res.status(401).json({
        allowed: false,
        error: "Please login to continue.",
        code: "unauthenticated"
      });
    }
    const { testType, testId } = req.body;
    if (!testType || !testId) {
      return res.status(400).json({
        allowed: false,
        error: "Test type and test identifier are required."
      });
    }
    if (user.email && isSuperAdminEmail(user.email)) {
      return res.json({ allowed: true, isAdmin: true });
    }
    let batchId = "";
    let isPublished = false;
    const db = getAdminFirestore();
    if (db) {
      try {
        if (testType === "weekly-warrior") {
          const snap = await db.collection("weeklyWarriorTests").doc(testId).get();
          if (snap.exists) {
            const ww = snap.data();
            batchId = ww?.batchId || "";
            isPublished = Boolean(ww?.isPublished);
          }
        } else {
          const snap = await db.collection("unitTests").doc(testId).get();
          if (snap.exists) {
            const ut = snap.data();
            batchId = ut?.batchId || "";
            isPublished = Boolean(ut?.isPublished);
          }
        }
      } catch (err) {
        console.warn("[server.ts] Error fetching test for verification:", err);
      }
    }
    if (batchId) {
      if (!isPublished) {
        return res.status(403).json({
          allowed: false,
          error: "This test is not currently available.",
          code: "test_unpublished"
        });
      }
      const access = await evaluateServerCourseAccess(user.uid, user.email, batchId);
      if (!access.hasAccess) {
        return res.status(403).json({
          allowed: false,
          status: access.status,
          error: access.reason,
          code: access.status === "expired" ? "course_expired" : "course_locked"
        });
      }
    }
    res.json({
      allowed: true,
      batchId
    });
  });
  app2.post("/api/access/verify-result", async (req, res) => {
    const user = await getVerifiedUser(req);
    if (!user) {
      return res.status(401).json({
        allowed: false,
        error: "Please login to continue.",
        code: "unauthenticated"
      });
    }
    const isSuperAdmin = Boolean(user.email && isSuperAdminEmail(user.email));
    if (isSuperAdmin) {
      return res.json({ allowed: true, isAdmin: true });
    }
    const { studentId, attemptId } = req.body;
    if (studentId && studentId !== user.uid) {
      return res.status(403).json({
        allowed: false,
        error: "You do not have permission to view another student's test scorecard.",
        code: "unauthorized_student_access"
      });
    }
    if (attemptId && typeof attemptId === "string") {
      const parts = attemptId.split("_");
      const suffix = parts[parts.length - 1];
      if (suffix && suffix.length >= 4 && !user.uid.startsWith(suffix)) {
        return res.status(403).json({
          allowed: false,
          error: "You do not have permission to view another student's test scorecard.",
          code: "unauthorized_attempt_access"
        });
      }
    }
    res.json({
      allowed: true,
      studentId: user.uid
    });
  });
  const serverTestResultsStore = /* @__PURE__ */ new Map();
  const serverTestAttemptsStore = /* @__PURE__ */ new Map();
  async function getRawTestQuestions(testType, testId) {
    const db = getAdminFirestore();
    const collectionName = testType === "weekly-warrior" ? "weeklyWarriorQuestions" : "unitTestQuestions";
    if (db) {
      try {
        const snap = await db.collection(collectionName).where("testId", "==", testId).get();
        if (!snap.empty) {
          const questions = snap.docs.map((d) => ({ id: d.id, ...d.data() }));
          questions.sort((a, b) => (a.order || 0) - (b.order || 0));
          return questions;
        }
      } catch (err) {
        console.warn(`[server.ts] Error fetching ${collectionName} from Firestore:`, err);
      }
    }
    return [];
  }
  app2.get("/api/tests/:testType/:testId/questions", async (req, res) => {
    try {
      const user = await getVerifiedUser(req);
      if (!user) {
        return res.status(401).json({ error: "Please login to access this assessment." });
      }
      const { testType, testId } = req.params;
      if (testType !== "weekly-warrior" && testType !== "unit-test") {
        return res.status(400).json({ error: "Invalid test type specified." });
      }
      let batchId = "";
      let isPublished = false;
      const db = getAdminFirestore();
      if (db) {
        try {
          if (testType === "weekly-warrior") {
            const tSnap = await db.collection("weeklyWarriorTests").doc(testId).get();
            if (tSnap.exists) {
              const ww = tSnap.data();
              batchId = ww?.batchId || "";
              isPublished = Boolean(ww?.isPublished);
            }
          } else {
            const tSnap = await db.collection("unitTests").doc(testId).get();
            if (tSnap.exists) {
              const ut = tSnap.data();
              batchId = ut?.batchId || "";
              isPublished = Boolean(ut?.isPublished);
            }
          }
        } catch (err) {
          console.warn("[server.ts] Error fetching test details for question delivery:", err);
        }
      }
      if (batchId) {
        const access = await evaluateServerCourseAccess(user.uid, user.email, batchId);
        if (!access.hasAccess) {
          return res.status(403).json({
            error: access.reason || "You are not enrolled in this course.",
            code: access.status === "expired" ? "course_expired" : "course_locked"
          });
        }
      }
      const rawQuestions = await getRawTestQuestions(testType, testId);
      const sanitizedQuestions = rawQuestions.map((q) => ({
        id: q.id,
        testId: q.testId,
        batchId: q.batchId,
        questionText: q.questionText,
        questionImageUrl: q.questionImageUrl || null,
        options: (q.options || []).map((opt) => ({
          id: opt.id,
          text: opt.text,
          imageUrl: opt.imageUrl || null
        })),
        marks: Number(q.marks) || 1,
        negativeMarks: Number(q.negativeMarks) || 0.25,
        order: Number(q.order) || 0,
        subjectTag: q.subjectTag || null
        // STRICT SECURITY: correctOptionId and explanation are completely excluded!
      }));
      return res.json({
        success: true,
        testId,
        testType,
        totalQuestions: sanitizedQuestions.length,
        questions: sanitizedQuestions
      });
    } catch (err) {
      console.error("[server.ts] Error delivering sanitized questions:", err);
      return res.status(500).json({ error: "Failed to deliver test questions." });
    }
  });
  app2.post("/api/tests/:testType/:testId/submit", async (req, res) => {
    try {
      const user = await getVerifiedUser(req);
      if (!user) {
        return res.status(401).json({ error: "Please login to submit this assessment." });
      }
      const { testType, testId } = req.params;
      const { attemptId, answers = {}, timeSpentSeconds = 0 } = req.body;
      if (!attemptId) {
        return res.status(400).json({ error: "Attempt identifier is required for submission." });
      }
      const rawQuestions = await getRawTestQuestions(testType, testId);
      if (!rawQuestions || rawQuestions.length === 0) {
        return res.status(404).json({ error: "Assessment questions not found." });
      }
      let totalMarks = 0;
      let score = 0;
      let correctCount = 0;
      let incorrectCount = 0;
      let unattemptedCount = 0;
      const subjectMap = {};
      for (const q of rawQuestions) {
        const qMarks = Number(q.marks) || 1;
        const qNegative = Number(q.negativeMarks) || 0.25;
        totalMarks += qMarks;
        const subjectKey = q.subjectTag || "General Nursing";
        if (!subjectMap[subjectKey]) {
          subjectMap[subjectKey] = { total: 0, correct: 0, incorrect: 0 };
        }
        subjectMap[subjectKey].total += 1;
        const studentOptionId = answers[q.id];
        if (!studentOptionId) {
          unattemptedCount += 1;
        } else if (studentOptionId === q.correctOptionId) {
          correctCount += 1;
          score += qMarks;
          subjectMap[subjectKey].correct += 1;
        } else {
          incorrectCount += 1;
          score -= qNegative;
          subjectMap[subjectKey].incorrect += 1;
        }
      }
      const finalScore = Math.max(0, Math.round(score * 100) / 100);
      const passingMarks = Math.round(totalMarks * 0.5 * 10) / 10;
      const isPassed = finalScore >= passingMarks;
      const attemptedCount = correctCount + incorrectCount;
      const accuracyPercentage = attemptedCount > 0 ? Math.round(correctCount / attemptedCount * 100) : 0;
      const breakdownBySubject = Object.entries(subjectMap).map(([subject, stats]) => ({
        subject,
        totalQuestions: stats.total,
        correctCount: stats.correct,
        incorrectCount: stats.incorrect,
        score: Math.max(0, stats.correct - stats.incorrect * 0.25)
      }));
      const now = (/* @__PURE__ */ new Date()).toISOString();
      const resultDocId = `res_${testType === "weekly-warrior" ? "ww" : "ut"}_${attemptId}`;
      const result = {
        id: resultDocId,
        attemptId,
        testId,
        batchId: rawQuestions[0]?.batchId || "",
        studentId: user.uid,
        studentName: user.name || "Student",
        studentEmail: user.email || "",
        score: finalScore,
        totalMarks,
        passingMarks,
        totalQuestions: rawQuestions.length,
        correctCount,
        incorrectCount,
        unattemptedCount,
        accuracyPercentage,
        accuracy: accuracyPercentage,
        timeTakenSeconds: timeSpentSeconds,
        timeSpentSeconds,
        isPassed,
        submittedAt: now,
        breakdownBySubject,
        answers
      };
      serverTestResultsStore.set(resultDocId, result);
      serverTestResultsStore.set(attemptId, result);
      const completedAttempt = {
        id: attemptId,
        testId,
        studentId: user.uid,
        status: "completed",
        score: finalScore,
        correctCount,
        incorrectCount,
        unattemptedCount,
        totalQuestions: rawQuestions.length,
        timeTakenSeconds: timeSpentSeconds,
        submittedAt: now,
        completedAt: now,
        answers
      };
      serverTestAttemptsStore.set(attemptId, completedAttempt);
      const db = getAdminFirestore();
      if (db) {
        try {
          const resultsCol = testType === "weekly-warrior" ? "weeklyWarriorResults" : "unitTestResults";
          const attemptsCol = testType === "weekly-warrior" ? "weeklyWarriorAttempts" : "unitTestAttempts";
          await db.collection(resultsCol).doc(resultDocId).set(result, { merge: true });
          await db.collection(attemptsCol).doc(attemptId).set(completedAttempt, { merge: true });
          console.log(`[server.ts] Assessment authoritative result saved to ${resultsCol}/${resultDocId}`);
        } catch (dbErr) {
          console.warn("[server.ts] Error persisting test result to Firestore:", dbErr);
        }
      }
      return res.json({
        success: true,
        message: "Assessment evaluated and recorded successfully.",
        result
      });
    } catch (err) {
      console.error("[server.ts] Error evaluating test submission:", err);
      return res.status(500).json({ error: "Failed to submit and evaluate assessment." });
    }
  });
  app2.get("/api/tests/:testType/:testId/review/:attemptId", async (req, res) => {
    try {
      const user = await getVerifiedUser(req);
      if (!user) {
        return res.status(401).json({ error: "Please login to access the test review." });
      }
      const { testType, testId, attemptId } = req.params;
      let result = serverTestResultsStore.get(attemptId) || serverTestResultsStore.get(`res_${testType === "weekly-warrior" ? "ww" : "ut"}_${attemptId}`);
      if (!result) {
        const db = getAdminFirestore();
        if (db) {
          try {
            const resultsCol = testType === "weekly-warrior" ? "weeklyWarriorResults" : "unitTestResults";
            const snap = await db.collection(resultsCol).doc(`res_${testType === "weekly-warrior" ? "ww" : "ut"}_${attemptId}`).get();
            if (snap.exists) {
              result = snap.data();
            }
          } catch (e) {
          }
        }
      }
      if (!result) {
        return res.status(404).json({ error: "Completed test scorecard not found for this attempt." });
      }
      const isSuperAdmin = Boolean(user.email && isSuperAdminEmail(user.email));
      if (!isSuperAdmin && result.studentId !== user.uid) {
        return res.status(403).json({ error: "Unauthorized to view this scorecard." });
      }
      const rawQuestions = await getRawTestQuestions(testType, testId);
      const studentAnswers = result.answers || {};
      const reviewItems = rawQuestions.map((q) => {
        const studentSelectedOptionId = studentAnswers[q.id] || null;
        const isCorrect = studentSelectedOptionId === q.correctOptionId;
        const isSkipped = !studentSelectedOptionId;
        return {
          questionId: q.id,
          questionText: q.questionText,
          questionImageUrl: q.questionImageUrl || null,
          options: q.options || [],
          correctOptionId: q.correctOptionId,
          studentSelectedOptionId,
          isCorrect,
          isSkipped,
          explanation: q.explanation || "Detailed clinical rationale is available in full lecture series.",
          explanationImageUrl: q.explanationImageUrl || null,
          marks: q.marks || 1,
          negativeMarks: q.negativeMarks || 0.25,
          subjectTag: q.subjectTag || "General Nursing"
        };
      });
      return res.json({
        success: true,
        reviewItems,
        result
      });
    } catch (err) {
      console.error("[server.ts] Error generating test review:", err);
      return res.status(500).json({ error: "Failed to generate test review." });
    }
  });
  app2.get("/api/tests/:testType/:testId/results/:attemptId", async (req, res) => {
    try {
      const user = await getVerifiedUser(req);
      if (!user) {
        return res.status(401).json({ error: "Please login to access this result." });
      }
      const { testType, attemptId } = req.params;
      let result = serverTestResultsStore.get(attemptId) || serverTestResultsStore.get(`res_${testType === "weekly-warrior" ? "ww" : "ut"}_${attemptId}`);
      if (!result) {
        const db = getAdminFirestore();
        if (db) {
          try {
            const resultsCol = testType === "weekly-warrior" ? "weeklyWarriorResults" : "unitTestResults";
            const snap = await db.collection(resultsCol).doc(`res_${testType === "weekly-warrior" ? "ww" : "ut"}_${attemptId}`).get();
            if (snap.exists) {
              result = snap.data();
            }
          } catch (e) {
          }
        }
      }
      if (!result) {
        return res.status(404).json({ error: "Scorecard not found." });
      }
      const isSuperAdmin = Boolean(user.email && isSuperAdminEmail(user.email));
      if (!isSuperAdmin && result.studentId !== user.uid) {
        return res.status(403).json({ error: "Unauthorized to view this scorecard." });
      }
      return res.json({ success: true, result });
    } catch (err) {
      console.error("[server.ts] Error retrieving test result:", err);
      return res.status(500).json({ error: "Failed to retrieve test result." });
    }
  });
  app2.post("/api/admin/purge-all-data", async (req, res) => {
    try {
      const user = await getVerifiedUser(req);
      const isSuperAdmin = Boolean(user && user.email && isSuperAdminEmail(user.email));
      serverTestResultsStore.clear();
      serverTestAttemptsStore.clear();
      cloudCatalog = {
        batches: [],
        subjects: [],
        chapters: [],
        classes: [],
        pdfNotes: [],
        weeklyWarriorTests: [],
        weeklyWarriorQuestions: [],
        unitTests: [],
        unitTestQuestions: [],
        deletedIds: [],
        updatedAt: (/* @__PURE__ */ new Date()).toISOString()
      };
      try {
        if (import_fs2.default.existsSync(CATALOG_FILE)) import_fs2.default.unlinkSync(CATALOG_FILE);
      } catch {
      }
      const db = getAdminFirestore();
      let totalDeleted = 0;
      if (db) {
        const collectionsToPurge = [
          "batches",
          "courses",
          "subjects",
          "chapters",
          "classes",
          "lectures",
          "pdf_notes",
          "pdfNotes",
          "weeklyWarriorTests",
          "weeklyWarriorQuestions",
          "weeklyWarriorAttempts",
          "weeklyWarriorResults",
          "unitTests",
          "unitTestQuestions",
          "unitTestAttempts",
          "unitTestResults",
          "tests",
          "questions",
          "enrollments",
          "payments",
          "coupons"
        ];
        for (const coll of collectionsToPurge) {
          try {
            const snap = await db.collection(coll).get();
            if (!snap.empty) {
              const batch = db.batch();
              let countInBatch = 0;
              for (const doc of snap.docs) {
                batch.delete(doc.ref);
                countInBatch++;
                totalDeleted++;
                if (countInBatch >= 450) {
                  await batch.commit();
                  countInBatch = 0;
                }
              }
              if (countInBatch > 0) {
                await batch.commit();
              }
            }
          } catch (e) {
            console.warn(`[server.ts] Warning purging ${coll}:`, e?.message || e);
          }
        }
      }
      console.log(`[server.ts] Complete purge executed. Total documents purged: ${totalDeleted}`);
      return res.json({
        success: true,
        message: "All real and fake data completely wiped from server and Firestore.",
        totalDeleted
      });
    } catch (err) {
      console.error("[server.ts] Error purging all data:", err);
      return res.status(500).json({ error: "Failed to execute clean slate purge." });
    }
  });
  return app2;
}
var app = buildApp();
async function startServer() {
  const PORT = 3e3;
  if (process.env.NODE_ENV !== "production") {
    const { createServer: createViteServer } = await import("vite");
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa"
    });
    app.use(vite.middlewares);
  } else {
    const distPath = import_path2.default.join(process.cwd(), "dist");
    app.use(import_express.default.static(distPath));
    app.get("*", (_req, res) => {
      res.sendFile(import_path2.default.join(distPath, "index.html"));
    });
  }
  app.listen(PORT, "0.0.0.0", () => {
    console.log(`[Axon LMS Server] Running on http://localhost:${PORT}`);
  });
}
if (process.env.VERCEL !== "1" && process.env.SERVERLESS !== "1" && !process.env.VERCEL_ENV) {
  startServer().catch((err) => {
    console.error("[Axon LMS Server] Fatal server startup error:", err);
    process.exit(1);
  });
}
var server_default = app;
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  app,
  buildApp,
  getRazorpayCredentials,
  startServer
});
