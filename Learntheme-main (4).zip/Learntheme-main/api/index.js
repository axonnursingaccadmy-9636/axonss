import { createRequire } from 'module';

process.env.VERCEL = '1';
process.env.SERVERLESS = '1';

const require = createRequire(import.meta.url);
const serverModule = require('./_server.cjs');
const app = serverModule.default || serverModule.app || serverModule;

export default app;
