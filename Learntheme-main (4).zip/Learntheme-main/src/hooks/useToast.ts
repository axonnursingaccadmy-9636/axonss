/**
 * Axon Nursing Academy - useToast Custom Hook
 * Provides convenient access to dispatching toasts, notifications, and feedback.
 */
import { useContext } from 'react';
import { ToastContext } from '@/src/contexts/ToastContext';
import { ToastContextValue } from '@/src/types/toast.types';

export function useToast(): ToastContextValue {
  const context = useContext(ToastContext);
  if (!context) {
    throw new Error('useToast must be used within a <ToastProvider>. Please wrap your component tree.');
  }
  return context;
}

export type {
  ToastType,
  ToastPosition,
  ToastOptions,
  ToastAction,
  ToastItemData,
} from '@/src/types/toast.types';
