/**
 * Axon Nursing Academy - Scroll Lock Hook
 * Prevents background scrolling when modals or mobile drawers are open
 * without turning <body> into a separate scroll container in Mobile Desktop Mode.
 */
import { useEffect } from 'react';

export function useScrollLock(isLocked: boolean) {
  useEffect(() => {
    if (isLocked) {
      document.documentElement.style.overflow = 'hidden';
      return () => {
        document.documentElement.style.removeProperty('overflow');
        document.body.style.removeProperty('overflow');
      };
    } else {
      document.documentElement.style.removeProperty('overflow');
      document.body.style.removeProperty('overflow');
    }
  }, [isLocked]);
}

export default useScrollLock;
