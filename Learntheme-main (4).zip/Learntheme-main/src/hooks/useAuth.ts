/**
 * Axon Nursing Academy - useAuth Hook
 * Clean ergonomic re-export of AuthContext consumer hook.
 */
export { useAuth } from '@/src/contexts/AuthContext';
export type { AuthContextType } from '@/src/contexts/AuthContext';
