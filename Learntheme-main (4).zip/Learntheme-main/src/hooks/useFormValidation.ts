/**
 * Axon Nursing Academy - Form Validation State Management Hook
 * Lightweight, robust, and framework-free validation handler for authentication forms.
 */
import { useState, useCallback } from 'react';

export type ValidationRule<T> = (value: any, values: T) => string | null | undefined;

export type ValidationSchema<T> = {
  [K in keyof T]?: ValidationRule<T>[];
};

export interface UseFormValidationOptions<T> {
  initialValues: T;
  validationSchema?: ValidationSchema<T>;
  onSubmit?: (values: T) => Promise<void> | void;
}

export interface UseFormValidationReturn<T> {
  values: T;
  errors: Partial<Record<keyof T, string>>;
  touched: Partial<Record<keyof T, boolean>>;
  isSubmitting: boolean;
  isValid: boolean;
  submitError: string | null;
  setSubmitError: (error: string | null) => void;
  handleChange: (field: keyof T, value: any) => void;
  handleBlur: (field: keyof T) => void;
  setFieldValue: (field: keyof T, value: any) => void;
  setFieldError: (field: keyof T, error: string | null) => void;
  validateField: (field: keyof T) => string | null;
  validateAll: () => boolean;
  handleSubmit: (e?: React.FormEvent) => Promise<void>;
  resetForm: () => void;
  setIsSubmitting: (isSubmitting: boolean) => void;
}

// Built-in common validation rules
export const validators = {
  required: (message = 'This field is required'): ValidationRule<any> => {
    return (value) => {
      if (value === null || value === undefined || (typeof value === 'string' && !value.trim())) {
        return message;
      }
      return null;
    };
  },

  email: (message = 'Please enter a valid email address'): ValidationRule<any> => {
    return (value) => {
      if (!value) return null;
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      return emailRegex.test(String(value).trim()) ? null : message;
    };
  },

  minLength: (min: number, message?: string): ValidationRule<any> => {
    return (value) => {
      if (!value) return null;
      const defaultMsg = `Must be at least ${min} characters`;
      return String(value).length >= min ? null : (message || defaultMsg);
    };
  },

  matches: (targetField: string, message = 'Fields do not match'): ValidationRule<any> => {
    return (value, values) => {
      if (!value) return null;
      return value === values[targetField] ? null : message;
    };
  },
};

export function useFormValidation<T extends Record<string, any>>({
  initialValues,
  validationSchema = {},
  onSubmit,
}: UseFormValidationOptions<T>): UseFormValidationReturn<T> {
  const [values, setValues] = useState<T>(initialValues);
  const [errors, setErrors] = useState<Partial<Record<keyof T, string>>>({});
  const [touched, setTouched] = useState<Partial<Record<keyof T, boolean>>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState<string | null>(null);

  const validateField = useCallback(
    (field: keyof T, currentValues = values): string | null => {
      const fieldRules = validationSchema[field];
      if (!fieldRules || fieldRules.length === 0) return null;

      for (const rule of fieldRules) {
        const error = rule(currentValues[field], currentValues);
        if (error) return error;
      }
      return null;
    },
    [validationSchema, values]
  );

  const validateAll = useCallback(
    (currentValues = values): boolean => {
      const newErrors: Partial<Record<keyof T, string>> = {};
      let hasErrors = false;

      (Object.keys(validationSchema) as (keyof T)[]).forEach((field) => {
        const error = validateField(field, currentValues);
        if (error) {
          newErrors[field] = error;
          hasErrors = true;
        }
      });

      setErrors(newErrors);
      return !hasErrors;
    },
    [validationSchema, validateField, values]
  );

  const handleChange = useCallback(
    (field: keyof T, value: any) => {
      setValues((prev) => {
        const next = { ...prev, [field]: value };
        // If field was touched, re-validate
        if (touched[field]) {
          const fieldError = validateField(field, next);
          setErrors((prevErr) => ({
            ...prevErr,
            [field]: fieldError || undefined,
          }));
        }
        return next;
      });

      if (submitError) setSubmitError(null);
    },
    [touched, validateField, submitError]
  );

  const handleBlur = useCallback(
    (field: keyof T) => {
      setTouched((prev) => ({ ...prev, [field]: true }));
      const fieldError = validateField(field);
      setErrors((prev) => ({
        ...prev,
        [field]: fieldError || undefined,
      }));
    },
    [validateField]
  );

  const setFieldValue = useCallback((field: keyof T, value: any) => {
    setValues((prev) => ({ ...prev, [field]: value }));
  }, []);

  const setFieldError = useCallback((field: keyof T, error: string | null) => {
    setErrors((prev) => ({
      ...prev,
      [field]: error || undefined,
    }));
  }, []);

  const resetForm = useCallback(() => {
    setValues(initialValues);
    setErrors({});
    setTouched({});
    setIsSubmitting(false);
    setSubmitError(null);
  }, [initialValues]);

  const handleSubmit = useCallback(
    async (e?: React.FormEvent) => {
      if (e && e.preventDefault) {
        e.preventDefault();
      }

      // Prevent duplicate submission while already submitting
      if (isSubmitting) {
        return;
      }

      setSubmitError(null);

      // Mark all validated fields as touched
      const allTouched: Partial<Record<keyof T, boolean>> = {};
      (Object.keys(validationSchema) as (keyof T)[]).forEach((f) => {
        allTouched[f] = true;
      });
      setTouched(allTouched);

      const isValid = validateAll();
      if (!isValid) return;

      if (onSubmit) {
        setIsSubmitting(true);
        try {
          await onSubmit(values);
        } catch (err: any) {
          setSubmitError(err?.message || 'An unexpected error occurred. Please try again.');
        } finally {
          setIsSubmitting(false);
        }
      }
    },
    [validateAll, onSubmit, values, validationSchema]
  );

  const isValid = Object.keys(errors).length === 0;

  return {
    values,
    errors,
    touched,
    isSubmitting,
    isValid,
    submitError,
    setSubmitError,
    handleChange,
    handleBlur,
    setFieldValue,
    setFieldError,
    validateField,
    validateAll,
    handleSubmit,
    resetForm,
    setIsSubmitting,
  };
}
