/**
 * Axon Nursing Academy - Centralized Design Tokens & Theme Constants
 */

export const THEME_CONFIG = {
  colors: {
    primary: {
      50: '#EFF6FF',
      100: '#DBEAFE',
      200: '#BFDBFE',
      300: '#93C5FD',
      400: '#60A5FA',
      500: '#3B82F6',
      600: '#1D4ED8', // Main Brand Blue
      700: '#1E40AF',
      800: '#1E3A8A',
      900: '#172554',
    },
    accent: {
      emerald: '#10B981',
      amber: '#F59E0B',
      rose: '#F43F5E',
      indigo: '#6366F1',
    },
    neutral: {
      surface: '#FFFFFF',
      background: '#F8FAFC',
      border: '#E2E8F0',
      muted: '#64748B',
      heading: '#0F172A',
    },
  },
  typography: {
    displayFont: "'Plus Jakarta Sans', sans-serif",
    accentFont: "'Outfit', sans-serif",
  },
  borderRadius: {
    sm: '0.375rem',
    md: '0.5rem',
    lg: '0.75rem',
    xl: '1rem',
    '2xl': '1.25rem',
    full: '9999px',
  },
  shadows: {
    card: '0 1px 3px 0 rgb(0 0 0 / 0.05), 0 1px 2px -1px rgb(0 0 0 / 0.05)',
    cardHover: '0 10px 15px -3px rgb(0 0 0 / 0.08), 0 4px 6px -4px rgb(0 0 0 / 0.05)',
    drawer: '0 20px 25px -5px rgb(0 0 0 / 0.1), 0 8px 10px -6px rgb(0 0 0 / 0.1)',
  },
} as const;
