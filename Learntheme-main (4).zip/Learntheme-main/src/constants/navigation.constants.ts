/**
 * Axon Nursing Academy - Navigation Constants
 */
import { ROUTES } from '@/src/config/routes.config';

export interface NavItem {
  id: string;
  label: string;
  path: string;
  iconName: string;
  badge?: string | number;
}

export const STUDENT_BOTTOM_NAV_ITEMS: NavItem[] = [
  {
    id: 'home',
    label: 'Home',
    path: ROUTES.STUDENT.ROOT,
    iconName: 'Home',
  },
  {
    id: 'my-courses',
    label: 'My Courses',
    path: ROUTES.STUDENT.COURSES,
    iconName: 'BookOpen',
  },
  {
    id: 'all-courses',
    label: 'All Courses',
    path: ROUTES.STUDENT.ALL_COURSES,
    iconName: 'Grid',
  },
  {
    id: 'chats',
    label: 'Axon AI',
    path: ROUTES.STUDENT.CHATS,
    iconName: 'Sparkles',
    badge: 'AI',
  },
  {
    id: 'profile',
    label: 'My Profile',
    path: ROUTES.STUDENT.PROFILE,
    iconName: 'User',
  },
];

export const ADMIN_SIDEBAR_NAV_ITEMS: NavItem[] = [
  {
    id: 'dashboard',
    label: 'Dashboard Overview',
    path: ROUTES.ADMIN.DASHBOARD,
    iconName: 'LayoutDashboard',
  },
  {
    id: 'batches',
    label: 'Batches / Courses',
    path: ROUTES.ADMIN.BATCHES,
    iconName: 'BookMarked',
  },
  {
    id: 'subjects',
    label: 'Subjects',
    path: ROUTES.ADMIN.SUBJECTS,
    iconName: 'Layers',
  },
  {
    id: 'chapters',
    label: 'Chapters',
    path: ROUTES.ADMIN.CHAPTERS,
    iconName: 'FolderTree',
  },
  {
    id: 'classes',
    label: 'Classes',
    path: ROUTES.ADMIN.CLASSES,
    iconName: 'BookOpen',
  },
  {
    id: 'video-classes',
    label: 'Video Classes',
    path: ROUTES.ADMIN.VIDEO_CLASSES,
    iconName: 'Video',
  },
  {
    id: 'pdf-notes',
    label: 'PDF Notes & Docs',
    path: ROUTES.ADMIN.PDF_NOTES,
    iconName: 'FileText',
  },
  {
    id: 'weekly-warrior',
    label: 'Weekly Warrior (Course Tests)',
    path: ROUTES.ADMIN.WEEKLY_WARRIOR,
    iconName: 'Award',
  },
  {
    id: 'unit-tests',
    label: 'Unit MCQs (Chapter Tests)',
    path: ROUTES.ADMIN.UNIT_TESTS,
    iconName: 'FileCheck',
  },
  {
    id: 'coupons',
    label: 'Coupons & Discounts',
    path: ROUTES.ADMIN.COUPONS,
    iconName: 'Tag',
  },
  {
    id: 'payments',
    label: 'Payments & Orders',
    path: ROUTES.ADMIN.PAYMENTS,
    iconName: 'CreditCard',
  },
  {
    id: 'audit-logs',
    label: 'CMS Audit Trail',
    path: ROUTES.ADMIN.AUDIT_LOGS,
    iconName: 'History',
  },
  {
    id: 'branding',
    label: 'Logo, Footer & Favicon',
    path: ROUTES.ADMIN.BRANDING,
    iconName: 'Image',
  },
  {
    id: 'students',
    label: 'Student Directory',
    path: ROUTES.ADMIN.STUDENTS,
    iconName: 'Users',
  },
];

export const PUBLIC_NAV_ITEMS: NavItem[] = [
  {
    id: 'home',
    label: 'Home',
    path: ROUTES.HOME,
    iconName: 'Home',
  },
  {
    id: 'explore-courses',
    label: 'Explore Courses',
    path: ROUTES.STUDENT.ALL_COURSES,
    iconName: 'Sparkles',
  },
  {
    id: 'login',
    label: 'Student Login',
    path: ROUTES.LOGIN,
    iconName: 'LogIn',
  },
];
