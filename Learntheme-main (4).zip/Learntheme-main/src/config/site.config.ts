/**
 * Axon Nursing Academy - Site & Platform Configuration
 */

export const SITE_CONFIG = {
  name: 'Axon Nursing Academy',
  shortName: 'Axon Nursing',
  tagline: 'Premier Online Nursing Education & Competitive Exam Prep',
  description: 'Specialized LMS platform for NORCET, NCLEX, AIIMS, MSc, Post Basic & BSc Nursing exams.',
  supportEmail: 'pmgautamjaipur@gmail.com',
  supportPhone: '+91 98765 43210',
  socialLinks: {
    youtube: 'https://youtube.com',
    telegram: 'https://telegram.org',
    instagram: 'https://instagram.com',
    whatsapp: 'https://whatsapp.com',
  },
  examCategories: [
    { id: 'norcet', name: 'NORCET / AIIMS', icon: 'Hospital' },
    { id: 'nclex', name: 'NCLEX - RN', icon: 'Globe' },
    { id: 'msc-nursing', name: 'M.Sc Nursing Entrance', icon: 'GraduationCap' },
    { id: 'staff-nurse', name: 'Staff Nurse / CHO', icon: 'Stethoscope' },
    { id: 'bsc-nursing', name: 'B.Sc Academic Nursing', icon: 'BookOpen' },
  ],
} as const;
