/**
 * Axon Nursing Academy - Route Path Constants
 */

export const ROUTES = {
  // Public
  HOME: '/',
  COURSES: '/courses',
  LOGIN: '/login',
  SIGNUP: '/signup',
  FORGOT_PASSWORD: '/forgot-password',

  // LMS Course Hierarchy
  COURSE: {
    DETAILS: (batchId: string = ':batchId') => `/course/${batchId}`,
    SUBJECT: (batchId: string = ':batchId', subjectId: string = ':subjectId') =>
      `/course/${batchId}/subject/${subjectId}`,
    CHAPTER: (
      batchId: string = ':batchId',
      subjectId: string = ':subjectId',
      chapterId: string = ':chapterId'
    ) => `/course/${batchId}/subject/${subjectId}/chapter/${chapterId}`,
    CLASS: (batchId: string = ':batchId', classId: string = ':classId') =>
      `/course/${batchId}/class/${classId}`,
  },

  // Student Learning Portal
  STUDENT: {
    ROOT: '/student',
    COURSES: '/student/courses',
    ALL_COURSES: '/student/all-courses',
    COURSE_DETAILS: (id: string = ':batchId') => `/course/${id}`,
    PROFILE: '/student/profile',
    CHATS: '/student/chats',
    LIVE_CLASSES: '/student/live',
    TEST_SERIES: '/student/tests',
    NOTICES: '/student/notices',
  },

  // Test Runner & Analytics (Phase 6)
  TEST: {
    PLAYER: (testType: string = ':testType', testId: string = ':testId') =>
      `/test/${testType}/${testId}`,
    RESULT: (
      testType: string = ':testType',
      testId: string = ':testId',
      attemptId: string = ':attemptId'
    ) => `/test/${testType}/${testId}/result/${attemptId}`,
  },

  // Admin Portal
  ADMIN: {
    ROOT: '/admin',
    DASHBOARD: '/admin/dashboard',
    BATCHES: '/admin/batches',
    COURSES: '/admin/batches',
    SUBJECTS: '/admin/subjects',
    CHAPTERS: '/admin/chapters',
    CLASSES: '/admin/classes',
    VIDEO_CLASSES: '/admin/video-classes',
    PDF_NOTES: '/admin/pdf-notes',
    COUPONS: '/admin/coupons',
    PAYMENTS: '/admin/payments',
    WEEKLY_WARRIOR: '/admin/weekly-warrior',
    WEEKLY_WARRIOR_QUESTIONS: (testId: string = ':testId') =>
      `/admin/weekly-warrior/${testId}/questions`,
    UNIT_TESTS: '/admin/unit-tests',
    UNIT_TEST_QUESTIONS: (testId: string = ':testId') =>
      `/admin/unit-tests/${testId}/questions`,
    AUDIT_LOGS: '/admin/audit-logs',
    BRANDING: '/admin/branding',
    STUDENTS: '/admin/students',
    TESTS: '/admin/weekly-warrior',
    LIVE: '/admin/live',
    NOTICES: '/admin/notices',
  },
} as const;
