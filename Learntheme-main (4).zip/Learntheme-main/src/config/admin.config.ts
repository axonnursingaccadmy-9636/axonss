/**
 * Axon Nursing Academy - Administrative Role Configuration
 * Declares primary administrator credentials and access verification helpers.
 * Strictly configured for the sole Academy Administrator: pmgautamjaipur@gmail.com
 */

// Designated administrator emails for Axon Nursing Academy
export const BUILT_IN_ADMIN_EMAILS = [
  'pmgautamjaipur@gmail.com',
  'axonnursingaccadmy@gmail.com',
  'supportaxonaccadmy@gmail.com',
  'pmgautam3917@gmail.com',
  'thelearntheme@gmail.com',
];

const configuredAdminEmails = (import.meta.env.VITE_ADMIN_EMAILS || import.meta.env.VITE_ADMIN_EMAIL || '')
  .split(',')
  .map((e: string) => e.trim().toLowerCase())
  .filter(Boolean);

export const DESIGNATED_ADMIN_EMAILS: string[] = Array.from(
  new Set([
    ...BUILT_IN_ADMIN_EMAILS.map((e) => e.toLowerCase()),
    ...configuredAdminEmails,
  ])
);

/**
 * Checks whether an email address belongs to the designated admin list.
 */
export function isDesignatedAdminEmail(email?: string | null): boolean {
  if (!email) return false;
  const cleanEmail = email.trim().toLowerCase();
  return cleanEmail === 'pmgautamjaipur@gmail.com' || DESIGNATED_ADMIN_EMAILS.includes(cleanEmail);
}
