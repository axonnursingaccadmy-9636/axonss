/**
 * Axon Nursing Academy - User & Role Types
 */

export type UserRole = 'student' | 'admin' | 'instructor';

export interface UserProfile {
  uid: string;
  fullName: string;
  email: string;
  role: 'student' | 'admin';
  isActive?: boolean;
  phone?: string;
  targetExam?: string;
  state?: string;
  qualification?: string;
  createdAt?: unknown;
  updatedAt?: unknown;
}

export interface User {
  id: string;
  uid: string;
  email: string;
  displayName: string;
  phoneNumber?: string;
  photoURL?: string;
  role: UserRole;
  createdAt: string;
  updatedAt: string;
  lastLoginAt?: string;
  isActive: boolean;
}

export interface StudentProfile extends User {
  role: 'student';
  targetExam?: 'NORCET' | 'NCLEX' | 'MSC_NURSING' | 'CHO' | 'BSC_NURSING' | 'OTHER';
  qualification?: string;
  city?: string;
  state?: string;
  enrolledCourseIds: string[];
  completedLessonIds: string[];
  testScores?: Record<string, number>;
}

export interface AdminProfile extends User {
  role: 'admin';
  permissions: string[];
  department?: string;
}
