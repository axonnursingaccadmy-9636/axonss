/**
 * Axon Nursing Academy - Toast Notification Types
 */
import React from 'react';

export type ToastType = 'success' | 'error' | 'warning' | 'info';

export type ToastPosition =
  | 'top-right'
  | 'top-center'
  | 'top-left'
  | 'bottom-right'
  | 'bottom-center'
  | 'bottom-left';

export interface ToastAction {
  label: string;
  onClick: () => void;
  variant?: 'primary' | 'secondary' | 'danger';
}

export interface ToastOptions {
  id?: string;
  type?: ToastType;
  title?: React.ReactNode;
  message: React.ReactNode;
  duration?: number; // In milliseconds. Default: 4000ms. Set to 0 or Infinity for persistent toasts.
  position?: ToastPosition;
  dismissible?: boolean; // Default: true
  action?: ToastAction;
  onDismiss?: () => void;
  icon?: React.ReactNode;
}

export interface ToastItemData {
  id: string;
  type: ToastType;
  title?: React.ReactNode;
  message: React.ReactNode;
  duration: number;
  position: ToastPosition;
  dismissible: boolean;
  action?: ToastAction;
  onDismiss?: () => void;
  icon?: React.ReactNode;
  createdAt: number;
}

export interface ToastPromiseMessages<T> {
  loading: React.ReactNode;
  success: React.ReactNode | ((data: T) => React.ReactNode);
  error: React.ReactNode | ((err: any) => React.ReactNode);
}

export interface ToastFunction {
  (message: React.ReactNode, options?: Partial<ToastOptions>): string;
  success: (message: React.ReactNode, options?: Partial<ToastOptions>) => string;
  error: (message: React.ReactNode, options?: Partial<ToastOptions>) => string;
  warning: (message: React.ReactNode, options?: Partial<ToastOptions>) => string;
  info: (message: React.ReactNode, options?: Partial<ToastOptions>) => string;
  promise: <T>(
    promise: Promise<T> | (() => Promise<T>),
    messages: ToastPromiseMessages<T>,
    options?: Partial<ToastOptions>
  ) => Promise<T>;
  dismiss: (id?: string) => void;
}

export interface ToastContextValue {
  toasts: ToastItemData[];
  toast: ToastFunction;
  dismiss: (id?: string) => void;
  dismissAll: () => void;
  position: ToastPosition;
  setPosition: (pos: ToastPosition) => void;
}
