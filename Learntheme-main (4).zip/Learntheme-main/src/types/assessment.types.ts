/**
 * Axon Nursing Academy - Phase 6 Real Production Test & MCQ Domain Types
 * Strict Separation:
 * 1. Weekly Warrior Tests: Course (Batch) -> Weekly Warrior Test -> Questions
 * 2. Unit MCQ Tests: Course (Batch) -> Subject -> Chapter -> Unit MCQ Test -> Questions
 */
import { Timestamp } from 'firebase/firestore';

export interface McqOption {
  id: string; // 'A' | 'B' | 'C' | 'D' or unique string
  text: string;
  imageUrl?: string;
}

/**
 * Weekly Warrior Course-Level Test
 */
export interface WeeklyWarriorTest {
  id: string;
  batchId: string; // Strictly Course-Level
  title: string;
  description?: string;
  durationMinutes: number;
  totalMarks: number;
  passingMarks: number;
  marksPerQuestion: number;
  negativeMarksPerQuestion: number;
  totalQuestions: number;
  instructions: string[];
  isPublished: boolean;
  order: number;
  scheduledStartTime?: string | null;
  scheduledEndTime?: string | null;
  allowReviewAfterSubmission: boolean;
  maxAttempts?: number;
  createdAt?: Timestamp | string | unknown;
  updatedAt?: Timestamp | string | unknown;
}

/**
 * Weekly Warrior Question
 */
export interface WeeklyWarriorQuestion {
  id: string;
  testId: string;
  batchId: string;
  questionText: string;
  questionImageUrl?: string;
  options: McqOption[];
  correctOptionId: string; // Kept secure, omitted for active test takers
  marks: number;
  negativeMarks: number;
  explanation?: string;
  explanationImageUrl?: string;
  subjectTag?: string;
  order: number;
  createdAt?: Timestamp | string | unknown;
  updatedAt?: Timestamp | string | unknown;
}

/**
 * Weekly Warrior Student Attempt
 */
export interface WeeklyWarriorAttempt {
  id: string;
  testId: string;
  batchId: string;
  studentId: string;
  studentName?: string;
  studentEmail?: string;
  status: 'in_progress' | 'completed' | 'abandoned';
  startedAt: string;
  completedAt?: string;
  timeRemainingSeconds: number;
  timeTakenSeconds: number;
  answers: Record<string, string>; // questionId -> optionId
  markedForReview: string[]; // questionId[]
  score?: number;
  totalMarks?: number;
  correctCount?: number;
  incorrectCount?: number;
  unattemptedCount?: number;
  accuracyPercentage?: number;
  isPassed?: boolean;
}

/**
 * Weekly Warrior Final Evaluated Result
 */
export interface WeeklyWarriorResult {
  id: string;
  attemptId: string;
  testId: string;
  batchId: string;
  studentId: string;
  studentName: string;
  studentEmail: string;
  score: number;
  totalMarks: number;
  passingMarks: number;
  totalQuestions: number;
  correctCount: number;
  incorrectCount: number;
  unattemptedCount: number;
  accuracyPercentage: number;
  accuracy?: number;
  timeTakenSeconds: number;
  timeSpentSeconds?: number;
  isPassed: boolean;
  submittedAt: string;
  rank?: number;
  percentile?: number;
  breakdownBySubject?: Record<string, { total: number; correct: number; score: number }>;
  subjectScores?: Record<string, { total: number; correct: number; marks: number; score?: number }>;
  answers?: Record<string, string>;
}

/**
 * Unit Chapter-Level MCQ Test
 */
export interface UnitTest {
  id: string;
  batchId: string;
  subjectId: string;
  chapterId: string;
  classId?: string;
  title: string;
  description?: string;
  durationMinutes: number;
  totalMarks: number;
  passingMarks: number;
  marksPerQuestion: number;
  negativeMarksPerQuestion: number;
  totalQuestions: number;
  instructions: string[];
  isPublished: boolean;
  order: number;
  allowReviewAfterSubmission: boolean;
  maxAttempts?: number;
  createdAt?: Timestamp | string | unknown;
  updatedAt?: Timestamp | string | unknown;
}

/**
 * Unit MCQ Question
 */
export interface UnitTestQuestion {
  id: string;
  testId: string;
  batchId: string;
  subjectId: string;
  chapterId: string;
  questionText: string;
  questionImageUrl?: string;
  options: McqOption[];
  correctOptionId: string; // Kept secure, omitted for active test takers
  marks: number;
  negativeMarks: number;
  explanation?: string;
  explanationImageUrl?: string;
  order: number;
  createdAt?: Timestamp | string | unknown;
  updatedAt?: Timestamp | string | unknown;
}

/**
 * Unit MCQ Student Attempt
 */
export interface UnitTestAttempt {
  id: string;
  testId: string;
  batchId: string;
  subjectId: string;
  chapterId: string;
  studentId: string;
  studentName?: string;
  studentEmail?: string;
  status: 'in_progress' | 'completed' | 'abandoned';
  startedAt: string;
  completedAt?: string;
  timeRemainingSeconds: number;
  timeTakenSeconds: number;
  answers: Record<string, string>; // questionId -> optionId
  markedForReview: string[];
  score?: number;
  totalMarks?: number;
  correctCount?: number;
  incorrectCount?: number;
  unattemptedCount?: number;
  accuracyPercentage?: number;
  isPassed?: boolean;
}

/**
 * Unit MCQ Final Evaluated Result
 */
export interface UnitTestResult {
  id: string;
  attemptId: string;
  testId: string;
  batchId: string;
  subjectId: string;
  chapterId: string;
  studentId: string;
  studentName: string;
  studentEmail: string;
  score: number;
  totalMarks: number;
  passingMarks: number;
  totalQuestions: number;
  correctCount: number;
  incorrectCount: number;
  unattemptedCount: number;
  accuracyPercentage: number;
  accuracy?: number;
  timeTakenSeconds: number;
  timeSpentSeconds?: number;
  isPassed: boolean;
  submittedAt: string;
  answers?: Record<string, string>;
  subjectScores?: Record<string, { total: number; correct: number; marks: number; score?: number }>;
}

/**
 * Safe Question shape for Active Test Player (no answer leaks)
 */
export interface PublicTestQuestion {
  id: string;
  testId: string;
  questionText: string;
  questionImageUrl?: string;
  options: McqOption[];
  marks: number;
  negativeMarks: number;
  order: number;
  subjectTag?: string;
}

export type StudentMcqQuestion = PublicTestQuestion;

export interface UserAnswerSubmission {
  questionId: string;
  selectedOptionId: string | null;
  isMarkedForReview: boolean;
}

/**
 * Detailed Question Review for post-submission Analysis
 */
export interface QuestionReviewItem {
  id: string;
  questionText: string;
  questionImageUrl?: string;
  options: McqOption[];
  selectedOptionId?: string;
  correctOptionId: string;
  isCorrect: boolean;
  isSkipped: boolean;
  marksAwarded: number;
  explanation?: string;
  explanationImageUrl?: string;
  subjectTag?: string;
}

