/**
 * Axon Nursing Academy - Student Enrollment & Access Types (Phase 6.1)
 * Authoritative course access tracking model.
 */

export type EnrollmentStatus = 'active' | 'expired' | 'revoked';

export interface Enrollment {
  id: string;
  userId: string;
  batchId: string;
  status: EnrollmentStatus;
  isFree: boolean;
  source?: 'purchase' | 'free_enrollment' | 'admin' | 'test_preview_enrollment';
  paymentProvider?: 'razorpay' | 'razorpay_preview_simulation' | null;
  paymentId?: string | null;
  orderId?: string | null;
  currency?: string;
  enrolledAt: string; // ISO date string
  expiresAt?: string | null; // ISO date string or null for lifetime
  couponCode?: string | null;
  amountPaid?: number;
  courseTitle?: string;
  courseThumbnail?: string;
  createdAt?: any;
  updatedAt?: any;
}

export interface CourseAccessCheck {
  hasAccess: boolean;
  isAdmin?: boolean;
  status?: EnrollmentStatus | 'not_enrolled';
  reason?: string;
  enrollment?: Enrollment | null;
  expiresAt?: string | null;
  isFreeCourse?: boolean;
}
