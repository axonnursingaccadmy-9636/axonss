/**
 * Axon Nursing Academy - Content, Notice, Banner & Interactive Types
 */

export interface Banner {
  id: string;
  title: string;
  subtitle?: string;
  ctaText: string;
  targetRoute: string;
  imageUrl?: string;
  badge?: string;
  backgroundColorClass?: string;
  isActive: boolean;
}

export interface LiveClass {
  id: string;
  courseId: string;
  title: string;
  subject: string;
  instructor: string;
  scheduledTime: string;
  durationMinutes: number;
  status: 'upcoming' | 'live' | 'completed';
  joinUrl?: string;
}

export interface Notice {
  id: string;
  title: string;
  content: string;
  priority: 'low' | 'normal' | 'urgent';
  createdAt: string;
  category: 'General' | 'Exam Alert' | 'Batch Update' | 'Results';
  linkUrl?: string;
}

export interface Testimonial {
  id: string;
  name: string;
  rankOrPost: string;
  exam: string;
  testimonial: string;
  avatarUrl?: string;
  rating: number;
}

export interface QuickActionItem {
  id: string;
  title: string;
  iconName: string;
  route: string;
  colorClass: string;
  bgClass: string;
  badge?: string;
}

export interface CategoryCardItem {
  id: string;
  title: string;
  subtitle?: string;
  iconName: string;
  colorClass: string;
  bgClass: string;
  countLabel?: string;
  route: string;
}
