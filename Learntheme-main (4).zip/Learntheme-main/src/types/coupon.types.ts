/**
 * Axon Nursing Academy - Admin-Managed Coupon Types (Phase 6.1)
 * Real, simple, admin-created coupon model and validation schema.
 */

export type CouponDiscountType = 'percentage' | 'fixed';

export interface Coupon {
  id: string;
  code: string;
  discountType: CouponDiscountType;
  discountValue: number;
  isActive: boolean;
  validFrom: string; // ISO date string
  validUntil: string; // ISO date string
  usageLimit: number;
  usedCount: number;
  applicableCourseIds: string[]; // ['all'] or array of batchIds
  description?: string;
  createdBy?: string;
  createdAt?: any;
  updatedAt?: any;
}

export interface CouponFormData {
  code: string;
  discountType: CouponDiscountType;
  discountValue: number;
  isActive: boolean;
  validFrom: string;
  validUntil: string;
  usageLimit: number;
  applicableCourseIds: string[];
  description?: string;
}

export interface CouponValidationResult {
  isValid: boolean;
  error?: string;
  coupon?: Coupon;
  discountAmount?: number;
  finalPrice?: number;
}
