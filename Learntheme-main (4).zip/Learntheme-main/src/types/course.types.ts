/**
 * Axon Nursing Academy - Course & Content Domain Types
 */

export type CourseCategory =
  | 'NORCET'
  | 'NCLEX_RN'
  | 'MSC_NURSING'
  | 'CHO_STAFF_NURSE'
  | 'FOUNDATION'
  | 'TEST_SERIES';

export type CourseAccessStatus = 'active' | 'expired' | 'locked' | 'preview';

export interface Course {
  id: string;
  title: string;
  slug: string;
  subtitle?: string;
  description: string;
  category: CourseCategory;
  thumbnailUrl: string;
  bannerUrl?: string;
  originalPrice: number;
  discountedPrice: number;
  isPurchased?: boolean;
  isFeatured?: boolean;
  isTrending?: boolean;
  rating: number;
  totalRatingsCount: number;
  totalEnrollments: number;
  validityDays: number;
  language: 'Hinglish' | 'English' | 'Hindi';
  faculty: {
    name: string;
    designation: string;
    avatarUrl?: string;
  };
  features: string[];
  totalLectures: number;
  totalPdfs: number;
  totalTests: number;
  totalLiveHours: number;
  createdAt: string;
  updatedAt: string;
}

export interface LegacyBatch {
  id: string;
  courseId: string;
  name: string;
  startDate: string;
  endDate: string;
  scheduleDescription: string;
  subjectIds: string[];
}

export interface LegacySubject {
  id: string;
  courseId: string;
  title: string;
  code?: string;
  thumbnailUrl?: string;
  totalChapters: number;
  totalHours: number;
  order: number;
}

export interface LegacyChapter {
  id: string;
  subjectId: string;
  title: string;
  order: number;
  totalVideos: number;
  totalPdfs: number;
}

export interface VideoLecture {
  id: string;
  chapterId: string;
  title: string;
  durationMinutes: number;
  videoUrl?: string; // Cloud / YouTube protected URL in Phase 2
  isFreePreview: boolean;
  order: number;
}

export interface LegacyPdfNote {
  id: string;
  chapterId: string;
  title: string;
  fileSizeMb: number;
  totalPages: number;
  fileUrl?: string;
  isDownloadable: boolean;
  order: number;
}


export interface Enrollment {
  id: string;
  studentId: string;
  courseId: string;
  purchasedAt: string;
  expiresAt: string;
  amountPaid: number;
  paymentId: string;
  status: 'active' | 'expired' | 'revoked';
  progressPercentage: number;
}
