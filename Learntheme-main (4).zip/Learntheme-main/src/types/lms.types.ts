/**
 * Axon Nursing Academy - Phase 3 Real Firestore LMS Hierarchy Types
 * Batch (Course) -> Subject -> Chapter -> LmsClass (Lesson)
 */
import { Timestamp } from 'firebase/firestore';

export interface Batch {
  id: string;
  title: string;
  slug: string;
  shortDescription: string;
  description: string;
  thumbnailUrl: string;
  bannerUrl: string;
  price: number;
  originalPrice: number;
  durationDays: number;
  duration?: string;
  isFree: boolean;
  isFeatured: boolean;
  isPublished: boolean;
  order: number;
  createdAt?: Timestamp | string | unknown;
  updatedAt?: Timestamp | string | unknown;
}

export interface Subject {
  id: string;
  batchId: string;
  name: string;
  description: string;
  thumbnailUrl: string;
  order: number;
  isPublished: boolean;
  createdAt?: Timestamp | string | unknown;
  updatedAt?: Timestamp | string | unknown;
}

export interface Chapter {
  id: string;
  batchId: string;
  subjectId: string;
  name: string;
  description: string;
  order: number;
  isPublished: boolean;
  createdAt?: Timestamp | string | unknown;
  updatedAt?: Timestamp | string | unknown;
}

export interface LmsClass {
  id: string;
  batchId: string;
  subjectId: string;
  chapterId: string;
  title: string;
  description: string;
  videoUrl: string;
  youtubeVideoId?: string;
  youtubeUrl?: string;
  videoProvider?: 'youtube' | 'direct' | 'vimeo';
  durationMinutes: number;
  thumbnailUrl: string;
  order: number;
  isFree: boolean;
  isPublished: boolean;
  createdAt?: Timestamp | string | unknown;
  updatedAt?: Timestamp | string | unknown;
}

export interface PdfNote {
  id: string;
  batchId: string;
  subjectId: string;
  chapterId: string;
  classId?: string;
  title: string;
  description?: string;
  fileUrl: string;
  storagePath: string;
  fileName: string;
  fileSizeBytes: number;
  pageCount?: number;
  order: number;
  isFree: boolean;
  isPublished: boolean;
  createdAt?: Timestamp | string | unknown;
  updatedAt?: Timestamp | string | unknown;
}

