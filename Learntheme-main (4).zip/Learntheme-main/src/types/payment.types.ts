/**
 * Axon Nursing Academy - Payment & Transaction Types (Phase 7 Razorpay Integration)
 * Authoritative payment and order tracking model.
 */

export type PaymentStatus = 'created' | 'paid' | 'failed' | 'refunded';

export interface PaymentRecord {
  id: string; // e.g. pay_ord_...
  userId: string; // Authenticated Firebase Student UID
  studentEmail?: string;
  studentName?: string;
  courseId: string; // Batch / Course ID
  courseTitle?: string;
  orderId: string; // Razorpay Order ID
  paymentId?: string | null; // Razorpay Payment ID (after verification)
  amount: number; // Final amount in INR
  amountInPaise: number; // Razorpay smallest currency unit
  originalAmount?: number; // Pre-discount course price
  discountAmount?: number; // Discount applied from coupon
  couponId?: string | null;
  couponCode?: string | null;
  currency: 'INR';
  status: PaymentStatus;
  createdAt: string;
  updatedAt: string;
  verifiedAt?: string | null;
  errorReason?: string | null;
}

export type Payment = PaymentRecord;

export interface RazorpayOrderResponse {
  orderId: string;
  amount: number; // in paise
  currency: string;
  keyId: string;
  isLiveMode?: boolean;
  courseTitle: string;
  courseDescription?: string;
  studentName?: string;
  studentEmail?: string;
}

export interface RazorpayVerificationPayload {
  razorpay_order_id: string;
  razorpay_payment_id: string;
  razorpay_signature: string;
  courseId: string;
}

export interface PaymentConfigStatus {
  configured: boolean;
  keyId: string | null;
  isLiveMode?: boolean;
}
