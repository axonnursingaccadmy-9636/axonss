/**
 * Axon Nursing Academy - Audit Log Types (Phase 4 CMS)
 */
import { Timestamp } from 'firebase/firestore';

export type AuditActionType =
  | 'BATCH_CREATED'
  | 'BATCH_UPDATED'
  | 'BATCH_DELETED'
  | 'BATCH_PUBLISHED'
  | 'BATCH_UNPUBLISHED'
  | 'SUBJECT_CREATED'
  | 'SUBJECT_UPDATED'
  | 'SUBJECT_DELETED'
  | 'SUBJECT_PUBLISHED'
  | 'SUBJECT_UNPUBLISHED'
  | 'CHAPTER_CREATED'
  | 'CHAPTER_UPDATED'
  | 'CHAPTER_DELETED'
  | 'CHAPTER_PUBLISHED'
  | 'CHAPTER_UNPUBLISHED'
  | 'CLASS_CREATED'
  | 'CLASS_UPDATED'
  | 'CLASS_DELETED'
  | 'CLASS_PUBLISHED'
  | 'CLASS_UNPUBLISHED'
  | 'PDF_NOTE_CREATED'
  | 'PDF_NOTE_UPDATED'
  | 'PDF_NOTE_DELETED'
  | 'PDF_NOTE_PUBLISHED'
  | 'PDF_NOTE_UNPUBLISHED'
  | 'DATABASE_SEEDED';

export interface AuditLog {
  id: string;
  actorUid: string;
  actorEmail?: string;
  action: AuditActionType | string;
  resourceType:
    | 'batch'
    | 'subject'
    | 'chapter'
    | 'class'
    | 'pdfNote'
    | 'database'
    | 'weekly_warrior_test'
    | 'weekly_warrior_question'
    | 'unit_test'
    | 'unit_test_question'
    | 'assessment';
  resourceId: string;
  resourceTitle?: string;
  details?: Record<string, any>;
  timestamp: Timestamp | string | unknown;
}

