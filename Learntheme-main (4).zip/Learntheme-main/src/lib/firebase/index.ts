/**
 * Axon Nursing Academy - Firebase Unified Client SDK Export
 * Central barrel module exporting App, Config, Auth, Firestore, and Storage.
 */

// Core Configuration & App Initializer
export * from './config';
export * from './firebase';

// Firebase Authentication
export * from './auth';

// Firestore Database & Collections
export * from './firestore';

// Cloud Storage & Storage Paths
export * from './storage';
