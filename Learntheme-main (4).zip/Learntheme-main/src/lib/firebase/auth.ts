/**
 * Axon Nursing Academy - Firebase Authentication Architecture Layer
 * Provides centralized, persisted Firebase Auth instance for production.
 */
import { getAuth, Auth, browserLocalPersistence, setPersistence } from 'firebase/auth';
import { getFirebaseApp } from './firebase';

let authInstance: Auth | null = null;

export function getFirebaseAuth(): Auth | null {
  const app = getFirebaseApp();
  if (!app) return null;
  if (!authInstance) {
    try {
      authInstance = getAuth(app);
      // Explicitly configure browser local persistence for web application session persistence
      if (typeof window !== 'undefined') {
        setPersistence(authInstance, browserLocalPersistence).catch(() => {
          // Gracefully fallback to default persistence if storage is restricted
        });
      }
    } catch (error) {
      console.warn('[Firebase Auth] Initialization error:', error);
      return null;
    }
  }
  return authInstance;
}

export const auth = getFirebaseAuth();
