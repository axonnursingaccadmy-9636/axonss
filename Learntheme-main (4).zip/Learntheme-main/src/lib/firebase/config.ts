/**
 * Axon Nursing Academy - Firebase Configuration Layer
 * Safe environment reading with fallback validation.
 */

import appletConfig from '@/firebase-applet-config.json';

export interface FirebaseClientConfig {
  apiKey: string;
  authDomain: string;
  databaseURL?: string;
  projectId: string;
  storageBucket: string;
  messagingSenderId: string;
  appId: string;
  measurementId?: string;
}

const env = (typeof import.meta !== 'undefined' && import.meta.env) ? import.meta.env : (process.env as any || {});

// Self-healing sanitization to protect against accidental typos in deployment environment variables
const rawProjectId = (env.VITE_FIREBASE_PROJECT_ID || env.FIREBASE_PROJECT_ID || appletConfig?.projectId || 'axon-nursing-institute').trim();
const resolvedProjectId =
  rawProjectId === 'xon-nursing-institute' || /^\d+$/.test(rawProjectId)
    ? 'axon-nursing-institute'
    : (rawProjectId || 'axon-nursing-institute');

const rawAuthDomain = (env.VITE_FIREBASE_AUTH_DOMAIN || env.FIREBASE_AUTH_DOMAIN || appletConfig?.authDomain || 'axon-nursing-institute.firebaseapp.com').trim();
const resolvedAuthDomain =
  rawAuthDomain.startsWith('xon-nursing') || /^\d+$/.test(rawAuthDomain)
    ? 'axon-nursing-institute.firebaseapp.com'
    : (rawAuthDomain || 'axon-nursing-institute.firebaseapp.com');

const rawStorageBucket = (env.VITE_FIREBASE_STORAGE_BUCKET || env.FIREBASE_STORAGE_BUCKET || appletConfig?.storageBucket || 'axon-nursing-institute.firebasestorage.app').trim();
const resolvedStorageBucket =
  rawStorageBucket.startsWith('xon-nursing') || /^\d+$/.test(rawStorageBucket)
    ? 'axon-nursing-institute.firebasestorage.app'
    : (rawStorageBucket || 'axon-nursing-institute.firebasestorage.app');

export const firebaseConfig: FirebaseClientConfig = {
  apiKey: (env.VITE_FIREBASE_API_KEY || env.FIREBASE_API_KEY || appletConfig?.apiKey || 'AIzaSyBAqhQaL3W_8mdqvD1jbTqESP09sSHU0bg').trim(),
  authDomain: resolvedAuthDomain,
  databaseURL: env.VITE_FIREBASE_DATABASE_URL || env.FIREBASE_DATABASE_URL || (appletConfig as any)?.databaseURL || 'https://axon-nursing-institute-default-rtdb.firebaseio.com',
  projectId: resolvedProjectId,
  storageBucket: resolvedStorageBucket,
  messagingSenderId: (env.VITE_FIREBASE_MESSAGING_SENDER_ID || env.FIREBASE_MESSAGING_SENDER_ID || appletConfig?.messagingSenderId || '497931821659').trim(),
  appId: (env.VITE_FIREBASE_APP_ID || env.FIREBASE_APP_ID || appletConfig?.appId || '1:497931821659:web:ea12e140413a241e95d57e').trim(),
  measurementId: (env.VITE_FIREBASE_MEASUREMENT_ID || env.FIREBASE_MEASUREMENT_ID || appletConfig?.measurementId || 'G-GRJHPMNZM7').trim(),
};

const rawRecaptchaKey = (env.VITE_RECAPTCHA_ENTERPRISE_SITE_KEY || '').trim();
export const recaptchaEnterpriseSiteKey = rawRecaptchaKey.startsWith('6L') && rawRecaptchaKey.length >= 30 ? rawRecaptchaKey : '';
export const appCheckDebugToken = '';

/**
 * Checks if client Firebase credentials have been configured.
 * In Phase 0, this will return false gracefully without crashing the UI.
 */
export function isFirebaseConfigured(): boolean {
  return Boolean(
    firebaseConfig.apiKey &&
    firebaseConfig.projectId &&
    firebaseConfig.authDomain
  );
}
