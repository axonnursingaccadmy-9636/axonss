/**
 * Axon Nursing Academy - Centralized Firestore Initialization & Error Handling
 * Singleton Firestore client instance and unified error formatting.
 */
import { getFirestore, initializeFirestore, Firestore } from 'firebase/firestore';
import { getFirebaseApp } from './firebase';
import { getFirebaseAuth } from './auth';

export const FIRESTORE_COLLECTIONS = {
  USERS: 'users',
  STUDENTS: 'students',
  ADMINS: 'admins',
  COURSES: 'courses',
  BATCHES: 'batches',
  SUBJECTS: 'subjects',
  CHAPTERS: 'chapters',
  CLASSES: 'classes',
  LECTURES: 'lectures',
  PDF_NOTES: 'pdf_notes',
  TESTS: 'tests',
  QUESTIONS: 'questions',
  ENROLLMENTS: 'enrollments',
  COUPONS: 'coupons',
  PAYMENTS: 'payments',
  LIVE_CLASSES: 'live_classes',
  NOTICES: 'notices',
  BANNERS: 'banners',
  TESTIMONIALS: 'testimonials',
} as const;

let firestoreInstance: Firestore | null = null;

export function getFirestoreDb(): Firestore | null {
  if (firestoreInstance) return firestoreInstance;

  const app = getFirebaseApp();
  if (!app) return null;

  try {
    firestoreInstance = initializeFirestore(app, {
      experimentalAutoDetectLongPolling: true,
    });
    return firestoreInstance;
  } catch {
    try {
      firestoreInstance = getFirestore(app);
      return firestoreInstance;
    } catch (error) {
      console.warn('[Firestore] Initialization skipped or deferred:', error);
      return null;
    }
  }
}

export const db = getFirestoreDb();

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
  };
}

export function formatFirestoreErrorMessage(error: unknown): string {
  if (!error) return 'An unexpected database error occurred.';
  const msg = error instanceof Error ? error.message : String(error);
  if (msg.includes('offline') || msg.includes('unavailable') || msg.includes('network')) {
    return 'Database is currently working in offline mode or network connection is unavailable.';
  }
  if (msg.includes('permission-denied') || msg.includes('Missing or insufficient permissions')) {
    return 'Access denied. You do not have permission to perform this database operation.';
  }
  if (msg.includes('not-found')) {
    return 'The requested record was not found.';
  }
  return msg;
}

export function handleFirestoreError(
  error: unknown,
  operationType: OperationType,
  path: string | null
): never {
  const auth = getFirebaseAuth();
  const currentAuthUser = auth?.currentUser;

  const rawMessage = error instanceof Error ? error.message : String(error);
  const friendlyMessage = formatFirestoreErrorMessage(error);

  const isOfflineOrUnavailable =
    rawMessage.includes('offline') ||
    rawMessage.includes('unavailable') ||
    rawMessage.includes('network') ||
    rawMessage.includes('Could not reach Cloud Firestore backend');

  // Only warn if it's transient offline/network
  if (isOfflineOrUnavailable) {
    console.warn(`[Firestore Offline Notice] ${operationType} on ${path}:`, rawMessage);
  } else {
    console.warn(`[Firestore Warning] ${operationType} on ${path}:`, rawMessage);
  }

  throw new Error(friendlyMessage);
}
