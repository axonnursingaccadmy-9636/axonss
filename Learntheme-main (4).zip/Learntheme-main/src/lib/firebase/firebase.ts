/**
 * Axon Nursing Academy - Firebase App Initializer
 * Initializes Firebase safely only if valid environment keys are supplied.
 */
import { initializeApp, getApps, getApp, FirebaseApp } from 'firebase/app';
import { getAnalytics, isSupported, Analytics } from 'firebase/analytics';
import { initializeAppCheck, ReCaptchaEnterpriseProvider, AppCheck } from 'firebase/app-check';
import { firebaseConfig, isFirebaseConfigured, recaptchaEnterpriseSiteKey, appCheckDebugToken } from './config';

let app: FirebaseApp | null = null;
let analytics: Analytics | null = null;
let appCheck: AppCheck | null = null;

export function getFirebaseApp(): FirebaseApp | null {
  if (!isFirebaseConfigured()) {
    return null;
  }

  if (!app) {
    app = getApps().length > 0 ? getApp() : initializeApp(firebaseConfig);
  }

  return app;
}

export function initAppCheck(_targetApp?: FirebaseApp | null): AppCheck | null {
  return null;
}

export async function getFirebaseAnalytics(): Promise<Analytics | null> {
  const currentApp = getFirebaseApp();
  if (!currentApp || typeof window === 'undefined') {
    return null;
  }
  if (!analytics) {
    try {
      const supported = await isSupported();
      if (supported) {
        analytics = getAnalytics(currentApp);
      }
    } catch {
      // Benign if analytics is disabled in restricted environments
    }
  }
  return analytics;
}

export const firebaseApp = getFirebaseApp();
