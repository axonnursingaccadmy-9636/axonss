/**
 * Axon Nursing Academy - Firebase Storage Architecture Layer
 * (Architectural preparation for Phase 3 Media & PDF Storage)
 * DO NOT implement file upload logic in Phase 0.
 */
import { getStorage, FirebaseStorage } from 'firebase/storage';
import { getFirebaseApp } from './firebase';

export const STORAGE_PATHS = {
  COURSE_THUMBNAILS: 'courses/thumbnails',
  COURSE_BANNERS: 'courses/banners',
  PDF_NOTES: 'courses/pdfs',
  USER_AVATARS: 'users/avatars',
  QUESTION_IMAGES: 'tests/questions',
  BANNER_IMAGES: 'banners',
  BRANDING: 'branding',
} as const;

export function getFirebaseStorageInstance(): FirebaseStorage | null {
  const app = getFirebaseApp();
  if (!app) return null;
  try {
    return getStorage(app);
  } catch (error) {
    console.warn('[Firebase Storage] Initialization skipped or deferred:', error);
    return null;
  }
}

export const storage = getFirebaseStorageInstance();
