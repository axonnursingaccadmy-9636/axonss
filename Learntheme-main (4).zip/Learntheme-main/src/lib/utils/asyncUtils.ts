/**
 * Axon Nursing Academy - Async Utilities
 * Provides bounded timeouts for network/Firestore operations to guarantee
 * near-instant UI response times and prevent long spinner hangs.
 */

export async function withTimeout<T>(
  promise: Promise<T>,
  timeoutMs = 1500,
  fallbackVal?: T
): Promise<T> {
  let timer: any;
  const timeoutPromise = new Promise<T>((resolve, reject) => {
    timer = setTimeout(() => {
      if (fallbackVal !== undefined) {
        resolve(fallbackVal);
      } else {
        reject(new Error(`Operation timed out after ${timeoutMs}ms`));
      }
    }, timeoutMs);
  });

  try {
    const result = await Promise.race([promise, timeoutPromise]);
    clearTimeout(timer);
    return result;
  } catch (err) {
    clearTimeout(timer);
    if (fallbackVal !== undefined) {
      return fallbackVal;
    }
    throw err;
  }
}
