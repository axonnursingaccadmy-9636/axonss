/**
 * Axon Nursing Academy - YouTube Utility Functions
 * Parses, validates, and builds embed and thumbnail URLs for YouTube educational videos.
 */

// Regular expressions for matching various YouTube URL formats
const YOUTUBE_REGEX =
  /(?:https?:\/\/)?(?:www\.|m\.)?(?:youtube\.com\/(?:watch\?(?:.*&)?v=|embed\/|v\/|shorts\/)|youtu\.be\/)([a-zA-Z0-9_-]{11})/;

const YOUTUBE_ID_ONLY_REGEX = /^[a-zA-Z0-9_-]{11}$/;

/**
 * Extracts the 11-character YouTube video ID from a URL or raw ID.
 */
export function extractYouTubeVideoId(input: string | null | undefined): string | null {
  if (!input) return null;
  const trimmed = input.trim();

  // If already an 11-character ID
  if (YOUTUBE_ID_ONLY_REGEX.test(trimmed)) {
    return trimmed;
  }

  const match = trimmed.match(YOUTUBE_REGEX);
  if (match && match[1]) {
    return match[1];
  }

  return null;
}

/**
 * Checks if a given input string is a valid YouTube URL or video ID.
 */
export function isValidYouTubeUrl(input: string | null | undefined): boolean {
  return extractYouTubeVideoId(input) !== null;
}

export interface YouTubeEmbedOptions {
  autoPlay?: boolean;
  rel?: 0 | 1;
  modestbranding?: 0 | 1;
  controls?: 0 | 1;
  enablejsapi?: 0 | 1;
  origin?: string;
}

/**
 * Builds a privacy-enhanced YouTube embed URL from a video ID or URL.
 */
export function getYouTubeEmbedUrl(
  videoIdOrUrl: string | null | undefined,
  options: YouTubeEmbedOptions = {}
): string | null {
  const videoId = extractYouTubeVideoId(videoIdOrUrl);
  if (!videoId) return null;

  const {
    autoPlay = false,
    rel = 0,
    modestbranding = 1,
    controls = 1,
    enablejsapi = 0,
  } = options;

  const params = new URLSearchParams();
  if (autoPlay) params.set('autoplay', '1');
  params.set('rel', String(rel));
  params.set('modestbranding', String(modestbranding));
  params.set('controls', String(controls));
  if (enablejsapi) params.set('enablejsapi', '1');

  const queryString = params.toString();
  return `https://www.youtube-nocookie.com/embed/${videoId}${queryString ? `?${queryString}` : ''}`;
}

export type YouTubeThumbnailQuality = 'default' | 'mq' | 'hq' | 'sd' | 'maxres';

/**
 * Returns the CDN thumbnail image URL for a YouTube video.
 * Quality:
 * - default: 120x90
 * - mq: 320x180 (Medium Quality)
 * - hq: 480x360 (High Quality)
 * - sd: 640x480 (Standard Def)
 * - maxres: 1280x720 (Max Resolution)
 */
export function getYouTubeThumbnailUrl(
  videoIdOrUrl: string | null | undefined,
  quality: YouTubeThumbnailQuality = 'hq'
): string | null {
  const videoId = extractYouTubeVideoId(videoIdOrUrl);
  if (!videoId) return null;

  const qualityMap: Record<YouTubeThumbnailQuality, string> = {
    default: 'default.jpg',
    mq: 'mqdefault.jpg',
    hq: 'hqdefault.jpg',
    sd: 'sddefault.jpg',
    maxres: 'maxresdefault.jpg',
  };

  const fileName = qualityMap[quality] || 'hqdefault.jpg';
  return `https://img.youtube.com/vi/${videoId}/${fileName}`;
}

/**
 * Normalizes any YouTube URL or ID into a canonical YouTube watch URL.
 */
export function getYouTubeWatchUrl(videoIdOrUrl: string | null | undefined): string | null {
  const videoId = extractYouTubeVideoId(videoIdOrUrl);
  if (!videoId) return null;
  return `https://www.youtube.com/watch?v=${videoId}`;
}

// Convenient aliases for consistent API usage
export const buildYouTubeThumbnailUrl = getYouTubeThumbnailUrl;
export const buildYouTubeWatchUrl = getYouTubeWatchUrl;
export const buildYouTubeEmbedUrl = getYouTubeEmbedUrl;
export function isValidYouTubeId(id: string | null | undefined): boolean {
  if (!id) return false;
  return YOUTUBE_ID_ONLY_REGEX.test(id.trim());
}
