/**
 * Axon Nursing Academy - Phase 0 Static UI Showcase Data
 *
 * NOTE:
 * This file contains strictly separated static visual showcase data
 * for Phase 0 frontend layout preview.
 * In Phase 1 & 2, this will be replaced with live Firebase Firestore data.
 */

import { Course, Banner, Testimonial, Notice, QuickActionItem, CategoryCardItem } from '@/src/types';

export const DEMO_BANNERS: Banner[] = [
  {
    id: 'b1',
    title: 'NORCET 8.0 Crash Course & Test Series',
    subtitle: 'Comprehensive 90-Day Clinical & Nursing Science Intensive with Live Doubts',
    ctaText: 'Explore Batch',
    targetRoute: '/student/all-courses',
    badge: 'LIVE ADMISSION',
    backgroundColorClass: 'from-blue-700 via-blue-800 to-indigo-900',
    isActive: true,
  },
  {
    id: 'b2',
    title: 'NCLEX-RN NextGen Masterclass 2026',
    subtitle: 'Clinical Judgment Measurement Model (CJMM) & High-Yield Case Studies',
    ctaText: 'View Details',
    targetRoute: '/student/all-courses',
    badge: 'INTERNATIONAL',
    backgroundColorClass: 'from-sky-700 via-blue-800 to-slate-900',
    isActive: true,
  },
  {
    id: 'b3',
    title: 'Daily High-Yield MCQ Practice Marathon',
    subtitle: 'Systematic Subject-Wise Questions with In-Depth Clinical Rationales',
    ctaText: 'Start Testing',
    targetRoute: '/student/all-courses',
    badge: 'DAILY TESTS',
    backgroundColorClass: 'from-indigo-800 via-blue-900 to-slate-900',
    isActive: true,
  },
];

export const DEMO_QUICK_ACTIONS: QuickActionItem[] = [
  {
    id: 'live-classes',
    title: 'Live Classes',
    iconName: 'Video',
    route: '/student/all-courses',
    colorClass: 'text-rose-600',
    bgClass: 'bg-rose-50 border-rose-100',
    badge: 'Live',
  },
  {
    id: 'test-series',
    title: 'Test Series',
    iconName: 'FileCheck',
    route: '/student/all-courses',
    colorClass: 'text-blue-600',
    bgClass: 'bg-blue-50 border-blue-100',
    badge: 'New',
  },
  {
    id: 'pdf-notes',
    title: 'PDF Notes',
    iconName: 'FileText',
    route: '/student/all-courses',
    colorClass: 'text-amber-600',
    bgClass: 'bg-amber-50 border-amber-100',
  },
  {
    id: 'pyq-bank',
    title: 'PYQ Papers',
    iconName: 'BookOpen',
    route: '/student/all-courses',
    colorClass: 'text-emerald-600',
    bgClass: 'bg-emerald-50 border-emerald-100',
  },
  {
    id: 'doubt-chat',
    title: 'Doubt Room',
    iconName: 'MessageSquare',
    route: '/student/chats',
    colorClass: 'text-purple-600',
    bgClass: 'bg-purple-50 border-purple-100',
  },
  {
    id: 'notice-board',
    title: 'Exam Alerts',
    iconName: 'Bell',
    route: '/student/all-courses',
    colorClass: 'text-cyan-600',
    bgClass: 'bg-cyan-50 border-cyan-100',
  },
];

export const DEMO_CATEGORIES: CategoryCardItem[] = [
  {
    id: 'norcet',
    title: 'NORCET & AIIMS Prep',
    subtitle: 'Nursing Officer Staff Grade-II',
    iconName: 'Hospital',
    colorClass: 'text-blue-700',
    bgClass: 'bg-blue-50/80 border-blue-100',
    route: '/student/all-courses',
  },
  {
    id: 'nclex',
    title: 'NCLEX-RN Next Gen',
    subtitle: 'USA, Canada & Australia Licensing',
    iconName: 'Globe',
    colorClass: 'text-indigo-700',
    bgClass: 'bg-indigo-50/80 border-indigo-100',
    route: '/student/all-courses',
  },
  {
    id: 'msc',
    title: 'M.Sc Nursing Entrance',
    subtitle: 'AIIMS, PGI, JIPMER, RUHS',
    iconName: 'GraduationCap',
    colorClass: 'text-teal-700',
    bgClass: 'bg-teal-50/80 border-teal-100',
    route: '/student/all-courses',
  },
  {
    id: 'cho',
    title: 'CHO & Staff Nurse',
    subtitle: 'State NHM & ESIC Recruitment',
    iconName: 'Stethoscope',
    colorClass: 'text-rose-700',
    bgClass: 'bg-rose-50/80 border-rose-100',
    route: '/student/all-courses',
  },
  {
    id: 'bsc',
    title: 'B.Sc Academic Foundation',
    subtitle: 'Year 1 to 4 Full Syllabus Support',
    iconName: 'BookMarked',
    colorClass: 'text-amber-700',
    bgClass: 'bg-amber-50/80 border-amber-100',
    route: '/student/all-courses',
  },
  {
    id: 'test-bank',
    title: 'Clinical Test Series',
    subtitle: 'Subject-wise & Grand Mock Exams',
    iconName: 'FileCheck2',
    colorClass: 'text-purple-700',
    bgClass: 'bg-purple-50/80 border-purple-100',
    route: '/student/all-courses',
  },
];

export const DEMO_FEATURED_COURSES: Course[] = [];

export const DEMO_PURCHASED_COURSES: Course[] = [];

export const DEMO_RECOMMENDED_COURSES: Course[] = [];

export const DEMO_TESTIMONIALS: Testimonial[] = [
  {
    id: 't1',
    name: 'Pooja Rawat',
    rankOrPost: 'Nursing Officer, AIIMS New Delhi (AIR 34 - NORCET)',
    exam: 'NORCET 7.0',
    testimonial: 'Axon Nursing Academy provided crystal-clear clinical concepts and standard mock tests. The image-based questions and faculty rationales were identical to the real exam.',
    avatarUrl: 'https://images.unsplash.com/photo-1594824813575-b6d85915d315?auto=format&fit=crop&w=200&q=80',
    rating: 5,
  },
  {
    id: 't2',
    name: 'Manish Gurjar',
    rankOrPost: 'Nursing Officer, AIIMS Rishikesh',
    exam: 'NORCET 6.0',
    testimonial: 'The system-wise PDF notes and daily live doubt sessions saved months of self-study. Best structured LMS for any nursing aspirant.',
    avatarUrl: 'https://images.unsplash.com/photo-1622253692010-333f2da6031d?auto=format&fit=crop&w=200&q=80',
    rating: 5,
  },
  {
    id: 't3',
    name: 'Simranjeet Kaur, RN',
    rankOrPost: 'Passed NCLEX-RN on 1st Attempt (85 Questions)',
    exam: 'NCLEX-RN USA',
    testimonial: 'NextGen clinical judgment case studies on Axon gave me the exact confidence needed. Bowtie and trend questions are top notch!',
    avatarUrl: 'https://images.unsplash.com/photo-1559839734-2b71ea197ec2?auto=format&fit=crop&w=200&q=80',
    rating: 5,
  },
];

export const DEMO_NOTICES: Notice[] = [
  {
    id: 'n1',
    title: 'NORCET 8.0 Official Notification & Exam Dates Released',
    content: 'All candidates are advised to verify application requirements. Special guideline session today at 7:00 PM.',
    priority: 'urgent',
    createdAt: '2026-03-01T10:00:00Z',
    category: 'Exam Alert',
  },
  {
    id: 'n2',
    title: 'Pharmacology Grand Revision Live Class Scheduled for Sunday',
    content: 'Prof. Sharma will cover Cardiovascular & Neuro Drugs with mnemonics and clinical scenarios.',
    priority: 'normal',
    createdAt: '2026-02-28T14:30:00Z',
    category: 'Batch Update',
  },
];
