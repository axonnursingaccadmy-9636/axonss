/**
 * Axon Nursing Academy - Application Routes Architecture & Route Protection Guards
 */
import React, { Suspense, lazy } from 'react';
import { Routes, Route, Navigate, useLocation, Outlet } from 'react-router-dom';
import { ShieldAlert, LogOut, PhoneCall } from 'lucide-react';
import { PublicLayout } from '@/src/layouts/PublicLayout/PublicLayout';
import { StudentLayout } from '@/src/layouts/StudentLayout/StudentLayout';
import { AdminLayout } from '@/src/layouts/AdminLayout/AdminLayout';
import { LoadingState } from '@/src/components/common/LoadingState';
import { Button } from '@/src/components/ui/Button';
import { useAuth } from '@/src/contexts/AuthContext';
import { ROUTES } from '@/src/config/routes.config';
import { SITE_CONFIG } from '@/src/config/site.config';

// Lazy-loaded pages for optimized bundle splitting
const HomePage = lazy(() => import('@/src/pages/public/HomePage'));
const LoginPage = lazy(() => import('@/src/pages/public/LoginPage'));
const SignupPage = lazy(() => import('@/src/pages/public/SignupPage'));
const ForgotPasswordPage = lazy(() => import('@/src/pages/public/ForgotPasswordPage'));
const NotFoundPage = lazy(() => import('@/src/pages/public/NotFoundPage'));

// Student Portal Pages
const StudentHomePage = lazy(() => import('@/src/pages/student/StudentHomePage'));
const StudentCoursesPage = lazy(() => import('@/src/pages/student/StudentCoursesPage'));
const StudentAllCoursesPage = lazy(() => import('@/src/pages/student/StudentAllCoursesPage'));
const StudentProfilePage = lazy(() => import('@/src/pages/student/StudentProfilePage'));
const StudentChatsPage = lazy(() => import('@/src/pages/student/StudentChatsPage'));

// LMS Hierarchy Pages (Phase 3)
const CourseDetailsPage = lazy(() => import('@/src/pages/student/CourseDetailsPage'));
const SubjectDetailsPage = lazy(() => import('@/src/pages/student/SubjectDetailsPage'));
const ChapterDetailsPage = lazy(() => import('@/src/pages/student/ChapterDetailsPage'));
const ClassDetailsPage = lazy(() => import('@/src/pages/student/ClassDetailsPage'));

// Phase 6 Assessment & Test Runner Pages
const TestPlayerPage = lazy(() => import('@/src/pages/student/TestPlayerPage'));
const TestResultPage = lazy(() => import('@/src/pages/student/TestResultPage'));

// Admin Management Portal Pages (Phase 4 CMS & Phase 6 Tests)
const AdminDashboardPage = lazy(() => import('@/src/pages/admin/AdminDashboardPage'));
const AdminBatchesPage = lazy(() => import('@/src/pages/admin/batches/AdminBatchesPage'));
const AdminSubjectsPage = lazy(() => import('@/src/pages/admin/subjects/AdminSubjectsPage'));
const AdminChaptersPage = lazy(() => import('@/src/pages/admin/chapters/AdminChaptersPage'));
const AdminClassesPage = lazy(() => import('@/src/pages/admin/classes/AdminClassesPage'));
const AdminVideoClassesPage = lazy(() => import('@/src/pages/admin/classes/AdminVideoClassesPage'));
const AdminPdfNotesPage = lazy(() => import('@/src/pages/admin/pdf-notes/AdminPdfNotesPage'));
const AdminAuditLogsPage = lazy(() => import('@/src/pages/admin/audit/AdminAuditLogsPage'));
const AdminStudentsPage = lazy(() => import('@/src/pages/admin/AdminStudentsPage'));
const AdminBrandingPage = lazy(() => import('@/src/pages/admin/settings/AdminBrandingPage'));
const AdminCouponsPage = lazy(() =>
  import('@/src/pages/admin/coupons/AdminCouponsPage').then((m) => ({ default: m.AdminCouponsPage }))
);
const AdminPaymentsPage = lazy(() => import('@/src/pages/admin/payments/AdminPaymentsPage'));
const AdminWeeklyWarriorPage = lazy(() => import('@/src/pages/admin/tests/AdminWeeklyWarriorPage'));
const AdminWeeklyWarriorQuestionsPage = lazy(
  () => import('@/src/pages/admin/tests/AdminWeeklyWarriorQuestionsPage')
);
const AdminUnitTestsPage = lazy(() => import('@/src/pages/admin/tests/AdminUnitTestsPage'));
const AdminUnitTestQuestionsPage = lazy(
  () => import('@/src/pages/admin/tests/AdminUnitTestQuestionsPage')
);

/**
 * Route protection guard for authenticated student areas.
 * Protects Student Dashboard pages and Premium Nursing Content from unauthorized access.
 * If unauthorized (unauthenticated), redirects immediately to /login with preserved return location.
 * If user account is deactivated (isActive === false), displays account resolution interface.
 */
function ProtectedStudentGuard() {
  const { isAuthenticated, isLoading, profile, logout } = useAuth();
  const location = useLocation();

  if (isLoading) {
    return <LoadingState message="Verifying student authorization..." fullScreen />;
  }

  if (!isAuthenticated) {
    return <Navigate to={ROUTES.LOGIN} state={{ from: location }} replace />;
  }

  // Account status check (deactivated accounts)
  if (profile && profile.isActive === false) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4">
        <div className="max-w-md w-full bg-white rounded-3xl border border-rose-100 p-6 sm:p-8 text-center shadow-lg">
          <div className="w-14 h-14 rounded-2xl bg-rose-100 text-rose-600 flex items-center justify-center mx-auto mb-4">
            <ShieldAlert className="w-7 h-7" />
          </div>
          <h2 className="text-xl font-bold text-slate-900 mb-2">Account Inactive</h2>
          <p className="text-xs text-slate-600 mb-6 leading-relaxed">
            Your student account is currently deactivated or pending administrative review. Please contact the {SITE_CONFIG.shortName} support desk to restore access.
          </p>

          <div className="space-y-3">
            <a href={`tel:${SITE_CONFIG.supportPhone}`} className="block">
              <Button
                variant="primary"
                fullWidth
                size="md"
                leftIcon={<PhoneCall className="w-4 h-4" />}
              >
                Contact Support ({SITE_CONFIG.supportPhone})
              </Button>
            </a>

            <Button
              variant="outline"
              fullWidth
              size="md"
              onClick={() => logout()}
              leftIcon={<LogOut className="w-4 h-4" />}
            >
              Sign Out
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return <Outlet />;
}

/**
 * Route protection guard for administrative dashboard and CMS management pages.
 * Strictly verifies credentials using AuthContext:
 * - If unauthenticated: redirects to /login with preserved location.
 * - If authenticated but not an admin: redirects unauthorized users away to /student.
 */
function ProtectedAdminGuard() {
  const { currentUser, profile, isAuthenticated, isAdmin, isLoading, profileLoading } = useAuth();
  const location = useLocation();

  if (isLoading || (currentUser && profileLoading && !profile)) {
    return <LoadingState message="Verifying administrative credentials..." fullScreen />;
  }

  if (!isAuthenticated) {
    return <Navigate to={ROUTES.LOGIN} state={{ from: location }} replace />;
  }

  if (!isAdmin) {
    // Unauthorized user attempted to access admin dashboard -> redirect away to student portal
    return <Navigate to={ROUTES.STUDENT.ROOT} replace />;
  }

  return <Outlet />;
}

/**
 * Redirects already-authenticated users away from public auth pages (login, signup)
 * to their respective dashboard portal.
 */
function PublicAuthGuard() {
  const { isAuthenticated, isAdmin, isLoading } = useAuth();

  if (isLoading) {
    return <LoadingState message="Checking session..." fullScreen />;
  }

  if (isAuthenticated) {
    return <Navigate to={isAdmin ? ROUTES.ADMIN.DASHBOARD : ROUTES.STUDENT.ROOT} replace />;
  }

  return <Outlet />;
}

export function AppRoutes() {
  return (
    <Suspense fallback={<LoadingState message="Loading Axon Academy..." fullScreen />}>
      <Routes>
        {/* Public Landing & Information Routes */}
        <Route element={<PublicLayout />}>
          <Route path="/" element={<HomePage />} />
          <Route element={<PublicAuthGuard />}>
            <Route path="/login" element={<LoginPage />} />
            <Route path="/signup" element={<SignupPage />} />
            <Route path="/forgot-password" element={<ForgotPasswordPage />} />
          </Route>
        </Route>

        {/* Public Browsable Course Catalog & Batch Syllabus Overviews */}
        <Route element={<StudentLayout />}>
          <Route path="/courses" element={<StudentAllCoursesPage />} />
          <Route path="/student/all-courses" element={<StudentAllCoursesPage />} />
          <Route path="/course/:batchId" element={<CourseDetailsPage />} />
        </Route>

        {/* Protected Premium Nursing Content & Student Dashboard Routes */}
        <Route element={<ProtectedStudentGuard />}>
          {/* Distraction-Free Test Taking Engine & Solution Review */}
          <Route path="/test/:testType/:testId" element={<TestPlayerPage />} />
          <Route path="/test/:testType/:testId/result/:attemptId" element={<TestResultPage />} />

          {/* Full-Page Clinical Doubt Room (Axon AI) */}
          <Route path="/student/chats" element={<StudentChatsPage />} />
          <Route path="/chats" element={<Navigate to="/student/chats" replace />} />
          <Route path="/axon-ai" element={<Navigate to="/student/chats" replace />} />

          {/* Student Portal Shell Layout */}
          <Route element={<StudentLayout />}>
            {/* Student Dashboard Pages */}
            <Route path="/student" element={<StudentHomePage />} />
            <Route path="/student/courses" element={<StudentCoursesPage />} />
            <Route path="/student/profile" element={<StudentProfilePage />} />

            {/* Premium Nursing Content Routes (Subject Modules, Chapters, Video Lectures) */}
            <Route path="/course/:batchId/subject/:subjectId" element={<SubjectDetailsPage />} />
            <Route
              path="/course/:batchId/subject/:subjectId/chapter/:chapterId"
              element={<ChapterDetailsPage />}
            />
            <Route path="/course/:batchId/class/:classId" element={<ClassDetailsPage />} />
          </Route>
        </Route>

        {/* Admin Management Portal & CMS Dashboard (Protected by ProtectedAdminGuard) */}
        <Route element={<ProtectedAdminGuard />}>
          <Route element={<AdminLayout />}>
            <Route path="/admin" element={<Navigate to="/admin/dashboard" replace />} />
            <Route path="/admin/dashboard" element={<AdminDashboardPage />} />
            <Route path="/admin/batches" element={<AdminBatchesPage />} />
            <Route path="/admin/courses" element={<AdminBatchesPage />} />
            <Route path="/admin/subjects" element={<AdminSubjectsPage />} />
            <Route path="/admin/chapters" element={<AdminChaptersPage />} />
            <Route path="/admin/classes" element={<AdminClassesPage />} />
            <Route path="/admin/video-classes" element={<AdminVideoClassesPage />} />
            <Route path="/admin/pdf-notes" element={<AdminPdfNotesPage />} />
            <Route path="/admin/coupons" element={<AdminCouponsPage />} />
            <Route path="/admin/payments" element={<AdminPaymentsPage />} />
            <Route path="/admin/weekly-warrior" element={<AdminWeeklyWarriorPage />} />
            <Route
              path="/admin/weekly-warrior/:testId/questions"
              element={<AdminWeeklyWarriorQuestionsPage />}
            />
            <Route path="/admin/unit-tests" element={<AdminUnitTestsPage />} />
            <Route
              path="/admin/unit-tests/:testId/questions"
              element={<AdminUnitTestQuestionsPage />}
            />
            <Route path="/admin/audit-logs" element={<AdminAuditLogsPage />} />
            <Route path="/admin/branding" element={<AdminBrandingPage />} />
            <Route path="/admin/students" element={<AdminStudentsPage />} />
            <Route path="/admin/tests" element={<Navigate to="/admin/weekly-warrior" replace />} />
            <Route path="/admin/live" element={<AdminClassesPage />} />
            <Route path="/admin/notices" element={<AdminDashboardPage />} />
          </Route>
        </Route>

        {/* Catch-all 404 Route */}
        <Route element={<PublicLayout />}>
          <Route path="*" element={<NotFoundPage />} />
        </Route>
      </Routes>
    </Suspense>
  );
}

export default AppRoutes;
