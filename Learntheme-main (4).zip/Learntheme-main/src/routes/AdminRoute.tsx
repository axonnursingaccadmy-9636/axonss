/**
 * Axon Nursing Academy - Production Admin Route Guard
 * Strictly allows access only to designated administrator (pmgautamjaipur@gmail.com).
 */
import React from 'react';
import { Navigate, Outlet, useLocation, Link } from 'react-router-dom';
import { useAuth } from '@/src/contexts/AuthContext';
import { LoadingState } from '@/src/components/common/LoadingState';
import { ROUTES } from '@/src/config/routes.config';
import { ShieldAlert, GraduationCap } from 'lucide-react';
import { Button } from '@/src/components/ui/Button';
import { Badge } from '@/src/components/ui/Badge';

export interface AdminRouteProps {
  children?: React.ReactNode;
}

export function AdminRoute({ children }: AdminRouteProps) {
  const { currentUser, profile, isAuthenticated, isAdmin, isLoading, profileLoading } = useAuth();
  const location = useLocation();

  if (isLoading || (currentUser && profileLoading && !profile)) {
    return <LoadingState message="Verifying administrative credentials..." fullScreen />;
  }

  if (!isAuthenticated) {
    return <Navigate to={ROUTES.LOGIN} state={{ from: location }} replace />;
  }

  // If user is authenticated and confirmed admin (pmgautamjaipur@gmail.com)
  if (isAdmin) {
    if (children) {
      return <>{children}</>;
    }
    return <Outlet />;
  }

  // For any other authenticated student/user, redirect them to student portal
  return <Navigate to={ROUTES.STUDENT.ROOT} replace />;
}

export default AdminRoute;
