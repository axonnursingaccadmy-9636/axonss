/**
 * Axon Nursing Academy - Protected Route
 * Enforces authenticated student session and active account status using real Firebase Auth & Firestore data.
 */
import React from 'react';
import { Navigate, Outlet, useLocation } from 'react-router-dom';
import { ShieldAlert, LogOut, PhoneCall } from 'lucide-react';
import { useAuth } from '@/src/contexts/AuthContext';
import { LoadingState } from '@/src/components/common/LoadingState';
import { ROUTES } from '@/src/config/routes.config';
import { SITE_CONFIG } from '@/src/config/site.config';
import { Button } from '@/src/components/ui/Button';

export interface ProtectedRouteProps {
  children?: React.ReactNode;
}

export function ProtectedRoute({ children }: ProtectedRouteProps) {
  const { isAuthenticated, isLoading, profile, logout } = useAuth();
  const location = useLocation();

  // Show loading indicator only during the initial Firebase Auth handshake (< 100ms)
  if (isLoading) {
    return <LoadingState message="Loading student portal..." fullScreen />;
  }

  // Redirect unauthenticated visitor to login page, preserving requested path
  if (!isAuthenticated) {
    return <Navigate to={ROUTES.LOGIN} state={{ from: location }} replace />;
  }

  // Section 11: Account Status Enforcement (isActive === false)
  if (profile && profile.isActive === false) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4">
        <div className="max-w-md w-full bg-white rounded-3xl border border-rose-100 p-6 sm:p-8 text-center shadow-lg">
          <div className="w-14 h-14 rounded-2xl bg-rose-100 text-rose-600 flex items-center justify-center mx-auto mb-4">
            <ShieldAlert className="w-7 h-7" />
          </div>
          <h2 className="text-xl font-bold text-slate-900 mb-2">Account Inactive</h2>
          <p className="text-xs text-slate-600 mb-6 leading-relaxed">
            Your student account is currently deactivated or pending administrative review. Please contact the {SITE_CONFIG.shortName} support desk to restore access.
          </p>

          <div className="space-y-3">
            <a href={`tel:${SITE_CONFIG.supportPhone}`} className="block">
              <Button
                variant="primary"
                fullWidth
                size="md"
                leftIcon={<PhoneCall className="w-4 h-4" />}
              >
                Contact Support ({SITE_CONFIG.supportPhone})
              </Button>
            </a>

            <Button
              variant="outline"
              fullWidth
              size="md"
              onClick={() => logout()}
              leftIcon={<LogOut className="w-4 h-4" />}
            >
              Sign Out
            </Button>
          </div>
        </div>
      </div>
    );
  }

  if (children) {
    return <>{children}</>;
  }

  return <Outlet />;
}

export default ProtectedRoute;
