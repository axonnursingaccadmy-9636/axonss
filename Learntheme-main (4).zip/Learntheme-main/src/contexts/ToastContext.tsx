/**
 * Axon Nursing Academy - Toast Notification Context & Provider
 * Manages toast state, creation, stack limiting, and rendering.
 */
import React, { createContext, useContext, useState, useCallback, useMemo, useRef } from 'react';
import {
  ToastContextValue,
  ToastFunction,
  ToastItemData,
  ToastOptions,
  ToastPosition,
  ToastPromiseMessages,
} from '@/src/types/toast.types';
import { ToastContainer } from '@/src/components/ui/Toast/ToastContainer';

export const ToastContext = createContext<ToastContextValue | undefined>(undefined);

interface ToastProviderProps {
  children: React.ReactNode;
  defaultPosition?: ToastPosition;
  defaultDuration?: number;
  maxToasts?: number;
}

let toastCounter = 0;
const generateUniqueId = (): string => {
  toastCounter += 1;
  return `toast-${Date.now()}-${toastCounter}-${Math.random().toString(36).substring(2, 7)}`;
};

export const ToastProvider: React.FC<ToastProviderProps> = ({
  children,
  defaultPosition = 'top-right',
  defaultDuration = 4000,
  maxToasts = 5,
}) => {
  const [toasts, setToasts] = useState<ToastItemData[]>([]);
  const [position, setPosition] = useState<ToastPosition>(defaultPosition);

  const defaultDurationRef = useRef(defaultDuration);
  defaultDurationRef.current = defaultDuration;

  const defaultPositionRef = useRef(defaultPosition);
  defaultPositionRef.current = defaultPosition;

  // Dismiss a specific toast by ID or all toasts
  const dismiss = useCallback((id?: string) => {
    if (!id) {
      setToasts([]);
      return;
    }
    setToasts((prev) => prev.filter((t) => t.id !== id));
  }, []);

  const dismissAll = useCallback(() => {
    setToasts([]);
  }, []);

  // Base toast creator
  const createToast = useCallback(
    (message: React.ReactNode, options?: Partial<ToastOptions>): string => {
      const id = options?.id || generateUniqueId();
      const newToast: ToastItemData = {
        id,
        type: options?.type || 'info',
        title: options?.title,
        message,
        duration:
          options?.duration !== undefined
            ? options.duration
            : defaultDurationRef.current,
        position: options?.position || defaultPositionRef.current,
        dismissible: options?.dismissible !== undefined ? options.dismissible : true,
        action: options?.action,
        onDismiss: options?.onDismiss,
        icon: options?.icon,
        createdAt: Date.now(),
      };

      setToasts((prev) => {
        // If updating an existing toast by id (e.g. from promise loading -> success)
        const exists = prev.some((t) => t.id === id);
        if (exists) {
          return prev.map((t) => (t.id === id ? newToast : t));
        }

        // Add new and enforce maxToasts limit
        const updated = [...prev, newToast];
        if (updated.length > maxToasts) {
          return updated.slice(updated.length - maxToasts);
        }
        return updated;
      });

      return id;
    },
    [maxToasts]
  );

  // Success helper
  const success = useCallback(
    (message: React.ReactNode, options?: Partial<ToastOptions>) => {
      return createToast(message, { ...options, type: 'success' });
    },
    [createToast]
  );

  // Error helper
  const error = useCallback(
    (message: React.ReactNode, options?: Partial<ToastOptions>) => {
      return createToast(message, {
        ...options,
        type: 'error',
        duration: options?.duration !== undefined ? options.duration : 5000,
      });
    },
    [createToast]
  );

  // Warning helper
  const warning = useCallback(
    (message: React.ReactNode, options?: Partial<ToastOptions>) => {
      return createToast(message, { ...options, type: 'warning' });
    },
    [createToast]
  );

  // Info helper
  const info = useCallback(
    (message: React.ReactNode, options?: Partial<ToastOptions>) => {
      return createToast(message, { ...options, type: 'info' });
    },
    [createToast]
  );

  // Promise helper (handles loading -> success / error transition seamlessly)
  const promise = useCallback(
    async <T,>(
      promiseOrFn: Promise<T> | (() => Promise<T>),
      messages: ToastPromiseMessages<T>,
      options?: Partial<ToastOptions>
    ): Promise<T> => {
      const id = options?.id || generateUniqueId();

      // Dispatch loading state (persistent until settled)
      createToast(messages.loading, {
        ...options,
        id,
        type: 'info',
        duration: 0, // Stay visible while waiting
      });

      try {
        const resolvedPromise =
          typeof promiseOrFn === 'function' ? promiseOrFn() : promiseOrFn;
        const result = await resolvedPromise;

        const successMsg =
          typeof messages.success === 'function'
            ? messages.success(result)
            : messages.success;

        createToast(successMsg, {
          ...options,
          id,
          type: 'success',
          duration: options?.duration || defaultDurationRef.current,
        });

        return result;
      } catch (err: any) {
        const errorMsg =
          typeof messages.error === 'function'
            ? messages.error(err)
            : messages.error;

        createToast(errorMsg, {
          ...options,
          id,
          type: 'error',
          duration: options?.duration !== undefined ? options.duration : 5000,
        });

        throw err;
      }
    },
    [createToast]
  );

  // Construct full callable toast object
  const toastObject = useMemo<ToastFunction>(() => {
    const fn = (message: React.ReactNode, options?: Partial<ToastOptions>) =>
      createToast(message, options);
    fn.success = success;
    fn.error = error;
    fn.warning = warning;
    fn.info = info;
    fn.promise = promise;
    fn.dismiss = dismiss;
    return fn;
  }, [createToast, success, error, warning, info, promise, dismiss]);

  const contextValue = useMemo<ToastContextValue>(
    () => ({
      toasts,
      toast: toastObject,
      dismiss,
      dismissAll,
      position,
      setPosition,
    }),
    [toasts, toastObject, dismiss, dismissAll, position]
  );

  return (
    <ToastContext.Provider value={contextValue}>
      {children}
      <ToastContainer
        toasts={toasts}
        onDismiss={dismiss}
        position={position}
      />
    </ToastContext.Provider>
  );
};
