/**
 * Axon Nursing Academy - Global Site Settings & Branding Context
 * Provides Logo, Footer, and Favicon state across the entire application.
 */
import React, { createContext, useContext, useEffect, useState, useCallback } from 'react';
import {
  SiteSettings,
  DEFAULT_SITE_SETTINGS,
  getLocalCachedSettings,
  fetchSiteSettings,
  updateSiteSettings as saveSiteSettings,
} from '@/src/services/firebase/siteSettingsService';
import { useAuth } from './AuthContext';

interface SiteSettingsContextType {
  settings: SiteSettings;
  updateSettings: (updates: Partial<SiteSettings>) => Promise<SiteSettings>;
  refreshSettings: () => Promise<void>;
  isLoading: boolean;
  isSaving: boolean;
}

const SiteSettingsContext = createContext<SiteSettingsContextType | null>(null);

export function SiteSettingsProvider({ children }: { children: React.ReactNode }) {
  const { currentUser } = useAuth();
  const [settings, setSettings] = useState<SiteSettings>(getLocalCachedSettings);
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);

  // Load from Firestore on mount
  const refreshSettings = useCallback(async () => {
    try {
      const remote = await fetchSiteSettings();
      setSettings(remote);
    } catch (e) {
      console.warn('[SiteSettingsContext] Error fetching site settings:', e);
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    refreshSettings();
  }, [refreshSettings]);

  // Synchronize Favicon dynamically with browser tab
  useEffect(() => {
    if (!settings.faviconUrl) return;

    try {
      let link = document.querySelector("link[rel*='icon']") as HTMLLinkElement | null;
      if (!link) {
        link = document.createElement('link');
        link.type = 'image/x-icon';
        link.rel = 'shortcut icon';
        document.head.appendChild(link);
      }
      link.href = settings.faviconUrl;
    } catch (e) {
      console.warn('[SiteSettingsContext] Could not update favicon link:', e);
    }
  }, [settings.faviconUrl]);

  const updateSettings = async (updates: Partial<SiteSettings>): Promise<SiteSettings> => {
    setIsSaving(true);
    try {
      const updated = await saveSiteSettings(updates, currentUser?.email || undefined);
      setSettings(updated);
      return updated;
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <SiteSettingsContext.Provider
      value={{
        settings,
        updateSettings,
        refreshSettings,
        isLoading,
        isSaving,
      }}
    >
      {children}
    </SiteSettingsContext.Provider>
  );
}

export function useSiteSettings() {
  const context = useContext(SiteSettingsContext);
  if (!context) {
    throw new Error('useSiteSettings must be used within a SiteSettingsProvider');
  }
  return context;
}
