/**
 * Axon Nursing Academy - Firebase Auth & Firestore Profile Context
 * Coordinates Firebase Authentication with Firestore User Profile data.
 */
import React, {
  createContext,
  useContext,
  useState,
  useEffect,
  useCallback,
  ReactNode,
} from 'react';
import { User as FirebaseUser, UserCredential } from 'firebase/auth';
import {
  signUpWithEmail,
  signInWithEmail,
  signInWithGooglePopup,
  signOutUser,
  sendPasswordReset,
  subscribeToAuth,
  getFriendlyAuthErrorMessage,
} from '@/src/services/firebase/authService';
import {
  createUserProfile,
  getUserProfile,
  updateUserProfile,
  ensureUserProfile,
} from '@/src/services/firebase/userService';
import { syncAllFirestoreCurriculumAsAdmin } from '@/src/services/firebase/adminBatchService';
import { isFirebaseConfigured } from '@/src/lib/firebase/config';
import { UserProfile } from '@/src/types/user.types';
import { isDesignatedAdminEmail } from '@/src/config/admin.config';

export interface AuthContextType {
  currentUser: FirebaseUser | null;
  profile: UserProfile | null;
  isAuthenticated: boolean;
  isAdmin: boolean;
  isLoading: boolean;
  loading: boolean;
  profileLoading: boolean;
  error: string | null;
  isFirebaseReady: boolean;
  signUp: (email: string, password: string, fullName: string) => Promise<UserCredential>;
  login: (email: string, password: string) => Promise<UserCredential>;
  loginWithGoogle: () => Promise<UserCredential>;
  logout: () => Promise<void>;
  resetPassword: (email: string) => Promise<void>;
  updateProfileName: (newFullName: string) => Promise<void>;
  refreshProfile: () => Promise<UserProfile | null>;
  clearError: () => void;
  // Legacy compatibility for Phase 0/1 callers
  signOutPlaceholder: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export interface AuthProviderProps {
  children: ReactNode;
}

export function AuthProvider({ children }: AuthProviderProps) {
  const [currentUser, setCurrentUser] = useState<FirebaseUser | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [profileLoading, setProfileLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const isFirebaseReady = isFirebaseConfigured();

  const clearError = useCallback(() => {
    setError(null);
  }, []);

  // Fetch or refresh Firestore profile for the current user
  const fetchProfileForUser = useCallback(async (user: FirebaseUser): Promise<UserProfile | null> => {
    setProfileLoading(true);
    try {
      // Add a 3-second timeout guard so slow networks or Firestore connection delays never stall the UI
      const timeoutPromise = new Promise<null>((resolve) => setTimeout(() => resolve(null), 3000));
      const profilePromise = ensureUserProfile(user);
      
      const userProfile = await Promise.race([profilePromise, timeoutPromise]);
      if (userProfile) {
        setProfile(userProfile);
        return userProfile;
      }
      return null;
    } catch (err: any) {
      console.warn('[AuthContext] Notice: Using fallback profile state while offline:', err?.message || err);
      return null;
    } finally {
      setProfileLoading(false);
    }
  }, []);

  // Listen to Firebase Auth state and immediately unblock UI for blazing fast response
  useEffect(() => {
    const unsubscribe = subscribeToAuth((user) => {
      setCurrentUser(user);
      if (user) {
        // Set an immediate initial profile from Auth session so user gets instant access (< 50ms)
        const isUserAdmin = isDesignatedAdminEmail(user.email);
        setProfile((prev) => prev || {
          uid: user.uid,
          fullName: user.displayName || (user.email ? user.email.split('@')[0] : 'Nursing Aspirant'),
          email: user.email || '',
          role: isUserAdmin ? 'admin' : 'student',
          isActive: true,
        });
        setIsLoading(false);

        // Asynchronously sync with Firestore in the background
        fetchProfileForUser(user).catch((err) => {
          console.warn('[AuthContext] Background profile sync completed:', err);
        });

        if (isUserAdmin) {
          syncAllFirestoreCurriculumAsAdmin().catch(() => {});
        }
      } else {
        setProfile(null);
        setProfileLoading(false);
        setIsLoading(false);
      }
    });

    return () => {
      unsubscribe();
    };
  }, [fetchProfileForUser]);

  // Sign up a new student: Firebase Auth -> Create users/{uid} in Firestore
  const signUp = useCallback(
    async (email: string, password: string, fullName: string) => {
      setError(null);
      setIsLoading(true);
      try {
        const credential = await signUpWithEmail(email, password, fullName);
        setCurrentUser(credential.user);

        // Explicitly create Firestore profile with role='student'
        try {
          const newProfile = await createUserProfile(credential.user.uid, {
            fullName,
            email: credential.user.email || email,
          });
          setProfile(newProfile);
        } catch (profileErr) {
          console.warn('[AuthContext] Note: Initial Firestore profile sync warning, fallback active:', profileErr);
          setProfile({
            uid: credential.user.uid,
            fullName,
            email: credential.user.email || email,
            role: isDesignatedAdminEmail(email) ? 'admin' : 'student',
            isActive: true,
          });
        }

        return credential;
      } catch (err: any) {
        const friendlyMessage = getFriendlyAuthErrorMessage(err);
        setError(friendlyMessage);
        throw new Error(friendlyMessage);
      } finally {
        setIsLoading(false);
      }
    },
    []
  );

  // Sign in existing user: Firebase Auth -> Load or create Firestore profile
  const login = useCallback(
    async (email: string, password: string) => {
      setError(null);
      setIsLoading(true);
      try {
        const credential = await signInWithEmail(email, password);
        setCurrentUser(credential.user);
        await fetchProfileForUser(credential.user);
        return credential;
      } catch (err: any) {
        const friendlyMessage = getFriendlyAuthErrorMessage(err);
        setError(friendlyMessage);
        throw new Error(friendlyMessage);
      } finally {
        setIsLoading(false);
      }
    },
    [fetchProfileForUser]
  );

  // Google OAuth sign-in / sign-up -> Auto-create Firestore profile if not exists
  const loginWithGoogle = useCallback(async () => {
    setError(null);
    setIsLoading(true);
    try {
      const credential = await signInWithGooglePopup();
      setCurrentUser(credential.user);
      await fetchProfileForUser(credential.user);
      return credential;
    } catch (err: any) {
      const friendlyMessage = getFriendlyAuthErrorMessage(err);
      setError(friendlyMessage);
      throw new Error(friendlyMessage);
    } finally {
      setIsLoading(false);
    }
  }, [fetchProfileForUser]);

  // Sign out
  const logout = useCallback(async () => {
    setError(null);
    setIsLoading(true);
    try {
      await signOutUser();
      setCurrentUser(null);
      setProfile(null);
    } catch (err: any) {
      const friendlyMessage = getFriendlyAuthErrorMessage(err);
      setError(friendlyMessage);
      throw new Error(friendlyMessage);
    } finally {
      setIsLoading(false);
    }
  }, []);

  // Password reset
  const resetPassword = useCallback(async (email: string) => {
    setError(null);
    try {
      await sendPasswordReset(email);
    } catch (err: any) {
      const friendlyMessage = getFriendlyAuthErrorMessage(err);
      setError(friendlyMessage);
      throw new Error(friendlyMessage);
    }
  }, []);

  // Update student full name in Firestore
  const updateProfileName = useCallback(
    async (newFullName: string) => {
      if (!currentUser) {
        throw new Error('You must be signed in to update your profile.');
      }
      setError(null);
      setProfileLoading(true);
      try {
        await updateUserProfile(currentUser.uid, { fullName: newFullName });
        setProfile((prev) =>
          prev
            ? {
                ...prev,
                fullName: newFullName.trim(),
                updatedAt: new Date().toISOString(),
              }
            : null
        );
      } catch (err: any) {
        console.error('[AuthContext] Profile update failed:', err);
        const msg = err.message || 'Failed to update profile name.';
        setError(msg);
        throw new Error(msg);
      } finally {
        setProfileLoading(false);
      }
    },
    [currentUser]
  );

  // Manual refresh of profile
  const refreshProfile = useCallback(async () => {
    if (!currentUser) return null;
    return fetchProfileForUser(currentUser);
  }, [currentUser, fetchProfileForUser]);

  const isCurrentAdmin =
    Boolean(currentUser && isDesignatedAdminEmail(currentUser.email)) ||
    Boolean(profile && isDesignatedAdminEmail(profile.email)) ||
    Boolean(profile && profile.role === 'admin');

  const value: AuthContextType = {
    currentUser,
    profile,
    isAuthenticated: Boolean(currentUser),
    isAdmin: Boolean(isCurrentAdmin),
    isLoading,
    loading: isLoading,
    profileLoading,
    error,
    isFirebaseReady,
    signUp,
    login,
    loginWithGoogle,
    logout,
    resetPassword,
    updateProfileName,
    refreshProfile,
    clearError,
    signOutPlaceholder: logout,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth(): AuthContextType {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
