/**
 * Axon Nursing Academy - Public Layout
 */
import React from 'react';
import { Outlet } from 'react-router-dom';
import { PublicHeader } from '@/src/components/layout/PublicHeader';
import { PublicFooter } from '@/src/components/layout/PublicFooter';

export function PublicLayout() {
  return (
    <div className="min-h-screen min-h-[100dvh] w-full relative flex flex-col bg-slate-50 text-slate-900 font-['Plus_Jakarta_Sans',sans-serif]">
      <PublicHeader />
      <main className="flex-1">
        <Outlet />
      </main>
      <PublicFooter />
    </div>
  );
}
export default PublicLayout;
