/**
 * Axon Nursing Academy - Student Mobile-First Shell Layout
 *
 * Provides:
 * - Top Sticky Header with Hamburger & Notifications
 * - Drawer Menu for extended navigation
 * - Main Viewport container (optimized for phone, tablet, and responsive desktop)
 * - Mobile Fixed Bottom Navigation bar (Home, My Courses, All Courses, Chats, My Profile)
 */
import React, { useState } from 'react';
import { Outlet } from 'react-router-dom';
import { TopHeader } from '@/src/components/layout/TopHeader';
import { BottomNavigation } from '@/src/components/layout/BottomNavigation';
import { DrawerMenu } from '@/src/components/layout/DrawerMenu';

export function StudentLayout() {
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);

  return (
    <div className="min-h-screen min-h-[100dvh] w-full relative bg-slate-50 text-slate-900 flex flex-col font-['Plus_Jakarta_Sans',sans-serif]">
      {/* Top Header */}
      <TopHeader onMenuClick={() => setIsDrawerOpen(true)} />

      {/* Slide-out Drawer */}
      <DrawerMenu isOpen={isDrawerOpen} onClose={() => setIsDrawerOpen(false)} />

      {/* Main Content Area: padded for mobile bottom nav bar */}
      <main className="flex-1 pb-20 md:pb-12 max-w-7xl w-full mx-auto px-3 sm:px-6 py-3 sm:py-6">
        <Outlet />
      </main>

      {/* Bottom Navigation for Mobile Devices */}
      <BottomNavigation />
    </div>
  );
}
export default StudentLayout;
