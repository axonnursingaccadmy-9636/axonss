/**
 * Axon Nursing Academy - Production Responsive Admin Portal Layout
 * Dynamic layout handling Mobile drawer, Tablet adaptive rail, and Desktop sidebar.
 */
import React, { useState, useEffect } from 'react';
import { Outlet, useLocation } from 'react-router-dom';
import { AdminSidebar } from '@/src/components/layout/AdminSidebar';
import { AdminHeader } from '@/src/components/layout/AdminHeader';
import { AdminMobileBottomNav } from '@/src/components/layout/AdminMobileBottomNav';

export function AdminLayout() {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [isCollapsed, setIsCollapsed] = useState(false);
  const location = useLocation();

  // Close mobile drawer automatically when navigating between pages
  useEffect(() => {
    setMobileOpen(false);
  }, [location.pathname, location.search]);

  return (
    <div className="min-h-screen bg-slate-100 flex font-['Plus_Jakarta_Sans',sans-serif] text-slate-800">
      {/* Responsive Sidebar (Desktop inline + Mobile overlay drawer) */}
      <AdminSidebar
        isMobileOpen={mobileOpen}
        onCloseMobile={() => setMobileOpen(false)}
        isCollapsed={isCollapsed}
        onToggleCollapse={() => setIsCollapsed(!isCollapsed)}
      />

      {/* Main Viewport Workspace */}
      <div className="flex-1 flex flex-col min-w-0 min-h-screen">
        <AdminHeader
          onOpenMobileMenu={() => setMobileOpen(true)}
          isCollapsed={isCollapsed}
          onToggleCollapse={() => setIsCollapsed(!isCollapsed)}
        />

        <main className="flex-1 p-3 sm:p-5 md:p-6 pb-24 lg:pb-10 min-w-0">
          <div className="max-w-7xl mx-auto w-full space-y-6">
            <Outlet />
          </div>
        </main>
      </div>

      {/* Quick Mobile Bottom Navigation Bar (< lg screens) */}
      <AdminMobileBottomNav onOpenMenu={() => setMobileOpen(true)} />
    </div>
  );
}

export default AdminLayout;
