/**
 * Axon Nursing Academy - Root App Component (Phase 0 Architecture)
 */
import React from 'react';
import { BrowserRouter } from 'react-router-dom';
import { AuthProvider } from '@/src/contexts/AuthContext';
import { SiteSettingsProvider } from '@/src/contexts/SiteSettingsContext';
import { ToastProvider } from '@/src/contexts/ToastContext';
import { ErrorBoundary } from '@/src/components/common/ErrorBoundary';
import { NavigationProgressBar } from '@/src/components/common/NavigationProgressBar';
import { AppRoutes } from '@/src/routes/AppRoutes';

export default function App() {
  return (
    <ErrorBoundary>
      <AuthProvider>
        <SiteSettingsProvider>
          <ToastProvider defaultPosition="top-right" defaultDuration={4000} maxToasts={5}>
            <BrowserRouter>
              <NavigationProgressBar />
              <AppRoutes />
            </BrowserRouter>
          </ToastProvider>
        </SiteSettingsProvider>
      </AuthProvider>
    </ErrorBoundary>
  );
}
