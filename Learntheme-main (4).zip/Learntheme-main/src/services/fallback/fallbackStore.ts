/**
 * Axon Nursing Academy - Resilient LMS Cache Store
 * Ultra-fast local-first cache with localStorage persistence.
 * Guarantees microsecond (0ms) render response times for Course, Subject, Chapter,
 * Video, PDF Notes, and MCQ tests across the entire student and admin LMS.
 */
import { Batch, Subject, Chapter, LmsClass, PdfNote } from '@/src/types/lms.types';
import { Enrollment } from '@/src/types/enrollment.types';
import { PaymentRecord } from '@/src/types/payment.types';
import {
  WeeklyWarriorTest,
  WeeklyWarriorQuestion,
  WeeklyWarriorAttempt,
  WeeklyWarriorResult,
  UnitTest,
  UnitTestQuestion,
  UnitTestAttempt,
  UnitTestResult,
} from '@/src/types/assessment.types';
import {
  FALLBACK_BATCHES,
  FALLBACK_SUBJECTS,
  FALLBACK_CHAPTERS,
  FALLBACK_CLASSES,
  FALLBACK_PDF_NOTES,
  FALLBACK_WEEKLY_WARRIOR_TESTS,
  FALLBACK_WEEKLY_WARRIOR_QUESTIONS,
  FALLBACK_UNIT_TESTS,
  FALLBACK_UNIT_TEST_QUESTIONS,
} from './fallbackLmsData';
import { fetchApi } from '@/src/services/api';

const STORAGE_KEYS = {
  BATCHES: 'axon_lms_batches_v5',
  SUBJECTS: 'axon_lms_subjects_v5',
  CHAPTERS: 'axon_lms_chapters_v5',
  CLASSES: 'axon_lms_classes_v5',
  PDF_NOTES: 'axon_lms_pdf_notes_v5',
  WW_TESTS: 'axon_lms_ww_tests_v5',
  WW_QUESTIONS: 'axon_lms_ww_questions_v5',
  WW_ATTEMPTS: 'axon_lms_ww_attempts_v5',
  WW_RESULTS: 'axon_lms_ww_results_v5',
  UNIT_TESTS: 'axon_lms_unit_tests_v5',
  UNIT_QUESTIONS: 'axon_lms_unit_questions_v5',
  UNIT_ATTEMPTS: 'axon_lms_unit_attempts_v5',
  UNIT_RESULTS: 'axon_lms_unit_results_v5',
  ENROLLMENTS: 'axon_lms_enrollments_v5',
  PAYMENTS: 'axon_lms_payments_v5',
  DELETED_IDS: 'axon_lms_deleted_ids_v5',
};

const CLEAN_SLATE_PURGE_KEY = 'axon_clean_slate_purge_v2026_10_05_v5';

// Mandatory one-time purge of all legacy v1/v2/v3 localStorage keys on every browser/phone
if (typeof window !== 'undefined') {
  try {
    if (localStorage.getItem(CLEAN_SLATE_PURGE_KEY) !== 'done') {
      const keysToRemove: string[] = [];
      for (let i = 0; i < localStorage.length; i++) {
        const k = localStorage.key(i);
        if (k && (k.startsWith('axon_') || k.startsWith('axon-'))) {
          keysToRemove.push(k);
        }
      }
      keysToRemove.forEach((k) => localStorage.removeItem(k));
      localStorage.setItem(CLEAN_SLATE_PURGE_KEY, 'done');
    }
  } catch {
    // ignore storage access errors
  }
}

function getDeletedIds(): Set<string> {
  if (typeof window === 'undefined') return new Set();
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.DELETED_IDS);
    return raw ? new Set(JSON.parse(raw)) : new Set();
  } catch {
    return new Set();
  }
}

function addDeletedId(...ids: string[]): void {
  if (typeof window === 'undefined') return;
  try {
    const current = getDeletedIds();
    ids.forEach((id) => {
      if (id) current.add(id);
    });
    localStorage.setItem(STORAGE_KEYS.DELETED_IDS, JSON.stringify(Array.from(current)));
  } catch {
    // ignore
  }
}

function removeDeletedId(id: string): void {
  if (typeof window === 'undefined' || !id) return;
  try {
    const current = getDeletedIds();
    if (current.delete(id)) {
      localStorage.setItem(STORAGE_KEYS.DELETED_IDS, JSON.stringify(Array.from(current)));
    }
  } catch {
    // ignore
  }
}

function loadFromStorage<T>(key: string, fallback: T): T {
  if (typeof window === 'undefined') return fallback;
  try {
    const deletedIds = getDeletedIds();
    const raw = localStorage.getItem(key);
    if (!raw) {
      if (Array.isArray(fallback)) {
        return fallback.filter((item: any) => !deletedIds.has(item?.id)) as unknown as T;
      }
      return fallback;
    }
    const parsed = JSON.parse(raw);
    if (Array.isArray(fallback)) {
      const idMap = new Map<string, any>();
      fallback.forEach((item: any) => {
        if (item && item.id && !deletedIds.has(item.id)) idMap.set(item.id, item);
      });
      if (Array.isArray(parsed)) {
        parsed.forEach((item: any) => {
          if (item && item.id && !deletedIds.has(item.id)) idMap.set(item.id, item);
        });
      }
      return Array.from(idMap.values()) as unknown as T;
    }
    return parsed;
  } catch (e) {
    return fallback;
  }
}

const CURRICULUM_KEYS = new Set<string>([
  STORAGE_KEYS.BATCHES,
  STORAGE_KEYS.SUBJECTS,
  STORAGE_KEYS.CHAPTERS,
  STORAGE_KEYS.CLASSES,
  STORAGE_KEYS.PDF_NOTES,
  STORAGE_KEYS.WW_TESTS,
  STORAGE_KEYS.WW_QUESTIONS,
  STORAGE_KEYS.UNIT_TESTS,
  STORAGE_KEYS.UNIT_QUESTIONS,
]);

let cloudPushTimer: ReturnType<typeof setTimeout> | null = null;
let isApplyingRemoteState = false;

// Protects items created/updated in the last 15 seconds from being overwritten by a lagging snapshot or initial fetch
const recentlySavedMap = new Map<string, { item: any; savedAt: number }>();

function markItemRecentlySaved(item: any): void {
  if (!item || !item.id) return;
  recentlySavedMap.set(String(item.id), { item, savedAt: Date.now() });
}

function unmarkItemRecentlySaved(...ids: string[]): void {
  for (const id of ids) {
    if (id) recentlySavedMap.delete(String(id));
  }
}

function preserveRecentlySaved<T extends { id: string; order?: number }>(
  incoming: T[],
  currentList: T[],
  filterFn?: (item: T) => boolean
): T[] {
  const now = Date.now();
  const deletedIds = getDeletedIds();
  const map = new Map<string, T>();

  for (const item of incoming || []) {
    if (item && item.id && !deletedIds.has(item.id)) {
      map.set(item.id, item);
    }
  }

  for (const item of currentList || []) {
    if (!item || !item.id || deletedIds.has(item.id)) continue;
    const recent = recentlySavedMap.get(item.id);
    if (recent && now - recent.savedAt < 15000) {
      if (!filterFn || filterFn(item)) {
        if (!map.has(item.id)) {
          map.set(item.id, item);
        }
      }
    } else if (recent) {
      recentlySavedMap.delete(item.id);
    }
  }

  return Array.from(map.values()).sort((a, b) => (a.order || 0) - (b.order || 0));
}

function scheduleCloudCatalogPush(replaceAll = false): void {
  if (typeof window === 'undefined' || isApplyingRemoteState) return;
  if (cloudPushTimer) clearTimeout(cloudPushTimer);
  cloudPushTimer = setTimeout(() => {
    fetchApi('/api/catalog/state', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        replaceAll,
        batches: dynamicBatches,
        subjects: dynamicSubjects,
        chapters: dynamicChapters,
        classes: dynamicClasses,
        pdfNotes: dynamicPdfNotes,
        weeklyWarriorTests: dynamicWeeklyWarriorTests,
        weeklyWarriorQuestions: dynamicWeeklyWarriorQuestions,
        unitTests: dynamicUnitTests,
        unitTestQuestions: dynamicUnitTestQuestions,
        deletedIds: Array.from(getDeletedIds()),
      }),
    }).catch(() => {});
  }, 60);
}

function saveToStorage<T>(key: string, data: T): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(key, JSON.stringify(data));
    if (CURRICULUM_KEYS.has(key)) {
      scheduleCloudCatalogPush(false);
    }
  } catch (e) {
    // ignore quota limits
  }
}

// In-memory runtime cache stores initialized from LocalStorage or static defaults
let dynamicBatches: Batch[] = loadFromStorage(STORAGE_KEYS.BATCHES, FALLBACK_BATCHES);
let dynamicSubjects: Subject[] = loadFromStorage(STORAGE_KEYS.SUBJECTS, FALLBACK_SUBJECTS);
let dynamicChapters: Chapter[] = loadFromStorage(STORAGE_KEYS.CHAPTERS, FALLBACK_CHAPTERS);
let dynamicClasses: LmsClass[] = loadFromStorage(STORAGE_KEYS.CLASSES, FALLBACK_CLASSES);
let dynamicPdfNotes: PdfNote[] = loadFromStorage(STORAGE_KEYS.PDF_NOTES, FALLBACK_PDF_NOTES);

// Test & MCQ runtime cache stores
let dynamicWeeklyWarriorTests: WeeklyWarriorTest[] = loadFromStorage(
  STORAGE_KEYS.WW_TESTS,
  FALLBACK_WEEKLY_WARRIOR_TESTS
);
let dynamicWeeklyWarriorQuestions: WeeklyWarriorQuestion[] = loadFromStorage(
  STORAGE_KEYS.WW_QUESTIONS,
  FALLBACK_WEEKLY_WARRIOR_QUESTIONS
);
let dynamicWeeklyWarriorAttempts: WeeklyWarriorAttempt[] = loadFromStorage(STORAGE_KEYS.WW_ATTEMPTS, []);
let dynamicWeeklyWarriorResults: WeeklyWarriorResult[] = loadFromStorage(STORAGE_KEYS.WW_RESULTS, []);

let dynamicUnitTests: UnitTest[] = loadFromStorage(STORAGE_KEYS.UNIT_TESTS, FALLBACK_UNIT_TESTS);
let dynamicUnitTestQuestions: UnitTestQuestion[] = loadFromStorage(
  STORAGE_KEYS.UNIT_QUESTIONS,
  FALLBACK_UNIT_TEST_QUESTIONS
);
let dynamicUnitTestAttempts: UnitTestAttempt[] = loadFromStorage(STORAGE_KEYS.UNIT_ATTEMPTS, []);
let dynamicUnitTestResults: UnitTestResult[] = loadFromStorage(STORAGE_KEYS.UNIT_RESULTS, []);
let dynamicEnrollments: Enrollment[] = loadFromStorage(STORAGE_KEYS.ENROLLMENTS, []);
let dynamicPayments: PaymentRecord[] = loadFromStorage(STORAGE_KEYS.PAYMENTS, []);

export const fallbackStore = {
  // Batches
  getBatches: (): Batch[] => [...dynamicBatches],
  getBatchById: (id: string): Batch | null =>
    dynamicBatches.find((b) => b.id === id || b.slug === id) || null,
  getBatchBySlug: (slug: string): Batch | null =>
    dynamicBatches.find((b) => b.slug === slug || b.id === slug) || null,
  saveBatch: (batch: Batch) => {
    removeDeletedId(batch.id);
    markItemRecentlySaved(batch);
    const idx = dynamicBatches.findIndex((b) => b.id === batch.id);
    if (idx >= 0) {
      dynamicBatches[idx] = { ...dynamicBatches[idx], ...batch };
    } else {
      dynamicBatches.push(batch);
    }
    saveToStorage(STORAGE_KEYS.BATCHES, dynamicBatches);
  },
  deleteBatch: (id: string) => {
    const removedSubjects = dynamicSubjects.filter((s) => s.batchId === id);
    const removedSubjectIds = new Set(removedSubjects.map((s) => s.id));
    const removedChapters = dynamicChapters.filter((c) => c.batchId === id || removedSubjectIds.has(c.subjectId));
    const removedChapterIds = new Set(removedChapters.map((c) => c.id));

    unmarkItemRecentlySaved(id, ...Array.from(removedSubjectIds), ...Array.from(removedChapterIds));
    addDeletedId(id, ...Array.from(removedSubjectIds), ...Array.from(removedChapterIds));

    dynamicBatches = dynamicBatches.filter((b) => b.id !== id);
    saveToStorage(STORAGE_KEYS.BATCHES, dynamicBatches);

    // Cascade delete associated subjects, chapters, classes, and pdf notes
    dynamicSubjects = dynamicSubjects.filter((s) => s.batchId !== id);
    saveToStorage(STORAGE_KEYS.SUBJECTS, dynamicSubjects);

    dynamicChapters = dynamicChapters.filter((c) => c.batchId !== id && !removedSubjectIds.has(c.subjectId));
    saveToStorage(STORAGE_KEYS.CHAPTERS, dynamicChapters);

    dynamicClasses = dynamicClasses.filter((cl) => cl.batchId !== id && !removedChapterIds.has(cl.chapterId) && !removedSubjectIds.has(cl.subjectId));
    saveToStorage(STORAGE_KEYS.CLASSES, dynamicClasses);

    dynamicPdfNotes = dynamicPdfNotes.filter((p) => p.batchId !== id && !removedChapterIds.has(p.chapterId) && !removedSubjectIds.has(p.subjectId));
    saveToStorage(STORAGE_KEYS.PDF_NOTES, dynamicPdfNotes);
  },
  syncBatches: (batches: Batch[]) => {
    dynamicBatches = preserveRecentlySaved(batches || [], dynamicBatches);
    saveToStorage(STORAGE_KEYS.BATCHES, dynamicBatches);
  },

  // Subjects
  getSubjects: (batchId?: string): Subject[] => {
    if (!batchId) return [...dynamicSubjects];
    return dynamicSubjects.filter((s) => s.batchId === batchId);
  },
  getSubjectById: (id: string): Subject | null => dynamicSubjects.find((s) => s.id === id) || null,
  saveSubject: (subject: Subject) => {
    removeDeletedId(subject.id);
    markItemRecentlySaved(subject);
    const idx = dynamicSubjects.findIndex((s) => s.id === subject.id);
    if (idx >= 0) {
      dynamicSubjects[idx] = { ...dynamicSubjects[idx], ...subject };
    } else {
      dynamicSubjects.push(subject);
    }
    saveToStorage(STORAGE_KEYS.SUBJECTS, dynamicSubjects);
  },
  deleteSubject: (id: string) => {
    const removedChapters = dynamicChapters.filter((c) => c.subjectId === id);
    const removedChapterIds = new Set(removedChapters.map((c) => c.id));

    unmarkItemRecentlySaved(id, ...Array.from(removedChapterIds));
    addDeletedId(id, ...Array.from(removedChapterIds));

    dynamicSubjects = dynamicSubjects.filter((s) => s.id !== id);
    saveToStorage(STORAGE_KEYS.SUBJECTS, dynamicSubjects);

    // Cascade delete associated chapters, classes, and pdf notes
    dynamicChapters = dynamicChapters.filter((c) => c.subjectId !== id);
    saveToStorage(STORAGE_KEYS.CHAPTERS, dynamicChapters);

    dynamicClasses = dynamicClasses.filter((cl) => cl.subjectId !== id && !removedChapterIds.has(cl.chapterId));
    saveToStorage(STORAGE_KEYS.CLASSES, dynamicClasses);

    dynamicPdfNotes = dynamicPdfNotes.filter((p) => p.subjectId !== id && !removedChapterIds.has(p.chapterId));
    saveToStorage(STORAGE_KEYS.PDF_NOTES, dynamicPdfNotes);
  },
  syncSubjects: (subjects: Subject[], batchId?: string) => {
    const deletedIds = getDeletedIds();
    const validSubjects = preserveRecentlySaved(
      subjects || [],
      dynamicSubjects,
      batchId ? (s) => s.batchId === batchId : undefined
    );
    if (batchId) {
      const otherSubjects = dynamicSubjects.filter((s) => s.batchId !== batchId && !deletedIds.has(s.id));
      dynamicSubjects = [...otherSubjects, ...validSubjects].sort((a, b) => (a.order || 0) - (b.order || 0));
    } else {
      dynamicSubjects = [...validSubjects].sort((a, b) => (a.order || 0) - (b.order || 0));
    }
    saveToStorage(STORAGE_KEYS.SUBJECTS, dynamicSubjects);
  },

  // Chapters
  getChapters: (subjectId?: string): Chapter[] => {
    if (!subjectId) return [...dynamicChapters];
    return dynamicChapters.filter((c) => c.subjectId === subjectId);
  },
  getChapterById: (id: string): Chapter | null => dynamicChapters.find((c) => c.id === id) || null,
  saveChapter: (chapter: Chapter) => {
    removeDeletedId(chapter.id);
    markItemRecentlySaved(chapter);
    const idx = dynamicChapters.findIndex((c) => c.id === chapter.id);
    if (idx >= 0) {
      dynamicChapters[idx] = { ...dynamicChapters[idx], ...chapter };
    } else {
      dynamicChapters.push(chapter);
    }
    saveToStorage(STORAGE_KEYS.CHAPTERS, dynamicChapters);
  },
  deleteChapter: (id: string) => {
    unmarkItemRecentlySaved(id);
    addDeletedId(id);
    dynamicChapters = dynamicChapters.filter((c) => c.id !== id);
    saveToStorage(STORAGE_KEYS.CHAPTERS, dynamicChapters);

    // Cascade delete associated classes and pdf notes
    dynamicClasses = dynamicClasses.filter((cl) => cl.chapterId !== id);
    saveToStorage(STORAGE_KEYS.CLASSES, dynamicClasses);

    dynamicPdfNotes = dynamicPdfNotes.filter((p) => p.chapterId !== id);
    saveToStorage(STORAGE_KEYS.PDF_NOTES, dynamicPdfNotes);
  },
  syncChapters: (chapters: Chapter[], subjectId?: string) => {
    const deletedIds = getDeletedIds();
    const validChapters = preserveRecentlySaved(
      chapters || [],
      dynamicChapters,
      subjectId ? (c) => c.subjectId === subjectId : undefined
    );
    if (subjectId) {
      const otherChapters = dynamicChapters.filter((c) => c.subjectId !== subjectId && !deletedIds.has(c.id));
      dynamicChapters = [...otherChapters, ...validChapters].sort((a, b) => (a.order || 0) - (b.order || 0));
    } else {
      dynamicChapters = [...validChapters].sort((a, b) => (a.order || 0) - (b.order || 0));
    }
    saveToStorage(STORAGE_KEYS.CHAPTERS, dynamicChapters);
  },

  // Classes
  getClasses: (chapterId?: string): LmsClass[] => {
    if (!chapterId) return [...dynamicClasses];
    return dynamicClasses.filter((cl) => cl.chapterId === chapterId);
  },
  getClassById: (id: string): LmsClass | null => dynamicClasses.find((cl) => cl.id === id) || null,
  saveClass: (cls: LmsClass) => {
    markItemRecentlySaved(cls);
    const idx = dynamicClasses.findIndex((c) => c.id === cls.id);
    if (idx >= 0) {
      dynamicClasses[idx] = { ...dynamicClasses[idx], ...cls };
    } else {
      dynamicClasses.push(cls);
    }
    saveToStorage(STORAGE_KEYS.CLASSES, dynamicClasses);
  },
  deleteClass: (id: string) => {
    unmarkItemRecentlySaved(id);
    dynamicClasses = dynamicClasses.filter((c) => c.id !== id);
    saveToStorage(STORAGE_KEYS.CLASSES, dynamicClasses);
  },
  syncClasses: (classes: LmsClass[], chapterId?: string) => {
    const valid = preserveRecentlySaved(
      (classes || []).filter(Boolean),
      dynamicClasses,
      chapterId ? (c) => c.chapterId === chapterId : undefined
    );
    if (chapterId) {
      const others = dynamicClasses.filter((c) => c.chapterId !== chapterId);
      dynamicClasses = [...others, ...valid].sort((a, b) => (a.order || 0) - (b.order || 0));
    } else {
      dynamicClasses = [...valid].sort((a, b) => (a.order || 0) - (b.order || 0));
    }
    saveToStorage(STORAGE_KEYS.CLASSES, dynamicClasses);
  },

  // PDF Notes
  getPdfNotes: (chapterId?: string): PdfNote[] => {
    if (!chapterId) return [...dynamicPdfNotes];
    return dynamicPdfNotes.filter((p) => p.chapterId === chapterId);
  },
  getPdfNoteById: (id: string): PdfNote | null => dynamicPdfNotes.find((p) => p.id === id) || null,
  savePdfNote: (note: PdfNote) => {
    markItemRecentlySaved(note);
    const idx = dynamicPdfNotes.findIndex((p) => p.id === note.id);
    if (idx >= 0) {
      dynamicPdfNotes[idx] = { ...dynamicPdfNotes[idx], ...note };
    } else {
      dynamicPdfNotes.push(note);
    }
    saveToStorage(STORAGE_KEYS.PDF_NOTES, dynamicPdfNotes);
  },
  deletePdfNote: (id: string) => {
    unmarkItemRecentlySaved(id);
    dynamicPdfNotes = dynamicPdfNotes.filter((p) => p.id !== id);
    saveToStorage(STORAGE_KEYS.PDF_NOTES, dynamicPdfNotes);
  },
  syncPdfNotes: (notes: PdfNote[], chapterId?: string) => {
    const valid = preserveRecentlySaved(
      (notes || []).filter(Boolean),
      dynamicPdfNotes,
      chapterId ? (p) => p.chapterId === chapterId : undefined
    );
    if (chapterId) {
      const others = dynamicPdfNotes.filter((p) => p.chapterId !== chapterId);
      dynamicPdfNotes = [...others, ...valid].sort((a, b) => (a.order || 0) - (b.order || 0));
    } else {
      dynamicPdfNotes = [...valid].sort((a, b) => (a.order || 0) - (b.order || 0));
    }
    saveToStorage(STORAGE_KEYS.PDF_NOTES, dynamicPdfNotes);
  },

  // Weekly Warrior Tests
  getWeeklyWarriorTests: (batchId?: string): WeeklyWarriorTest[] => {
    if (!batchId) return [...dynamicWeeklyWarriorTests];
    return dynamicWeeklyWarriorTests.filter((t) => t.batchId === batchId);
  },
  getWeeklyWarriorTestById: (id: string): WeeklyWarriorTest | null =>
    dynamicWeeklyWarriorTests.find((t) => t.id === id) || null,
  saveWeeklyWarriorTest: (test: WeeklyWarriorTest) => {
    const idx = dynamicWeeklyWarriorTests.findIndex((t) => t.id === test.id);
    if (idx >= 0) {
      dynamicWeeklyWarriorTests[idx] = { ...dynamicWeeklyWarriorTests[idx], ...test };
    } else {
      dynamicWeeklyWarriorTests.push(test);
    }
    saveToStorage(STORAGE_KEYS.WW_TESTS, dynamicWeeklyWarriorTests);
  },
  deleteWeeklyWarriorTest: (id: string) => {
    dynamicWeeklyWarriorTests = dynamicWeeklyWarriorTests.filter((t) => t.id !== id);
    dynamicWeeklyWarriorQuestions = dynamicWeeklyWarriorQuestions.filter((q) => q.testId !== id);
    saveToStorage(STORAGE_KEYS.WW_TESTS, dynamicWeeklyWarriorTests);
    saveToStorage(STORAGE_KEYS.WW_QUESTIONS, dynamicWeeklyWarriorQuestions);
  },
  syncWeeklyWarriorTests: (tests: WeeklyWarriorTest[], batchId?: string) => {
    const valid = (tests || []).filter(Boolean);
    if (batchId) {
      const others = dynamicWeeklyWarriorTests.filter((t) => t.batchId !== batchId);
      dynamicWeeklyWarriorTests = [...others, ...valid].sort((a, b) => (a.order || 0) - (b.order || 0));
    } else {
      dynamicWeeklyWarriorTests = [...valid].sort((a, b) => (a.order || 0) - (b.order || 0));
    }
    saveToStorage(STORAGE_KEYS.WW_TESTS, dynamicWeeklyWarriorTests);
  },

  // Weekly Warrior Questions
  getWeeklyWarriorQuestions: (testId?: string): WeeklyWarriorQuestion[] => {
    if (!testId) return [...dynamicWeeklyWarriorQuestions];
    return dynamicWeeklyWarriorQuestions.filter((q) => q.testId === testId);
  },
  getWeeklyWarriorQuestionById: (id: string): WeeklyWarriorQuestion | null =>
    dynamicWeeklyWarriorQuestions.find((q) => q.id === id) || null,
  saveWeeklyWarriorQuestion: (q: WeeklyWarriorQuestion) => {
    const idx = dynamicWeeklyWarriorQuestions.findIndex((item) => item.id === q.id);
    if (idx >= 0) {
      dynamicWeeklyWarriorQuestions[idx] = { ...dynamicWeeklyWarriorQuestions[idx], ...q };
    } else {
      dynamicWeeklyWarriorQuestions.push(q);
    }
    saveToStorage(STORAGE_KEYS.WW_QUESTIONS, dynamicWeeklyWarriorQuestions);
  },
  deleteWeeklyWarriorQuestion: (id: string) => {
    dynamicWeeklyWarriorQuestions = dynamicWeeklyWarriorQuestions.filter((q) => q.id !== id);
    saveToStorage(STORAGE_KEYS.WW_QUESTIONS, dynamicWeeklyWarriorQuestions);
  },
  syncWeeklyWarriorQuestions: (questions: WeeklyWarriorQuestion[], testId?: string) => {
    const valid = (questions || []).filter(Boolean);
    if (testId) {
      const others = dynamicWeeklyWarriorQuestions.filter((q) => q.testId !== testId);
      dynamicWeeklyWarriorQuestions = [...others, ...valid].sort((a, b) => (a.order || 0) - (b.order || 0));
    } else {
      dynamicWeeklyWarriorQuestions = [...valid].sort((a, b) => (a.order || 0) - (b.order || 0));
    }
    saveToStorage(STORAGE_KEYS.WW_QUESTIONS, dynamicWeeklyWarriorQuestions);
  },

  // Weekly Warrior Attempts & Results
  getWeeklyWarriorAttempts: (testId?: string, studentId?: string): WeeklyWarriorAttempt[] => {
    return dynamicWeeklyWarriorAttempts.filter((a) => {
      if (testId && a.testId !== testId) return false;
      if (studentId && a.studentId !== studentId) return false;
      return true;
    });
  },
  getWeeklyWarriorAttemptById: (id: string): WeeklyWarriorAttempt | null =>
    dynamicWeeklyWarriorAttempts.find((a) => a.id === id) || null,
  saveWeeklyWarriorAttempt: (attempt: WeeklyWarriorAttempt) => {
    const idx = dynamicWeeklyWarriorAttempts.findIndex((a) => a.id === attempt.id);
    if (idx >= 0) {
      dynamicWeeklyWarriorAttempts[idx] = { ...dynamicWeeklyWarriorAttempts[idx], ...attempt };
    } else {
      dynamicWeeklyWarriorAttempts.push(attempt);
    }
    saveToStorage(STORAGE_KEYS.WW_ATTEMPTS, dynamicWeeklyWarriorAttempts);
  },
  getWeeklyWarriorResult: (resultOrAttemptId: string): WeeklyWarriorResult | null =>
    dynamicWeeklyWarriorResults.find((r) => r.id === resultOrAttemptId || r.attemptId === resultOrAttemptId) || null,
  saveWeeklyWarriorResult: (result: WeeklyWarriorResult) => {
    const idx = dynamicWeeklyWarriorResults.findIndex((r) => r.id === result.id);
    if (idx >= 0) {
      dynamicWeeklyWarriorResults[idx] = { ...dynamicWeeklyWarriorResults[idx], ...result };
    } else {
      dynamicWeeklyWarriorResults.push(result);
    }
    saveToStorage(STORAGE_KEYS.WW_RESULTS, dynamicWeeklyWarriorResults);
  },

  // Unit MCQ Tests
  getUnitTests: (chapterId?: string): UnitTest[] => {
    if (!chapterId) return [...dynamicUnitTests];
    return dynamicUnitTests.filter((t) => t.chapterId === chapterId);
  },
  getUnitTestById: (id: string): UnitTest | null => dynamicUnitTests.find((t) => t.id === id) || null,
  saveUnitTest: (test: UnitTest) => {
    const idx = dynamicUnitTests.findIndex((t) => t.id === test.id);
    if (idx >= 0) {
      dynamicUnitTests[idx] = { ...dynamicUnitTests[idx], ...test };
    } else {
      dynamicUnitTests.push(test);
    }
    saveToStorage(STORAGE_KEYS.UNIT_TESTS, dynamicUnitTests);
  },
  deleteUnitTest: (id: string) => {
    dynamicUnitTests = dynamicUnitTests.filter((t) => t.id !== id);
    dynamicUnitTestQuestions = dynamicUnitTestQuestions.filter((q) => q.testId !== id);
    saveToStorage(STORAGE_KEYS.UNIT_TESTS, dynamicUnitTests);
    saveToStorage(STORAGE_KEYS.UNIT_QUESTIONS, dynamicUnitTestQuestions);
  },
  syncUnitTests: (tests: UnitTest[], chapterId?: string) => {
    const valid = (tests || []).filter(Boolean);
    if (chapterId) {
      const others = dynamicUnitTests.filter((t) => t.chapterId !== chapterId);
      dynamicUnitTests = [...others, ...valid].sort((a, b) => (a.order || 0) - (b.order || 0));
    } else {
      dynamicUnitTests = [...valid].sort((a, b) => (a.order || 0) - (b.order || 0));
    }
    saveToStorage(STORAGE_KEYS.UNIT_TESTS, dynamicUnitTests);
  },

  // Unit MCQ Questions
  getUnitTestQuestions: (testId?: string): UnitTestQuestion[] => {
    if (!testId) return [...dynamicUnitTestQuestions];
    return dynamicUnitTestQuestions.filter((q) => q.testId === testId);
  },
  getUnitTestQuestionById: (id: string): UnitTestQuestion | null =>
    dynamicUnitTestQuestions.find((q) => q.id === id) || null,
  saveUnitTestQuestion: (q: UnitTestQuestion) => {
    const idx = dynamicUnitTestQuestions.findIndex((item) => item.id === q.id);
    if (idx >= 0) {
      dynamicUnitTestQuestions[idx] = { ...dynamicUnitTestQuestions[idx], ...q };
    } else {
      dynamicUnitTestQuestions.push(q);
    }
    saveToStorage(STORAGE_KEYS.UNIT_QUESTIONS, dynamicUnitTestQuestions);
  },
  deleteUnitTestQuestion: (id: string) => {
    dynamicUnitTestQuestions = dynamicUnitTestQuestions.filter((q) => q.id !== id);
    saveToStorage(STORAGE_KEYS.UNIT_QUESTIONS, dynamicUnitTestQuestions);
  },
  syncUnitTestQuestions: (questions: UnitTestQuestion[], testId?: string) => {
    const valid = (questions || []).filter(Boolean);
    if (testId) {
      const others = dynamicUnitTestQuestions.filter((q) => q.testId !== testId);
      dynamicUnitTestQuestions = [...others, ...valid].sort((a, b) => (a.order || 0) - (b.order || 0));
    } else {
      dynamicUnitTestQuestions = [...valid].sort((a, b) => (a.order || 0) - (b.order || 0));
    }
    saveToStorage(STORAGE_KEYS.UNIT_QUESTIONS, dynamicUnitTestQuestions);
  },

  // Unit MCQ Attempts & Results
  getUnitTestAttempts: (testId?: string, studentId?: string): UnitTestAttempt[] => {
    return dynamicUnitTestAttempts.filter((a) => {
      if (testId && a.testId !== testId) return false;
      if (studentId && a.studentId !== studentId) return false;
      return true;
    });
  },
  getUnitTestAttemptById: (id: string): UnitTestAttempt | null =>
    dynamicUnitTestAttempts.find((a) => a.id === id) || null,
  saveUnitTestAttempt: (attempt: UnitTestAttempt) => {
    const idx = dynamicUnitTestAttempts.findIndex((a) => a.id === attempt.id);
    if (idx >= 0) {
      dynamicUnitTestAttempts[idx] = { ...dynamicUnitTestAttempts[idx], ...attempt };
    } else {
      dynamicUnitTestAttempts.push(attempt);
    }
    saveToStorage(STORAGE_KEYS.UNIT_ATTEMPTS, dynamicUnitTestAttempts);
  },
  getUnitTestResult: (resultOrAttemptId: string): UnitTestResult | null =>
    dynamicUnitTestResults.find((r) => r.id === resultOrAttemptId || r.attemptId === resultOrAttemptId) || null,
  saveUnitTestResult: (result: UnitTestResult) => {
    const idx = dynamicUnitTestResults.findIndex((r) => r.id === result.id);
    if (idx >= 0) {
      dynamicUnitTestResults[idx] = { ...dynamicUnitTestResults[idx], ...result };
    } else {
      dynamicUnitTestResults.push(result);
    }
    saveToStorage(STORAGE_KEYS.UNIT_RESULTS, dynamicUnitTestResults);
  },

  // Enrollments (Offline & Local Resilience)
  getEnrollment: (userId: string, batchId: string): Enrollment | null => {
    const docId = `enr_${userId}_${batchId}`;
    return dynamicEnrollments.find((e) => e.id === docId || (e.userId === userId && e.batchId === batchId)) || null;
  },
  getEnrollmentsByUser: (userId: string): Enrollment[] => {
    return dynamicEnrollments.filter((e) => e.userId === userId && e.status === 'active');
  },
  getAllEnrollments: (): Enrollment[] => [...dynamicEnrollments],
  saveEnrollment: (enrollment: Enrollment) => {
    const idx = dynamicEnrollments.findIndex((e) => e.id === enrollment.id);
    if (idx >= 0) {
      dynamicEnrollments[idx] = { ...dynamicEnrollments[idx], ...enrollment };
    } else {
      dynamicEnrollments.push(enrollment);
    }
    saveToStorage(STORAGE_KEYS.ENROLLMENTS, dynamicEnrollments);
  },

  // Payments (Phase 7 Razorpay Transactions)
  getPayments: (): PaymentRecord[] => [...dynamicPayments],
  getPaymentsByUser: (userId: string): PaymentRecord[] => {
    return dynamicPayments.filter((p) => p.userId === userId);
  },
  getPaymentById: (id: string): PaymentRecord | null => {
    return dynamicPayments.find((p) => p.id === id) || null;
  },
  getPaymentByOrderId: (orderId: string): PaymentRecord | null => {
    return dynamicPayments.find((p) => p.orderId === orderId) || null;
  },
  savePayment: (payment: PaymentRecord) => {
    const idx = dynamicPayments.findIndex((p) => p.id === payment.id || p.orderId === payment.orderId);
    if (idx >= 0) {
      dynamicPayments[idx] = { ...dynamicPayments[idx], ...payment };
    } else {
      dynamicPayments.push(payment);
    }
    saveToStorage(STORAGE_KEYS.PAYMENTS, dynamicPayments);
  },

  // Complete Clean Slate Purge
  clearAllCurriculum: () => {
    dynamicBatches = [];
    dynamicSubjects = [];
    dynamicChapters = [];
    dynamicClasses = [];
    dynamicPdfNotes = [];
    dynamicWeeklyWarriorTests = [];
    dynamicWeeklyWarriorQuestions = [];
    dynamicWeeklyWarriorAttempts = [];
    dynamicWeeklyWarriorResults = [];
    dynamicUnitTests = [];
    dynamicUnitTestQuestions = [];
    dynamicUnitTestAttempts = [];
    dynamicUnitTestResults = [];
    dynamicEnrollments = [];
    dynamicPayments = [];
    if (typeof window !== 'undefined') {
      try {
        const keysToRemove: string[] = [];
        for (let i = 0; i < localStorage.length; i++) {
          const key = localStorage.key(i);
          if (key && (key.startsWith('axon_') || key.startsWith('axon-'))) {
            keysToRemove.push(key);
          }
        }
        keysToRemove.forEach((k) => localStorage.removeItem(k));
        localStorage.setItem(CLEAN_SLATE_PURGE_KEY, 'done');
        scheduleCloudCatalogPush(true);
      } catch (e) {
        // ignore
      }
    }
  },
};

// Automatically synchronize with authoritative Cloud Run catalog on startup (read-only replacement, never re-uploads stale localStorage)
if (typeof window !== 'undefined') {
  fetchApi('/api/catalog/state')
    .then((res) => (res.ok ? res.json() : null))
    .then((remote) => {
      if (!remote) return;
      isApplyingRemoteState = true;
      try {
        if (Array.isArray(remote.batches)) {
          dynamicBatches = preserveRecentlySaved(remote.batches, dynamicBatches);
          saveToStorage(STORAGE_KEYS.BATCHES, dynamicBatches);
        }
        if (Array.isArray(remote.subjects)) {
          dynamicSubjects = preserveRecentlySaved(remote.subjects, dynamicSubjects);
          saveToStorage(STORAGE_KEYS.SUBJECTS, dynamicSubjects);
        }
        if (Array.isArray(remote.chapters)) {
          dynamicChapters = preserveRecentlySaved(remote.chapters, dynamicChapters);
          saveToStorage(STORAGE_KEYS.CHAPTERS, dynamicChapters);
        }
        if (Array.isArray(remote.classes)) {
          dynamicClasses = preserveRecentlySaved(remote.classes, dynamicClasses);
          saveToStorage(STORAGE_KEYS.CLASSES, dynamicClasses);
        }
        if (Array.isArray(remote.pdfNotes)) {
          dynamicPdfNotes = preserveRecentlySaved(remote.pdfNotes, dynamicPdfNotes);
          saveToStorage(STORAGE_KEYS.PDF_NOTES, dynamicPdfNotes);
        }
        if (Array.isArray(remote.weeklyWarriorTests)) {
          dynamicWeeklyWarriorTests = preserveRecentlySaved(remote.weeklyWarriorTests, dynamicWeeklyWarriorTests);
          saveToStorage(STORAGE_KEYS.WW_TESTS, dynamicWeeklyWarriorTests);
        }
        if (Array.isArray(remote.weeklyWarriorQuestions)) {
          dynamicWeeklyWarriorQuestions = preserveRecentlySaved(remote.weeklyWarriorQuestions, dynamicWeeklyWarriorQuestions);
          saveToStorage(STORAGE_KEYS.WW_QUESTIONS, dynamicWeeklyWarriorQuestions);
        }
        if (Array.isArray(remote.unitTests)) {
          dynamicUnitTests = preserveRecentlySaved(remote.unitTests, dynamicUnitTests);
          saveToStorage(STORAGE_KEYS.UNIT_TESTS, dynamicUnitTests);
        }
        if (Array.isArray(remote.unitTestQuestions)) {
          dynamicUnitTestQuestions = preserveRecentlySaved(remote.unitTestQuestions, dynamicUnitTestQuestions);
          saveToStorage(STORAGE_KEYS.UNIT_QUESTIONS, dynamicUnitTestQuestions);
        }
      } finally {
        isApplyingRemoteState = false;
      }
    })
    .catch(() => {});
}
