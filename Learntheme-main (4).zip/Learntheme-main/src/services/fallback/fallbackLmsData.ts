/**
 * Axon Nursing Academy - LMS Data Provider
 * Provides foundational NORCET & Nursing Officer curriculum out-of-the-box
 * and syncs dynamically with Admin CMS, Cloud Run Backend, and Firestore.
 */
import { Batch, Subject, Chapter, LmsClass, PdfNote } from '../../types/lms.types';
import {
  WeeklyWarriorTest,
  WeeklyWarriorQuestion,
  UnitTest,
  UnitTestQuestion,
} from '../../types/assessment.types';

export const FALLBACK_BATCHES: Batch[] = [];

export const FALLBACK_SUBJECTS: Subject[] = [];

export const FALLBACK_CHAPTERS: Chapter[] = [];

export const FALLBACK_CLASSES: LmsClass[] = [];

export const FALLBACK_PDF_NOTES: PdfNote[] = [];

export const FALLBACK_WEEKLY_WARRIOR_TESTS: WeeklyWarriorTest[] = [];

export const FALLBACK_WEEKLY_WARRIOR_QUESTIONS: WeeklyWarriorQuestion[] = [];

export const FALLBACK_UNIT_TESTS: UnitTest[] = [];

export const FALLBACK_UNIT_TEST_QUESTIONS: UnitTestQuestion[] = [];

