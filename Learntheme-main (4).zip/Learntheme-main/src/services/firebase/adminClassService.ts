/**
 * Axon Nursing Academy - Firebase Firestore Admin Class Service
 * Complete CRUD operations and video publishing control for Classes/Lessons.
 */
import {
  collection,
  doc,
  getDocs,
  setDoc,
  updateDoc,
  deleteDoc,
  query,
  where,
  orderBy,
  onSnapshot,
  serverTimestamp,
} from 'firebase/firestore';
import { getFirestoreDb, OperationType, handleFirestoreError } from '@/src/lib/firebase/firestore';
import { LmsClass } from '@/src/types/lms.types';
import { extractYouTubeVideoId, getYouTubeThumbnailUrl, getYouTubeWatchUrl } from '@/src/lib/utils/youtubeUtils';
import { logAdminAction } from './auditService';
import { generateSlug } from './adminBatchService';
import { fallbackStore } from '@/src/services/fallback/fallbackStore';
import { withTimeout } from '@/src/lib/utils/asyncUtils';

const CLASSES_COLLECTION = 'classes';

export interface ClassFormData {
  batchId: string;
  subjectId: string;
  chapterId: string;
  title: string;
  description: string;
  videoUrl: string;
  youtubeVideoId?: string;
  youtubeUrl?: string;
  videoProvider?: 'youtube' | 'direct' | 'vimeo';
  durationMinutes: number;
  thumbnailUrl: string;
  order: number;
  isFree: boolean;
  isPublished: boolean;
}

function parseClassDoc(docSnap: any): LmsClass {
  const data = docSnap.data();
  const rawVideoUrl = data.videoUrl || data.youtubeUrl || '';
  const ytId = data.youtubeVideoId || extractYouTubeVideoId(rawVideoUrl);

  return {
    id: docSnap.id,
    batchId: data.batchId || '',
    subjectId: data.subjectId || '',
    chapterId: data.chapterId || '',
    title: data.title || 'Untitled Class',
    description: data.description || '',
    videoUrl: rawVideoUrl,
    youtubeVideoId: ytId || undefined,
    youtubeUrl: ytId ? getYouTubeWatchUrl(ytId) || rawVideoUrl : undefined,
    videoProvider: data.videoProvider || (ytId ? 'youtube' : 'direct'),
    durationMinutes: typeof data.durationMinutes === 'number' ? data.durationMinutes : 0,
    thumbnailUrl: data.thumbnailUrl || (ytId ? getYouTubeThumbnailUrl(ytId) || '' : ''),
    order: typeof data.order === 'number' ? data.order : 0,
    isFree: Boolean(data.isFree),
    isPublished: Boolean(data.isPublished),
    createdAt: data.createdAt,
    updatedAt: data.updatedAt,
  };
}

/**
 * Fetch all classes across all chapters for Admin CMS.
 */
export async function getAllClassesAdmin(): Promise<LmsClass[]> {
  const cached = fallbackStore.getClasses();
  const db = getFirestoreDb();
  if (!db) return cached;

  try {
    const fetchFromFirestore = async () => {
      const classesRef = collection(db, CLASSES_COLLECTION);
      const q = query(classesRef, orderBy('order', 'asc'));
      const snapshot = await getDocs(q);

      const classes: LmsClass[] = (snapshot?.docs || []).map((docSnap) => parseClassDoc(docSnap));
      const sorted = classes.sort((a, b) => (a.order || 0) - (b.order || 0));
      fallbackStore.syncClasses(sorted);
      return sorted;
    };

    return await withTimeout(fetchFromFirestore(), 1200, cached);
  } catch (err: any) {
    console.warn('[AdminClassService] Returning cached classes:', err?.message || err);
    return cached;
  }
}

/**
 * Real-time listener for classes in Admin CMS.
 */
export function subscribeToClassesAdmin(
  callback: (classes: LmsClass[]) => void,
  chapterId?: string,
  onError?: (err: any) => void
): () => void {
  const db = getFirestoreDb();
  if (!db) {
    callback(fallbackStore.getClasses(chapterId));
    return () => {};
  }

  try {
    const classesRef = collection(db, CLASSES_COLLECTION);
    const q = chapterId ? query(classesRef, where('chapterId', '==', chapterId)) : classesRef;

    return onSnapshot(
      q,
      (snapshot) => {
        const classes: LmsClass[] = snapshot.docs.map((docSnap) => parseClassDoc(docSnap));
        const sorted = classes.sort((a, b) => (a.order || 0) - (b.order || 0));
        fallbackStore.syncClasses(sorted, chapterId);
        callback(sorted);
      },
      (err) => {
        console.warn('[AdminClassService] Realtime subscription notice:', err);
        callback(fallbackStore.getClasses(chapterId));
        if (onError) onError(err);
      }
    );
  } catch (err: any) {
    console.warn('[AdminClassService] Realtime listener error:', err);
    callback(fallbackStore.getClasses(chapterId));
    return () => {};
  }
}

/**
 * Fetch all classes belonging to a chapter (both published & drafts).
 */
export async function getClassesForChapterAdmin(chapterId: string): Promise<LmsClass[]> {
  const cached = fallbackStore.getClasses(chapterId);
  const db = getFirestoreDb();
  if (!db || !chapterId) return cached;

  try {
    const fetchFromFirestore = async () => {
      const classesRef = collection(db, CLASSES_COLLECTION);
      const q = query(classesRef, where('chapterId', '==', chapterId));
      const snapshot = await getDocs(q);

      const classes: LmsClass[] = (snapshot?.docs || []).map((docSnap) => parseClassDoc(docSnap));
      const sorted = classes.sort((a, b) => (a.order || 0) - (b.order || 0));
      fallbackStore.syncClasses(sorted, chapterId);
      return sorted;
    };

    return await withTimeout(fetchFromFirestore(), 1200, cached);
  } catch (err: any) {
    console.warn('[AdminClassService] Returning chapter cached classes:', err?.message || err);
    return cached;
  }
}

/**
 * Create a new Class/Lesson in Firestore.
 */
export async function createClass(
  data: ClassFormData,
  actorUid: string,
  actorEmail?: string
): Promise<LmsClass> {
  const slug = generateSlug(data.title) || 'class';
  const classId = `${data.chapterId}_${slug}_${Date.now()}`;
  const videoInput = (data.videoUrl || '').trim();
  const ytId = extractYouTubeVideoId(videoInput);
  const isYouTube = Boolean(ytId);

  let defaultThumbnail = (data.thumbnailUrl || '').trim();
  if (!defaultThumbnail && ytId) {
    defaultThumbnail = getYouTubeThumbnailUrl(ytId) || '';
  }

  const payload: LmsClass = {
    id: classId,
    batchId: data.batchId,
    subjectId: data.subjectId,
    chapterId: data.chapterId,
    title: data.title.trim(),
    description: (data.description || '').trim(),
    videoUrl: videoInput,
    youtubeVideoId: ytId || undefined,
    youtubeUrl: ytId ? getYouTubeWatchUrl(ytId) || videoInput : undefined,
    videoProvider: isYouTube ? 'youtube' : 'direct',
    durationMinutes: Number(data.durationMinutes) || 0,
    thumbnailUrl: defaultThumbnail,
    order: Number(data.order) || 1,
    isFree: Boolean(data.isFree),
    isPublished: Boolean(data.isPublished),
  };

  // Always register in runtime fallback store
  fallbackStore.saveClass(payload);

  const db = getFirestoreDb();
  if (!db) {
    return payload;
  }

  try {
    const docRef = doc(db, CLASSES_COLLECTION, classId);
    const firestorePayload: Record<string, any> = {
      id: payload.id,
      batchId: payload.batchId,
      subjectId: payload.subjectId,
      chapterId: payload.chapterId,
      title: payload.title,
      description: payload.description,
      videoUrl: payload.videoUrl || '',
      youtubeVideoId: ytId || '',
      youtubeUrl: ytId ? getYouTubeWatchUrl(ytId) || videoInput : '',
      videoProvider: payload.videoProvider || 'youtube',
      durationMinutes: payload.durationMinutes,
      thumbnailUrl: payload.thumbnailUrl || '',
      order: payload.order,
      isFree: payload.isFree,
      isPublished: payload.isPublished,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    };
    await setDoc(docRef, firestorePayload);

    await logAdminAction({
      actorUid,
      actorEmail,
      action: 'CLASS_CREATED',
      resourceType: 'class',
      resourceId: classId,
      resourceTitle: data.title,
      details: {
        chapterId: data.chapterId,
        isPublished: data.isPublished,
        isFree: data.isFree,
        isYouTube,
        youtubeVideoId: ytId || '',
      },
    }).catch(() => {});

    return payload;
  } catch (err: any) {
    console.warn('[AdminClassService] Firestore write deferred, saved to local cache:', err?.message || err);
    return payload;
  }
}

/**
 * Update an existing class.
 */
export async function updateClass(
  classId: string,
  data: Partial<ClassFormData>,
  actorUid: string,
  actorEmail?: string
): Promise<void> {
  const existing = fallbackStore.getClassById(classId);
  if (existing) {
    fallbackStore.saveClass({ ...existing, ...data } as LmsClass);
  }

  const db = getFirestoreDb();
  if (!db) return;

  try {
    const docRef = doc(db, CLASSES_COLLECTION, classId);

    const updatePayload: Record<string, any> = {
      updatedAt: serverTimestamp(),
    };

    for (const [k, v] of Object.entries(data)) {
      if (v !== undefined) {
        updatePayload[k] = v;
      }
    }

    if (data.videoUrl !== undefined) {
      const videoInput = data.videoUrl.trim();
      const ytId = extractYouTubeVideoId(videoInput);
      updatePayload.videoUrl = videoInput;
      updatePayload.youtubeVideoId = ytId || '';
      updatePayload.youtubeUrl = ytId ? getYouTubeWatchUrl(ytId) || videoInput : '';
      updatePayload.videoProvider = ytId ? 'youtube' : 'direct';

      if (!data.thumbnailUrl && ytId) {
        updatePayload.thumbnailUrl = getYouTubeThumbnailUrl(ytId) || '';
      }
    }

    await Promise.race([
      setDoc(docRef, updatePayload, { merge: true }),
      new Promise<void>((resolve) => setTimeout(resolve, 1500)),
    ]);

    logAdminAction({
      actorUid,
      actorEmail,
      action: 'CLASS_UPDATED',
      resourceType: 'class',
      resourceId: classId,
      resourceTitle: data.title || classId,
      details: { changedFields: Object.keys(data) },
    }).catch(() => {});
  } catch (err: any) {
    console.warn('[AdminClassService] Firestore update deferred:', err?.message || err);
  }
}

/**
 * Toggle publish status of a class.
 */
export async function toggleClassPublish(
  classId: string,
  newPublishedState: boolean,
  classTitle: string,
  actorUid: string,
  actorEmail?: string
): Promise<void> {
  const existing = fallbackStore.getClassById(classId);
  if (existing) {
    fallbackStore.saveClass({ ...existing, isPublished: newPublishedState });
  }

  const db = getFirestoreDb();
  if (!db) return;

  try {
    const docRef = doc(db, CLASSES_COLLECTION, classId);
    await Promise.race([
      setDoc(docRef, {
        isPublished: newPublishedState,
        updatedAt: serverTimestamp(),
      }, { merge: true }),
      new Promise<void>((resolve) => setTimeout(resolve, 1200)),
    ]);

    logAdminAction({
      actorUid,
      actorEmail,
      action: newPublishedState ? 'CLASS_PUBLISHED' : 'CLASS_UNPUBLISHED',
      resourceType: 'class',
      resourceId: classId,
      resourceTitle: classTitle,
      details: { isPublished: newPublishedState },
    }).catch(() => {});
  } catch (err: any) {
    console.warn('[AdminClassService] Firestore toggle deferred:', err?.message || err);
  }
}

/**
 * Delete a class.
 */
export async function deleteClass(
  classId: string,
  classTitle: string,
  actorUid: string,
  actorEmail?: string
): Promise<void> {
  fallbackStore.deleteClass(classId);

  const db = getFirestoreDb();
  if (!db) return;

  const path = `${CLASSES_COLLECTION}/${classId}`;
  try {
    const docRef = doc(db, CLASSES_COLLECTION, classId);
    await deleteDoc(docRef);

    await logAdminAction({
      actorUid,
      actorEmail,
      action: 'CLASS_DELETED',
      resourceType: 'class',
      resourceId: classId,
      resourceTitle: classTitle,
    }).catch(() => {});
  } catch (err: any) {
    console.warn('[AdminClassService] Firestore delete deferred:', err?.message || err);
  }
}
