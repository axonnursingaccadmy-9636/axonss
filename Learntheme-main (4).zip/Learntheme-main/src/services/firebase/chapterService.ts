/**
 * Axon Nursing Academy - Firebase Firestore Chapter Service
 * Ultra-fast local-first query with background Firestore synchronization.
 */
import {
  collection,
  doc,
  getDoc,
  getDocs,
  query,
  where,
  orderBy,
} from 'firebase/firestore';
import { getFirestoreDb } from '@/src/lib/firebase/firestore';
import { Chapter } from '@/src/types/lms.types';
import { fallbackStore } from '@/src/services/fallback/fallbackStore';
import { withTimeout } from '@/src/lib/utils/asyncUtils';

const CHAPTERS_COLLECTION = 'chapters';

/**
 * Fetch all published chapters belonging to a specific subject.
 */
export async function getPublishedChapters(subjectId: string): Promise<Chapter[]> {
  const cached = fallbackStore.getChapters(subjectId).filter((c) => c.isPublished);
  const timeoutMs = cached.length > 0 ? 4000 : 8000;

  const db = getFirestoreDb();
  if (!db || !subjectId) {
    return cached;
  }

  try {
    const fetchFromFirestore = async () => {
      const chaptersRef = collection(db, CHAPTERS_COLLECTION);
      const q = query(
        chaptersRef,
        where('subjectId', '==', subjectId),
        where('isPublished', '==', true)
      );

      const snapshot = await getDocs(q);

      const chapters: Chapter[] = (snapshot?.docs || []).map((docSnap) => {
        const data = docSnap.data();
        return {
          id: docSnap.id,
          batchId: data.batchId || '',
          subjectId: data.subjectId || subjectId,
          name: data.name || 'Untitled Chapter',
          description: data.description || '',
          order: typeof data.order === 'number' ? data.order : 0,
          isPublished: Boolean(data.isPublished),
          createdAt: data.createdAt,
          updatedAt: data.updatedAt,
        };
      });

      const sorted = chapters.sort((a, b) => (a.order || 0) - (b.order || 0));
      fallbackStore.syncChapters(sorted, subjectId);
      return sorted;
    };

    return await withTimeout(fetchFromFirestore(), timeoutMs, cached);
  } catch (err: any) {
    console.warn('[chapterService] Serving cached chapters:', err?.message || err);
    return cached;
  }
}

/**
 * Fetch a single chapter by ID.
 */
export async function getChapterById(chapterId: string): Promise<Chapter | null> {
  const cached = fallbackStore.getChapterById(chapterId);

  const db = getFirestoreDb();
  if (!db || !chapterId) {
    return cached;
  }

  try {
    const fetchFromFirestore = async () => {
      const docRef = doc(db, CHAPTERS_COLLECTION, chapterId);
      const docSnap = await getDoc(docRef);

      if (!docSnap.exists()) {
        return cached;
      }

      const data = docSnap.data();
      if (!data.isPublished) {
        return null;
      }

      const chapter: Chapter = {
        id: docSnap.id,
        batchId: data.batchId || '',
        subjectId: data.subjectId || '',
        name: data.name || 'Untitled Chapter',
        description: data.description || '',
        order: typeof data.order === 'number' ? data.order : 0,
        isPublished: Boolean(data.isPublished),
        createdAt: data.createdAt,
        updatedAt: data.updatedAt,
      };

      fallbackStore.saveChapter(chapter);
      return chapter;
    };

    return await withTimeout(fetchFromFirestore(), 1200, cached);
  } catch (err: any) {
    console.warn('[chapterService] Serving cached chapter by ID:', err?.message || err);
    return cached;
  }
}
