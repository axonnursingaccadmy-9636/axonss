/**
 * Axon Nursing Academy - Firebase Firestore Audit Logging Service
 */
import {
  collection,
  doc,
  setDoc,
  getDocs,
  query,
  orderBy,
  limit,
  serverTimestamp,
} from 'firebase/firestore';
import { getFirestoreDb, OperationType, handleFirestoreError } from '@/src/lib/firebase/firestore';
import { getFirebaseAuth } from '@/src/lib/firebase/auth';
import { AuditLog, AuditActionType } from '@/src/types/audit.types';

const AUDIT_COLLECTION = 'auditLogs';
const PRIMARY_ADMIN_EMAIL = 'pmgautamjaipur@gmail.com';

function normalizeAdminActorEmail(email?: string | null): string {
  const cleaned = (email || '').trim();
  if (!cleaned || cleaned.toLowerCase() === 'admin@axonnursing.edu') {
    const authEmail = getFirebaseAuth()?.currentUser?.email?.trim();
    if (authEmail && authEmail.toLowerCase() !== 'admin@axonnursing.edu') {
      return authEmail;
    }
    return PRIMARY_ADMIN_EMAIL;
  }
  return cleaned;
}

export interface CreateAuditLogParams {
  actorUid: string;
  actorEmail?: string;
  action: AuditActionType | string;
  resourceType:
    | 'batch'
    | 'subject'
    | 'chapter'
    | 'class'
    | 'pdfNote'
    | 'database'
    | 'weekly_warrior_test'
    | 'weekly_warrior_question'
    | 'unit_test'
    | 'unit_test_question'
    | 'assessment'
    | 'coupon'
    | 'enrollment';
  resourceId: string;
  resourceTitle?: string;
  resourceName?: string;
  details?: Record<string, any>;
}


/**
 * Record an audit log for an administrative operation.
 */
export async function logAdminAction(params: CreateAuditLogParams): Promise<void> {
  const db = getFirestoreDb();
  if (!db) return;

  const logId = `log_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
  const path = `${AUDIT_COLLECTION}/${logId}`;

  try {
    const docRef = doc(db, AUDIT_COLLECTION, logId);
    await setDoc(docRef, {
      id: logId,
      actorUid: params.actorUid,
      actorEmail: normalizeAdminActorEmail(params.actorEmail),
      action: params.action,
      resourceType: params.resourceType,
      resourceId: params.resourceId,
      resourceTitle: params.resourceTitle || params.resourceName || '',
      details: params.details || {},
      timestamp: serverTimestamp(),
    });
  } catch (err) {
    // Non-blocking: log warning so main mutation doesn't fail if audit rules catch
    console.warn('[auditService] Failed to record audit log:', err);
  }
}

export const logAdminAudit = logAdminAction;

/**
 * Fetch recent audit logs for Admin Dashboard / Audit Log page.
 */
export async function getRecentAuditLogs(maxCount: number = 30): Promise<AuditLog[]> {
  const db = getFirestoreDb();
  if (!db) return [];

  const path = AUDIT_COLLECTION;
  try {
    const auditRef = collection(db, AUDIT_COLLECTION);
    const q = query(auditRef, orderBy('timestamp', 'desc'), limit(maxCount));
    const snapshot = await getDocs(q);

    return snapshot.docs.map((docSnap) => {
      const data = docSnap.data();
      const rawEmail = (data.actorEmail || '').trim();
      const actorEmail =
        !rawEmail || rawEmail.toLowerCase() === 'admin@axonnursing.edu' || rawEmail === 'System Admin'
          ? PRIMARY_ADMIN_EMAIL
          : rawEmail;
      return {
        id: docSnap.id,
        actorUid: data.actorUid || '',
        actorEmail,
        action: data.action || 'OPERATION',
        resourceType: data.resourceType || 'batch',
        resourceId: data.resourceId || '',
        resourceTitle: data.resourceTitle || '',
        details: data.details || {},
        timestamp: data.timestamp,
      };
    });
  } catch (err: any) {
    console.warn('[auditService] Notice loading audit logs:', err?.message || err);
    return [];
  }
}
