/**
 * Axon Nursing Academy - Firebase Firestore Admin Chapter Service
 * Complete CRUD operations and publishing control for Chapters.
 */
import {
  collection,
  doc,
  getDocs,
  setDoc,
  updateDoc,
  deleteDoc,
  query,
  where,
  orderBy,
  serverTimestamp,
} from 'firebase/firestore';
import { getFirestoreDb, OperationType, handleFirestoreError } from '@/src/lib/firebase/firestore';
import { Chapter } from '@/src/types/lms.types';
import { logAdminAction } from './auditService';
import { generateSlug } from './adminBatchService';
import { fallbackStore } from '@/src/services/fallback/fallbackStore';
import { withTimeout } from '@/src/lib/utils/asyncUtils';

const CHAPTERS_COLLECTION = 'chapters';

export interface ChapterFormData {
  batchId: string;
  subjectId: string;
  name: string;
  description: string;
  order: number;
  isPublished: boolean;
}

/**
 * Fetch all chapters across all subjects for Admin CMS.
 */
export async function getAllChaptersAdmin(): Promise<Chapter[]> {
  const db = getFirestoreDb();
  if (!db) return fallbackStore.getChapters();

  try {
    const chaptersRef = collection(db, CHAPTERS_COLLECTION);
    const snapshot = await getDocs(chaptersRef);

    const chapters: Chapter[] = snapshot.docs.map((docSnap) => {
      const data = docSnap.data();
      return {
        id: docSnap.id,
        batchId: data.batchId || '',
        subjectId: data.subjectId || '',
        name: data.name || 'Untitled Chapter',
        description: data.description || '',
        order: typeof data.order === 'number' ? data.order : 0,
        isPublished: Boolean(data.isPublished),
        createdAt: data.createdAt,
        updatedAt: data.updatedAt,
      };
    });

    const sorted = chapters.sort((a, b) => (a.order || 0) - (b.order || 0));
    fallbackStore.syncChapters(sorted);
    return sorted;
  } catch (err: any) {
    console.warn('[AdminChapterService] Returning cached chapters:', err?.message || err);
    return fallbackStore.getChapters();
  }
}

/**
 * Fetch all chapters belonging to a subject (both published & drafts).
 */
export async function getChaptersForSubjectAdmin(subjectId: string): Promise<Chapter[]> {
  const db = getFirestoreDb();
  if (!db || !subjectId) return fallbackStore.getChapters(subjectId);

  try {
    const chaptersRef = collection(db, CHAPTERS_COLLECTION);
    const q = query(chaptersRef, where('subjectId', '==', subjectId));
    const snapshot = await getDocs(q);

    const chapters: Chapter[] = snapshot.docs.map((docSnap) => {
      const data = docSnap.data();
      return {
        id: docSnap.id,
        batchId: data.batchId || '',
        subjectId: data.subjectId || subjectId,
        name: data.name || 'Untitled Chapter',
        description: data.description || '',
        order: typeof data.order === 'number' ? data.order : 0,
        isPublished: Boolean(data.isPublished),
        createdAt: data.createdAt,
        updatedAt: data.updatedAt,
      };
    });

    const sorted = chapters.sort((a, b) => (a.order || 0) - (b.order || 0));
    fallbackStore.syncChapters(sorted, subjectId);
    return sorted;
  } catch (err: any) {
    console.warn('[AdminChapterService] Returning subject cached chapters:', err?.message || err);
    return fallbackStore.getChapters(subjectId);
  }
}

/**
 * Create a new chapter in Firestore.
 */
export async function createChapter(
  data: ChapterFormData,
  actorUid: string,
  actorEmail?: string
): Promise<Chapter> {
  const cleanSlug = generateSlug(data.name) || 'chap';
  const chapterId = `${data.subjectId || 'subj'}_${cleanSlug}_${Date.now()}`;

  const payload: Chapter = {
    id: chapterId,
    batchId: data.batchId,
    subjectId: data.subjectId,
    name: data.name.trim(),
    description: data.description.trim(),
    order: Number(data.order) || 0,
    isPublished: Boolean(data.isPublished),
  };

  // Immediate local cache update
  fallbackStore.saveChapter(payload);

  const db = getFirestoreDb();
  if (db) {
    try {
      const docRef = doc(db, CHAPTERS_COLLECTION, chapterId);
      await setDoc(docRef, {
        ...payload,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });

      logAdminAction({
        actorUid,
        actorEmail,
        action: 'CHAPTER_CREATED',
        resourceType: 'chapter',
        resourceId: chapterId,
        resourceTitle: data.name,
        details: { subjectId: data.subjectId, batchId: data.batchId, isPublished: data.isPublished },
      }).catch(() => {});
    } catch (err: any) {
      console.warn('[AdminChapterService] Firestore create notice (saved locally):', err?.message || err);
    }
  }

  return payload;
}

/**
 * Update an existing chapter.
 */
export async function updateChapter(
  chapterId: string,
  data: Partial<ChapterFormData>,
  actorUid: string,
  actorEmail?: string
): Promise<void> {
  const existing = fallbackStore.getChapterById(chapterId);
  fallbackStore.saveChapter({ ...(existing || {}), ...data, id: chapterId } as Chapter);

  const db = getFirestoreDb();
  if (!db) return;

  try {
    const docRef = doc(db, CHAPTERS_COLLECTION, chapterId);
    await setDoc(docRef, {
      ...data,
      updatedAt: serverTimestamp(),
    }, { merge: true });

    logAdminAction({
      actorUid,
      actorEmail,
      action: 'CHAPTER_UPDATED',
      resourceType: 'chapter',
      resourceId: chapterId,
      resourceTitle: data.name || chapterId,
      details: { changedFields: Object.keys(data) },
    }).catch(() => {});
  } catch (err: any) {
    console.warn('[AdminChapterService] Firestore update notice (saved locally):', err?.message || err);
  }
}

/**
 * Toggle publish status of a chapter.
 */
export async function toggleChapterPublish(
  chapterId: string,
  newPublishedState: boolean,
  chapterName: string,
  actorUid: string,
  actorEmail?: string
): Promise<void> {
  const existing = fallbackStore.getChapterById(chapterId);
  if (existing) {
    fallbackStore.saveChapter({ ...existing, isPublished: newPublishedState });
  }

  const db = getFirestoreDb();
  if (!db) return;

  try {
    const docRef = doc(db, CHAPTERS_COLLECTION, chapterId);
    await setDoc(docRef, {
      isPublished: newPublishedState,
      updatedAt: serverTimestamp(),
    }, { merge: true });

    logAdminAction({
      actorUid,
      actorEmail,
      action: newPublishedState ? 'CHAPTER_PUBLISHED' : 'CHAPTER_UNPUBLISHED',
      resourceType: 'chapter',
      resourceId: chapterId,
      resourceTitle: chapterName,
      details: { isPublished: newPublishedState },
    }).catch(() => {});
  } catch (err: any) {
    console.warn('[AdminChapterService] Firestore toggle notice (saved locally):', err?.message || err);
  }
}

/**
 * Delete a chapter from Firestore and cascade delete child items.
 */
export async function deleteChapter(
  chapterId: string,
  chapterName: string,
  actorUid: string,
  actorEmail?: string
): Promise<void> {
  fallbackStore.deleteChapter(chapterId);

  const db = getFirestoreDb();
  if (!db) return;

  try {
    const docRef = doc(db, CHAPTERS_COLLECTION, chapterId);
    await deleteDoc(docRef);

    // Cascade delete child classes and pdf notes from Firestore
    try {
      const classesRef = collection(db, 'classes');
      const classesSnap = await getDocs(query(classesRef, where('chapterId', '==', chapterId)));
      for (const clDoc of classesSnap.docs) {
        await deleteDoc(clDoc.ref);
      }

      const notesRef = collection(db, 'pdf_notes');
      const notesSnap = await getDocs(query(notesRef, where('chapterId', '==', chapterId)));
      for (const nDoc of notesSnap.docs) {
        await deleteDoc(nDoc.ref);
      }
    } catch (cleanupErr) {
      console.warn('[AdminChapterService] Cascade cleanup notice:', cleanupErr);
    }

    logAdminAction({
      actorUid,
      actorEmail,
      action: 'CHAPTER_DELETED',
      resourceType: 'chapter',
      resourceId: chapterId,
      resourceTitle: chapterName,
    }).catch(() => {});
  } catch (err: any) {
    console.warn('[AdminChapterService] Firestore delete notice (deleted locally):', err?.message || err);
  }
}
