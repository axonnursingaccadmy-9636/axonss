/**
 * Axon Nursing Academy - Firebase Authentication Service
 * Wraps Firebase Web SDK Auth methods with comprehensive error handling.
 */
import {
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signOut,
  sendPasswordResetEmail,
  updateProfile,
  GoogleAuthProvider,
  signInWithPopup,
  onAuthStateChanged,
  User as FirebaseUser,
  UserCredential,
  NextOrObserver,
  Unsubscribe,
} from 'firebase/auth';
import { getFirebaseAuth } from '@/src/lib/firebase/auth';
import { isFirebaseConfigured } from '@/src/lib/firebase/config';

/**
 * Human-readable mapping of Firebase Auth error codes to user-friendly messages.
 * Complies with strict security standards (does not reveal sensitive information unnecessarily).
 */
export function getFriendlyAuthErrorMessage(error: any): string {
  if (!error) return 'Authentication failed. Please check your credentials and try again.';

  const code = typeof error === 'string' ? error : error?.code || '';

  switch (code) {
    // 2. Login error mappings
    case 'auth/user-not-found':
      return 'No account found with this email address.';
    case 'auth/wrong-password':
      return 'Incorrect password. Please try again.';
    case 'auth/invalid-credential':
      return 'Incorrect email or password.';
    case 'auth/user-disabled':
      return 'This account has been disabled. Please contact support.';
    case 'auth/too-many-requests':
      return 'Too many failed attempts. Please try again later.';
    case 'auth/operation-not-allowed':
      return 'Email/password login is currently unavailable. Please contact support.';

    // 4. Signup error mappings
    case 'auth/email-already-in-use':
      return 'An account with this email already exists. Please log in.';
    case 'auth/weak-password':
      return 'Password is too weak. Please use a stronger password.';
    case 'auth/password-does-not-meet-requirements':
      return 'Your password does not meet the required security requirements.';

    // Common input validation mappings
    case 'auth/invalid-email':
    case 'auth/missing-email':
      return 'Please enter a valid email address.';
    case 'auth/missing-password':
      return 'Password is required.';

    // Network error mapping
    case 'auth/network-request-failed':
      return 'Network error. Please check your internet connection and try again.';

    // 7. Firebase connection / configuration failures
    case 'auth/unconfigured':
    case 'auth/unauthorized-domain':
    case 'auth/api-key-not-valid':
    case 'auth/api-key-not-valid-please-pass-a-valid-api-key':
    case 'auth/configuration-not-found':
    case 'auth/invalid-api-key':
    case 'auth/app-deleted':
    case 'auth/firebase-app-check-token-is-invalid':
    case 'auth/app-check-token-is-invalid':
      return 'Authentication service is not configured correctly. Please contact support.';

    // Popup OAuth (if used)
    case 'auth/popup-closed-by-user':
      return 'Sign-in was cancelled before completion. Please try again.';
    case 'auth/popup-blocked':
      return 'Sign-in popup was blocked by your browser. Please allow popups for this site.';
    case 'auth/cancelled-popup-request':
      return 'Only one sign-in request can be processed at a time.';
    case 'auth/account-exists-with-different-credential':
      return 'An account already exists with the same email using a different sign-in method.';
    case 'auth/requires-recent-login':
      return 'This action requires a recent sign-in. Please log out and sign in again.';

    default:
      // Never expose technical error objects, stack traces, or Firebase internal messages
      return 'Authentication failed. Please check your credentials and try again.';
  }
}

/**
 * Sign up a new student with Email and Password.
 */
export async function signUpWithEmail(
  email: string,
  pass: string,
  displayName?: string
): Promise<UserCredential> {
  const auth = getFirebaseAuth();
  if (!auth) {
    throw new Error('auth/unconfigured');
  }

  const cleanEmail = email.trim().toLowerCase();
  const credential = await createUserWithEmailAndPassword(auth, cleanEmail, pass);

  if (displayName && credential.user) {
    try {
      await updateProfile(credential.user, {
        displayName: displayName.trim(),
      });
    } catch (profileError) {
      console.warn('[authService] Failed to set displayName during signup:', profileError);
    }
  }

  return credential;
}

/**
 * Sign in existing student/admin with Email and Password.
 */
export async function signInWithEmail(
  email: string,
  pass: string
): Promise<UserCredential> {
  const auth = getFirebaseAuth();
  if (!auth) {
    throw new Error('auth/unconfigured');
  }

  const cleanEmail = email.trim().toLowerCase();
  return signInWithEmailAndPassword(auth, cleanEmail, pass);
}

/**
 * Sign in or Sign up with Google OAuth popup.
 */
export async function signInWithGooglePopup(): Promise<UserCredential> {
  const auth = getFirebaseAuth();
  if (!auth) {
    throw new Error('auth/unconfigured');
  }

  const provider = new GoogleAuthProvider();
  provider.setCustomParameters({ prompt: 'select_account' });

  return signInWithPopup(auth, provider);
}

/**
 * Sign out current authenticated user.
 */
export async function signOutUser(): Promise<void> {
  const auth = getFirebaseAuth();
  if (!auth) return;
  await signOut(auth);
}

/**
 * Send password reset email instructions.
 */
export async function sendPasswordReset(email: string): Promise<void> {
  const auth = getFirebaseAuth();
  if (!auth) {
    throw new Error('auth/unconfigured');
  }

  const cleanEmail = email.trim().toLowerCase();
  await sendPasswordResetEmail(auth, cleanEmail);
}

/**
 * Listen to real-time auth state changes.
 */
export function subscribeToAuth(
  observerOrNext: NextOrObserver<FirebaseUser>
): Unsubscribe {
  const auth = getFirebaseAuth();
  if (!auth) {
    // If not configured, immediately fire null user
    if (typeof observerOrNext === 'function') {
      observerOrNext(null);
    } else if (observerOrNext && typeof observerOrNext.next === 'function') {
      observerOrNext.next(null);
    }
    return () => {};
  }

  return onAuthStateChanged(auth, observerOrNext);
}
