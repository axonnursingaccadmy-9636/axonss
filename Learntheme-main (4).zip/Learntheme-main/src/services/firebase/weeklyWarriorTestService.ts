/**
 * Axon Nursing Academy - Firebase Firestore Weekly Warrior Test Service
 * Course-level competitive weekly test & MCQ system with zero-trust evaluation.
 */
import {
  collection,
  doc,
  getDoc,
  getDocs,
  setDoc,
  updateDoc,
  deleteDoc,
  query,
  where,
  orderBy,
  serverTimestamp,
} from 'firebase/firestore';
import { getFirestoreDb } from '@/src/lib/firebase/firestore';
import { getFirebaseAuth } from '@/src/lib/firebase/auth';
import { getApiUrl } from '@/src/services/api';
import {
  WeeklyWarriorTest,
  WeeklyWarriorQuestion,
  WeeklyWarriorAttempt,
  WeeklyWarriorResult,
  PublicTestQuestion,
  QuestionReviewItem,
  McqOption,
} from '@/src/types/assessment.types';
import { logAdminAction } from './auditService';
import { fallbackStore } from '@/src/services/fallback/fallbackStore';
import { withTimeout } from '@/src/lib/utils/asyncUtils';

const TESTS_COLLECTION = 'weeklyWarriorTests';
const QUESTIONS_COLLECTION = 'weeklyWarriorQuestions';
const ATTEMPTS_COLLECTION = 'weeklyWarriorAttempts';
const RESULTS_COLLECTION = 'weeklyWarriorResults';

async function getStudentAuthHeaders(): Promise<Record<string, string>> {
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
  };
  try {
    const auth = getFirebaseAuth();
    if (auth?.currentUser && typeof auth.currentUser.getIdToken === 'function') {
      const token = await auth.currentUser.getIdToken().catch(() => null);
      if (token) {
        headers['Authorization'] = `Bearer ${token}`;
      }
    }
  } catch (e) {
    // continue
  }
  return headers;
}

export interface WeeklyWarriorTestFormData {
  batchId: string;
  title: string;
  description?: string;
  durationMinutes: number;
  totalMarks: number;
  passingMarks: number;
  marksPerQuestion: number;
  negativeMarksPerQuestion: number;
  totalQuestions: number;
  instructions: string[];
  isPublished: boolean;
  order: number;
  scheduledStartTime?: string | null;
  scheduledEndTime?: string | null;
  allowReviewAfterSubmission: boolean;
  maxAttempts?: number;
}

export interface WeeklyWarriorQuestionFormData {
  testId: string;
  batchId: string;
  questionText: string;
  questionImageUrl?: string;
  options: McqOption[];
  correctOptionId: string;
  marks: number;
  negativeMarks: number;
  explanation?: string;
  explanationImageUrl?: string;
  subjectTag?: string;
  order: number;
}

// -------------------------------------------------------------
// 1. ADMIN TEST MANAGEMENT
// -------------------------------------------------------------

/**
 * Fetch all Weekly Warrior tests (all statuses) for Admin CMS.
 */
export async function getAllWeeklyWarriorTestsAdmin(batchId?: string): Promise<WeeklyWarriorTest[]> {
  const cached = fallbackStore.getWeeklyWarriorTests(batchId);
  const db = getFirestoreDb();
  if (!db) return cached;

  try {
    const fetchFromFirestore = async () => {
      const testsRef = collection(db, TESTS_COLLECTION);
      const q = batchId ? query(testsRef, where('batchId', '==', batchId)) : testsRef;
      const snapshot = await getDocs(q);

      const tests: WeeklyWarriorTest[] = (snapshot?.docs || []).map((d) => {
        const data = d.data();
        return {
          id: d.id,
          batchId: data.batchId,
          title: data.title || 'Untitled Test',
          description: data.description || '',
          durationMinutes: Number(data.durationMinutes) || 30,
          totalMarks: Number(data.totalMarks) || 100,
          passingMarks: Number(data.passingMarks) || 40,
          marksPerQuestion: Number(data.marksPerQuestion) || 1,
          negativeMarksPerQuestion: Number(data.negativeMarksPerQuestion) || 0.25,
          totalQuestions: Number(data.totalQuestions) || 0,
          instructions: Array.isArray(data.instructions) ? data.instructions : [],
          isPublished: Boolean(data.isPublished),
          order: Number(data.order) || 0,
          scheduledStartTime: data.scheduledStartTime || null,
          scheduledEndTime: data.scheduledEndTime || null,
          allowReviewAfterSubmission: data.allowReviewAfterSubmission ?? true,
          maxAttempts: Number(data.maxAttempts) || 0,
          createdAt: data.createdAt,
          updatedAt: data.updatedAt,
        };
      });

      const sorted = tests.sort((a, b) => (a.order || 0) - (b.order || 0));
      fallbackStore.syncWeeklyWarriorTests(sorted, batchId);
      return sorted;
    };

    return await withTimeout(fetchFromFirestore(), 1200, cached);
  } catch (err: any) {
    console.warn('[WeeklyWarriorService] Returning cached tests:', err?.message || err);
    return cached;
  }
}

/**
 * Fetch a single Weekly Warrior test by ID.
 */
export async function getWeeklyWarriorTestById(testId: string): Promise<WeeklyWarriorTest | null> {
  const cached = fallbackStore.getWeeklyWarriorTestById(testId);
  const db = getFirestoreDb();
  if (!db || !testId) return cached;

  try {
    const fetchDoc = async () => {
      const docRef = doc(db, TESTS_COLLECTION, testId);
      const snap = await getDoc(docRef);
      if (!snap.exists()) {
        return cached;
      }
      const data = snap.data();
      const testItem: WeeklyWarriorTest = {
        id: snap.id,
        batchId: data.batchId,
        title: data.title || 'Untitled Test',
        description: data.description || '',
        durationMinutes: Number(data.durationMinutes) || 30,
        totalMarks: Number(data.totalMarks) || 100,
        passingMarks: Number(data.passingMarks) || 40,
        marksPerQuestion: Number(data.marksPerQuestion) || 1,
        negativeMarksPerQuestion: Number(data.negativeMarksPerQuestion) || 0.25,
        totalQuestions: Number(data.totalQuestions) || 0,
        instructions: Array.isArray(data.instructions) ? data.instructions : [],
        isPublished: Boolean(data.isPublished),
        order: Number(data.order) || 0,
        scheduledStartTime: data.scheduledStartTime || null,
        scheduledEndTime: data.scheduledEndTime || null,
        allowReviewAfterSubmission: data.allowReviewAfterSubmission ?? true,
        maxAttempts: Number(data.maxAttempts) || 0,
        createdAt: data.createdAt,
        updatedAt: data.updatedAt,
      };
      fallbackStore.saveWeeklyWarriorTest(testItem);
      return testItem;
    };

    return await withTimeout(fetchDoc(), 1000, cached);
  } catch (err: any) {
    console.warn('[WeeklyWarriorService] Returning cached test:', err?.message || err);
    return cached;
  }
}

/**
 * Create a new Weekly Warrior Test (Admin).
 */
export async function createWeeklyWarriorTest(
  data: WeeklyWarriorTestFormData,
  actorUid: string,
  actorEmail?: string
): Promise<WeeklyWarriorTest> {
  const testId = `ww_${Date.now()}`;
  const payload: WeeklyWarriorTest = {
    id: testId,
    batchId: data.batchId,
    title: data.title.trim(),
    description: data.description?.trim() || '',
    durationMinutes: Number(data.durationMinutes) || 30,
    totalMarks: Number(data.totalMarks) || 100,
    passingMarks: Number(data.passingMarks) || 40,
    marksPerQuestion: Number(data.marksPerQuestion) || 1,
    negativeMarksPerQuestion: Number(data.negativeMarksPerQuestion) || 0.25,
    totalQuestions: Number(data.totalQuestions) || 0,
    instructions: Array.isArray(data.instructions) ? data.instructions : [],
    isPublished: Boolean(data.isPublished),
    order: Number(data.order) || 0,
    scheduledStartTime: data.scheduledStartTime || null,
    scheduledEndTime: data.scheduledEndTime || null,
    allowReviewAfterSubmission: data.allowReviewAfterSubmission ?? true,
    maxAttempts: Number(data.maxAttempts) || 0,
  };

  fallbackStore.saveWeeklyWarriorTest(payload);

  const db = getFirestoreDb();
  if (!db) return payload;

  try {
    const docRef = doc(db, TESTS_COLLECTION, testId);
    await setDoc(docRef, {
      ...payload,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });

    await logAdminAction({
      actorUid,
      actorEmail,
      action: 'TEST_CREATED',
      resourceType: 'weekly_warrior_test',
      resourceId: testId,
      resourceTitle: data.title,
      details: { batchId: data.batchId, duration: data.durationMinutes },
    }).catch(() => {});

    return payload;
  } catch (err: any) {
    console.warn('[WeeklyWarriorService] Saved to local cache:', err?.message || err);
    return payload;
  }
}

/**
 * Update an existing Weekly Warrior Test (Admin).
 */
export async function updateWeeklyWarriorTest(
  testId: string,
  data: Partial<WeeklyWarriorTestFormData>,
  actorUid: string,
  actorEmail?: string
): Promise<void> {
  const existing = fallbackStore.getWeeklyWarriorTestById(testId);
  if (existing) {
    fallbackStore.saveWeeklyWarriorTest({ ...existing, ...data } as WeeklyWarriorTest);
  }

  const db = getFirestoreDb();
  if (!db) return;

  try {
    const docRef = doc(db, TESTS_COLLECTION, testId);
    await updateDoc(docRef, {
      ...data,
      updatedAt: serverTimestamp(),
    });

    await logAdminAction({
      actorUid,
      actorEmail,
      action: 'TEST_UPDATED',
      resourceType: 'weekly_warrior_test',
      resourceId: testId,
      resourceTitle: data.title || testId,
      details: { changedFields: Object.keys(data) },
    }).catch(() => {});
  } catch (err: any) {
    console.warn('[WeeklyWarriorService] Update deferred:', err?.message || err);
  }
}

/**
 * Toggle publish status of a Weekly Warrior Test.
 */
export async function toggleWeeklyWarriorPublish(
  testId: string,
  isPublished: boolean,
  testTitle: string,
  actorUid: string,
  actorEmail?: string
): Promise<void> {
  const existing = fallbackStore.getWeeklyWarriorTestById(testId);
  if (existing) {
    fallbackStore.saveWeeklyWarriorTest({ ...existing, isPublished });
  }

  const db = getFirestoreDb();
  if (!db) return;

  try {
    const docRef = doc(db, TESTS_COLLECTION, testId);
    await updateDoc(docRef, {
      isPublished,
      updatedAt: serverTimestamp(),
    });

    await logAdminAction({
      actorUid,
      actorEmail,
      action: isPublished ? 'TEST_PUBLISHED' : 'TEST_UNPUBLISHED',
      resourceType: 'weekly_warrior_test',
      resourceId: testId,
      resourceTitle: testTitle,
      details: { isPublished },
    }).catch(() => {});
  } catch (err: any) {
    console.warn('[WeeklyWarriorService] Toggle publish deferred:', err?.message || err);
  }
}

/**
 * Delete a Weekly Warrior Test (Admin).
 */
export async function deleteWeeklyWarriorTest(
  testId: string,
  testTitle: string,
  actorUid: string,
  actorEmail?: string
): Promise<void> {
  fallbackStore.deleteWeeklyWarriorTest(testId);

  const db = getFirestoreDb();
  if (!db) return;

  try {
    const docRef = doc(db, TESTS_COLLECTION, testId);
    await deleteDoc(docRef);

    // Clean up questions in background
    const questionsRef = collection(db, QUESTIONS_COLLECTION);
    const qSnap = await getDocs(query(questionsRef, where('testId', '==', testId)));
    qSnap.forEach(async (qDoc) => {
      await deleteDoc(doc(db, QUESTIONS_COLLECTION, qDoc.id)).catch(() => {});
    });

    await logAdminAction({
      actorUid,
      actorEmail,
      action: 'TEST_DELETED',
      resourceType: 'weekly_warrior_test',
      resourceId: testId,
      resourceTitle: testTitle,
    }).catch(() => {});
  } catch (err: any) {
    console.warn('[WeeklyWarriorService] Delete deferred:', err?.message || err);
  }
}

// -------------------------------------------------------------
// 2. QUESTION MANAGEMENT (ADMIN)
// -------------------------------------------------------------

/**
 * Fetch all questions for a Weekly Warrior test (Admin - includes answers).
 */
export async function getWeeklyWarriorQuestionsAdmin(testId: string): Promise<WeeklyWarriorQuestion[]> {
  const cached = fallbackStore.getWeeklyWarriorQuestions(testId);
  const db = getFirestoreDb();
  if (!db) return cached;

  try {
    const fetchFromFirestore = async () => {
      const questionsRef = collection(db, QUESTIONS_COLLECTION);
      const q = query(questionsRef, where('testId', '==', testId));
      const snapshot = await getDocs(q);

      const questions: WeeklyWarriorQuestion[] = (snapshot?.docs || []).map((d) => {
        const data = d.data();
        return {
          id: d.id,
          testId: data.testId,
          batchId: data.batchId,
          questionText: data.questionText || '',
          questionImageUrl: data.questionImageUrl || undefined,
          options: Array.isArray(data.options) ? data.options : [],
          correctOptionId: data.correctOptionId || '',
          marks: Number(data.marks) || 1,
          negativeMarks: Number(data.negativeMarks) || 0.25,
          explanation: data.explanation || '',
          explanationImageUrl: data.explanationImageUrl || undefined,
          subjectTag: data.subjectTag || '',
          order: Number(data.order) || 0,
          createdAt: data.createdAt,
          updatedAt: data.updatedAt,
        };
      });

      const sorted = questions.sort((a, b) => (a.order || 0) - (b.order || 0));
      fallbackStore.syncWeeklyWarriorQuestions(sorted, testId);
      return sorted;
    };

    return await withTimeout(fetchFromFirestore(), 1200, cached);
  } catch (err: any) {
    console.warn('[WeeklyWarriorService] Returning cached questions:', err?.message || err);
    return cached;
  }
}

/**
 * Create a Question for Weekly Warrior Test (Admin).
 */
export async function createWeeklyWarriorQuestion(
  data: WeeklyWarriorQuestionFormData,
  actorUid: string,
  actorEmail?: string
): Promise<WeeklyWarriorQuestion> {
  const questionId = `wwq_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
  const payload: WeeklyWarriorQuestion = {
    id: questionId,
    testId: data.testId,
    batchId: data.batchId,
    questionText: data.questionText.trim(),
    questionImageUrl: data.questionImageUrl?.trim() || undefined,
    options: data.options,
    correctOptionId: data.correctOptionId,
    marks: Number(data.marks) || 1,
    negativeMarks: Number(data.negativeMarks) || 0.25,
    explanation: data.explanation?.trim() || '',
    explanationImageUrl: data.explanationImageUrl?.trim() || undefined,
    subjectTag: data.subjectTag?.trim() || '',
    order: Number(data.order) || 0,
  };

  fallbackStore.saveWeeklyWarriorQuestion(payload);

  // Sync test total questions count
  const allQ = fallbackStore.getWeeklyWarriorQuestions(data.testId);
  const totalMarks = allQ.reduce((sum, q) => sum + (q.marks || 1), 0);
  const testObj = fallbackStore.getWeeklyWarriorTestById(data.testId);
  if (testObj) {
    fallbackStore.saveWeeklyWarriorTest({
      ...testObj,
      totalQuestions: allQ.length,
      totalMarks: totalMarks,
    });
  }

  const db = getFirestoreDb();
  if (!db) return payload;

  try {
    const docRef = doc(db, QUESTIONS_COLLECTION, questionId);
    await setDoc(docRef, {
      ...payload,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });

    // Update parent test totalQuestions count in Firestore
    const testRef = doc(db, TESTS_COLLECTION, data.testId);
    await updateDoc(testRef, {
      totalQuestions: allQ.length,
      totalMarks: totalMarks,
      updatedAt: serverTimestamp(),
    }).catch(() => {});

    await logAdminAction({
      actorUid,
      actorEmail,
      action: 'QUESTION_CREATED',
      resourceType: 'weekly_warrior_question',
      resourceId: questionId,
      resourceTitle: data.questionText.substring(0, 40),
      details: { testId: data.testId },
    }).catch(() => {});

    return payload;
  } catch (err: any) {
    console.warn('[WeeklyWarriorService] Saved question locally:', err?.message || err);
    return payload;
  }
}

/**
 * Update a Question for Weekly Warrior Test (Admin).
 */
export async function updateWeeklyWarriorQuestion(
  questionId: string,
  data: Partial<WeeklyWarriorQuestionFormData>,
  actorUid: string,
  actorEmail?: string
): Promise<void> {
  const existing = fallbackStore.getWeeklyWarriorQuestionById(questionId);
  if (existing) {
    fallbackStore.saveWeeklyWarriorQuestion({ ...existing, ...data } as WeeklyWarriorQuestion);
  }

  const db = getFirestoreDb();
  if (!db) return;

  try {
    const docRef = doc(db, QUESTIONS_COLLECTION, questionId);
    await updateDoc(docRef, {
      ...data,
      updatedAt: serverTimestamp(),
    });

    await logAdminAction({
      actorUid,
      actorEmail,
      action: 'QUESTION_UPDATED',
      resourceType: 'weekly_warrior_question',
      resourceId: questionId,
      resourceTitle: data.questionText?.substring(0, 40) || questionId,
    }).catch(() => {});
  } catch (err: any) {
    console.warn('[WeeklyWarriorService] Question update deferred:', err?.message || err);
  }
}

/**
 * Delete a Question for Weekly Warrior Test (Admin).
 */
export async function deleteWeeklyWarriorQuestion(
  questionId: string,
  testId: string,
  actorUid: string,
  actorEmail?: string
): Promise<void> {
  fallbackStore.deleteWeeklyWarriorQuestion(questionId);

  // Sync test total count
  const allQ = fallbackStore.getWeeklyWarriorQuestions(testId);
  const totalMarks = allQ.reduce((sum, q) => sum + (q.marks || 1), 0);
  const testObj = fallbackStore.getWeeklyWarriorTestById(testId);
  if (testObj) {
    fallbackStore.saveWeeklyWarriorTest({
      ...testObj,
      totalQuestions: allQ.length,
      totalMarks: totalMarks,
    });
  }

  const db = getFirestoreDb();
  if (!db) return;

  try {
    const docRef = doc(db, QUESTIONS_COLLECTION, questionId);
    await deleteDoc(docRef);

    const testRef = doc(db, TESTS_COLLECTION, testId);
    await updateDoc(testRef, {
      totalQuestions: allQ.length,
      totalMarks: totalMarks,
      updatedAt: serverTimestamp(),
    }).catch(() => {});

    await logAdminAction({
      actorUid,
      actorEmail,
      action: 'QUESTION_DELETED',
      resourceType: 'weekly_warrior_question',
      resourceId: questionId,
      resourceTitle: questionId,
    }).catch(() => {});
  } catch (err: any) {
    console.warn('[WeeklyWarriorService] Question delete deferred:', err?.message || err);
  }
}

// -------------------------------------------------------------
// 3. STUDENT LEARNER TEST & ATTEMPT SERVICE
// -------------------------------------------------------------

/**
 * Get published Weekly Warrior tests for a specific Course Batch.
 */
export async function getPublishedWeeklyWarriorTests(batchId: string): Promise<WeeklyWarriorTest[]> {
  const all = await getAllWeeklyWarriorTestsAdmin(batchId);
  return all.filter((t) => t.isPublished);
}

/**
 * Get sanitized questions for the active test player (Answer key is strictly hidden).
 */
export async function getPublicWeeklyWarriorQuestions(testId: string): Promise<PublicTestQuestion[]> {
  try {
    const headers = await getStudentAuthHeaders();
    const res = await fetch(getApiUrl(`/api/tests/weekly-warrior/${encodeURIComponent(testId)}/questions`), { headers });
    if (res.ok) {
      const data = await res.json();
      if (data.success && Array.isArray(data.questions) && data.questions.length > 0) {
        return data.questions;
      }
    }
  } catch (err) {
    console.warn('[WeeklyWarriorService] Error fetching questions from server endpoint, using fallback:', err);
  }

  // Sanitized fallback
  const allQuestions = await getWeeklyWarriorQuestionsAdmin(testId);
  return allQuestions.map((q) => ({
    id: q.id,
    testId: q.testId,
    questionText: q.questionText,
    questionImageUrl: q.questionImageUrl,
    options: q.options.map((opt) => ({
      id: opt.id,
      text: opt.text,
      imageUrl: opt.imageUrl,
    })),
    marks: q.marks,
    negativeMarks: q.negativeMarks,
    order: q.order,
    subjectTag: q.subjectTag,
  }));
}

export const getWeeklyWarriorQuestionsForStudent = getPublicWeeklyWarriorQuestions;

/**
 * Start or resume a student attempt for Weekly Warrior.
 */
export async function startWeeklyWarriorAttempt(
  testId: string,
  batchId: string,
  studentId: string,
  studentName: string = 'Student',
  studentEmail: string = ''
): Promise<WeeklyWarriorAttempt> {
  const existingAttempts = await getWeeklyWarriorStudentAttempts(testId, studentId);
  const active = existingAttempts.find((a) => a.status === 'in_progress');
  if (active) return active;

  const testData = await getWeeklyWarriorTestById(testId);

  // Authoritative attempt limit verification (Section 9.13)
  if (testData?.maxAttempts && testData.maxAttempts > 0) {
    const completedCount = existingAttempts.filter((a) => a.status === 'completed').length;
    if (completedCount >= testData.maxAttempts) {
      throw new Error(`Maximum attempt limit reached. You are allowed up to ${testData.maxAttempts} attempt(s) for this exam.`);
    }
  }

  const durationMinutes = testData?.durationMinutes || 30;

  const attemptId = `ww_att_${Date.now()}_${studentId.substring(0, 5)}`;
  const newAttempt: WeeklyWarriorAttempt = {
    id: attemptId,
    testId,
    batchId,
    studentId,
    studentName,
    studentEmail,
    status: 'in_progress',
    startedAt: new Date().toISOString(),
    timeRemainingSeconds: durationMinutes * 60,
    timeTakenSeconds: 0,
    answers: {},
    markedForReview: [],
  };

  fallbackStore.saveWeeklyWarriorAttempt(newAttempt);

  const db = getFirestoreDb();
  if (db) {
    const docRef = doc(db, ATTEMPTS_COLLECTION, attemptId);
    setDoc(docRef, {
      ...newAttempt,
      createdAt: serverTimestamp(),
    }).catch((err) => {
      console.warn('[WeeklyWarriorService] Attempt stored in fallback:', err);
    });
  }

  return newAttempt;
}

/**
 * Periodically save student attempt progress (answers, time remaining, flagged questions).
 */
export async function saveWeeklyWarriorAttemptProgress(
  attemptId: string,
  answers: Record<string, string>,
  markedForReview: string[],
  timeRemainingSeconds: number,
  timeTakenSeconds: number
): Promise<void> {
  const existing = fallbackStore.getWeeklyWarriorAttemptById(attemptId);
  if (existing) {
    fallbackStore.saveWeeklyWarriorAttempt({
      ...existing,
      answers,
      markedForReview,
      timeRemainingSeconds,
      timeTakenSeconds,
    });
  }

  const db = getFirestoreDb();
  if (!db) return;

  try {
    const docRef = doc(db, ATTEMPTS_COLLECTION, attemptId);
    await updateDoc(docRef, {
      answers,
      markedForReview,
      timeRemainingSeconds,
      timeTakenSeconds,
      updatedAt: serverTimestamp(),
    });
  } catch (err) {
    // Silent catch for periodic autosave
  }
}

/**
 * Submit Weekly Warrior Attempt and calculate authoritative score.
 */
export async function submitWeeklyWarriorAttempt(
  attemptId: string,
  testId: string,
  answers: Record<string, string>,
  timeTakenSeconds: number,
  studentId: string,
  studentName: string = 'Student',
  studentEmail: string = ''
): Promise<WeeklyWarriorResult> {
  // Authoritative server-only submission and evaluation
  const headers = await getStudentAuthHeaders();
  const res = await fetch(getApiUrl(`/api/tests/weekly-warrior/${encodeURIComponent(testId)}/submit`), {
    method: 'POST',
    headers,
    body: JSON.stringify({
      attemptId,
      answers,
      timeSpentSeconds: timeTakenSeconds,
    }),
  });

  if (!res.ok) {
    const errData = await res.json().catch(() => null);
    throw new Error(errData?.error || `Server test evaluation failed with status ${res.status}. Local score calculation is forbidden.`);
  }

  const data = await res.json();
  if (!data.success || !data.result) {
    throw new Error(data.error || 'Server rejected Weekly Warrior test submission.');
  }

  fallbackStore.saveWeeklyWarriorResult(data.result);
  return data.result;
}

/**
 * Get Result Scorecard by resultId or attemptId.
 */
export async function getWeeklyWarriorResult(resultOrAttemptId: string): Promise<WeeklyWarriorResult | null> {
  const fallbackRes = fallbackStore.getWeeklyWarriorResult(resultOrAttemptId);
  if (fallbackRes) return fallbackRes;

  const db = getFirestoreDb();
  if (!db) return null;

  try {
    const docRef = doc(db, RESULTS_COLLECTION, resultOrAttemptId);
    const snap = await getDoc(docRef);
    if (snap.exists()) {
      return snap.data() as WeeklyWarriorResult;
    }

    // Try query by attemptId
    const q = query(collection(db, RESULTS_COLLECTION), where('attemptId', '==', resultOrAttemptId));
    const qSnap = await getDocs(q);
    if (!qSnap.empty) {
      return qSnap.docs[0].data() as WeeklyWarriorResult;
    }

    return null;
  } catch (err) {
    return null;
  }
}

/**
 * Get Question Review List for Post-submission analysis.
 */
export async function getWeeklyWarriorQuestionReviewList(
  testId: string,
  userAnswers: Record<string, string>,
  attemptId?: string
): Promise<QuestionReviewItem[]> {
  if (attemptId) {
    try {
      const headers = await getStudentAuthHeaders();
      const res = await fetch(getApiUrl(`/api/tests/weekly-warrior/${encodeURIComponent(testId)}/review/${encodeURIComponent(attemptId)}`), { headers });
      if (res.ok) {
        const data = await res.json();
        if (data.success && Array.isArray(data.reviewItems)) {
          return data.reviewItems.map((item: any) => ({
            id: item.questionId,
            questionText: item.questionText,
            questionImageUrl: item.questionImageUrl,
            options: item.options,
            selectedOptionId: item.studentSelectedOptionId,
            correctOptionId: item.correctOptionId,
            isCorrect: item.isCorrect,
            isSkipped: item.isSkipped,
            marksAwarded: item.isCorrect ? item.marks : item.isSkipped ? 0 : -(item.negativeMarks || 0),
            explanation: item.explanation,
            explanationImageUrl: item.explanationImageUrl,
            subjectTag: item.subjectTag,
          }));
        }
      }
    } catch (err) {
      console.warn('[WeeklyWarriorService] Server review fetch failed:', err);
    }
  }

  return [];
}

/**
 * Get student previous attempts for a test.
 */
export async function getWeeklyWarriorStudentAttempts(
  testId: string,
  studentId: string
): Promise<WeeklyWarriorAttempt[]> {
  const db = getFirestoreDb();
  if (!db) return fallbackStore.getWeeklyWarriorAttempts(testId, studentId);

  try {
    const q = query(
      collection(db, ATTEMPTS_COLLECTION),
      where('testId', '==', testId),
      where('studentId', '==', studentId),
      orderBy('startedAt', 'desc')
    );
    const snap = await getDocs(q);
    if (snap.empty) {
      return fallbackStore.getWeeklyWarriorAttempts(testId, studentId);
    }
    return snap.docs.map((d) => d.data() as WeeklyWarriorAttempt);
  } catch (err) {
    return fallbackStore.getWeeklyWarriorAttempts(testId, studentId);
  }
}

/**
 * Get all attempts for a test (Admin Analytics).
 */
export async function getWeeklyWarriorAttemptsForAdmin(testId: string): Promise<WeeklyWarriorAttempt[]> {
  const db = getFirestoreDb();
  if (!db) return fallbackStore.getWeeklyWarriorAttempts(testId);

  try {
    const q = query(collection(db, ATTEMPTS_COLLECTION), where('testId', '==', testId));
    const snap = await getDocs(q);
    if (snap.empty) {
      return fallbackStore.getWeeklyWarriorAttempts(testId);
    }
    return snap.docs.map((d) => d.data() as WeeklyWarriorAttempt);
  } catch (err) {
    return fallbackStore.getWeeklyWarriorAttempts(testId);
  }
}
