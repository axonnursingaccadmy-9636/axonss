/**
 * Axon Nursing Academy - Firebase Firestore Admin Subject Service
 * Complete CRUD operations and publishing control for Subjects.
 */
import {
  collection,
  doc,
  getDocs,
  setDoc,
  updateDoc,
  deleteDoc,
  query,
  where,
  orderBy,
  onSnapshot,
  serverTimestamp,
} from 'firebase/firestore';
import { getFirestoreDb, OperationType, handleFirestoreError } from '@/src/lib/firebase/firestore';
import { Subject } from '@/src/types/lms.types';
import { logAdminAction } from './auditService';
import { generateSlug } from './adminBatchService';
import { fallbackStore } from '@/src/services/fallback/fallbackStore';
import { withTimeout } from '@/src/lib/utils/asyncUtils';

const SUBJECTS_COLLECTION = 'subjects';

export interface SubjectFormData {
  batchId: string;
  name: string;
  description: string;
  thumbnailUrl: string;
  order: number;
  isPublished: boolean;
}

/**
 * Fetch all subjects across all batches for Admin CMS.
 */
export async function getAllSubjectsAdmin(): Promise<Subject[]> {
  const db = getFirestoreDb();
  if (!db) return fallbackStore.getSubjects();

  try {
    const subjectsRef = collection(db, SUBJECTS_COLLECTION);
    const snapshot = await getDocs(subjectsRef);

    const subjects: Subject[] = snapshot.docs.map((docSnap) => {
      const data = docSnap.data();
      return {
        id: docSnap.id,
        batchId: data.batchId || '',
        name: data.name || 'Untitled Subject',
        description: data.description || '',
        thumbnailUrl: data.thumbnailUrl || '',
        order: typeof data.order === 'number' ? data.order : 0,
        isPublished: Boolean(data.isPublished),
        createdAt: data.createdAt,
        updatedAt: data.updatedAt,
      };
    });

    const sorted = subjects.sort((a, b) => (a.order || 0) - (b.order || 0));
    fallbackStore.syncSubjects(sorted);
    return sorted;
  } catch (err: any) {
    console.warn('[AdminSubjectService] Returning cached subjects:', err?.message || err);
    return fallbackStore.getSubjects();
  }
}

/**
 * Real-time listener for subjects in Admin CMS.
 */
export function subscribeToSubjectsAdmin(
  callback: (subjects: Subject[]) => void,
  batchId?: string,
  onError?: (err: any) => void
): () => void {
  const db = getFirestoreDb();
  if (!db) {
    callback(fallbackStore.getSubjects(batchId));
    return () => {};
  }

  try {
    const subjectsRef = collection(db, SUBJECTS_COLLECTION);
    const q = batchId ? query(subjectsRef, where('batchId', '==', batchId)) : subjectsRef;

    return onSnapshot(
      q,
      (snapshot) => {
        const subjects: Subject[] = snapshot.docs.map((docSnap) => {
          const data = docSnap.data();
          return {
            id: docSnap.id,
            batchId: data.batchId || '',
            name: data.name || 'Untitled Subject',
            description: data.description || '',
            thumbnailUrl: data.thumbnailUrl || '',
            order: typeof data.order === 'number' ? data.order : 0,
            isPublished: Boolean(data.isPublished),
            createdAt: data.createdAt,
            updatedAt: data.updatedAt,
          };
        });

        const sorted = subjects.sort((a, b) => (a.order || 0) - (b.order || 0));
        fallbackStore.syncSubjects(sorted, batchId);
        callback(sorted);
      },
      (err) => {
        console.warn('[AdminSubjectService] Realtime subscription notice:', err);
        callback(fallbackStore.getSubjects(batchId));
        if (onError) onError(err);
      }
    );
  } catch (err: any) {
    console.warn('[AdminSubjectService] Realtime listener error:', err);
    callback(fallbackStore.getSubjects(batchId));
    return () => {};
  }
}

/**
 * Fetch all subjects for a specific batch (both published and drafts).
 */
export async function getSubjectsForBatchAdmin(batchId: string): Promise<Subject[]> {
  const db = getFirestoreDb();
  if (!db || !batchId) return fallbackStore.getSubjects(batchId);

  try {
    const subjectsRef = collection(db, SUBJECTS_COLLECTION);
    const q = query(subjectsRef, where('batchId', '==', batchId));
    const snapshot = await getDocs(q);

    const subjects: Subject[] = snapshot.docs.map((docSnap) => {
      const data = docSnap.data();
      return {
        id: docSnap.id,
        batchId: data.batchId || batchId,
        name: data.name || 'Untitled Subject',
        description: data.description || '',
        thumbnailUrl: data.thumbnailUrl || '',
        order: typeof data.order === 'number' ? data.order : 0,
        isPublished: Boolean(data.isPublished),
        createdAt: data.createdAt,
        updatedAt: data.updatedAt,
      };
    });

    const sorted = subjects.sort((a, b) => (a.order || 0) - (b.order || 0));
    fallbackStore.syncSubjects(sorted, batchId);
    return sorted;
  } catch (err: any) {
    console.warn('[AdminSubjectService] Returning batch cached subjects:', err?.message || err);
    return fallbackStore.getSubjects(batchId);
  }
}

/**
 * Create a new subject in Firestore.
 */
export async function createSubject(
  data: SubjectFormData,
  actorUid: string,
  actorEmail?: string
): Promise<Subject> {
  const cleanSlug = generateSlug(data.name) || 'sub';
  const subjectId = `${data.batchId || 'batch'}_${cleanSlug}_${Date.now()}`;

  const payload: Subject = {
    id: subjectId,
    batchId: data.batchId,
    name: data.name.trim(),
    description: data.description.trim(),
    thumbnailUrl: data.thumbnailUrl.trim() || 'https://images.unsplash.com/photo-1579684385127-1ef15d508118?w=800&auto=format&fit=crop&q=80',
    order: Number(data.order) || 0,
    isPublished: Boolean(data.isPublished),
  };

  // Immediate local cache update
  fallbackStore.saveSubject(payload);

  const db = getFirestoreDb();
  if (db) {
    try {
      const docRef = doc(db, SUBJECTS_COLLECTION, subjectId);
      await setDoc(docRef, {
        ...payload,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });

      logAdminAction({
        actorUid,
        actorEmail,
        action: 'SUBJECT_CREATED',
        resourceType: 'subject',
        resourceId: subjectId,
        resourceTitle: data.name,
        details: { batchId: data.batchId, isPublished: data.isPublished },
      }).catch(() => {});
    } catch (err: any) {
      console.warn('[AdminSubjectService] Firestore create notice (saved locally):', err?.message || err);
    }
  }

  return payload;
}

/**
 * Update an existing subject in Firestore.
 */
export async function updateSubject(
  subjectId: string,
  data: Partial<SubjectFormData>,
  actorUid: string,
  actorEmail?: string
): Promise<void> {
  const existing = fallbackStore.getSubjectById(subjectId);
  fallbackStore.saveSubject({ ...(existing || {}), ...data, id: subjectId } as Subject);

  const db = getFirestoreDb();
  if (!db) return;

  try {
    const docRef = doc(db, SUBJECTS_COLLECTION, subjectId);
    await setDoc(docRef, {
      ...data,
      updatedAt: serverTimestamp(),
    }, { merge: true });

    logAdminAction({
      actorUid,
      actorEmail,
      action: 'SUBJECT_UPDATED',
      resourceType: 'subject',
      resourceId: subjectId,
      resourceTitle: data.name || subjectId,
      details: { changedFields: Object.keys(data) },
    }).catch(() => {});
  } catch (err: any) {
    console.warn('[AdminSubjectService] Firestore update notice (saved locally):', err?.message || err);
  }
}

/**
 * Toggle publish status of a subject in Firestore.
 */
export async function toggleSubjectPublish(
  subjectId: string,
  newPublishedState: boolean,
  subjectName: string,
  actorUid: string,
  actorEmail?: string
): Promise<void> {
  const existing = fallbackStore.getSubjectById(subjectId);
  if (existing) {
    fallbackStore.saveSubject({ ...existing, isPublished: newPublishedState });
  }

  const db = getFirestoreDb();
  if (!db) return;

  try {
    const docRef = doc(db, SUBJECTS_COLLECTION, subjectId);
    await setDoc(docRef, {
      isPublished: newPublishedState,
      updatedAt: serverTimestamp(),
    }, { merge: true });

    logAdminAction({
      actorUid,
      actorEmail,
      action: newPublishedState ? 'SUBJECT_PUBLISHED' : 'SUBJECT_UNPUBLISHED',
      resourceType: 'subject',
      resourceId: subjectId,
      resourceTitle: subjectName,
      details: { isPublished: newPublishedState },
    }).catch(() => {});
  } catch (err: any) {
    console.warn('[AdminSubjectService] Firestore toggle notice (saved locally):', err?.message || err);
  }
}

/**
 * Delete a subject from Firestore and cascade delete all child chapters and classes.
 */
export async function deleteSubject(
  subjectId: string,
  subjectName: string,
  actorUid: string,
  actorEmail?: string
): Promise<void> {
  // 1. Delete from local cache and cascade in memory
  fallbackStore.deleteSubject(subjectId);

  const db = getFirestoreDb();
  if (!db) return;

  try {
    // 2. Delete primary subject document from Firestore
    const docRef = doc(db, SUBJECTS_COLLECTION, subjectId);
    await deleteDoc(docRef);

    // 3. Cascade delete associated chapters and classes from Firestore
    try {
      const chaptersRef = collection(db, 'chapters');
      const chaptersSnap = await getDocs(query(chaptersRef, where('subjectId', '==', subjectId)));
      const chapterIds: string[] = [];
      for (const cDoc of chaptersSnap.docs) {
        chapterIds.push(cDoc.id);
        await deleteDoc(cDoc.ref);
      }

      const classesRef = collection(db, 'classes');
      const classesSnap = await getDocs(query(classesRef, where('subjectId', '==', subjectId)));
      for (const clDoc of classesSnap.docs) {
        await deleteDoc(clDoc.ref);
      }

      const notesRef = collection(db, 'pdf_notes');
      const notesSnap = await getDocs(query(notesRef, where('subjectId', '==', subjectId)));
      for (const nDoc of notesSnap.docs) {
        await deleteDoc(nDoc.ref);
      }
    } catch (cleanupErr) {
      console.warn('[AdminSubjectService] Cascade cleanup notice:', cleanupErr);
    }

    logAdminAction({
      actorUid,
      actorEmail,
      action: 'SUBJECT_DELETED',
      resourceType: 'subject',
      resourceId: subjectId,
      resourceTitle: subjectName,
    }).catch(() => {});
  } catch (err: any) {
    console.warn('[AdminSubjectService] Firestore delete notice (deleted locally):', err?.message || err);
  }
}
