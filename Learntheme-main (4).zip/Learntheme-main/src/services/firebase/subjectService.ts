/**
 * Axon Nursing Academy - Firebase Firestore Subject Service
 * Ultra-fast local-first query with background Firestore synchronization.
 */
import {
  collection,
  doc,
  getDoc,
  getDocs,
  query,
  where,
  orderBy,
} from 'firebase/firestore';
import { getFirestoreDb } from '@/src/lib/firebase/firestore';
import { Subject } from '@/src/types/lms.types';
import { fallbackStore } from '@/src/services/fallback/fallbackStore';
import { withTimeout } from '@/src/lib/utils/asyncUtils';

const SUBJECTS_COLLECTION = 'subjects';

/**
 * Fetch all published subjects belonging to a specific batch.
 */
export async function getPublishedSubjects(batchId: string): Promise<Subject[]> {
  const cached = fallbackStore.getSubjects(batchId).filter((s) => s.isPublished);
  const timeoutMs = cached.length > 0 ? 4000 : 8000;

  const db = getFirestoreDb();
  if (!db || !batchId) {
    return cached;
  }

  try {
    const fetchFromFirestore = async () => {
      const subjectsRef = collection(db, SUBJECTS_COLLECTION);
      const q = query(
        subjectsRef,
        where('batchId', '==', batchId),
        where('isPublished', '==', true)
      );

      const snapshot = await getDocs(q);

      const subjects: Subject[] = (snapshot?.docs || []).map((docSnap) => {
        const data = docSnap.data();
        return {
          id: docSnap.id,
          batchId: data.batchId || batchId,
          name: data.name || 'Untitled Subject',
          description: data.description || '',
          thumbnailUrl: data.thumbnailUrl || '',
          order: typeof data.order === 'number' ? data.order : 0,
          isPublished: Boolean(data.isPublished),
          createdAt: data.createdAt,
          updatedAt: data.updatedAt,
        };
      });

      const sorted = subjects.sort((a, b) => (a.order || 0) - (b.order || 0));
      fallbackStore.syncSubjects(sorted, batchId);
      return sorted;
    };

    return await withTimeout(fetchFromFirestore(), timeoutMs, cached);
  } catch (err: any) {
    console.warn('[subjectService] Serving cached subjects:', err?.message || err);
    return cached;
  }
}

/**
 * Fetch a single subject by ID.
 */
export async function getSubjectById(subjectId: string): Promise<Subject | null> {
  const cached = fallbackStore.getSubjectById(subjectId);

  const db = getFirestoreDb();
  if (!db || !subjectId) {
    return cached;
  }

  try {
    const fetchFromFirestore = async () => {
      const docRef = doc(db, SUBJECTS_COLLECTION, subjectId);
      const docSnap = await getDoc(docRef);

      if (!docSnap.exists()) {
        return cached;
      }

      const data = docSnap.data();
      if (!data.isPublished) {
        return null;
      }

      const subject: Subject = {
        id: docSnap.id,
        batchId: data.batchId || '',
        name: data.name || 'Untitled Subject',
        description: data.description || '',
        thumbnailUrl: data.thumbnailUrl || '',
        order: typeof data.order === 'number' ? data.order : 0,
        isPublished: Boolean(data.isPublished),
        createdAt: data.createdAt,
        updatedAt: data.updatedAt,
      };

      fallbackStore.saveSubject(subject);
      return subject;
    };

    return await withTimeout(fetchFromFirestore(), 1200, cached);
  } catch (err: any) {
    console.warn('[subjectService] Serving cached subject by ID:', err?.message || err);
    return cached;
  }
}
