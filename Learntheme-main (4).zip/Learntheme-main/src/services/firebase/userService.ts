/**
 * Axon Nursing Academy - Firestore User Profile Service
 * Manages user profile creation, retrieval, and validated updates in Firestore.
 */
import {
  doc,
  getDoc,
  setDoc,
  updateDoc,
  serverTimestamp,
} from 'firebase/firestore';
import { User as FirebaseUser } from 'firebase/auth';
import { getFirebaseAuth } from '@/src/lib/firebase/auth';
import { getFirestoreDb, handleFirestoreError, OperationType, FIRESTORE_COLLECTIONS } from '@/src/lib/firebase/firestore';
import { UserProfile } from '@/src/types/user.types';
import { isDesignatedAdminEmail } from '@/src/config/admin.config';

/**
 * Validates a student full name.
 */
export function validateFullName(name: string): { isValid: boolean; error?: string; sanitized: string } {
  const sanitized = (name || '').trim().replace(/\s+/g, ' ');
  if (!sanitized) {
    return { isValid: false, error: 'Full name is required.', sanitized: '' };
  }
  if (sanitized.length < 2) {
    return { isValid: false, error: 'Full name must be at least 2 characters.', sanitized };
  }
  if (sanitized.length > 100) {
    return { isValid: false, error: 'Full name cannot exceed 100 characters.', sanitized: sanitized.slice(0, 100) };
  }
  return { isValid: true, sanitized };
}

/**
 * Creates a new Firestore student profile under users/{uid}.
 * Permanent student role is enforced (role cannot be self-assigned).
 */
export async function createUserProfile(
  uid: string,
  data: {
    fullName: string;
    email: string;
  }
): Promise<UserProfile> {
  const db = getFirestoreDb();
  if (!db) {
    throw new Error('Firestore is not configured. Please check your Firebase settings.');
  }

  const { isValid, error, sanitized } = validateFullName(data.fullName);
  if (!isValid) {
    throw new Error(error || 'Invalid full name provided.');
  }

  const path = `${FIRESTORE_COLLECTIONS.USERS}/${uid}`;
  const userRef = doc(db, FIRESTORE_COLLECTIONS.USERS, uid);

  const normalizedEmail = (data.email || '').trim().toLowerCase();
  const isAdmin = isDesignatedAdminEmail(normalizedEmail);

  const profilePayload = {
    uid,
    fullName: sanitized,
    email: normalizedEmail,
    role: (isAdmin ? 'admin' : 'student') as 'student' | 'admin',
    isActive: true,
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp(),
  };

  try {
    await setDoc(userRef, profilePayload, { merge: true });
    return {
      ...profilePayload,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
  } catch (err) {
    handleFirestoreError(err, OperationType.CREATE, path);
  }
}

/**
 * Retrieves a user profile document from users/{uid}.
 */
export async function getUserProfile(uid: string): Promise<UserProfile | null> {
  const db = getFirestoreDb();
  if (!db) {
    return null;
  }

  const path = `${FIRESTORE_COLLECTIONS.USERS}/${uid}`;
  const userRef = doc(db, FIRESTORE_COLLECTIONS.USERS, uid);

  try {
    const docSnap = await getDoc(userRef);
    if (!docSnap.exists()) {
      return null;
    }

    const data = docSnap.data();
    const auth = getFirebaseAuth();
    const userEmail = data.email || auth?.currentUser?.email || '';
    const isDesignated = isDesignatedAdminEmail(userEmail);
    const isAdmin = isDesignated || data.role === 'admin';

    // If designated admin had student role stored in Firestore, promote immediately and await
    if (isDesignated && data.role !== 'admin') {
      try {
        await setDoc(
          userRef,
          {
            uid: data.uid || uid,
            email: userEmail.toLowerCase(),
            role: 'admin',
            isActive: true,
            updatedAt: serverTimestamp(),
          },
          { merge: true }
        );
      } catch {
        // Ignore if offline or restricted
      }
    }

    return {
      uid: data.uid || uid,
      fullName: data.fullName || 'User',
      email: userEmail,
      role: isAdmin ? 'admin' : 'student',
      isActive: data.isActive !== undefined ? Boolean(data.isActive) : true,
      createdAt: data.createdAt,
      updatedAt: data.updatedAt,
    };
  } catch (err: any) {
    const msg = err?.message || String(err);
    if (msg.includes('offline') || msg.includes('unavailable') || msg.includes('Failed to get document because the client is offline')) {
      console.warn(`[Firestore Offline Notice] users/${uid} is currently offline.`);
      return null;
    }
    // Fallback: If document read is restricted or user doc not yet created, return profile from active auth session
    const auth = getFirebaseAuth();
    const currentAuthUser = auth?.currentUser;
    if (currentAuthUser && currentAuthUser.uid === uid) {
      const email = currentAuthUser.email || '';
      const isAdmin = isDesignatedAdminEmail(email);
      return {
        uid,
        fullName: currentAuthUser.displayName || (email ? email.split('@')[0] : 'User'),
        email,
        role: isAdmin ? 'admin' : 'student',
        isActive: true,
      };
    }
    console.warn(`[userService] Notice: Could not read users/${uid}:`, msg);
    return null;
  }
}

/**
 * Updates editable profile fields in Firestore.
 */
export async function updateUserProfile(
  uid: string,
  updates: Partial<UserProfile>
): Promise<void> {
  const db = getFirestoreDb();
  if (!db) {
    throw new Error('Firestore is not configured.');
  }

  const payload: Record<string, any> = {
    ...updates,
    updatedAt: serverTimestamp(),
  };

  if (updates.fullName) {
    const { isValid, error, sanitized } = validateFullName(updates.fullName);
    if (!isValid) {
      throw new Error(error || 'Invalid full name provided.');
    }
    payload.fullName = sanitized;
  }

  const path = `${FIRESTORE_COLLECTIONS.USERS}/${uid}`;
  const userRef = doc(db, FIRESTORE_COLLECTIONS.USERS, uid);

  try {
    await updateDoc(userRef, payload);
  } catch (err) {
    handleFirestoreError(err, OperationType.UPDATE, path);
  }
}

/**
 * Ensures a user profile exists in Firestore.
 * If user exists in Auth but not in Firestore (e.g. Phase 1 users, Google OAuth),
 * creates a safe default student profile automatically.
 * If Firestore is temporarily offline, returns a safe fallback profile without crashing.
 */
export async function ensureUserProfile(
  user: FirebaseUser,
  fallbackDisplayName?: string
): Promise<UserProfile> {
  const derivedName =
    user.displayName ||
    fallbackDisplayName ||
    (user.email ? user.email.split('@')[0] : 'Nursing Aspirant');

  const userEmail = user.email || '';
  const isAdmin = isDesignatedAdminEmail(userEmail);

  const fallbackProfile: UserProfile = {
    uid: user.uid,
    fullName: derivedName,
    email: userEmail,
    role: isAdmin ? 'admin' : 'student',
    isActive: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };

  try {
    const existing = await getUserProfile(user.uid);
    if (existing) {
      return existing;
    }
  } catch (fetchErr) {
    console.warn('[userService] Could not fetch profile from Firestore, attempting fallback create:', fetchErr);
  }

  try {
    return await createUserProfile(user.uid, {
      fullName: derivedName,
      email: user.email || '',
    });
  } catch (createErr) {
    console.warn('[userService] Could not write profile to Firestore (using fallback state):', createErr);
    return fallbackProfile;
  }
}
