/**
 * Axon Nursing Academy - Firebase Firestore PDF Notes Service (Student LMS)
 * Ultra-fast local-first query with background Firestore synchronization.
 */
import {
  collection,
  doc,
  getDoc,
  getDocs,
  query,
  where,
  orderBy,
} from 'firebase/firestore';
import { getFirestoreDb } from '@/src/lib/firebase/firestore';
import { PdfNote } from '@/src/types/lms.types';
import { fallbackStore } from '@/src/services/fallback/fallbackStore';
import { withTimeout } from '@/src/lib/utils/asyncUtils';

const PDF_NOTES_COLLECTION = 'pdfNotes';

/**
 * Fetch all published PDF notes belonging to a specific chapter.
 */
export async function getPublishedPdfNotes(chapterId: string): Promise<PdfNote[]> {
  const cached = fallbackStore.getPdfNotes(chapterId).filter((p) => p.isPublished);
  const timeoutMs = cached.length > 0 ? 4000 : 8000;

  const db = getFirestoreDb();
  if (!db || !chapterId) {
    return cached;
  }

  try {
    const fetchFromFirestore = async () => {
      const notesRef = collection(db, PDF_NOTES_COLLECTION);
      const q = query(
        notesRef,
        where('chapterId', '==', chapterId),
        where('isPublished', '==', true)
      );

      const snapshot = await getDocs(q);

      const notes: PdfNote[] = (snapshot?.docs || []).map((docSnap) => {
        const data = docSnap.data();
        return {
          id: docSnap.id,
          batchId: data.batchId || '',
          subjectId: data.subjectId || '',
          chapterId: data.chapterId || chapterId,
          classId: data.classId || '',
          title: data.title || 'Untitled Note',
          description: data.description || '',
          fileUrl: data.fileUrl || '',
          storagePath: data.storagePath || '',
          fileName: data.fileName || 'document.pdf',
          fileSizeBytes: typeof data.fileSizeBytes === 'number' ? data.fileSizeBytes : 0,
          pageCount: typeof data.pageCount === 'number' ? data.pageCount : undefined,
          order: typeof data.order === 'number' ? data.order : 0,
          isFree: Boolean(data.isFree),
          isPublished: Boolean(data.isPublished),
          createdAt: data.createdAt,
          updatedAt: data.updatedAt,
        };
      });

      const sorted = notes.sort((a, b) => (a.order || 0) - (b.order || 0));
      fallbackStore.syncPdfNotes(sorted, chapterId);
      return sorted;
    };

    return await withTimeout(fetchFromFirestore(), timeoutMs, cached);
  } catch (err: any) {
    console.warn('[pdfNotesService] Serving cached PDF notes:', err?.message || err);
    return cached;
  }
}

/**
 * Fetch published PDF notes for a specific class (if mapped).
 */
export async function getPublishedPdfNotesForClass(classId: string): Promise<PdfNote[]> {
  const cached = fallbackStore.getPdfNotes().filter((p) => p.classId === classId && p.isPublished);

  const db = getFirestoreDb();
  if (!db || !classId) {
    return cached;
  }

  try {
    const fetchFromFirestore = async () => {
      const notesRef = collection(db, PDF_NOTES_COLLECTION);
      const q = query(
        notesRef,
        where('classId', '==', classId),
        where('isPublished', '==', true)
      );
      const snapshot = await getDocs(q);

      const notes: PdfNote[] = (snapshot?.docs || []).map((docSnap) => {
        const data = docSnap.data();
        return {
          id: docSnap.id,
          batchId: data.batchId || '',
          subjectId: data.subjectId || '',
          chapterId: data.chapterId || '',
          classId: data.classId || classId,
          title: data.title || 'Untitled Note',
          description: data.description || '',
          fileUrl: data.fileUrl || '',
          storagePath: data.storagePath || '',
          fileName: data.fileName || 'document.pdf',
          fileSizeBytes: typeof data.fileSizeBytes === 'number' ? data.fileSizeBytes : 0,
          pageCount: typeof data.pageCount === 'number' ? data.pageCount : undefined,
          order: typeof data.order === 'number' ? data.order : 0,
          isFree: Boolean(data.isFree),
          isPublished: Boolean(data.isPublished),
          createdAt: data.createdAt,
          updatedAt: data.updatedAt,
        };
      });

      const sorted = notes.sort((a, b) => (a.order || 0) - (b.order || 0));
      fallbackStore.syncPdfNotes(sorted);
      return sorted;
    };

    return await withTimeout(fetchFromFirestore(), 1200, cached);
  } catch (err: any) {
    console.warn('[pdfNotesService] Serving cached class PDF notes:', err?.message || err);
    return cached;
  }
}

/**
 * Get total published PDF count for a batch.
 */
export async function getPublishedPdfNoteCountForBatch(batchId: string): Promise<number> {
  const cachedCount = fallbackStore.getPdfNotes().filter((p) => p.batchId === batchId && p.isPublished).length;

  const db = getFirestoreDb();
  if (!db || !batchId) {
    return cachedCount;
  }

  try {
    const fetchCount = async () => {
      const notesRef = collection(db, PDF_NOTES_COLLECTION);
      const q = query(
        notesRef,
        where('batchId', '==', batchId),
        where('isPublished', '==', true)
      );
      const snapshot = await getDocs(q);
      return snapshot.size;
    };

    return await withTimeout(fetchCount(), 1000, cachedCount);
  } catch (err) {
    return cachedCount;
  }
}
