/**
 * Axon Nursing Academy - Production Firestore Coupon Service (Phase 6.1)
 * Authoritative admin-managed discount coupon storage and validation engine.
 * STRICT ZERO-TRUST: Only admin-created coupons stored in Firestore are accepted.
 */
import {
  collection,
  doc,
  getDoc,
  getDocs,
  setDoc,
  updateDoc,
  deleteDoc,
  query,
  where,
  limit,
  serverTimestamp,
} from 'firebase/firestore';
import { getFirestoreDb, handleFirestoreError, OperationType, FIRESTORE_COLLECTIONS } from '@/src/lib/firebase/firestore';
import { Coupon, CouponFormData, CouponValidationResult } from '@/src/types/coupon.types';
import { logAdminAudit } from './auditService';

/**
 * Normalizes a coupon code to uppercase trimmed alphanumeric format.
 */
export function normalizeCouponCode(code: string): string {
  return (code || '').trim().toUpperCase().replace(/[^A-Z0-9_-]/g, '');
}

/**
 * Validates a student-entered coupon code against live Firestore coupon records.
 * STRICT VALIDATION:
 * 1. Document exists in Firestore `coupons` collection
 * 2. Coupon is active (`isActive === true`)
 * 3. Date is within validFrom and validUntil
 * 4. Usage count has not reached usageLimit
 * 5. Coupon applies to the requested batchId
 * 6. Computes legitimate discount without negative price
 */
export async function validateCouponForCourse(
  rawCode: string,
  batchId: string,
  coursePrice: number
): Promise<CouponValidationResult> {
  const code = normalizeCouponCode(rawCode);
  if (!code) {
    return {
      isValid: false,
      error: 'Please enter a coupon code.',
    };
  }

  if (coursePrice <= 0) {
    return {
      isValid: false,
      error: 'Coupons cannot be applied to free courses.',
    };
  }

  const db = getFirestoreDb();
  if (!db) {
    return {
      isValid: false,
      error: 'Database is currently offline. Please try again later.',
    };
  }

  try {
    // Query authoritative coupon by code
    const q = query(
      collection(db, FIRESTORE_COLLECTIONS.COUPONS),
      where('code', '==', code)
    );
    const snap = await getDocs(q);

    if (snap.empty) {
      return {
        isValid: false,
        error: `Coupon code "${code}" is invalid or does not exist.`,
      };
    }

    const couponDoc = snap.docs[0];
    const data = couponDoc.data();
    const coupon: Coupon = {
      id: couponDoc.id,
      code: data.code,
      discountType: data.discountType,
      discountValue: Number(data.discountValue) || 0,
      isActive: Boolean(data.isActive),
      validFrom: data.validFrom,
      validUntil: data.validUntil,
      usageLimit: Number(data.usageLimit) || 0,
      usedCount: Number(data.usedCount) || 0,
      applicableCourseIds: Array.isArray(data.applicableCourseIds) ? data.applicableCourseIds : ['all'],
      description: data.description || '',
      createdBy: data.createdBy,
      createdAt: data.createdAt,
      updatedAt: data.updatedAt,
    };

    // 1. Activity check
    if (!coupon.isActive) {
      return {
        isValid: false,
        error: `Coupon code "${code}" is currently deactivated.`,
        coupon,
      };
    }

    // 2. Date window check
    const now = Date.now();
    if (coupon.validFrom) {
      const fromTime = new Date(coupon.validFrom).getTime();
      if (!isNaN(fromTime) && now < fromTime) {
        return {
          isValid: false,
          error: `Coupon "${code}" is not valid yet (activates on ${new Date(coupon.validFrom).toLocaleDateString()}).`,
          coupon,
        };
      }
    }

    if (coupon.validUntil) {
      const untilTime = new Date(coupon.validUntil).getTime();
      if (!isNaN(untilTime) && now > untilTime) {
        return {
          isValid: false,
          error: `Coupon code "${code}" expired on ${new Date(coupon.validUntil).toLocaleDateString()}.`,
          coupon,
        };
      }
    }

    // 3. Usage limit check
    if (coupon.usageLimit > 0 && coupon.usedCount >= coupon.usageLimit) {
      return {
        isValid: false,
        error: `Coupon "${code}" has reached its maximum redemption limit (${coupon.usageLimit}).`,
        coupon,
      };
    }

    // 4. Applicable course check
    const isApplicable =
      coupon.applicableCourseIds.length === 0 ||
      coupon.applicableCourseIds.includes('all') ||
      coupon.applicableCourseIds.includes(batchId);

    if (!isApplicable) {
      return {
        isValid: false,
        error: `Coupon "${code}" is not applicable for this course batch.`,
        coupon,
      };
    }

    // 5. Discount calculation
    let discountAmount = 0;
    if (coupon.discountType === 'percentage') {
      if (coupon.discountValue <= 0 || coupon.discountValue > 100) {
        return {
          isValid: false,
          error: 'Coupon configuration error: invalid percentage discount.',
          coupon,
        };
      }
      discountAmount = Math.round((coursePrice * coupon.discountValue) / 100);
    } else if (coupon.discountType === 'fixed') {
      if (coupon.discountValue <= 0) {
        return {
          isValid: false,
          error: 'Coupon configuration error: invalid fixed discount amount.',
          coupon,
        };
      }
      discountAmount = Math.min(coursePrice, coupon.discountValue);
    } else {
      return {
        isValid: false,
        error: 'Unsupported coupon discount type.',
        coupon,
      };
    }

    const finalPrice = Math.max(0, coursePrice - discountAmount);

    return {
      isValid: true,
      coupon,
      discountAmount,
      finalPrice,
    };
  } catch (err: any) {
    console.warn('[couponService] Notice validating coupon:', err?.message || err);
    return {
      isValid: false,
      error: 'Failed to validate coupon code. Please try again.',
    };
  }
}

/**
 * Admin: Fetch all coupons from Firestore.
 */
export async function getAllCouponsAdmin(): Promise<Coupon[]> {
  const db = getFirestoreDb();
  if (!db) return [];

  try {
    const snap = await getDocs(collection(db, FIRESTORE_COLLECTIONS.COUPONS));
    return snap.docs.map((d) => {
      const data = d.data();
      return {
        id: d.id,
        code: data.code,
        discountType: data.discountType,
        discountValue: Number(data.discountValue) || 0,
        isActive: Boolean(data.isActive),
        validFrom: data.validFrom,
        validUntil: data.validUntil,
        usageLimit: Number(data.usageLimit) || 0,
        usedCount: Number(data.usedCount) || 0,
        applicableCourseIds: Array.isArray(data.applicableCourseIds) ? data.applicableCourseIds : ['all'],
        description: data.description || '',
        createdBy: data.createdBy,
        createdAt: data.createdAt,
        updatedAt: data.updatedAt,
      };
    });
  } catch (err: any) {
    console.warn('[couponService] Notice fetching coupons:', err?.message || err);
    return [];
  }
}

/**
 * Admin: Create a new coupon.
 */
export async function createCoupon(
  formData: CouponFormData,
  adminUid: string,
  adminEmail?: string
): Promise<Coupon> {
  const db = getFirestoreDb();
  if (!db) throw new Error('Firestore is not configured.');

  const code = normalizeCouponCode(formData.code);
  if (!code || code.length < 3) {
    throw new Error('Coupon code must be at least 3 characters.');
  }

  if (formData.discountValue <= 0) {
    throw new Error('Discount value must be greater than 0.');
  }

  if (formData.discountType === 'percentage' && formData.discountValue > 100) {
    throw new Error('Percentage discount cannot exceed 100%.');
  }

  // Check uniqueness
  const existingQ = query(
    collection(db, FIRESTORE_COLLECTIONS.COUPONS),
    where('code', '==', code)
  );
  const existingSnap = await getDocs(existingQ);
  if (!existingSnap.empty) {
    throw new Error(`A coupon with code "${code}" already exists.`);
  }

  const id = `coupon_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
  const docRef = doc(db, FIRESTORE_COLLECTIONS.COUPONS, id);

  const payload: Coupon = {
    id,
    code,
    discountType: formData.discountType,
    discountValue: Number(formData.discountValue),
    isActive: formData.isActive,
    validFrom: formData.validFrom || new Date().toISOString(),
    validUntil: formData.validUntil || new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
    usageLimit: Number(formData.usageLimit) || 100,
    usedCount: 0,
    applicableCourseIds:
      formData.applicableCourseIds && formData.applicableCourseIds.length > 0
        ? formData.applicableCourseIds
        : ['all'],
    description: formData.description || '',
    createdBy: adminUid,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };

  try {
    await setDoc(docRef, {
      ...payload,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });

    logAdminAudit({
      actorUid: adminUid,
      actorEmail: adminEmail || 'pmgautamjaipur@gmail.com',
      action: 'create',
      resourceType: 'coupon',
      resourceId: id,
      resourceName: code,
      details: {
        discountType: payload.discountType,
        discountValue: payload.discountValue,
        usageLimit: payload.usageLimit,
      },
    }).catch(() => {});

    return payload;
  } catch (err) {
    handleFirestoreError(err, OperationType.CREATE, `${FIRESTORE_COLLECTIONS.COUPONS}/${id}`);
    throw err;
  }
}

/**
 * Admin: Update an existing coupon.
 */
export async function updateCoupon(
  id: string,
  updates: Partial<CouponFormData>,
  adminUid: string,
  adminEmail?: string
): Promise<void> {
  const db = getFirestoreDb();
  if (!db) throw new Error('Firestore is not configured.');

  const docRef = doc(db, FIRESTORE_COLLECTIONS.COUPONS, id);

  const payload: Record<string, any> = {
    ...updates,
    updatedAt: serverTimestamp(),
  };

  if (updates.code) {
    payload.code = normalizeCouponCode(updates.code);
  }

  if (updates.discountValue !== undefined) {
    const val = Number(updates.discountValue);
    if (val <= 0) throw new Error('Discount value must be greater than 0.');
    if (updates.discountType === 'percentage' && val > 100) {
      throw new Error('Percentage discount cannot exceed 100%.');
    }
    payload.discountValue = val;
  }

  try {
    await updateDoc(docRef, payload);

    logAdminAudit({
      actorUid: adminUid,
      actorEmail: adminEmail || 'pmgautamjaipur@gmail.com',
      action: 'update',
      resourceType: 'coupon',
      resourceId: id,
      resourceName: updates.code || id,
      details: updates,
    }).catch(() => {});
  } catch (err) {
    handleFirestoreError(err, OperationType.UPDATE, `${FIRESTORE_COLLECTIONS.COUPONS}/${id}`);
    throw err;
  }
}

/**
 * Admin: Toggle coupon active status.
 */
export async function toggleCouponActive(
  id: string,
  current: boolean,
  adminUid: string,
  adminEmail?: string
): Promise<boolean> {
  const next = !current;
  await updateCoupon(id, { isActive: next }, adminUid, adminEmail);
  return next;
}

/**
 * Admin: Delete a coupon.
 */
export async function deleteCoupon(
  id: string,
  adminUid: string,
  adminEmail?: string
): Promise<void> {
  const db = getFirestoreDb();
  if (!db) throw new Error('Firestore is not configured.');

  const docRef = doc(db, FIRESTORE_COLLECTIONS.COUPONS, id);

  try {
    await deleteDoc(docRef);

    logAdminAudit({
      actorUid: adminUid,
      actorEmail: adminEmail || 'pmgautamjaipur@gmail.com',
      action: 'delete',
      resourceType: 'coupon',
      resourceId: id,
      resourceTitle: id,
      details: { deletedAt: new Date().toISOString() },
    }).catch(() => {});
  } catch (err) {
    handleFirestoreError(err, OperationType.DELETE, `${FIRESTORE_COLLECTIONS.COUPONS}/${id}`);
    throw err;
  }
}

/**
 * Records coupon redemption upon student purchase.
 * Increments the coupon's usedCount in Firestore.
 */
export async function recordCouponRedemption(
  code: string,
  userId: string,
  batchId: string
): Promise<void> {
  const db = getFirestoreDb();
  if (!db) return;

  const normalized = normalizeCouponCode(code);
  if (!normalized) return;

  try {
    const q = query(
      collection(db, FIRESTORE_COLLECTIONS.COUPONS),
      where('code', '==', normalized),
      limit(1)
    );
    const snap = await getDocs(q);
    if (snap.empty) return;

    const couponDoc = snap.docs[0];
    const currentUsed = Number(couponDoc.data()?.usedCount) || 0;

    await updateDoc(couponDoc.ref, {
      usedCount: currentUsed + 1,
      updatedAt: serverTimestamp(),
    });
  } catch (err) {
    console.warn('[couponService] Error recording coupon redemption:', err);
  }
}
