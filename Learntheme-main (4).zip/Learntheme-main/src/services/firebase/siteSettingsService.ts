/**
 * Axon Nursing Academy - Site Settings & Branding Service
 * Persists Logo, Footer, Favicon, and Academy metadata in Firestore & Local Storage.
 */
import { doc, getDoc, setDoc, serverTimestamp } from 'firebase/firestore';
import { getFirestoreDb } from '@/src/lib/firebase/firestore';
import { SITE_CONFIG } from '@/src/config/site.config';

export interface SiteSettings {
  logoUrl: string;
  footerLogoUrl: string;
  faviconUrl: string;
  siteName: string;
  shortName: string;
  tagline: string;
  footerText: string;
  supportEmail: string;
  supportPhone: string;
  updatedAt?: string;
  updatedBy?: string;
}

export const DEFAULT_SITE_SETTINGS: SiteSettings = {
  logoUrl: '',
  footerLogoUrl: '',
  faviconUrl: '',
  siteName: SITE_CONFIG.name,
  shortName: SITE_CONFIG.shortName,
  tagline: SITE_CONFIG.tagline,
  footerText: SITE_CONFIG.description,
  supportEmail: SITE_CONFIG.supportEmail,
  supportPhone: SITE_CONFIG.supportPhone,
};

const STORAGE_KEY = 'axon_site_branding_cache';
const SETTINGS_COLLECTION = 'site_settings';
const SETTINGS_DOC_ID = 'general';

/**
 * Loads cached settings from localStorage for instant synchronous initial render
 */
export function getLocalCachedSettings(): SiteSettings {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      return { ...DEFAULT_SITE_SETTINGS, ...JSON.parse(raw) };
    }
  } catch (e) {
    console.warn('[SiteSettingsService] Local cache read error:', e);
  }
  return DEFAULT_SITE_SETTINGS;
}

/**
 * Saves settings to localStorage
 */
export function setLocalCachedSettings(settings: SiteSettings): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(settings));
  } catch (e) {
    console.warn('[SiteSettingsService] Local cache write error:', e);
  }
}

/**
 * Fetches the current site branding & metadata from Firestore
 */
export async function fetchSiteSettings(): Promise<SiteSettings> {
  const localCached = getLocalCachedSettings();
  const db = getFirestoreDb();
  if (!db) {
    return localCached;
  }

  try {
    const docRef = doc(db, SETTINGS_COLLECTION, SETTINGS_DOC_ID);
    const snap = await getDoc(docRef);

    if (snap.exists()) {
      const data = snap.data();
      const merged: SiteSettings = {
        logoUrl: data.logoUrl || '',
        footerLogoUrl: data.footerLogoUrl || '',
        faviconUrl: data.faviconUrl || '',
        siteName: data.siteName || SITE_CONFIG.name,
        shortName: data.shortName || SITE_CONFIG.shortName,
        tagline: data.tagline || SITE_CONFIG.tagline,
        footerText: data.footerText || SITE_CONFIG.description,
        supportEmail: data.supportEmail || SITE_CONFIG.supportEmail,
        supportPhone: data.supportPhone || SITE_CONFIG.supportPhone,
        updatedAt: data.updatedAt ? new Date(data.updatedAt.toDate?.() || data.updatedAt).toISOString() : undefined,
      };
      setLocalCachedSettings(merged);
      return merged;
    }
  } catch (error) {
    console.warn('[SiteSettingsService] Firestore fetch error, using cache:', error);
  }

  return localCached;
}

/**
 * Updates site branding & metadata in Firestore and local storage
 */
export async function updateSiteSettings(
  updates: Partial<SiteSettings>,
  actorEmail?: string
): Promise<SiteSettings> {
  const current = getLocalCachedSettings();
  const updated: SiteSettings = {
    ...current,
    ...updates,
    updatedAt: new Date().toISOString(),
    updatedBy: actorEmail || 'Admin',
  };

  // Always update local cache immediately
  setLocalCachedSettings(updated);

  const db = getFirestoreDb();
  if (db) {
    try {
      const docRef = doc(db, SETTINGS_COLLECTION, SETTINGS_DOC_ID);
      await setDoc(
        docRef,
        {
          ...updated,
          updatedAt: serverTimestamp(),
        },
        { merge: true }
      );
    } catch (error) {
      console.warn('[SiteSettingsService] Firestore save error (persisted locally):', error);
    }
  }

  return updated;
}
