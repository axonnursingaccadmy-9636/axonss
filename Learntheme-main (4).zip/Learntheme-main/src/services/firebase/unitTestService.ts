/**
 * Axon Nursing Academy - Firebase Firestore Unit MCQ Test Service
 * Chapter/Unit-level MCQ assessment service strictly tied to Subject and Chapter hierarchy.
 */
import {
  collection,
  doc,
  getDoc,
  getDocs,
  setDoc,
  updateDoc,
  deleteDoc,
  query,
  where,
  orderBy,
  serverTimestamp,
} from 'firebase/firestore';
import { getFirestoreDb } from '@/src/lib/firebase/firestore';
import { getFirebaseAuth } from '@/src/lib/firebase/auth';
import { getApiUrl } from '@/src/services/api';
import {
  UnitTest,
  UnitTestQuestion,
  UnitTestAttempt,
  UnitTestResult,
  PublicTestQuestion,
  QuestionReviewItem,
  McqOption,
} from '@/src/types/assessment.types';
import { logAdminAction } from './auditService';
import { fallbackStore } from '@/src/services/fallback/fallbackStore';
import { withTimeout } from '@/src/lib/utils/asyncUtils';

const TESTS_COLLECTION = 'unitTests';
const QUESTIONS_COLLECTION = 'unitTestQuestions';
const ATTEMPTS_COLLECTION = 'unitTestAttempts';
const RESULTS_COLLECTION = 'unitTestResults';

async function getStudentAuthHeaders(): Promise<Record<string, string>> {
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
  };
  try {
    const auth = getFirebaseAuth();
    if (auth?.currentUser && typeof auth.currentUser.getIdToken === 'function') {
      const token = await auth.currentUser.getIdToken().catch(() => null);
      if (token) {
        headers['Authorization'] = `Bearer ${token}`;
      }
    }
  } catch (e) {
    // continue
  }
  return headers;
}

export interface UnitTestFormData {
  batchId: string;
  subjectId: string;
  chapterId: string;
  classId?: string;
  title: string;
  description?: string;
  durationMinutes: number;
  totalMarks: number;
  passingMarks: number;
  marksPerQuestion: number;
  negativeMarksPerQuestion: number;
  totalQuestions: number;
  instructions: string[];
  isPublished: boolean;
  order: number;
  allowReviewAfterSubmission: boolean;
}

export interface UnitTestQuestionFormData {
  testId: string;
  chapterId: string;
  subjectId: string;
  batchId: string;
  questionText: string;
  questionImageUrl?: string;
  options: McqOption[];
  correctOptionId: string;
  marks: number;
  negativeMarks: number;
  explanation?: string;
  explanationImageUrl?: string;
  order: number;
}

// -------------------------------------------------------------
// 1. ADMIN UNIT TEST MANAGEMENT
// -------------------------------------------------------------

/**
 * Fetch all Unit MCQ tests (Admin CMS).
 */
export async function getAllUnitTestsAdmin(chapterId?: string): Promise<UnitTest[]> {
  const cached = fallbackStore.getUnitTests(chapterId);
  const db = getFirestoreDb();
  if (!db) return cached;

  try {
    const fetchFromFirestore = async () => {
      const testsRef = collection(db, TESTS_COLLECTION);
      const q = chapterId ? query(testsRef, where('chapterId', '==', chapterId)) : testsRef;
      const snapshot = await getDocs(q);

      const tests: UnitTest[] = (snapshot?.docs || []).map((d) => {
        const data = d.data();
        return {
          id: d.id,
          batchId: data.batchId,
          subjectId: data.subjectId,
          chapterId: data.chapterId,
          classId: data.classId || undefined,
          title: data.title || 'Untitled Unit Test',
          description: data.description || '',
          durationMinutes: Number(data.durationMinutes) || 15,
          totalMarks: Number(data.totalMarks) || 20,
          passingMarks: Number(data.passingMarks) || 10,
          marksPerQuestion: Number(data.marksPerQuestion) || 1,
          negativeMarksPerQuestion: Number(data.negativeMarksPerQuestion) || 0.25,
          totalQuestions: Number(data.totalQuestions) || 0,
          instructions: Array.isArray(data.instructions) ? data.instructions : [],
          isPublished: Boolean(data.isPublished),
          order: Number(data.order) || 0,
          allowReviewAfterSubmission: data.allowReviewAfterSubmission ?? true,
          createdAt: data.createdAt,
          updatedAt: data.updatedAt,
        };
      });

      const sorted = tests.sort((a, b) => (a.order || 0) - (b.order || 0));
      fallbackStore.syncUnitTests(sorted, chapterId);
      return sorted;
    };

    return await withTimeout(fetchFromFirestore(), 1200, cached);
  } catch (err: any) {
    console.warn('[UnitTestService] Returning cached unit tests:', err?.message || err);
    return cached;
  }
}

/**
 * Fetch a single Unit MCQ test by ID.
 */
export async function getUnitTestById(testId: string): Promise<UnitTest | null> {
  const cached = fallbackStore.getUnitTestById(testId);
  const db = getFirestoreDb();
  if (!db || !testId) return cached;

  try {
    const fetchDoc = async () => {
      const docRef = doc(db, TESTS_COLLECTION, testId);
      const snap = await getDoc(docRef);
      if (!snap.exists()) {
        return cached;
      }
      const data = snap.data();
      const testItem: UnitTest = {
        id: snap.id,
        batchId: data.batchId,
        subjectId: data.subjectId,
        chapterId: data.chapterId,
        classId: data.classId || undefined,
        title: data.title || 'Untitled Unit Test',
        description: data.description || '',
        durationMinutes: Number(data.durationMinutes) || 15,
        totalMarks: Number(data.totalMarks) || 20,
        passingMarks: Number(data.passingMarks) || 10,
        marksPerQuestion: Number(data.marksPerQuestion) || 1,
        negativeMarksPerQuestion: Number(data.negativeMarksPerQuestion) || 0.25,
        totalQuestions: Number(data.totalQuestions) || 0,
        instructions: Array.isArray(data.instructions) ? data.instructions : [],
        isPublished: Boolean(data.isPublished),
        order: Number(data.order) || 0,
        allowReviewAfterSubmission: data.allowReviewAfterSubmission ?? true,
        createdAt: data.createdAt,
        updatedAt: data.updatedAt,
      };
      fallbackStore.saveUnitTest(testItem);
      return testItem;
    };

    return await withTimeout(fetchDoc(), 1000, cached);
  } catch (err: any) {
    console.warn('[UnitTestService] Returning cached test:', err?.message || err);
    return cached;
  }
}

/**
 * Create a new Unit MCQ Test (Admin).
 */
export async function createUnitTest(
  data: UnitTestFormData,
  actorUid: string,
  actorEmail?: string
): Promise<UnitTest> {
  const testId = `unit_test_${Date.now()}`;
  const payload: UnitTest = {
    id: testId,
    batchId: data.batchId,
    subjectId: data.subjectId,
    chapterId: data.chapterId,
    classId: data.classId || undefined,
    title: data.title.trim(),
    description: data.description?.trim() || '',
    durationMinutes: Number(data.durationMinutes) || 15,
    totalMarks: Number(data.totalMarks) || 20,
    passingMarks: Number(data.passingMarks) || 10,
    marksPerQuestion: Number(data.marksPerQuestion) || 1,
    negativeMarksPerQuestion: Number(data.negativeMarksPerQuestion) || 0.25,
    totalQuestions: Number(data.totalQuestions) || 0,
    instructions: Array.isArray(data.instructions) ? data.instructions : [],
    isPublished: Boolean(data.isPublished),
    order: Number(data.order) || 0,
    allowReviewAfterSubmission: data.allowReviewAfterSubmission ?? true,
  };

  fallbackStore.saveUnitTest(payload);

  const db = getFirestoreDb();
  if (!db) return payload;

  try {
    const docRef = doc(db, TESTS_COLLECTION, testId);
    await setDoc(docRef, {
      ...payload,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });

    await logAdminAction({
      actorUid,
      actorEmail,
      action: 'UNIT_TEST_CREATED',
      resourceType: 'unit_test',
      resourceId: testId,
      resourceTitle: data.title,
      details: { chapterId: data.chapterId, subjectId: data.subjectId },
    }).catch(() => {});

    return payload;
  } catch (err: any) {
    console.warn('[UnitTestService] Saved to local cache:', err?.message || err);
    return payload;
  }
}

/**
 * Update an existing Unit MCQ Test (Admin).
 */
export async function updateUnitTest(
  testId: string,
  data: Partial<UnitTestFormData>,
  actorUid: string,
  actorEmail?: string
): Promise<void> {
  const existing = fallbackStore.getUnitTestById(testId);
  if (existing) {
    fallbackStore.saveUnitTest({ ...existing, ...data } as UnitTest);
  }

  const db = getFirestoreDb();
  if (!db) return;

  try {
    const docRef = doc(db, TESTS_COLLECTION, testId);
    await updateDoc(docRef, {
      ...data,
      updatedAt: serverTimestamp(),
    });

    await logAdminAction({
      actorUid,
      actorEmail,
      action: 'UNIT_TEST_UPDATED',
      resourceType: 'unit_test',
      resourceId: testId,
      resourceTitle: data.title || testId,
      details: { changedFields: Object.keys(data) },
    }).catch(() => {});
  } catch (err: any) {
    console.warn('[UnitTestService] Update deferred:', err?.message || err);
  }
}

/**
 * Toggle publish status of a Unit MCQ Test.
 */
export async function toggleUnitTestPublish(
  testId: string,
  isPublished: boolean,
  testTitle: string,
  actorUid: string,
  actorEmail?: string
): Promise<void> {
  const existing = fallbackStore.getUnitTestById(testId);
  if (existing) {
    fallbackStore.saveUnitTest({ ...existing, isPublished });
  }

  const db = getFirestoreDb();
  if (!db) return;

  try {
    const docRef = doc(db, TESTS_COLLECTION, testId);
    await updateDoc(docRef, {
      isPublished,
      updatedAt: serverTimestamp(),
    });

    await logAdminAction({
      actorUid,
      actorEmail,
      action: isPublished ? 'UNIT_TEST_PUBLISHED' : 'UNIT_TEST_UNPUBLISHED',
      resourceType: 'unit_test',
      resourceId: testId,
      resourceTitle: testTitle,
      details: { isPublished },
    }).catch(() => {});
  } catch (err: any) {
    console.warn('[UnitTestService] Toggle publish deferred:', err?.message || err);
  }
}

/**
 * Delete a Unit MCQ Test (Admin).
 */
export async function deleteUnitTest(
  testId: string,
  testTitle: string,
  actorUid: string,
  actorEmail?: string
): Promise<void> {
  fallbackStore.deleteUnitTest(testId);

  const db = getFirestoreDb();
  if (!db) return;

  try {
    const docRef = doc(db, TESTS_COLLECTION, testId);
    await deleteDoc(docRef);

    // Clean up questions in background
    const questionsRef = collection(db, QUESTIONS_COLLECTION);
    const qSnap = await getDocs(query(questionsRef, where('testId', '==', testId)));
    qSnap.forEach(async (qDoc) => {
      await deleteDoc(doc(db, QUESTIONS_COLLECTION, qDoc.id)).catch(() => {});
    });

    await logAdminAction({
      actorUid,
      actorEmail,
      action: 'UNIT_TEST_DELETED',
      resourceType: 'unit_test',
      resourceId: testId,
      resourceTitle: testTitle,
    }).catch(() => {});
  } catch (err: any) {
    console.warn('[UnitTestService] Delete deferred:', err?.message || err);
  }
}

// -------------------------------------------------------------
// 2. QUESTION MANAGEMENT (ADMIN)
// -------------------------------------------------------------

/**
 * Fetch all questions for a Unit MCQ test (Admin - includes answers).
 */
export async function getUnitTestQuestionsAdmin(testId: string): Promise<UnitTestQuestion[]> {
  const cached = fallbackStore.getUnitTestQuestions(testId);
  const db = getFirestoreDb();
  if (!db) return cached;

  try {
    const fetchFromFirestore = async () => {
      const questionsRef = collection(db, QUESTIONS_COLLECTION);
      const q = query(questionsRef, where('testId', '==', testId));
      const snapshot = await getDocs(q);

      const questions: UnitTestQuestion[] = (snapshot?.docs || []).map((d) => {
        const data = d.data();
        return {
          id: d.id,
          testId: data.testId,
          chapterId: data.chapterId,
          subjectId: data.subjectId,
          batchId: data.batchId,
          questionText: data.questionText || '',
          questionImageUrl: data.questionImageUrl || undefined,
          options: Array.isArray(data.options) ? data.options : [],
          correctOptionId: data.correctOptionId || '',
          marks: Number(data.marks) || 1,
          negativeMarks: Number(data.negativeMarks) || 0.25,
          explanation: data.explanation || '',
          explanationImageUrl: data.explanationImageUrl || undefined,
          order: Number(data.order) || 0,
          createdAt: data.createdAt,
          updatedAt: data.updatedAt,
        };
      });

      const sorted = questions.sort((a, b) => (a.order || 0) - (b.order || 0));
      fallbackStore.syncUnitTestQuestions(sorted, testId);
      return sorted;
    };

    return await withTimeout(fetchFromFirestore(), 1200, cached);
  } catch (err: any) {
    console.warn('[UnitTestService] Returning cached questions:', err?.message || err);
    return cached;
  }
}

/**
 * Create a Question for Unit MCQ Test (Admin).
 */
export async function createUnitTestQuestion(
  data: UnitTestQuestionFormData,
  actorUid: string,
  actorEmail?: string
): Promise<UnitTestQuestion> {
  const questionId = `utq_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
  const payload: UnitTestQuestion = {
    id: questionId,
    testId: data.testId,
    chapterId: data.chapterId,
    subjectId: data.subjectId,
    batchId: data.batchId,
    questionText: data.questionText.trim(),
    questionImageUrl: data.questionImageUrl?.trim() || undefined,
    options: data.options,
    correctOptionId: data.correctOptionId,
    marks: Number(data.marks) || 1,
    negativeMarks: Number(data.negativeMarks) || 0.25,
    explanation: data.explanation?.trim() || '',
    explanationImageUrl: data.explanationImageUrl?.trim() || undefined,
    order: Number(data.order) || 0,
  };

  fallbackStore.saveUnitTestQuestion(payload);

  // Sync test total questions count
  const allQ = fallbackStore.getUnitTestQuestions(data.testId);
  const totalMarks = allQ.reduce((sum, q) => sum + (q.marks || 1), 0);
  const testObj = fallbackStore.getUnitTestById(data.testId);
  if (testObj) {
    fallbackStore.saveUnitTest({
      ...testObj,
      totalQuestions: allQ.length,
      totalMarks: totalMarks,
    });
  }

  const db = getFirestoreDb();
  if (!db) return payload;

  try {
    const docRef = doc(db, QUESTIONS_COLLECTION, questionId);
    await setDoc(docRef, {
      ...payload,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });

    // Update parent test totalQuestions count in Firestore
    const testRef = doc(db, TESTS_COLLECTION, data.testId);
    await updateDoc(testRef, {
      totalQuestions: allQ.length,
      totalMarks: totalMarks,
      updatedAt: serverTimestamp(),
    }).catch(() => {});

    await logAdminAction({
      actorUid,
      actorEmail,
      action: 'UNIT_QUESTION_CREATED',
      resourceType: 'unit_test_question',
      resourceId: questionId,
      resourceTitle: data.questionText.substring(0, 40),
      details: { testId: data.testId },
    }).catch(() => {});

    return payload;
  } catch (err: any) {
    console.warn('[UnitTestService] Saved question locally:', err?.message || err);
    return payload;
  }
}

/**
 * Update a Question for Unit MCQ Test (Admin).
 */
export async function updateUnitTestQuestion(
  questionId: string,
  data: Partial<UnitTestQuestionFormData>,
  actorUid: string,
  actorEmail?: string
): Promise<void> {
  const existing = fallbackStore.getUnitTestQuestionById(questionId);
  if (existing) {
    fallbackStore.saveUnitTestQuestion({ ...existing, ...data } as UnitTestQuestion);
  }

  const db = getFirestoreDb();
  if (!db) return;

  try {
    const docRef = doc(db, QUESTIONS_COLLECTION, questionId);
    await updateDoc(docRef, {
      ...data,
      updatedAt: serverTimestamp(),
    });

    await logAdminAction({
      actorUid,
      actorEmail,
      action: 'UNIT_QUESTION_UPDATED',
      resourceType: 'unit_test_question',
      resourceId: questionId,
      resourceTitle: data.questionText?.substring(0, 40) || questionId,
    }).catch(() => {});
  } catch (err: any) {
    console.warn('[UnitTestService] Question update deferred:', err?.message || err);
  }
}

/**
 * Delete a Question for Unit MCQ Test (Admin).
 */
export async function deleteUnitTestQuestion(
  questionId: string,
  testId: string,
  actorUid: string,
  actorEmail?: string
): Promise<void> {
  fallbackStore.deleteUnitTestQuestion(questionId);

  // Sync test total count
  const allQ = fallbackStore.getUnitTestQuestions(testId);
  const totalMarks = allQ.reduce((sum, q) => sum + (q.marks || 1), 0);
  const testObj = fallbackStore.getUnitTestById(testId);
  if (testObj) {
    fallbackStore.saveUnitTest({
      ...testObj,
      totalQuestions: allQ.length,
      totalMarks: totalMarks,
    });
  }

  const db = getFirestoreDb();
  if (!db) return;

  try {
    const docRef = doc(db, QUESTIONS_COLLECTION, questionId);
    await deleteDoc(docRef);

    const testRef = doc(db, TESTS_COLLECTION, testId);
    await updateDoc(testRef, {
      totalQuestions: allQ.length,
      totalMarks: totalMarks,
      updatedAt: serverTimestamp(),
    }).catch(() => {});

    await logAdminAction({
      actorUid,
      actorEmail,
      action: 'UNIT_QUESTION_DELETED',
      resourceType: 'unit_test_question',
      resourceId: questionId,
      resourceTitle: questionId,
    }).catch(() => {});
  } catch (err: any) {
    console.warn('[UnitTestService] Question delete deferred:', err?.message || err);
  }
}

// -------------------------------------------------------------
// 3. STUDENT LEARNER UNIT TEST & ATTEMPT SERVICE
// -------------------------------------------------------------

/**
 * Get published Unit tests for a specific Chapter.
 */
export async function getPublishedUnitTests(chapterId: string): Promise<UnitTest[]> {
  const all = await getAllUnitTestsAdmin(chapterId);
  return all.filter((t) => t.isPublished);
}

/**
 * Get sanitized questions for the active test player (Answer key is strictly hidden).
 */
export async function getPublicUnitTestQuestions(testId: string): Promise<PublicTestQuestion[]> {
  try {
    const headers = await getStudentAuthHeaders();
    const res = await fetch(getApiUrl(`/api/tests/unit-test/${encodeURIComponent(testId)}/questions`), { headers });
    if (res.ok) {
      const data = await res.json();
      if (data.success && Array.isArray(data.questions) && data.questions.length > 0) {
        return data.questions;
      }
    }
  } catch (err) {
    console.warn('[UnitTestService] Error fetching questions from server endpoint, using fallback:', err);
  }

  // Sanitized fallback
  const allQuestions = await getUnitTestQuestionsAdmin(testId);
  return allQuestions.map((q) => ({
    id: q.id,
    testId: q.testId,
    questionText: q.questionText,
    questionImageUrl: q.questionImageUrl,
    options: q.options.map((opt) => ({
      id: opt.id,
      text: opt.text,
      imageUrl: opt.imageUrl,
    })),
    marks: q.marks,
    negativeMarks: q.negativeMarks,
    order: q.order,
  }));
}

export const getUnitTestQuestionsForStudent = getPublicUnitTestQuestions;

/**
 * Start or resume a student attempt for Unit MCQ Test.
 */
export async function startUnitTestAttempt(
  testId: string,
  batchId: string,
  subjectId: string,
  chapterId: string,
  studentId: string,
  studentName: string = 'Student',
  studentEmail: string = ''
): Promise<UnitTestAttempt> {
  const existingAttempts = await getUnitTestStudentAttempts(testId, studentId);
  const active = existingAttempts.find((a) => a.status === 'in_progress');
  if (active) return active;

  const testData = await getUnitTestById(testId);

  // Authoritative attempt limit verification (Section 9.13)
  if (testData?.maxAttempts && testData.maxAttempts > 0) {
    const completedCount = existingAttempts.filter((a) => a.status === 'completed').length;
    if (completedCount >= testData.maxAttempts) {
      throw new Error(`Maximum attempt limit reached. You are allowed up to ${testData.maxAttempts} attempt(s) for this unit test.`);
    }
  }

  const durationMinutes = testData?.durationMinutes || 15;

  const attemptId = `ut_att_${Date.now()}_${studentId.substring(0, 5)}`;
  const newAttempt: UnitTestAttempt = {
    id: attemptId,
    testId,
    batchId,
    subjectId,
    chapterId,
    studentId,
    studentName,
    studentEmail,
    status: 'in_progress',
    startedAt: new Date().toISOString(),
    timeRemainingSeconds: durationMinutes * 60,
    timeTakenSeconds: 0,
    answers: {},
    markedForReview: [],
  };

  fallbackStore.saveUnitTestAttempt(newAttempt);

  const db = getFirestoreDb();
  if (db) {
    const docRef = doc(db, ATTEMPTS_COLLECTION, attemptId);
    setDoc(docRef, {
      ...newAttempt,
      createdAt: serverTimestamp(),
    }).catch((err) => {
      console.warn('[UnitTestService] Attempt stored in fallback:', err);
    });
  }

  return newAttempt;
}

/**
 * Periodically save student attempt progress.
 */
export async function saveUnitTestAttemptProgress(
  attemptId: string,
  answers: Record<string, string>,
  markedForReview: string[],
  timeRemainingSeconds: number,
  timeTakenSeconds: number
): Promise<void> {
  const existing = fallbackStore.getUnitTestAttemptById(attemptId);
  if (existing) {
    fallbackStore.saveUnitTestAttempt({
      ...existing,
      answers,
      markedForReview,
      timeRemainingSeconds,
      timeTakenSeconds,
    });
  }

  const db = getFirestoreDb();
  if (!db) return;

  try {
    const docRef = doc(db, ATTEMPTS_COLLECTION, attemptId);
    await updateDoc(docRef, {
      answers,
      markedForReview,
      timeRemainingSeconds,
      timeTakenSeconds,
      updatedAt: serverTimestamp(),
    });
  } catch (err) {
    // Silent catch for periodic autosave
  }
}

/**
 * Submit Unit MCQ Attempt and evaluate score.
 */
export async function submitUnitTestAttempt(
  attemptId: string,
  testId: string,
  answers: Record<string, string>,
  timeTakenSeconds: number,
  studentId: string,
  studentName: string = 'Student',
  studentEmail: string = ''
): Promise<UnitTestResult> {
  // Authoritative server-only submission and evaluation
  const headers = await getStudentAuthHeaders();
  const res = await fetch(getApiUrl(`/api/tests/unit-test/${encodeURIComponent(testId)}/submit`), {
    method: 'POST',
    headers,
    body: JSON.stringify({
      attemptId,
      answers,
      timeSpentSeconds: timeTakenSeconds,
    }),
  });

  if (!res.ok) {
    const errData = await res.json().catch(() => null);
    throw new Error(errData?.error || `Server test evaluation failed with status ${res.status}. Local score calculation is forbidden.`);
  }

  const data = await res.json();
  if (!data.success || !data.result) {
    throw new Error(data.error || 'Server rejected unit test submission.');
  }

  fallbackStore.saveUnitTestResult(data.result);
  return data.result;
}

/**
 * Get Result Scorecard by resultId or attemptId.
 */
export async function getUnitTestResult(resultOrAttemptId: string): Promise<UnitTestResult | null> {
  const fallbackRes = fallbackStore.getUnitTestResult(resultOrAttemptId);
  if (fallbackRes) return fallbackRes;

  const db = getFirestoreDb();
  if (!db) return null;

  try {
    const docRef = doc(db, RESULTS_COLLECTION, resultOrAttemptId);
    const snap = await getDoc(docRef);
    if (snap.exists()) {
      return snap.data() as UnitTestResult;
    }

    const q = query(collection(db, RESULTS_COLLECTION), where('attemptId', '==', resultOrAttemptId));
    const qSnap = await getDocs(q);
    if (!qSnap.empty) {
      return qSnap.docs[0].data() as UnitTestResult;
    }

    return null;
  } catch (err) {
    return null;
  }
}

/**
 * Get Question Review List for Post-submission analysis.
 */
export async function getUnitTestQuestionReviewList(
  testId: string,
  userAnswers: Record<string, string>,
  attemptId?: string
): Promise<QuestionReviewItem[]> {
  if (attemptId) {
    try {
      const headers = await getStudentAuthHeaders();
      const res = await fetch(getApiUrl(`/api/tests/unit-test/${encodeURIComponent(testId)}/review/${encodeURIComponent(attemptId)}`), { headers });
      if (res.ok) {
        const data = await res.json();
        if (data.success && Array.isArray(data.reviewItems)) {
          return data.reviewItems.map((item: any) => ({
            id: item.questionId,
            questionText: item.questionText,
            questionImageUrl: item.questionImageUrl,
            options: item.options,
            selectedOptionId: item.studentSelectedOptionId,
            correctOptionId: item.correctOptionId,
            isCorrect: item.isCorrect,
            isSkipped: item.isSkipped,
            marksAwarded: item.isCorrect ? item.marks : item.isSkipped ? 0 : -(item.negativeMarks || 0),
            explanation: item.explanation,
            explanationImageUrl: item.explanationImageUrl,
            subjectTag: item.subjectTag,
          }));
        }
      }
    } catch (err) {
      console.warn('[UnitTestService] Server review fetch failed:', err);
    }
  }

  return [];
}

/**
 * Get student previous attempts for a unit test.
 */
export async function getUnitTestStudentAttempts(
  testId: string,
  studentId: string
): Promise<UnitTestAttempt[]> {
  const db = getFirestoreDb();
  if (!db) return fallbackStore.getUnitTestAttempts(testId, studentId);

  try {
    const q = query(
      collection(db, ATTEMPTS_COLLECTION),
      where('testId', '==', testId),
      where('studentId', '==', studentId),
      orderBy('startedAt', 'desc')
    );
    const snap = await getDocs(q);
    if (snap.empty) {
      return fallbackStore.getUnitTestAttempts(testId, studentId);
    }
    return snap.docs.map((d) => d.data() as UnitTestAttempt);
  } catch (err) {
    return fallbackStore.getUnitTestAttempts(testId, studentId);
  }
}

/**
 * Get all attempts for a test (Admin Analytics).
 */
export async function getUnitTestAttemptsForAdmin(testId: string): Promise<UnitTestAttempt[]> {
  const db = getFirestoreDb();
  if (!db) return fallbackStore.getUnitTestAttempts(testId);

  try {
    const q = query(collection(db, ATTEMPTS_COLLECTION), where('testId', '==', testId));
    const snap = await getDocs(q);
    if (snap.empty) {
      return fallbackStore.getUnitTestAttempts(testId);
    }
    return snap.docs.map((d) => d.data() as UnitTestAttempt);
  } catch (err) {
    return fallbackStore.getUnitTestAttempts(testId);
  }
}
