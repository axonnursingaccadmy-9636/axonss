/**
 * Axon Nursing Academy - Production Firestore Enrollment & Course Access Service (Phase 6.1)
 * Authoritative source of truth for student course purchases and free enrollment access.
 */
import {
  collection,
  doc,
  getDoc,
  getDocs,
  setDoc,
  updateDoc,
  deleteDoc,
  query,
  where,
  serverTimestamp,
} from 'firebase/firestore';
import { getFirestoreDb, handleFirestoreError, OperationType, FIRESTORE_COLLECTIONS } from '@/src/lib/firebase/firestore';
import { getFirebaseAuth } from '@/src/lib/firebase/auth';
import { Enrollment, CourseAccessCheck } from '@/src/types/enrollment.types';
import { Batch } from '@/src/types/lms.types';
import { isDesignatedAdminEmail } from '@/src/config/admin.config';
import { getUserProfile, ensureUserProfile } from './userService';
import { logAdminAudit } from './auditService';
import { validateCouponForCourse, recordCouponRedemption } from './couponService';
import { checkCourseAccessFromApi, getUserActiveEnrollmentsFromApi } from '@/src/services/payment/razorpayService';
import { getApiUrl, fetchApi } from '@/src/services/api';

/**
 * Generates deterministic enrollment document ID: enr_{userId}_{batchId}
 */
export function getEnrollmentDocId(userId: string, batchId: string): string {
  const cleanUser = (userId || '').replace(/[^a-zA-Z0-9_-]/g, '');
  const cleanBatch = (batchId || '').replace(/[^a-zA-Z0-9_-]/g, '');
  return `enr_${cleanUser}_${cleanBatch}`;
}

/**
 * Authoritative Course Access Check.
 * Protects Subjects, Chapters, Classes, PDFs, Unit MCQs, and Weekly Warrior Tests.
 * Students CANNOT bypass access merely by modifying URL params.
 */
export async function checkStudentCourseAccess(
  userId: string | undefined,
  batchId: string | undefined,
  isFreeBatch?: boolean,
  userEmail?: string | null
): Promise<CourseAccessCheck> {
  if (!userId || !batchId) {
    return {
      hasAccess: false,
      status: 'not_enrolled',
      reason: 'Authentication and course identifier are required.',
    };
  }

  const auth = getFirebaseAuth();
  const effectiveEmail = userEmail || auth?.currentUser?.email;
  let isAdmin = isDesignatedAdminEmail(effectiveEmail);

  const db = getFirestoreDb();
  if (!db) {
    if (isAdmin) {
      return {
        hasAccess: true,
        isAdmin: true,
        status: 'not_enrolled',
        enrollment: null,
        reason: 'Administrator preview privileges (database offline).',
      };
    }
    return {
      hasAccess: false,
      isAdmin: false,
      status: 'not_enrolled',
      reason: 'Database is currently unavailable. Please verify network connection.',
    };
  }

  try {
    // Check if user has admin privileges via profile if not already determined
    if (!isAdmin) {
      try {
        const profile = await getUserProfile(userId);
        if (profile && (isDesignatedAdminEmail(profile.email) || profile.role === 'admin')) {
          isAdmin = true;
        }
      } catch (profileErr) {
        console.warn('[enrollmentService] Note: User profile check notice:', profileErr);
      }
    }

    // 1. Check deterministic enrollment document: enr_{userId}_{batchId}
    const docId = getEnrollmentDocId(userId, batchId);
    const docRef = doc(db, FIRESTORE_COLLECTIONS.ENROLLMENTS, docId);
    let snap: any = null;
    try {
      snap = await getDoc(docRef);
    } catch (snapErr) {
      console.warn('[enrollmentService] Note: Direct enrollment doc query notice:', snapErr);
    }

    if (snap && snap.exists()) {
      const data = snap.data();
      const enrollment: Enrollment = {
        id: snap.id,
        userId: data.userId,
        batchId: data.batchId,
        status: data.status || 'active',
        isFree: Boolean(data.isFree),
        enrolledAt: data.enrolledAt,
        expiresAt: data.expiresAt || null,
        couponCode: data.couponCode || null,
        amountPaid: data.amountPaid || 0,
        courseTitle: data.courseTitle,
        courseThumbnail: data.courseThumbnail,
        createdAt: data.createdAt,
        updatedAt: data.updatedAt,
      };

      if (enrollment.status !== 'active') {
        return {
          hasAccess: isAdmin,
          isAdmin,
          status: enrollment.status,
          reason: `Course enrollment is ${enrollment.status}.`,
          enrollment,
        };
      }

      // Check expiry if expiresAt is set
      if (enrollment.expiresAt) {
        const expiryTime = new Date(enrollment.expiresAt).getTime();
        if (!isNaN(expiryTime) && Date.now() > expiryTime) {
          return {
            hasAccess: isAdmin,
            isAdmin,
            status: 'expired',
            reason: `Your access to this course expired on ${new Date(enrollment.expiresAt).toLocaleDateString()}.`,
            enrollment,
            expiresAt: enrollment.expiresAt,
          };
        }
      }

      return {
        hasAccess: true,
        isAdmin,
        status: 'active',
        enrollment,
        expiresAt: enrollment.expiresAt,
      };
    }

    // Secondary fallback: query by userId and batchId in case document used custom id
    let querySnap: any = null;
    try {
      const q = query(
        collection(db, FIRESTORE_COLLECTIONS.ENROLLMENTS),
        where('userId', '==', userId),
        where('batchId', '==', batchId)
      );
      querySnap = await getDocs(q);
    } catch (queryErr) {
      console.warn('[enrollmentService] Note: Fallback query notice:', queryErr);
    }

    if (querySnap && !querySnap.empty) {
      const d = querySnap.docs[0];
      const data = d.data();
      const enrollment: Enrollment = {
        id: d.id,
        userId: data.userId,
        batchId: data.batchId,
        status: data.status || 'active',
        isFree: Boolean(data.isFree),
        source: data.source,
        paymentProvider: data.paymentProvider,
        paymentId: data.paymentId,
        orderId: data.orderId,
        currency: data.currency,
        enrolledAt: data.enrolledAt,
        expiresAt: data.expiresAt || null,
        couponCode: data.couponCode || null,
        amountPaid: data.amountPaid || 0,
        courseTitle: data.courseTitle,
        courseThumbnail: data.courseThumbnail,
        createdAt: data.createdAt,
        updatedAt: data.updatedAt,
      };

      if (enrollment.status === 'active') {
        if (enrollment.expiresAt) {
          const expiryTime = new Date(enrollment.expiresAt).getTime();
          if (!isNaN(expiryTime) && Date.now() > expiryTime) {
            return {
              hasAccess: isAdmin,
              isAdmin,
              status: 'expired',
              reason: 'Your access period has expired.',
              enrollment,
            };
          }
        }
        return {
          hasAccess: true,
          isAdmin,
          status: 'active',
          enrollment,
          expiresAt: enrollment.expiresAt,
        };
      }
    }

    // 3. Fallback check against authoritative server API
    try {
      const idToken = await auth?.currentUser?.getIdToken();
      if (idToken) {
        const apiCheck = await checkCourseAccessFromApi(batchId, idToken);
        if (apiCheck && apiCheck.enrollment && apiCheck.enrollment.status === 'active') {
          return {
            hasAccess: true,
            status: 'active',
            isAdmin: Boolean(apiCheck.isAdmin || isAdmin),
            enrollment: apiCheck.enrollment,
            expiresAt: apiCheck.enrollment?.expiresAt || undefined,
          };
        } else if (apiCheck && apiCheck.isAdmin) {
          isAdmin = true;
        }
      }
    } catch (apiErr) {
      console.warn('[enrollmentService] Note: Server access query fallback warning:', apiErr);
    }

    // If user is admin but has not enrolled/purchased this course
    if (isAdmin) {
      return {
        hasAccess: true,
        isAdmin: true,
        status: 'not_enrolled',
        enrollment: null,
        reason: 'Administrator preview privileges (not enrolled as a student).',
      };
    }

    // No active enrollment found for student
    return {
      hasAccess: false,
      isAdmin: false,
      status: 'not_enrolled',
      enrollment: null,
      isFreeCourse: Boolean(isFreeBatch),
      reason: isFreeBatch
        ? 'Click "Enroll in Free Batch" to activate your access.'
        : 'You have not purchased this course batch yet.',
    };
  } catch (err: any) {
    console.warn('[enrollmentService] Note: Direct course check deferred to server API:', err?.message || err);
    // Even if Firestore threw an error, check backend API directly
    try {
      const idToken = await auth?.currentUser?.getIdToken();
      if (idToken) {
        const apiCheck = await checkCourseAccessFromApi(batchId, idToken);
        if (apiCheck && apiCheck.enrollment && apiCheck.enrollment.status === 'active') {
          return {
            hasAccess: true,
            status: 'active',
            isAdmin: Boolean(apiCheck.isAdmin || isAdmin),
            enrollment: apiCheck.enrollment,
            expiresAt: apiCheck.enrollment?.expiresAt || undefined,
          };
        } else if (apiCheck && apiCheck.isAdmin) {
          isAdmin = true;
        }
      }
    } catch (retryErr) {
      // Ignore
    }

    if (isAdmin) {
      return {
        hasAccess: true,
        isAdmin: true,
        status: 'not_enrolled',
        enrollment: null,
        reason: 'Administrator preview privileges (not enrolled as a student).',
      };
    }

    return {
      hasAccess: false,
      isAdmin: false,
      status: 'not_enrolled',
      enrollment: null,
      isFreeCourse: Boolean(isFreeBatch),
      reason: isFreeBatch
        ? 'Click "Enroll in Free Batch" to activate your access.'
        : 'You have not purchased this course batch yet.',
    };
  }
}

/**
 * Enrolls an authenticated student in a free batch (isFree === true).
 * Strictly complies with Rule 13:
 * "Follow the existing free-course access mechanism. Do not treat a free course as a fake paid purchase."
 */
export async function enrollInFreeBatch(
  userId: string,
  batch: Batch
): Promise<Enrollment> {
  if (!batch.isFree) {
    throw new Error('This course requires tuition fee payment and cannot be enrolled for free.');
  }

  const db = getFirestoreDb();
  if (!db) throw new Error('Firestore is not configured.');

  const docId = getEnrollmentDocId(userId, batch.id);
  const docRef = doc(db, FIRESTORE_COLLECTIONS.ENROLLMENTS, docId);

  const now = new Date();
  const expiresAt =
    batch.durationDays > 0
      ? new Date(now.getTime() + batch.durationDays * 24 * 60 * 60 * 1000).toISOString()
      : null;

  const enrollmentPayload: Enrollment = {
    id: docId,
    userId,
    batchId: batch.id,
    status: 'active',
    isFree: true,
    enrolledAt: now.toISOString(),
    expiresAt,
    amountPaid: 0,
    courseTitle: batch.title,
    courseThumbnail: batch.thumbnailUrl,
    createdAt: now.toISOString(),
    updatedAt: now.toISOString(),
  };

  try {
    await setDoc(docRef, {
      ...enrollmentPayload,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });
    return enrollmentPayload;
  } catch (err) {
    handleFirestoreError(err, OperationType.CREATE, `${FIRESTORE_COLLECTIONS.ENROLLMENTS}/${docId}`);
    throw err;
  }
}

/**
 * Enrolls a student in a paid course batch after authoritative coupon validation and checkout.
 * Enforces zero-trust: Validates coupon code in Firestore before applying any discount.
 * For paid courses with amount > 0, direct purchase is strictly blocked; Razorpay verified flow must be used.
 */
export async function purchaseBatchWithCoupon(
  userId: string,
  batch: Batch,
  couponCode?: string | null
): Promise<{ success: boolean; enrollment: Enrollment; amountPaid: number }> {
  const db = getFirestoreDb();
  if (!db) throw new Error('Firestore is not configured.');

  let finalPrice = Math.max(0, batch.price);
  let validatedCode: string | null = null;

  if (couponCode && couponCode.trim()) {
    const val = await validateCouponForCourse(couponCode, batch.id, batch.price);
    if (!val.isValid) {
      throw new Error(val.error || 'Invalid or expired coupon code.');
    }
    finalPrice = typeof val.finalPrice === 'number' ? Math.max(0, val.finalPrice) : finalPrice;
    validatedCode = val.coupon?.code || couponCode.trim().toUpperCase();
  }

  // If the course still requires payment, reject client-side enrollment creation
  if (finalPrice > 0) {
    throw new Error('Direct paid enrollment is disabled. Please proceed with Razorpay checkout.');
  }

  const docId = getEnrollmentDocId(userId, batch.id);
  const docRef = doc(db, FIRESTORE_COLLECTIONS.ENROLLMENTS, docId);

  const now = new Date();
  const expiresAt =
    batch.durationDays > 0
      ? new Date(now.getTime() + batch.durationDays * 24 * 60 * 60 * 1000).toISOString()
      : null;

  const enrollmentPayload: Enrollment = {
    id: docId,
    userId,
    batchId: batch.id,
    status: 'active',
    isFree: true,
    source: 'purchase',
    paymentProvider: null,
    paymentId: null,
    orderId: null,
    currency: 'INR',
    enrolledAt: now.toISOString(),
    expiresAt,
    couponCode: validatedCode,
    amountPaid: 0,
    courseTitle: batch.title,
    courseThumbnail: batch.thumbnailUrl,
    createdAt: now.toISOString(),
    updatedAt: now.toISOString(),
  };

  try {
    await setDoc(docRef, {
      ...enrollmentPayload,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });

    // Authoritatively increment redemption count on coupon
    if (validatedCode) {
      try {
        await recordCouponRedemption(validatedCode, userId, batch.id);
      } catch (couponErr) {
        console.warn('[enrollmentService] Could not increment coupon usedCount:', couponErr);
      }
    }

    return {
      success: true,
      enrollment: enrollmentPayload,
      amountPaid: 0,
    };
  } catch (err) {
    handleFirestoreError(err, OperationType.CREATE, `${FIRESTORE_COLLECTIONS.ENROLLMENTS}/${docId}`);
    throw err;
  }
}

/**
 * Retrieves all active enrollments for a given student from Firestore with authoritative server merge.
 */
export async function getStudentActiveEnrollments(userId: string): Promise<Enrollment[]> {
  const mergedMap = new Map<string, Enrollment>();

  // 1. Fetch from client Firestore
  try {
    const db = getFirestoreDb();
    if (db) {
      const q = query(
        collection(db, FIRESTORE_COLLECTIONS.ENROLLMENTS),
        where('userId', '==', userId),
        where('status', '==', 'active')
      );
      const snap = await getDocs(q);

      if (snap && !snap.empty) {
        snap.docs.forEach((d) => {
          const data = d.data();
          const enrollment: Enrollment = {
            id: d.id,
            userId: data.userId,
            batchId: data.batchId,
            status: data.status || 'active',
            isFree: Boolean(data.isFree),
            enrolledAt: data.enrolledAt,
            expiresAt: data.expiresAt || null,
            couponCode: data.couponCode || null,
            amountPaid: data.amountPaid || 0,
            courseTitle: data.courseTitle,
            courseThumbnail: data.courseThumbnail,
            createdAt: data.createdAt,
            updatedAt: data.updatedAt,
          };
          if (enrollment.batchId) {
            mergedMap.set(enrollment.batchId, enrollment);
          }
        });
      }
    }
  } catch (err) {
    console.warn('[enrollmentService] Note: Firestore student enrollments query warning:', err);
  }

  // 2. Fetch server-verified active enrollments as authoritative merge
  try {
    const auth = getFirebaseAuth();
    const idToken = await auth?.currentUser?.getIdToken();
    if (idToken) {
      const serverEnrollments = await getUserActiveEnrollmentsFromApi(idToken);
      if (Array.isArray(serverEnrollments)) {
        serverEnrollments.forEach((e) => {
          if (e && e.batchId && !mergedMap.has(e.batchId)) {
            mergedMap.set(e.batchId, e);
          }
        });
      }
    }
  } catch (srvErr) {
    console.warn('[enrollmentService] Note: Server enrollments fetch warning:', srvErr);
  }

  return Array.from(mergedMap.values());
}

/**
 * Admin: Grant enrollment to any student (for scholarship, offline registration, or testing).
 */
export async function grantStudentEnrollmentAdmin(
  studentUid: string,
  batch: Batch,
  adminUid: string,
  customDurationDays?: number,
  notes?: string
): Promise<Enrollment> {
  const db = getFirestoreDb();
  if (!db) throw new Error('Firestore is not configured.');

  const docId = getEnrollmentDocId(studentUid, batch.id);
  const docRef = doc(db, FIRESTORE_COLLECTIONS.ENROLLMENTS, docId);

  const durationDays = customDurationDays !== undefined ? customDurationDays : batch.durationDays;
  const now = new Date();
  const expiresAt =
    durationDays > 0
      ? new Date(now.getTime() + durationDays * 24 * 60 * 60 * 1000).toISOString()
      : null;

  const payload: Enrollment = {
    id: docId,
    userId: studentUid,
    batchId: batch.id,
    status: 'active',
    isFree: batch.isFree,
    enrolledAt: now.toISOString(),
    expiresAt,
    amountPaid: batch.isFree ? 0 : batch.price,
    courseTitle: batch.title,
    courseThumbnail: batch.thumbnailUrl,
    createdAt: now.toISOString(),
    updatedAt: now.toISOString(),
  };

  try {
    await setDoc(docRef, {
      ...payload,
      adminGrantedBy: adminUid,
      adminNotes: notes || 'Granted via Admin CMS',
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });

    logAdminAudit({
      actorUid: adminUid,
      actorEmail: 'pmgautamjaipur@gmail.com',
      action: 'create',
      resourceType: 'enrollment',
      resourceId: docId,
      resourceName: batch.title,
      details: { studentUid, batchId: batch.id, notes },
    }).catch(() => {});

    return payload;
  } catch (err) {
    handleFirestoreError(err, OperationType.CREATE, `${FIRESTORE_COLLECTIONS.ENROLLMENTS}/${docId}`);
    throw err;
  }
}

/**
 * Admin: Revoke or deactivate student enrollment.
 */
export async function revokeStudentEnrollmentAdmin(
  enrollmentId: string,
  adminUid: string
): Promise<void> {
  const db = getFirestoreDb();
  if (!db) throw new Error('Firestore is not configured.');

  const docRef = doc(db, FIRESTORE_COLLECTIONS.ENROLLMENTS, enrollmentId);

  try {
    await updateDoc(docRef, {
      status: 'revoked',
      revokedBy: adminUid,
      revokedAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });

    logAdminAudit({
      actorUid: adminUid,
      actorEmail: 'pmgautamjaipur@gmail.com',
      action: 'update',
      resourceType: 'enrollment',
      resourceId: enrollmentId,
      resourceName: 'Revoked Access',
      details: { status: 'revoked' },
    }).catch(() => {});
  } catch (err) {
    handleFirestoreError(err, OperationType.UPDATE, `${FIRESTORE_COLLECTIONS.ENROLLMENTS}/${enrollmentId}`);
    throw err;
  }
}

function mapEnrollmentDoc(id: string, data: any): Enrollment {
  return {
    id,
    userId: data.userId,
    batchId: data.batchId,
    status: data.status || 'active',
    isFree: Boolean(data.isFree),
    source: data.source,
    paymentProvider: data.paymentProvider,
    paymentId: data.paymentId,
    orderId: data.orderId,
    enrolledAt: data.enrolledAt,
    expiresAt: data.expiresAt || null,
    couponCode: data.couponCode || null,
    amountPaid: data.amountPaid || 0,
    courseTitle: data.courseTitle,
    courseThumbnail: data.courseThumbnail,
    createdAt: data.createdAt,
    updatedAt: data.updatedAt,
  };
}

/**
 * Admin: Fetch all enrollments across all students and batches.
 */
export async function getAllEnrollmentsAdmin(): Promise<Enrollment[]> {
  const mergedMap = new Map<string, Enrollment>();
  const db = getFirestoreDb();
  const auth = getFirebaseAuth();
  const currentUser = auth?.currentUser;

  if (db && currentUser) {
    try {
      const q = query(collection(db, FIRESTORE_COLLECTIONS.ENROLLMENTS));
      const snap = await getDocs(q);
      snap.docs.forEach((d) => {
        mergedMap.set(d.id, mapEnrollmentDoc(d.id, d.data()));
      });
    } catch (firstErr: any) {
      // If designated admin profile hasn't been synced to role='admin' in Firestore yet, sync and retry
      if (isDesignatedAdminEmail(currentUser.email)) {
        try {
          await ensureUserProfile(currentUser);
          const retrySnap = await getDocs(query(collection(db, FIRESTORE_COLLECTIONS.ENROLLMENTS)));
          retrySnap.docs.forEach((d) => {
            mergedMap.set(d.id, mapEnrollmentDoc(d.id, d.data()));
          });
        } catch {
          // Fallback to user-scoped query if Firebase Console rules restrict collection-wide list
          try {
            const ownQ = query(
              collection(db, FIRESTORE_COLLECTIONS.ENROLLMENTS),
              where('userId', '==', currentUser.uid)
            );
            const ownSnap = await getDocs(ownQ);
            ownSnap.docs.forEach((d) => {
              mergedMap.set(d.id, mapEnrollmentDoc(d.id, d.data()));
            });
          } catch {
            // Handled via server API fallback below
          }
        }
      } else {
        console.warn('[enrollmentService] Notice fetching enrollments:', firstErr?.message || firstErr);
      }
    }
  }

  // Merge authoritative enrollments from backend Admin API
  if (currentUser) {
    try {
      const idToken = await currentUser.getIdToken().catch(() => null);
      if (idToken) {
        const res = await fetchApi('/api/payments/admin-enrollments', {
          headers: { Authorization: `Bearer ${idToken}` },
        });
        if (res.ok) {
          const data = await res.json();
          if (Array.isArray(data.enrollments)) {
            data.enrollments.forEach((e: any) => {
              const id = e.id || getEnrollmentDocId(e.userId, e.batchId);
              if (id && !mergedMap.has(id)) {
                mergedMap.set(id, mapEnrollmentDoc(id, e));
              }
            });
          }
        }
      }
    } catch {
      // Ignore network/API fallback errors
    }
  }

  return Array.from(mergedMap.values()).sort((a, b) => {
    const timeA = new Date(a.enrolledAt || 0).getTime();
    const timeB = new Date(b.enrolledAt || 0).getTime();
    return timeB - timeA;
  });
}

/**
 * Admin: Fetch all enrollments for a course batch.
 */
export async function getEnrollmentsForBatchAdmin(batchId?: string): Promise<Enrollment[]> {
  const all = await getAllEnrollmentsAdmin();
  if (!batchId) return all;
  return all.filter((e) => e.batchId === batchId);
}
