/**
 * Axon Nursing Academy - Firebase Firestore Batch Service
 * Ultra-fast local-first query with background Firestore synchronization.
 */
import {
  collection,
  doc,
  getDoc,
  getDocs,
  query,
  where,
  orderBy,
  onSnapshot,
} from 'firebase/firestore';
import { getFirestoreDb } from '@/src/lib/firebase/firestore';
import { Batch } from '@/src/types/lms.types';
import { fallbackStore } from '@/src/services/fallback/fallbackStore';
import { withTimeout } from '@/src/lib/utils/asyncUtils';
import { fetchApi } from '@/src/services/api';

const BATCHES_COLLECTION = 'batches';

function mapBatchDoc(docSnap: any): Batch {
  const data = typeof docSnap.data === 'function' ? docSnap.data() : docSnap;
  const id = docSnap.id || data.id;
  return {
    id,
    title: data.title || 'Untitled Batch',
    slug: data.slug || id,
    shortDescription: data.shortDescription || '',
    description: data.description || '',
    thumbnailUrl: data.thumbnailUrl || '',
    bannerUrl: data.bannerUrl || '',
    price: typeof data.price === 'number' ? data.price : Number(data.price) || 0,
    originalPrice: typeof data.originalPrice === 'number' ? data.originalPrice : Number(data.originalPrice) || 0,
    durationDays: typeof data.durationDays === 'number' ? data.durationDays : 180,
    duration: data.duration || (typeof data.durationDays === 'number' && data.durationDays > 0 ? `${data.durationDays} Days` : '180 Days'),
    isFree: Boolean(data.isFree),
    isFeatured: Boolean(data.isFeatured),
    isPublished: data.isPublished !== undefined ? Boolean(data.isPublished) : true,
    order: typeof data.order === 'number' ? data.order : Number(data.order) || 0,
    createdAt: data.createdAt,
    updatedAt: data.updatedAt,
  };
}

async function fetchPublishedBatchesFromApi(): Promise<Batch[]> {
  try {
    const res = await fetchApi('/api/catalog/batches');
    if (res.ok) {
      const data = await res.json();
      if (Array.isArray(data.batches)) {
        return data.batches
          .map((b: any) => mapBatchDoc(b))
          .filter((b: Batch) => b.isPublished)
          .sort((a: Batch, b: Batch) => (a.order || 0) - (b.order || 0));
      }
    }
  } catch {
    // Ignore API fallback error
  }
  return [];
}

/**
 * Fetch all published batches ordered by ascending display order.
 */
export async function getPublishedBatches(): Promise<Batch[]> {
  const cached = fallbackStore.getBatches().filter((b) => b.isPublished);
  const timeoutMs = cached.length > 0 ? 4000 : 10000;

  const db = getFirestoreDb();

  try {
    const fetchAllSources = async (): Promise<Batch[]> => {
      const merged = new Map<string, Batch>();

      const [fsBatches, apiBatches] = await Promise.all([
        (async () => {
          if (!db) return [];
          try {
            const batchesRef = collection(db, BATCHES_COLLECTION);
            const q = query(batchesRef, where('isPublished', '==', true));
            const snapshot = await getDocs(q);
            return snapshot.docs.map(mapBatchDoc);
          } catch {
            try {
              const allSnap = await getDocs(collection(db, BATCHES_COLLECTION));
              return allSnap.docs.map(mapBatchDoc).filter((b) => b.isPublished);
            } catch {
              return [];
            }
          }
        })(),
        fetchPublishedBatchesFromApi(),
      ]);

      apiBatches.forEach((b) => merged.set(b.id, b));
      fsBatches.forEach((b) => merged.set(b.id, b));

      const list = Array.from(merged.values()).filter((b) => b.isPublished);
      const sorted = list.sort((a, b) => (a.order || 0) - (b.order || 0));
      fallbackStore.syncBatches(sorted);
      return sorted;
    };

    return await withTimeout(fetchAllSources(), timeoutMs, cached);
  } catch (err: any) {
    console.warn('[batchService] Serving cached batches:', err?.message || err);
    return cached;
  }
}

/**
 * Real-time listener for all published batches.
 * Fires whenever batches are added, edited, or published in Firebase.
 */
export function subscribeToPublishedBatches(
  callback: (batches: Batch[]) => void,
  onError?: (err: any) => void
): () => void {
  const db = getFirestoreDb();
  if (!db) {
    getPublishedBatches().then(callback);
    return () => {};
  }

  // Also kick off full fetch (including API fallback) immediately
  getPublishedBatches().then((list) => {
    if (list.length > 0) callback(list);
  });

  try {
    const batchesRef = collection(db, BATCHES_COLLECTION);
    const q = query(batchesRef, where('isPublished', '==', true));

    return onSnapshot(
      q,
      (snapshot) => {
        if (!snapshot || snapshot.empty) {
          fetchPublishedBatchesFromApi().then((apiList) => {
            fallbackStore.syncBatches(apiList);
            callback(apiList);
          });
          return;
        }
        const batches: Batch[] = snapshot.docs.map(mapBatchDoc);
        const sorted = batches.sort((a, b) => (a.order || 0) - (b.order || 0));
        fallbackStore.syncBatches(sorted);
        callback(sorted);
      },
      (err) => {
        console.warn('[batchService] Realtime subscription notice:', err?.message || err);
        fetchPublishedBatchesFromApi().then((apiList) => {
          if (apiList.length > 0) {
            callback(apiList);
          } else {
            callback(fallbackStore.getBatches().filter((b) => b.isPublished));
          }
        });
        if (onError) onError(err);
      }
    );
  } catch (err: any) {
    console.warn('[batchService] Realtime listener failed to initialize:', err);
    callback(fallbackStore.getBatches().filter((b) => b.isPublished));
    return () => {};
  }
}

/**
 * Fetch featured published batches for Home screen.
 */
export async function getFeaturedBatches(): Promise<Batch[]> {
  const allPublished = await getPublishedBatches();
  const featured = allPublished.filter((b) => b.isFeatured);
  return featured.length > 0 ? featured : allPublished;
}

/**
 * Fetch a single batch by ID. Returns null if not found or unpublished.
 */
export async function getBatchById(batchId: string): Promise<Batch | null> {
  const cached = fallbackStore.getBatchById(batchId);
  const timeoutMs = cached ? 4000 : 10000;

  const db = getFirestoreDb();
  if (!batchId) {
    return cached;
  }

  try {
    const fetchFromFirestore = async () => {
      if (db) {
        try {
          const docRef = doc(db, BATCHES_COLLECTION, batchId);
          const docSnap = await getDoc(docRef);

          if (docSnap.exists()) {
            const data = docSnap.data();
            if (!data.isPublished) {
              return null;
            }
            const batch = mapBatchDoc(docSnap);
            fallbackStore.saveBatch(batch);
            return batch;
          }
        } catch {
          // Fallback to API list below
        }
      }

      const apiBatches = await fetchPublishedBatchesFromApi();
      const found = apiBatches.find((b) => b.id === batchId || b.slug === batchId);
      if (found) {
        fallbackStore.saveBatch(found);
        return found;
      }

      return cached;
    };

    return await withTimeout(fetchFromFirestore(), timeoutMs, cached);
  } catch (err: any) {
    console.warn('[batchService] Serving cached batch by ID:', err?.message || err);
    return cached;
  }
}
