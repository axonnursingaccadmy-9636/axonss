/**
 * Axon Nursing Academy - Firebase Firestore Admin Batch Service
 * Complete CRUD operations and publishing control for Course Batches.
 */
import {
  collection,
  doc,
  getDoc,
  getDocs,
  setDoc,
  updateDoc,
  deleteDoc,
  query,
  where,
  orderBy,
  onSnapshot,
  serverTimestamp,
} from 'firebase/firestore';
import { getFirestoreDb, OperationType, handleFirestoreError } from '@/src/lib/firebase/firestore';
import { getFirebaseAuth } from '@/src/lib/firebase/auth';
import { ensureUserProfile } from './userService';
import { Batch } from '@/src/types/lms.types';
import { logAdminAction } from './auditService';
import { fallbackStore } from '@/src/services/fallback/fallbackStore';
import { withTimeout } from '@/src/lib/utils/asyncUtils';
import { fetchApi } from '@/src/services/api';

// Tracks batches created/updated in the last 12 seconds so onSnapshot race conditions never wipe out a newly created batch
const recentlySavedBatches = new Map<string, { batch: Batch; savedAt: number }>();

function markBatchRecentlySaved(batch: Batch): void {
  recentlySavedBatches.set(batch.id, { batch, savedAt: Date.now() });
}

function mergeWithRecentlySaved(remoteBatches: Batch[]): Batch[] {
  const now = Date.now();
  const map = new Map<string, Batch>();
  for (const b of remoteBatches) {
    if (b && b.id) map.set(b.id, b);
  }
  for (const [id, entry] of recentlySavedBatches.entries()) {
    if (now - entry.savedAt < 12000) {
      if (!map.has(id)) {
        map.set(id, entry.batch);
      }
    } else {
      recentlySavedBatches.delete(id);
    }
  }
  return Array.from(map.values()).sort((a, b) => (a.order || 0) - (b.order || 0));
}

async function syncBatchToBackend(action: 'upsert' | 'delete', batchData: any): Promise<boolean> {
  try {
    const auth = getFirebaseAuth();
    const token = await auth?.currentUser?.getIdToken().catch(() => null);
    const headers: Record<string, string> = { 'Content-Type': 'application/json' };
    if (token) headers['Authorization'] = `Bearer ${token}`;
    const res = await fetchApi('/api/catalog/batches/sync', {
      method: 'POST',
      headers,
      body: JSON.stringify({ action, batch: batchData }),
    });
    return res.ok;
  } catch {
    return false;
  }
}

const BATCHES_COLLECTION = 'batches';

export interface BatchFormData {
  title: string;
  slug?: string;
  shortDescription: string;
  description: string;
  thumbnailUrl: string;
  bannerUrl: string;
  price: number;
  originalPrice: number;
  durationDays: number;
  duration?: string;
  isFree: boolean;
  isFeatured: boolean;
  isPublished: boolean;
  order: number;
}

/**
 * Generate URL-friendly slug from title
 */
export function generateSlug(text: string): string {
  return text
    .toLowerCase()
    .trim()
    .replace(/[^\w\s-]/g, '')
    .replace(/[\s_-]+/g, '-')
    .replace(/^-+|-+$/g, '');
}

/**
 * Fetch all batches (both published & drafts) for Admin CMS.
 */
export async function getAllBatchesAdmin(): Promise<Batch[]> {
  const db = getFirestoreDb();
  if (!db) return fallbackStore.getBatches();

  try {
    const batchesRef = collection(db, BATCHES_COLLECTION);
    const snapshot = await getDocs(batchesRef);

    const batches: Batch[] = snapshot.docs.map((docSnap) => {
      const data = docSnap.data();
      return {
        id: docSnap.id,
        title: data.title || 'Untitled Batch',
        slug: data.slug || docSnap.id,
        shortDescription: data.shortDescription || '',
        description: data.description || '',
        thumbnailUrl: data.thumbnailUrl || '',
        bannerUrl: data.bannerUrl || '',
        price: typeof data.price === 'number' ? data.price : 0,
        originalPrice: typeof data.originalPrice === 'number' ? data.originalPrice : 0,
        durationDays: typeof data.durationDays === 'number' ? data.durationDays : 180,
        duration: data.duration || (typeof data.durationDays === 'number' && data.durationDays > 0 ? `${data.durationDays} Days` : '180 Days'),
        isFree: Boolean(data.isFree),
        isFeatured: Boolean(data.isFeatured),
        isPublished: Boolean(data.isPublished),
        order: typeof data.order === 'number' ? data.order : 0,
        createdAt: data.createdAt,
        updatedAt: data.updatedAt,
      };
    });

    const sorted = mergeWithRecentlySaved(batches);
    fallbackStore.syncBatches(sorted);
    return sorted;
  } catch (err: any) {
    console.warn('[AdminBatchService] Returning cached batches:', err?.message || err);
    return fallbackStore.getBatches();
  }
}

/**
 * Real-time listener for all Batches in Admin CMS.
 * Synchronizes with Firestore live updates and updates local state.
 */
export function subscribeToBatchesAdmin(
  callback: (batches: Batch[]) => void,
  onError?: (err: any) => void
): () => void {
  const db = getFirestoreDb();
  if (!db) {
    callback(fallbackStore.getBatches());
    return () => {};
  }

  try {
    const batchesRef = collection(db, BATCHES_COLLECTION);
    return onSnapshot(
      batchesRef,
      (snapshot) => {
        const batches: Batch[] = snapshot.docs.map((docSnap) => {
          const data = docSnap.data();
          return {
            id: docSnap.id,
            title: data.title || 'Untitled Batch',
            slug: data.slug || docSnap.id,
            shortDescription: data.shortDescription || '',
            description: data.description || '',
            thumbnailUrl: data.thumbnailUrl || '',
            bannerUrl: data.bannerUrl || '',
            price: typeof data.price === 'number' ? data.price : 0,
            originalPrice: typeof data.originalPrice === 'number' ? data.originalPrice : 0,
            durationDays: typeof data.durationDays === 'number' ? data.durationDays : 180,
            duration:
              data.duration ||
              (typeof data.durationDays === 'number' && data.durationDays > 0
                ? `${data.durationDays} Days`
                : '180 Days'),
            isFree: Boolean(data.isFree),
            isFeatured: Boolean(data.isFeatured),
            isPublished: Boolean(data.isPublished),
            order: typeof data.order === 'number' ? data.order : 0,
            createdAt: data.createdAt,
            updatedAt: data.updatedAt,
          };
        });

        const sorted = mergeWithRecentlySaved(batches);
        fallbackStore.syncBatches(sorted);
        callback(sorted);
      },
      (err) => {
        console.warn('[AdminBatchService] Realtime listener notice:', err);
        callback(fallbackStore.getBatches());
        if (onError) onError(err);
      }
    );
  } catch (err: any) {
    console.warn('[AdminBatchService] Failed to establish realtime listener:', err);
    callback(fallbackStore.getBatches());
    return () => {};
  }
}

/**
 * Create a new Batch in Firestore.
 */
export async function createBatch(
  data: BatchFormData,
  actorUid: string,
  actorEmail?: string
): Promise<Batch> {
  const cleanSlug = generateSlug(data.title) || 'batch';
  const slug = data.slug?.trim() || cleanSlug;
  const batchId = slug || `batch_${Date.now()}`;

  const price = Math.max(0, Number(data.price) || 0);
  const originalPrice = Math.max(0, Number(data.originalPrice) || 0);
  const durationDays = Math.max(0, Number(data.durationDays) || 180);
  const duration = data.duration?.trim() || (durationDays > 0 ? `${durationDays} Days` : '180 Days');

  const payload: Batch = {
    id: batchId,
    title: data.title.trim(),
    slug: slug || batchId,
    shortDescription: data.shortDescription.trim(),
    description: data.description.trim(),
    thumbnailUrl: data.thumbnailUrl.trim() || 'https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?w=800&auto=format&fit=crop&q=80',
    bannerUrl: data.bannerUrl.trim() || 'https://images.unsplash.com/photo-1584515979956-d9f6e5d09982?w=1200&auto=format&fit=crop&q=80',
    price,
    originalPrice,
    durationDays,
    duration,
    isFree: Boolean(data.isFree),
    isFeatured: Boolean(data.isFeatured),
    isPublished: Boolean(data.isPublished),
    order: Number(data.order) || 0,
  };

  const db = getFirestoreDb();
  if (!db) {
    throw new Error('Firestore is not configured or unavailable. Batch creation requires an active database.');
  }

  // Immediate local cache update + recent-save protection
  markBatchRecentlySaved(payload);
  fallbackStore.saveBatch(payload);

  // Run backend Admin SDK persistence and client Firestore persistence in parallel
  const backendPromise = syncBatchToBackend('upsert', payload);

  let clientSaved = false;
  try {
    const docRef = doc(db, BATCHES_COLLECTION, batchId);
    await withTimeout(
      setDoc(docRef, {
        ...payload,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      }),
      6000,
      'Client Firestore write timed out'
    );
    clientSaved = true;

    logAdminAction({
      actorUid,
      actorEmail,
      action: 'BATCH_CREATED',
      resourceType: 'batch',
      resourceId: batchId,
      resourceTitle: data.title,
      details: { isPublished: data.isPublished, price: data.price },
    }).catch(() => {});
  } catch (err: any) {
    console.warn('[AdminBatchService] Client Firestore create notice, relying on backend Admin SDK:', err?.message || err);
  }

  const backendSaved = await backendPromise;
  if (!clientSaved && !backendSaved) {
    throw new Error('Failed to save batch to Firestore. Please try again.');
  }

  return payload;
}

/**
 * Update an existing batch in Firestore.
 */
export async function updateBatch(
  batchId: string,
  data: Partial<BatchFormData>,
  actorUid: string,
  actorEmail?: string
): Promise<void> {
  const sanitized: Partial<BatchFormData> = { ...data };
  if (sanitized.price !== undefined) sanitized.price = Math.max(0, Number(sanitized.price) || 0);
  if (sanitized.originalPrice !== undefined) sanitized.originalPrice = Math.max(0, Number(sanitized.originalPrice) || 0);
  if (sanitized.durationDays !== undefined) sanitized.durationDays = Math.max(0, Number(sanitized.durationDays) || 0);

  const db = getFirestoreDb();
  if (!db) {
    throw new Error('Firestore is not configured or unavailable. Batch update requires an active database.');
  }

  const existing = fallbackStore.getBatchById(batchId);
  const mergedBatch = {
    ...(existing || {}),
    ...sanitized,
    id: batchId,
  } as Batch;
  markBatchRecentlySaved(mergedBatch);
  fallbackStore.saveBatch(mergedBatch);
  const backendPromise = syncBatchToBackend('upsert', mergedBatch);

  try {
    const docRef = doc(db, BATCHES_COLLECTION, batchId);
    const updatePayload: Record<string, any> = {
      ...sanitized,
      updatedAt: serverTimestamp(),
    };

    if (data.title && !data.slug) {
      updatePayload.slug = generateSlug(data.title);
    }

    await withTimeout(setDoc(docRef, updatePayload, { merge: true }), 6000, 'Client Firestore update timed out');

    logAdminAction({
      actorUid,
      actorEmail,
      action: 'BATCH_UPDATED',
      resourceType: 'batch',
      resourceId: batchId,
      resourceTitle: data.title || batchId,
      details: { changedFields: Object.keys(data) },
    }).catch(() => {});
  } catch (err: any) {
    console.warn('[AdminBatchService] Firestore update notice (saved via backend):', err?.message || err);
  }

  await backendPromise;
}

/**
 * Toggle publish status of a batch.
 */
export async function toggleBatchPublish(
  batchId: string,
  newPublishedState: boolean,
  batchTitle: string,
  actorUid: string,
  actorEmail?: string
): Promise<void> {
  const db = getFirestoreDb();
  if (!db) {
    throw new Error('Firestore is not configured or unavailable.');
  }

  const existing = fallbackStore.getBatchById(batchId);
  if (existing) {
    const updated = { ...existing, isPublished: newPublishedState };
    fallbackStore.saveBatch(updated);
    syncBatchToBackend('upsert', updated);
  } else {
    syncBatchToBackend('upsert', { id: batchId, title: batchTitle, isPublished: newPublishedState });
  }

  try {
    const auth = getFirebaseAuth();
    if (auth?.currentUser) {
      await ensureUserProfile(auth.currentUser).catch(() => {});
    }
    const docRef = doc(db, BATCHES_COLLECTION, batchId);
    await setDoc(docRef, {
      isPublished: newPublishedState,
      updatedAt: serverTimestamp(),
    }, { merge: true });

    logAdminAction({
      actorUid,
      actorEmail,
      action: newPublishedState ? 'BATCH_PUBLISHED' : 'BATCH_UNPUBLISHED',
      resourceType: 'batch',
      resourceId: batchId,
      resourceTitle: batchTitle,
      details: { isPublished: newPublishedState },
    }).catch(() => {});
  } catch (err: any) {
    console.warn('[AdminBatchService] Firestore toggle notice (saved locally):', err?.message || err);
  }
}

/**
 * Delete a batch from Firestore and cascade delete all child items.
 */
export async function deleteBatch(
  batchId: string,
  batchTitle: string,
  actorUid: string,
  actorEmail?: string
): Promise<void> {
  const db = getFirestoreDb();
  if (!db) {
    throw new Error('Firestore is not configured or unavailable.');
  }

  // 1. Delete from local cache store and cascade in memory
  recentlySavedBatches.delete(batchId);
  fallbackStore.deleteBatch(batchId);
  const backendPromise = syncBatchToBackend('delete', { id: batchId });

  try {
    const auth = getFirebaseAuth();
    if (auth?.currentUser) {
      await ensureUserProfile(auth.currentUser).catch(() => {});
    }
    // 2. Delete primary batch document from Firestore
    const docRef = doc(db, BATCHES_COLLECTION, batchId);
    await deleteDoc(docRef);

    // 3. Cascade delete associated subjects, chapters, classes, and pdf_notes from Firestore
    try {
      // Find all subjects belonging to this batch
      const subjectsRef = collection(db, 'subjects');
      const subjectsSnap = await getDocs(query(subjectsRef, where('batchId', '==', batchId)));
      const subjectIds: string[] = [];
      for (const sDoc of subjectsSnap.docs) {
        subjectIds.push(sDoc.id);
        await deleteDoc(sDoc.ref);
      }

      // Find and delete all chapters belonging to this batch or linked subjects
      const chaptersRef = collection(db, 'chapters');
      const chaptersSnap = await getDocs(chaptersRef);
      const chapterIds: string[] = [];
      for (const cDoc of chaptersSnap.docs) {
        const cData = cDoc.data();
        if (cData.batchId === batchId || (cData.subjectId && subjectIds.includes(cData.subjectId))) {
          chapterIds.push(cDoc.id);
          await deleteDoc(cDoc.ref);
        }
      }

      // Find and delete all classes belonging to this batch, subjects, or chapters
      const classesRef = collection(db, 'classes');
      const classesSnap = await getDocs(classesRef);
      for (const clDoc of classesSnap.docs) {
        const clData = clDoc.data();
        if (
          clData.batchId === batchId ||
          (clData.chapterId && chapterIds.includes(clData.chapterId)) ||
          (clData.subjectId && subjectIds.includes(clData.subjectId))
        ) {
          await deleteDoc(clDoc.ref);
        }
      }

      // Find and delete all pdf notes
      const notesRef = collection(db, 'pdf_notes');
      const notesSnap = await getDocs(notesRef);
      for (const nDoc of notesSnap.docs) {
        const nData = nDoc.data();
        if (nData.batchId === batchId) {
          await deleteDoc(nDoc.ref);
        }
      }
    } catch (cleanupErr) {
      console.warn('[AdminBatchService] Cascade cleanup notice:', cleanupErr);
    }

    logAdminAction({
      actorUid,
      actorEmail,
      action: 'BATCH_DELETED',
      resourceType: 'batch',
      resourceId: batchId,
      resourceTitle: batchTitle,
    }).catch(() => {});
  } catch (err: any) {
    console.warn('[AdminBatchService] Firestore delete notice (deleted locally):', err?.message || err);
  }
}

/**
 * Pulls all batches, subjects, chapters, classes, and PDF notes from Firestore
 * using the authenticated Super Admin session and mirrors them to the public Cloud Run catalog
 * so all student phones can view them even if Firebase Console rules restrict unauthenticated reads.
 */
export async function syncAllFirestoreCurriculumAsAdmin(): Promise<void> {
  const db = getFirestoreDb();
  if (!db) return;

  try {
    // Pull authoritative state from Firestore and sync to fallbackStore & Cloud Run server
    const [batchesSnap, subjectsSnap, chaptersSnap, classesSnap, pdfNotesSnap] = await Promise.all([
      getDocs(collection(db, 'batches')).catch(() => null),
      getDocs(collection(db, 'subjects')).catch(() => null),
      getDocs(collection(db, 'chapters')).catch(() => null),
      getDocs(collection(db, 'classes')).catch(() => null),
      getDocs(collection(db, 'pdfNotes')).catch(() => null),
    ]);

    if (batchesSnap) {
      const fsBatches: Batch[] = batchesSnap.docs.map((docSnap) => {
        const data = docSnap.data();
        return {
          id: docSnap.id,
          title: data.title || 'Untitled Batch',
          slug: data.slug || docSnap.id,
          shortDescription: data.shortDescription || '',
          description: data.description || '',
          thumbnailUrl: data.thumbnailUrl || '',
          bannerUrl: data.bannerUrl || '',
          price: typeof data.price === 'number' ? data.price : Number(data.price) || 0,
          originalPrice: typeof data.originalPrice === 'number' ? data.originalPrice : Number(data.originalPrice) || 0,
          durationDays: typeof data.durationDays === 'number' ? data.durationDays : 180,
          duration:
            data.duration ||
            (typeof data.durationDays === 'number' && data.durationDays > 0
              ? `${data.durationDays} Days`
              : '180 Days'),
          isFree: Boolean(data.isFree),
          isFeatured: Boolean(data.isFeatured),
          isPublished: data.isPublished !== undefined ? Boolean(data.isPublished) : true,
          order: typeof data.order === 'number' ? data.order : 0,
          createdAt: data.createdAt,
          updatedAt: data.updatedAt,
        };
      });
      fallbackStore.syncBatches(fsBatches);
    }

    if (subjectsSnap) {
      const fsSubjects = subjectsSnap.docs.map((d) => ({ id: d.id, ...(d.data() as any) }));
      fallbackStore.syncSubjects(fsSubjects);
    }

    if (chaptersSnap) {
      const fsChapters = chaptersSnap.docs.map((d) => ({ id: d.id, ...(d.data() as any) }));
      fallbackStore.syncChapters(fsChapters);
    }

    if (classesSnap) {
      const fsClasses = classesSnap.docs.map((d) => ({ id: d.id, ...(d.data() as any) }));
      fallbackStore.syncClasses(fsClasses);
    }

    if (pdfNotesSnap) {
      const fsNotes = pdfNotesSnap.docs.map((d) => ({ id: d.id, ...(d.data() as any) }));
      fallbackStore.syncPdfNotes(fsNotes);
    }

    await fetchApi('/api/catalog/state', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        replaceAll: true,
        batches: fallbackStore.getBatches(),
        subjects: fallbackStore.getSubjects(),
        chapters: fallbackStore.getChapters(),
        classes: fallbackStore.getClasses(),
        pdfNotes: fallbackStore.getPdfNotes(),
      }),
    }).catch(() => {});
  } catch (err) {
    console.warn('[AdminBatchService] Background curriculum mirror notice:', err);
  }
}
