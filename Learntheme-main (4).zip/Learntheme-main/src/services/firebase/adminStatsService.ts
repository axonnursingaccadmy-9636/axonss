/**
 * Axon Nursing Academy - Firebase Firestore Admin Statistics Service
 * Computes live metrics for LMS hierarchy and users.
 */
import {
  collection,
  getDocs,
  onSnapshot,
} from 'firebase/firestore';
import { getFirestoreDb } from '@/src/lib/firebase/firestore';
import { fallbackStore } from '@/src/services/fallback/fallbackStore';

export interface AdminDashboardMetrics {
  totalBatches: number;
  publishedBatches: number;
  draftBatches: number;
  totalSubjects: number;
  totalChapters: number;
  totalClasses: number;
  freeClasses: number;
  totalStudents: number;
  totalAdmins: number;
  totalEnrollments: number;
  totalPaidPurchases: number;
  totalRevenue: number;
}

/**
 * Fetch real aggregate statistics across Firestore collections for Admin Dashboard.
 */
export async function getAdminDashboardMetrics(): Promise<AdminDashboardMetrics> {
  const db = getFirestoreDb();
  if (!db) {
    const batches = fallbackStore.getBatches();
    const subjects = fallbackStore.getSubjects();
    const chapters = fallbackStore.getChapters();
    const classes = fallbackStore.getClasses();
    return {
      totalBatches: batches.length,
      publishedBatches: batches.filter((b) => b.isPublished).length,
      draftBatches: batches.filter((b) => !b.isPublished).length,
      totalSubjects: subjects.length,
      totalChapters: chapters.length,
      totalClasses: classes.length,
      freeClasses: classes.filter((c) => c.isFree).length,
      totalStudents: 0,
      totalAdmins: 1,
      totalEnrollments: 0,
      totalPaidPurchases: 0,
      totalRevenue: 0,
    };
  }

  try {
    const [batchesSnap, subjectsSnap, chaptersSnap, classesSnap, usersSnap, enrollmentsSnap, paymentsSnap] = await Promise.all([
      getDocs(collection(db, 'batches')).catch(() => ({ docs: [], size: 0 })),
      getDocs(collection(db, 'subjects')).catch(() => ({ docs: [], size: 0 })),
      getDocs(collection(db, 'chapters')).catch(() => ({ docs: [], size: 0 })),
      getDocs(collection(db, 'classes')).catch(() => ({ docs: [], size: 0 })),
      getDocs(collection(db, 'users')).catch(() => ({ docs: [], size: 0 })),
      getDocs(collection(db, 'enrollments')).catch(() => ({ docs: [], size: 0 })),
      getDocs(collection(db, 'payments')).catch(() => ({ docs: [], size: 0 })),
    ]);

    let publishedBatches = 0;
    let draftBatches = 0;
    batchesSnap.docs.forEach((d) => {
      if (d.data().isPublished) publishedBatches++;
      else draftBatches++;
    });

    let freeClasses = 0;
    classesSnap.docs.forEach((d) => {
      if (d.data().isFree) freeClasses++;
    });

    let totalStudents = 0;
    let totalAdmins = 0;
    usersSnap.docs.forEach((d) => {
      if (d.data().role === 'admin') totalAdmins++;
      else totalStudents++;
    });

    let totalPaidPurchases = 0;
    let totalRevenue = 0;
    paymentsSnap.docs.forEach((d) => {
      const p = d.data();
      if (p.status === 'paid') {
        totalPaidPurchases++;
        totalRevenue += (p.amount || 0);
      }
    });

    return {
      totalBatches: batchesSnap.size,
      publishedBatches,
      draftBatches,
      totalSubjects: subjectsSnap.size,
      totalChapters: chaptersSnap.size,
      totalClasses: classesSnap.size,
      freeClasses,
      totalStudents,
      totalAdmins,
      totalEnrollments: enrollmentsSnap.size,
      totalPaidPurchases,
      totalRevenue,
    };
  } catch (err) {
    console.warn('[adminStatsService] Could not aggregate metrics:', err);
    const batches = fallbackStore.getBatches();
    const subjects = fallbackStore.getSubjects();
    const chapters = fallbackStore.getChapters();
    const classes = fallbackStore.getClasses();
    return {
      totalBatches: batches.length,
      publishedBatches: batches.filter((b) => b.isPublished).length,
      draftBatches: batches.filter((b) => !b.isPublished).length,
      totalSubjects: subjects.length,
      totalChapters: chapters.length,
      totalClasses: classes.length,
      freeClasses: classes.filter((c) => c.isFree).length,
      totalStudents: 0,
      totalAdmins: 1,
      totalEnrollments: 0,
      totalPaidPurchases: 0,
      totalRevenue: 0,
    };
  }
}

/**
 * Real-time listener for Admin Dashboard Metrics.
 * Automatically pushes new aggregate numbers whenever collections change in Firestore.
 */
export function subscribeToAdminMetrics(
  callback: (metrics: AdminDashboardMetrics) => void,
  onError?: (err: any) => void
): () => void {
  const db = getFirestoreDb();
  if (!db) {
    const batches = fallbackStore.getBatches();
    const subjects = fallbackStore.getSubjects();
    const chapters = fallbackStore.getChapters();
    const classes = fallbackStore.getClasses();
    callback({
      totalBatches: batches.length,
      publishedBatches: batches.filter((b) => b.isPublished).length,
      draftBatches: batches.filter((b) => !b.isPublished).length,
      totalSubjects: subjects.length,
      totalChapters: chapters.length,
      totalClasses: classes.length,
      freeClasses: classes.filter((c) => c.isFree).length,
      totalStudents: 0,
      totalAdmins: 1,
      totalEnrollments: 0,
      totalPaidPurchases: 0,
      totalRevenue: 0,
    });
    return () => {};
  }

  let batchesDocs: any[] = [];
  let subjectsDocs: any[] = [];
  let chaptersDocs: any[] = [];
  let classesDocs: any[] = [];
  let usersDocs: any[] = [];
  let enrollmentsDocs: any[] = [];
  let paymentsDocs: any[] = [];

  const emit = () => {
    let publishedBatches = 0;
    let draftBatches = 0;
    batchesDocs.forEach((d) => {
      if (d.data().isPublished) publishedBatches++;
      else draftBatches++;
    });

    let freeClasses = 0;
    classesDocs.forEach((d) => {
      if (d.data().isFree) freeClasses++;
    });

    let totalStudents = 0;
    let totalAdmins = 0;
    usersDocs.forEach((d) => {
      if (d.data().role === 'admin') totalAdmins++;
      else totalStudents++;
    });

    let totalPaidPurchases = 0;
    let totalRevenue = 0;
    paymentsDocs.forEach((d) => {
      const p = d.data();
      if (p.status === 'paid') {
        totalPaidPurchases++;
        totalRevenue += (p.amount || 0);
      }
    });

    callback({
      totalBatches: batchesDocs.length,
      publishedBatches,
      draftBatches,
      totalSubjects: subjectsDocs.length,
      totalChapters: chaptersDocs.length,
      totalClasses: classesDocs.length,
      freeClasses,
      totalStudents,
      totalAdmins,
      totalEnrollments: enrollmentsDocs.length,
      totalPaidPurchases,
      totalRevenue,
    });
  };

  try {
    const unsubs = [
      onSnapshot(
        collection(db, 'batches'),
        (snap) => {
          batchesDocs = snap.docs;
          emit();
        },
        (err) => onError?.(err)
      ),
      onSnapshot(
        collection(db, 'subjects'),
        (snap) => {
          subjectsDocs = snap.docs;
          emit();
        },
        (err) => onError?.(err)
      ),
      onSnapshot(
        collection(db, 'chapters'),
        (snap) => {
          chaptersDocs = snap.docs;
          emit();
        },
        (err) => onError?.(err)
      ),
      onSnapshot(
        collection(db, 'classes'),
        (snap) => {
          classesDocs = snap.docs;
          emit();
        },
        (err) => onError?.(err)
      ),
      onSnapshot(
        collection(db, 'users'),
        (snap) => {
          usersDocs = snap.docs;
          emit();
        },
        (err) => onError?.(err)
      ),
      onSnapshot(
        collection(db, 'enrollments'),
        (snap) => {
          enrollmentsDocs = snap.docs;
          emit();
        },
        (err) => onError?.(err)
      ),
      onSnapshot(
        collection(db, 'payments'),
        (snap) => {
          paymentsDocs = snap.docs;
          emit();
        },
        (err) => onError?.(err)
      ),
    ];

    return () => {
      unsubs.forEach((u) => u());
    };
  } catch (err: any) {
    console.warn('[adminStatsService] Realtime subscription error:', err);
    return () => {};
  }
}
