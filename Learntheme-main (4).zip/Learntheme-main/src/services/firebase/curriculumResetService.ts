/**
 * Axon Nursing Academy - Curriculum Clean Slate & Purge Service
 * Deletes all courses, subjects, chapters, unit classes, notes, and tests
 * from Firebase Firestore and local/fallback storage so the admin can rebuild fresh.
 */
import {
  collection,
  doc,
  getDocs,
  deleteDoc,
  writeBatch,
} from 'firebase/firestore';
import { getAuth } from 'firebase/auth';
import { getFirestoreDb } from '@/src/lib/firebase/firestore';
import { fallbackStore } from '@/src/services/fallback/fallbackStore';
import { logAdminAction } from './auditService';

export interface PurgeResult {
  success: boolean;
  message: string;
  deletedCounts: {
    batches: number;
    subjects: number;
    chapters: number;
    classes: number;
    notes: number;
    tests: number;
    questions: number;
  };
  totalDeleted: number;
}

export async function deleteAllCurriculumFromFirestoreAndLocal(
  actorUid?: string,
  actorEmail?: string
): Promise<PurgeResult> {
  const counts = {
    batches: 0,
    subjects: 0,
    chapters: 0,
    classes: 0,
    notes: 0,
    tests: 0,
    questions: 0,
  };

  // 1. Wipe local store and browser storage immediately
  fallbackStore.clearAllCurriculum();

  // 2. Call backend server-authoritative purge endpoint
  try {
    const auth = getAuth();
    const token = auth.currentUser ? await auth.currentUser.getIdToken().catch(() => null) : null;
    await fetch('/api/admin/purge-all-data', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...(token ? { Authorization: `Bearer ${token}` } : {}),
      },
    }).catch(() => {});
  } catch (apiErr) {
    console.warn('[curriculumResetService] Notice on API purge:', apiErr);
  }

  const db = getFirestoreDb();
  if (!db) {
    return {
      success: true,
      message: 'All local, cached, and offline curriculum deleted cleanly. (Firestore client offline)',
      deletedCounts: counts,
      totalDeleted: 0,
    };
  }

  // Explicit targeted delete of known legacy demo IDs
  const explicitLegacyDocs = [
    { coll: 'batches', id: 'shikhar-batch-norcet-2026' },
    { coll: 'batches', id: 'nclex-rn-international-mastery' },
    { coll: 'batches', id: 'nursing-foundation-free-starter' },
    { coll: 'courses', id: 'shikhar-batch-norcet-2026' },
    { coll: 'courses', id: 'nclex-rn-international-mastery' },
    { coll: 'courses', id: 'nursing-foundation-free-starter' },
    { coll: 'subjects', id: 'sub-foundation' },
    { coll: 'subjects', id: 'sub-medsurg' },
    { coll: 'subjects', id: 'sub-pharmacology' },
    { coll: 'subjects', id: 'sub-obg-pediatrics' },
    { coll: 'chapters', id: 'chap-cardiovascular' },
    { coll: 'chapters', id: 'chap-respiratory' },
    { coll: 'chapters', id: 'chap-fluid-electrolytes' },
    { coll: 'chapters', id: 'chap-autonomic-nervous' },
    { coll: 'chapters', id: 'chap-antibiotics' },
    { coll: 'chapters', id: 'chap-maternal-health' },
    { coll: 'chapters', id: 'chap-ecg-rhythm' },
    { coll: 'classes', id: 'cls-cardio-01' },
    { coll: 'classes', id: 'cls-cardio-02' },
    { coll: 'classes', id: 'cls-resp-01' },
    { coll: 'classes', id: 'cls-resp-02' },
    { coll: 'classes', id: 'cls-fluid-01' },
    { coll: 'classes', id: 'cls-ecg-master' },
    { coll: 'classes', id: 'cls-abg-analysis' },
    { coll: 'pdf_notes', id: 'pdf-cardio-01' },
    { coll: 'pdf_notes', id: 'pdf-respiratory-01' },
    { coll: 'pdf_notes', id: 'pdf-ecg-free-01' },
    { coll: 'pdfNotes', id: 'pdf-cardio-01' },
    { coll: 'pdfNotes', id: 'pdf-respiratory-01' },
    { coll: 'pdfNotes', id: 'pdf-ecg-free-01' },
    { coll: 'weeklyWarriorTests', id: 'ww-norcet-week-01' },
    { coll: 'weeklyWarriorTests', id: 'ww-norcet-week-02' },
    { coll: 'weeklyWarriorQuestions', id: 'wwq-cardio-01' },
    { coll: 'weeklyWarriorQuestions', id: 'wwq-cardio-02' },
    { coll: 'weeklyWarriorQuestions', id: 'wwq-cardio-03' },
    { coll: 'weeklyWarriorQuestions', id: 'wwq-resp-01' },
    { coll: 'weeklyWarriorQuestions', id: 'wwq-resp-02' },
    { coll: 'unitTests', id: 'ut-pharm-kinetics-01' },
    { coll: 'unitTests', id: 'ut-cardio-mi-01' },
    { coll: 'unitTestQuestions', id: 'utq-pharm-01' },
    { coll: 'unitTestQuestions', id: 'utq-pharm-02' },
    { coll: 'unitTestQuestions', id: 'utq-pharm-03' },
  ];

  for (const item of explicitLegacyDocs) {
    try {
      await deleteDoc(doc(db, item.coll, item.id));
    } catch {
      // document may not exist, safe to ignore
    }
  }

  // 3. Collections to completely purge
  const curriculumCollections = [
    { name: 'batches', key: 'batches' as const },
    { name: 'courses', key: 'batches' as const },
    { name: 'subjects', key: 'subjects' as const },
    { name: 'chapters', key: 'chapters' as const },
    { name: 'classes', key: 'classes' as const },
    { name: 'lectures', key: 'classes' as const },
    { name: 'pdf_notes', key: 'notes' as const },
    { name: 'pdfNotes', key: 'notes' as const },
    { name: 'weeklyWarriorTests', key: 'tests' as const },
    { name: 'weeklyWarriorQuestions', key: 'questions' as const },
    { name: 'weeklyWarriorAttempts', key: 'tests' as const },
    { name: 'weeklyWarriorResults', key: 'tests' as const },
    { name: 'unitTests', key: 'tests' as const },
    { name: 'unitTestQuestions', key: 'questions' as const },
    { name: 'unitTestAttempts', key: 'tests' as const },
    { name: 'unitTestResults', key: 'tests' as const },
    { name: 'tests', key: 'tests' as const },
    { name: 'questions', key: 'questions' as const },
    { name: 'enrollments', key: 'batches' as const },
    { name: 'payments', key: 'batches' as const },
    { name: 'coupons', key: 'batches' as const },
  ];

  let totalDeleted = 0;

  for (const collInfo of curriculumCollections) {
    try {
      const collRef = collection(db, collInfo.name);
      const snap = await getDocs(collRef);
      if (!snap.empty) {
        // Delete documents
        for (const docSnap of snap.docs) {
          try {
            await deleteDoc(docSnap.ref);
            counts[collInfo.key] = (counts[collInfo.key] || 0) + 1;
            totalDeleted++;
          } catch (delErr: any) {
            console.warn(`[curriculumResetService] Error deleting doc ${docSnap.id} in ${collInfo.name}:`, delErr?.message);
          }
        }
      }
    } catch (collErr: any) {
      console.warn(`[curriculumResetService] Notice reading ${collInfo.name}:`, collErr?.message);
    }
  }

  // Double check local storage is totally clean
  fallbackStore.clearAllCurriculum();

  // Log admin audit trail
  if (actorUid) {
    logAdminAction({
      actorUid,
      actorEmail,
      action: 'CURRICULUM_PURGED_CLEAN_SLATE',
      resourceType: 'database',
      resourceId: 'all_curriculum',
      resourceTitle: 'Purge Courses, Subjects, Chapters, Units & Tests',
      details: {
        totalDeleted,
        breakdown: counts,
      },
    }).catch(() => {});
  }

  return {
    success: true,
    message: `All curriculum and test data deleted: ${counts.batches} courses, ${counts.subjects} subjects, ${counts.chapters} chapters, ${counts.classes} classes, ${counts.notes} notes, and ${counts.tests} tests removed. Ready to create fresh from scratch.`,
    deletedCounts: counts,
    totalDeleted,
  };
}
