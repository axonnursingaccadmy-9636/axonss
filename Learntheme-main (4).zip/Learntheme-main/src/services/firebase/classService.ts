/**
 * Axon Nursing Academy - Firebase Firestore Class/Lesson Service
 * Ultra-fast local-first query with background Firestore synchronization.
 */
import {
  collection,
  doc,
  getDoc,
  getDocs,
  query,
  where,
  orderBy,
} from 'firebase/firestore';
import { getFirestoreDb } from '@/src/lib/firebase/firestore';
import { LmsClass } from '@/src/types/lms.types';
import { extractYouTubeVideoId, getYouTubeThumbnailUrl, getYouTubeWatchUrl } from '@/src/lib/utils/youtubeUtils';
import { fallbackStore } from '@/src/services/fallback/fallbackStore';
import { withTimeout } from '@/src/lib/utils/asyncUtils';

const CLASSES_COLLECTION = 'classes';

function parseClassDoc(docSnap: any): LmsClass {
  const data = docSnap.data();
  const rawVideoUrl = data.videoUrl || data.youtubeUrl || '';
  const ytId = data.youtubeVideoId || extractYouTubeVideoId(rawVideoUrl);

  return {
    id: docSnap.id,
    batchId: data.batchId || '',
    subjectId: data.subjectId || '',
    chapterId: data.chapterId || '',
    title: data.title || 'Untitled Class',
    description: data.description || '',
    videoUrl: rawVideoUrl,
    youtubeVideoId: ytId || undefined,
    youtubeUrl: ytId ? getYouTubeWatchUrl(ytId) || rawVideoUrl : undefined,
    videoProvider: data.videoProvider || (ytId ? 'youtube' : 'direct'),
    durationMinutes: typeof data.durationMinutes === 'number' ? data.durationMinutes : 0,
    thumbnailUrl: data.thumbnailUrl || (ytId ? getYouTubeThumbnailUrl(ytId) || '' : ''),
    order: typeof data.order === 'number' ? data.order : 0,
    isFree: Boolean(data.isFree),
    isPublished: Boolean(data.isPublished),
    createdAt: data.createdAt,
    updatedAt: data.updatedAt,
  };
}

/**
 * Fetch all published classes/lessons belonging to a specific chapter.
 */
export async function getPublishedClasses(chapterId: string): Promise<LmsClass[]> {
  const cached = fallbackStore.getClasses(chapterId).filter((c) => c.isPublished);
  const timeoutMs = cached.length > 0 ? 4000 : 8000;

  const db = getFirestoreDb();
  if (!db || !chapterId) {
    return cached;
  }

  try {
    const fetchFromFirestore = async () => {
      const classesRef = collection(db, CLASSES_COLLECTION);
      const q = query(
        classesRef,
        where('chapterId', '==', chapterId),
        where('isPublished', '==', true)
      );

      const snapshot = await getDocs(q);

      const classes: LmsClass[] = (snapshot?.docs || []).map((docSnap) => parseClassDoc(docSnap));
      const sorted = classes.sort((a, b) => (a.order || 0) - (b.order || 0));
      fallbackStore.syncClasses(sorted, chapterId);
      return sorted;
    };

    return await withTimeout(fetchFromFirestore(), timeoutMs, cached);
  } catch (err: any) {
    console.warn('[classService] Serving cached classes:', err?.message || err);
    return cached;
  }
}

/**
 * Fetch a single class by ID.
 */
export async function getClassById(classId: string): Promise<LmsClass | null> {
  const cached = fallbackStore.getClassById(classId);

  const db = getFirestoreDb();
  if (!db || !classId) {
    return cached;
  }

  try {
    const fetchFromFirestore = async () => {
      const docRef = doc(db, CLASSES_COLLECTION, classId);
      const docSnap = await getDoc(docRef);

      if (!docSnap.exists()) {
        return cached;
      }

      const data = docSnap.data();
      if (!data.isPublished) {
        return null;
      }

      const classItem = parseClassDoc(docSnap);
      fallbackStore.saveClass(classItem);
      return classItem;
    };

    return await withTimeout(fetchFromFirestore(), 1200, cached);
  } catch (err: any) {
    console.warn('[classService] Serving cached class by ID:', err?.message || err);
    return cached;
  }
}

/**
 * Helper to get the total published class count for a batch.
 */
export async function getPublishedClassCountForBatch(batchId: string): Promise<number> {
  const cachedCount = fallbackStore.getClasses().filter((c) => c.batchId === batchId && c.isPublished).length;

  const db = getFirestoreDb();
  if (!db || !batchId) {
    return cachedCount;
  }

  try {
    const fetchCount = async () => {
      const classesRef = collection(db, CLASSES_COLLECTION);
      const q = query(
        classesRef,
        where('batchId', '==', batchId),
        where('isPublished', '==', true)
      );
      const snapshot = await getDocs(q);
      return snapshot.size;
    };

    return await withTimeout(fetchCount(), 1000, cachedCount);
  } catch (err: any) {
    return cachedCount;
  }
}
