/**
 * Axon Nursing Academy - Firebase Firestore Admin PDF Notes Service
 * Handles CRUD operations, publishing controls, and storage synchronization for clinical PDF notes.
 */
import {
  collection,
  doc,
  getDocs,
  setDoc,
  updateDoc,
  deleteDoc,
  query,
  where,
  orderBy,
  serverTimestamp,
} from 'firebase/firestore';
import { getFirestoreDb, OperationType, handleFirestoreError } from '@/src/lib/firebase/firestore';
import { PdfNote } from '@/src/types/lms.types';
import { logAdminAction } from './auditService';
import { generateSlug } from './adminBatchService';
import { deleteStorageFile } from './storageService';
import { fallbackStore } from '@/src/services/fallback/fallbackStore';
import { withTimeout } from '@/src/lib/utils/asyncUtils';

const PDF_NOTES_COLLECTION = 'pdfNotes';

export interface PdfNoteFormData {
  batchId: string;
  subjectId: string;
  chapterId: string;
  classId?: string;
  title: string;
  description?: string;
  fileUrl: string;
  storagePath: string;
  fileName: string;
  fileSizeBytes: number;
  pageCount?: number;
  order: number;
  isFree: boolean;
  isPublished: boolean;
}

/**
 * Fetch all PDF notes across the system for Admin CMS.
 */
export async function getAllPdfNotesAdmin(): Promise<PdfNote[]> {
  const cached = fallbackStore.getPdfNotes();
  const db = getFirestoreDb();
  if (!db) return cached;

  try {
    const fetchFromFirestore = async () => {
      const notesRef = collection(db, PDF_NOTES_COLLECTION);
      const q = query(notesRef, orderBy('order', 'asc'));
      const snapshot = await getDocs(q);

      const notes: PdfNote[] = (snapshot?.docs || []).map((docSnap) => {
        const data = docSnap.data();
        return {
          id: docSnap.id,
          batchId: data.batchId || '',
          subjectId: data.subjectId || '',
          chapterId: data.chapterId || '',
          classId: data.classId || '',
          title: data.title || 'Untitled Note',
          description: data.description || '',
          fileUrl: data.fileUrl || '',
          storagePath: data.storagePath || '',
          fileName: data.fileName || 'document.pdf',
          fileSizeBytes: typeof data.fileSizeBytes === 'number' ? data.fileSizeBytes : 0,
          pageCount: typeof data.pageCount === 'number' ? data.pageCount : undefined,
          order: typeof data.order === 'number' ? data.order : 0,
          isFree: Boolean(data.isFree),
          isPublished: Boolean(data.isPublished),
          createdAt: data.createdAt,
          updatedAt: data.updatedAt,
        };
      });

      const sorted = notes.sort((a, b) => (a.order || 0) - (b.order || 0));
      fallbackStore.syncPdfNotes(sorted);
      return sorted;
    };

    return await withTimeout(fetchFromFirestore(), 1200, cached);
  } catch (err: any) {
    console.warn('[AdminPdfNotesService] Returning cached notes:', err?.message || err);
    return cached;
  }
}

/**
 * Fetch PDF notes belonging to a specific chapter for Admin CMS.
 */
export async function getPdfNotesForChapterAdmin(chapterId: string): Promise<PdfNote[]> {
  const cached = fallbackStore.getPdfNotes(chapterId);
  const db = getFirestoreDb();
  if (!db || !chapterId) return cached;

  try {
    const fetchFromFirestore = async () => {
      const notesRef = collection(db, PDF_NOTES_COLLECTION);
      const q = query(notesRef, where('chapterId', '==', chapterId));
      const snapshot = await getDocs(q);

      const notes: PdfNote[] = (snapshot?.docs || []).map((docSnap) => {
        const data = docSnap.data();
        return {
          id: docSnap.id,
          batchId: data.batchId || '',
          subjectId: data.subjectId || '',
          chapterId: data.chapterId || chapterId,
          classId: data.classId || '',
          title: data.title || 'Untitled Note',
          description: data.description || '',
          fileUrl: data.fileUrl || '',
          storagePath: data.storagePath || '',
          fileName: data.fileName || 'document.pdf',
          fileSizeBytes: typeof data.fileSizeBytes === 'number' ? data.fileSizeBytes : 0,
          pageCount: typeof data.pageCount === 'number' ? data.pageCount : undefined,
          order: typeof data.order === 'number' ? data.order : 0,
          isFree: Boolean(data.isFree),
          isPublished: Boolean(data.isPublished),
          createdAt: data.createdAt,
          updatedAt: data.updatedAt,
        };
      });

      const sorted = notes.sort((a, b) => (a.order || 0) - (b.order || 0));
      fallbackStore.syncPdfNotes(sorted, chapterId);
      return sorted;
    };

    return await withTimeout(fetchFromFirestore(), 1200, cached);
  } catch (err: any) {
    console.warn('[AdminPdfNotesService] Returning chapter cached notes:', err?.message || err);
    return cached;
  }
}

/**
 * Create a new PDF note entry in Firestore.
 */
export async function createPdfNote(
  data: PdfNoteFormData,
  actorUid: string,
  actorEmail?: string
): Promise<PdfNote> {
  const slug = generateSlug(data.title);
  const noteId = `pdf_${data.chapterId}_${slug}` || `pdf_${Date.now()}`;

  const payload: PdfNote = {
    id: noteId,
    batchId: data.batchId,
    subjectId: data.subjectId,
    chapterId: data.chapterId,
    classId: data.classId || '',
    title: data.title.trim(),
    description: data.description?.trim() || '',
    fileUrl: data.fileUrl.trim(),
    storagePath: data.storagePath.trim(),
    fileName: data.fileName.trim(),
    fileSizeBytes: Number(data.fileSizeBytes) || 0,
    pageCount: data.pageCount ? Number(data.pageCount) : undefined,
    order: Number(data.order) || 0,
    isFree: Boolean(data.isFree),
    isPublished: Boolean(data.isPublished),
  };

  // Always save to fallback store
  fallbackStore.savePdfNote(payload);

  const db = getFirestoreDb();
  if (!db) {
    return payload;
  }

  const path = `${PDF_NOTES_COLLECTION}/${noteId}`;
  try {
    const docRef = doc(db, PDF_NOTES_COLLECTION, noteId);
    await setDoc(docRef, {
      ...payload,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });

    await logAdminAction({
      actorUid,
      actorEmail,
      action: 'PDF_NOTE_CREATED',
      resourceType: 'pdfNote',
      resourceId: noteId,
      resourceTitle: data.title,
      details: {
        chapterId: data.chapterId,
        fileName: data.fileName,
        fileSizeBytes: data.fileSizeBytes,
        isPublished: data.isPublished,
      },
    }).catch(() => {});

    return payload;
  } catch (err: any) {
    console.warn('[AdminPdfNotesService] Firestore write deferred, saved to local cache:', err?.message || err);
    return payload;
  }
}

/**
 * Update an existing PDF note.
 */
export async function updatePdfNote(
  noteId: string,
  data: Partial<PdfNoteFormData>,
  actorUid: string,
  actorEmail?: string
): Promise<void> {
  const existing = fallbackStore.getPdfNoteById(noteId);
  fallbackStore.savePdfNote({ ...(existing || {}), ...data, id: noteId } as PdfNote);

  const db = getFirestoreDb();
  if (!db) return;

  try {
    const docRef = doc(db, PDF_NOTES_COLLECTION, noteId);

    await Promise.race([
      setDoc(docRef, {
        ...data,
        updatedAt: serverTimestamp(),
      }, { merge: true }),
      new Promise<void>((resolve) => setTimeout(resolve, 1200)),
    ]);

    logAdminAction({
      actorUid,
      actorEmail,
      action: 'PDF_NOTE_UPDATED',
      resourceType: 'pdfNote',
      resourceId: noteId,
      resourceTitle: data.title || noteId,
      details: { changedFields: Object.keys(data) },
    }).catch(() => {});
  } catch (err: any) {
    console.warn('[AdminPdfNotesService] Firestore update deferred:', err?.message || err);
  }
}

/**
 * Toggle PDF note published status.
 */
export async function togglePdfNotePublish(
  noteId: string,
  newPublishedState: boolean,
  noteTitle: string,
  actorUid: string,
  actorEmail?: string
): Promise<void> {
  const existing = fallbackStore.getPdfNoteById(noteId);
  if (existing) {
    fallbackStore.savePdfNote({ ...existing, isPublished: newPublishedState });
  }

  const db = getFirestoreDb();
  if (!db) return;

  try {
    const docRef = doc(db, PDF_NOTES_COLLECTION, noteId);
    await Promise.race([
      setDoc(docRef, {
        isPublished: newPublishedState,
        updatedAt: serverTimestamp(),
      }, { merge: true }),
      new Promise<void>((resolve) => setTimeout(resolve, 1200)),
    ]);

    logAdminAction({
      actorUid,
      actorEmail,
      action: newPublishedState ? 'PDF_NOTE_PUBLISHED' : 'PDF_NOTE_UNPUBLISHED',
      resourceType: 'pdfNote',
      resourceId: noteId,
      resourceTitle: noteTitle,
      details: { isPublished: newPublishedState },
    }).catch(() => {});
  } catch (err: any) {
    console.warn('[AdminPdfNotesService] Firestore toggle deferred:', err?.message || err);
  }
}

/**
 * Delete a PDF note from Firestore and delete its file from Firebase Storage.
 */
export async function deletePdfNote(
  noteId: string,
  noteTitle: string,
  storagePath: string,
  actorUid: string,
  actorEmail?: string
): Promise<void> {
  fallbackStore.deletePdfNote(noteId);

  const db = getFirestoreDb();
  if (!db) return;

  const path = `${PDF_NOTES_COLLECTION}/${noteId}`;
  try {
    // 1. Delete Firestore document
    const docRef = doc(db, PDF_NOTES_COLLECTION, noteId);
    await deleteDoc(docRef);

    // 2. Delete file in Firebase Storage if path present
    if (storagePath) {
      await deleteStorageFile(storagePath).catch((err) => {
        console.warn('[AdminPdfNotesService] Storage file delete warning:', err);
      });
    }

    // 3. Log audit event
    await logAdminAction({
      actorUid,
      actorEmail,
      action: 'PDF_NOTE_DELETED',
      resourceType: 'pdfNote',
      resourceId: noteId,
      resourceTitle: noteTitle,
      details: { storagePath },
    }).catch(() => {});
  } catch (err: any) {
    console.warn('[AdminPdfNotesService] Firestore delete deferred:', err?.message || err);
  }
}
