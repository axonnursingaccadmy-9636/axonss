/**
 * Axon Nursing Academy - Cloud File & Media Storage Service
 * Provides reliable, cross-device PDF & Image uploading with real-time 0% -> 100% progress tracking
 * backed by Cloud Firestore chunked storage + Express/Vercel streaming endpoints.
 */
import { doc, setDoc, getDoc, deleteDoc } from 'firebase/firestore';
import { getFirestoreDb } from '@/src/lib/firebase/firestore';
import { STORAGE_PATHS } from '@/src/lib/firebase/storage';

export interface StorageUploadResult {
  downloadUrl: string;
  storagePath: string;
  fileName: string;
  fileSizeBytes: number;
  contentType: string;
}

export interface UploadOptions {
  onProgress?: (percent: number) => void;
  customFileName?: string;
}

export const MAX_PDF_SIZE_BYTES = 50 * 1024 * 1024; // 50MB
export const MAX_IMAGE_SIZE_BYTES = 10 * 1024 * 1024; // 10MB

// Safe chunk size (~550 KB per Firestore document, well below 1 MiB limit)
const CHUNK_CHAR_SIZE = 550 * 1024;

/**
 * Validates PDF file before uploading.
 */
export function validatePdfFile(file: File): { valid: boolean; error?: string } {
  if (!file) {
    return { valid: false, error: 'No file selected.' };
  }

  const isPdf =
    file.type === 'application/pdf' ||
    file.name.toLowerCase().endsWith('.pdf');

  if (!isPdf) {
    return { valid: false, error: 'Invalid file format. Please select a valid PDF document.' };
  }

  if (file.size > MAX_PDF_SIZE_BYTES) {
    return {
      valid: false,
      error: `PDF file size exceeds maximum limit of 50MB (Selected: ${(file.size / (1024 * 1024)).toFixed(1)}MB).`,
    };
  }

  return { valid: true };
}

/**
 * Validates Image file (Thumbnail / Banner) before uploading.
 */
export function validateImageFile(file: File): { valid: boolean; error?: string } {
  if (!file) {
    return { valid: false, error: 'No image file selected.' };
  }

  const validTypes = ['image/jpeg', 'image/png', 'image/webp', 'image/svg+xml', 'image/x-icon', 'image/vnd.microsoft.icon'];
  if (!validTypes.includes(file.type) && !file.type.startsWith('image/')) {
    return { valid: false, error: 'Invalid image format. Supported formats: JPG, PNG, WebP, SVG.' };
  }

  if (file.size > MAX_IMAGE_SIZE_BYTES) {
    return {
      valid: false,
      error: `Image file size exceeds maximum limit of 10MB (Selected: ${(file.size / (1024 * 1024)).toFixed(1)}MB).`,
    };
  }

  return { valid: true };
}

/**
 * Reads a File as a Data URL while reporting real-time byte reading progress.
 */
function readFileAsDataUrlWithProgress(
  file: File,
  onProgress?: (percent: number) => void,
  startPct: number = 2,
  endPct: number = 25
): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    if (onProgress) onProgress(startPct);

    reader.onprogress = (event) => {
      if (event.lengthComputable && onProgress) {
        const ratio = event.loaded / Math.max(1, event.total);
        const current = Math.round(startPct + ratio * (endPct - startPct));
        onProgress(Math.min(endPct, Math.max(startPct, current)));
      }
    };

    reader.onload = () => {
      if (onProgress) onProgress(endPct);
      resolve(String(reader.result || ''));
    };

    reader.onerror = () => {
      reject(new Error('Failed to read selected file from device.'));
    };

    reader.readAsDataURL(file);
  });
}

/**
 * Uploads a PDF note to Cloud Firestore chunked storage + Backend API stream
 * with smooth, real-time 0% -> 100% progress reporting.
 */
export async function uploadPdfNote(
  file: File,
  batchId: string,
  chapterId: string,
  options: UploadOptions = {}
): Promise<StorageUploadResult> {
  const validation = validatePdfFile(file);
  if (!validation.valid) {
    throw new Error(validation.error);
  }

  const report = (pct: number) => {
    if (options.onProgress) {
      options.onProgress(Math.max(0, Math.min(100, Math.round(pct))));
    }
  };

  report(2);

  // Step 1: Read file into Base64 (2% -> 24%)
  const dataUrl = await readFileAsDataUrlWithProgress(file, report, 2, 24);
  const rawBase64 = dataUrl.includes(',') ? dataUrl.split(',')[1] : dataUrl;

  if (!rawBase64) {
    throw new Error('Selected PDF file is empty or unreadable.');
  }

  // Step 2: Split into safe Firestore-compatible chunks
  const chunks: string[] = [];
  for (let i = 0; i < rawBase64.length; i += CHUNK_CHAR_SIZE) {
    chunks.push(rawBase64.slice(i, i + CHUNK_CHAR_SIZE));
  }
  const totalChunks = Math.max(1, chunks.length);

  const sanitizedName = (options.customFileName || file.name)
    .replace(/[^a-zA-Z0-9._-]/g, '_')
    .toLowerCase();
  const fileId = `pdf_${Date.now()}_${Math.random().toString(36).substring(2, 8)}`;
  const storagePath = `stored_files/${fileId}`;
  const downloadUrl = `/api/storage/pdf/${fileId}`;

  const db = getFirestoreDb();
  const nowIso = new Date().toISOString();

  const metaPayload = {
    fileId,
    fileName: file.name,
    sanitizedName,
    contentType: 'application/pdf',
    fileSizeBytes: file.size,
    totalChunks,
    batchId: batchId || '',
    chapterId: chapterId || '',
    createdAt: nowIso,
    updatedAt: nowIso,
  };

  report(28);

  // Save file metadata first
  if (db) {
    try {
      await setDoc(doc(db, 'stored_files', fileId), metaPayload);
    } catch (e) {
      console.warn('[StorageService] Client Firestore meta write notice, using API fallback:', e);
    }
  }

  // Step 3: Upload each chunk sequentially and update percentage (28% -> 98%)
  for (let i = 0; i < totalChunks; i++) {
    const chunkData = chunks[i];
    const chunkDocId = `${fileId}_chunk_${i}`;
    let storedInFirestore = false;

    if (db) {
      try {
        await setDoc(doc(db, 'stored_file_chunks', chunkDocId), {
          fileId,
          chunkIndex: i,
          data: chunkData,
          updatedAt: nowIso,
        });
        storedInFirestore = true;
      } catch (fsErr) {
        console.warn(`[StorageService] Direct Firestore write for chunk ${i} deferred to API:`, fsErr);
      }
    }

    // Also push chunk to backend API so /api/storage/pdf/:fileId has immediate warm cache
    // and guarantees persistence via Admin SDK if client rules were restricted
    try {
      const res = await fetch('/api/storage/chunk', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          fileId,
          chunkIndex: i,
          totalChunks,
          data: chunkData,
          fileName: file.name,
          contentType: 'application/pdf',
          fileSizeBytes: file.size,
          batchId: batchId || '',
          chapterId: chapterId || '',
        }),
      });
      if (!res.ok && !storedInFirestore) {
        throw new Error(`Chunk ${i + 1}/${totalChunks} upload failed (${res.status})`);
      }
    } catch (apiErr: any) {
      if (!storedInFirestore) {
        throw new Error(apiErr?.message || 'Failed to upload PDF chunk to cloud storage.');
      }
    }

    const chunkProgress = 28 + Math.round(((i + 1) / totalChunks) * 70);
    report(chunkProgress);
  }

  report(100);

  return {
    downloadUrl,
    storagePath,
    fileName: file.name,
    fileSizeBytes: file.size,
    contentType: 'application/pdf',
  };
}

/**
 * Resolves a stored PDF URL (`/api/storage/pdf/:fileId` or external URL) into a playable Blob URL
 * if direct client-side Firestore reconstruction is needed as a fallback.
 */
export async function resolvePdfBlobUrl(
  fileUrl: string,
  onProgress?: (percent: number) => void
): Promise<string> {
  if (!fileUrl) return '';
  if (!fileUrl.includes('/api/storage/pdf/') && !fileUrl.includes('/api/storage/file/')) {
    return fileUrl;
  }

  const fileId = fileUrl.split('/').pop()?.split('?')[0] || '';
  if (!fileId) return fileUrl;

  // First try fetching from the streaming endpoint
  try {
    if (onProgress) onProgress(20);
    const res = await fetch(`/api/storage/pdf/${fileId}`);
    if (res.ok) {
      const contentType = res.headers.get('content-type') || '';
      if (contentType.includes('application/pdf')) {
        const blob = await res.blob();
        if (onProgress) onProgress(100);
        return URL.createObjectURL(blob);
      }
    }
  } catch {
    // Fall back to direct Firestore chunk assembly below
  }

  const db = getFirestoreDb();
  if (!db) return fileUrl;

  const metaSnap = await getDoc(doc(db, 'stored_files', fileId));
  if (!metaSnap.exists()) return fileUrl;

  const meta = metaSnap.data();
  const totalChunks = Number(meta?.totalChunks) || 1;
  const parts: string[] = [];

  for (let i = 0; i < totalChunks; i++) {
    const cSnap = await getDoc(doc(db, 'stored_file_chunks', `${fileId}_chunk_${i}`));
    if (!cSnap.exists()) return fileUrl;
    parts.push(cSnap.data()?.data || '');
    if (onProgress) {
      onProgress(Math.round(((i + 1) / totalChunks) * 100));
    }
  }

  const fullBase64 = parts.join('');
  const cleanBase64 = fullBase64.includes(',') ? fullBase64.split(',')[1] : fullBase64;
  const binaryStr = atob(cleanBase64);
  const bytes = new Uint8Array(binaryStr.length);
  for (let i = 0; i < binaryStr.length; i++) {
    bytes[i] = binaryStr.charCodeAt(i);
  }

  const blob = new Blob([bytes], { type: 'application/pdf' });
  return URL.createObjectURL(blob);
}

/**
 * Strips wide-gamut APP2 (ICC_PROFILE, 0xFFE2) JPEG segments that cause
 * Android Chrome Skia GPU tile tearing when rendering multiple base64 thumbnails.
 */
function stripJpegIccProfileClient(dataUrl: string): string {
  const prefix = 'data:image/jpeg;base64,';
  if (!dataUrl || !dataUrl.startsWith(prefix)) return dataUrl;
  try {
    const b64 = dataUrl.slice(prefix.length);
    const bin = atob(b64);
    const len = bin.length;
    if (len < 4 || bin.charCodeAt(0) !== 0xff || bin.charCodeAt(1) !== 0xd8) {
      return dataUrl;
    }
    const bytes = new Uint8Array(len);
    for (let k = 0; k < len; k++) {
      bytes[k] = bin.charCodeAt(k);
    }
    const parts: Uint8Array[] = [bytes.subarray(0, 2)];
    let i = 2;
    let stripped = false;
    while (i < len) {
      if (bytes[i] !== 0xff) {
        parts.push(bytes.subarray(i));
        break;
      }
      const marker = bytes[i + 1];
      if (marker === 0xda || marker === 0xd9 || i + 4 > len) {
        parts.push(bytes.subarray(i));
        break;
      }
      const segLen = (bytes[i + 2] << 8) | bytes[i + 3];
      const segEnd = i + 2 + segLen;
      if (marker === 0xe2) {
        stripped = true;
      } else {
        parts.push(bytes.subarray(i, segEnd));
      }
      i = segEnd;
    }
    if (!stripped) return dataUrl;
    const totalOut = parts.reduce((acc, p) => acc + p.length, 0);
    const out = new Uint8Array(totalOut);
    let offset = 0;
    for (const p of parts) {
      out.set(p, offset);
      offset += p.length;
    }
    let outBin = '';
    const chunkSize = 8192;
    for (let c = 0; c < out.length; c += chunkSize) {
      outBin += String.fromCharCode(...out.subarray(c, c + chunkSize));
    }
    return prefix + btoa(outBin);
  } catch {
    return dataUrl;
  }
}

/**
 * Compresses and converts an image to an optimized Base64 data URL
 * while reporting smooth 0% -> 100% progress.
 */
export async function compressImageToDataUrl(
  file: File,
  maxDimension: number = 1000,
  quality: number = 0.85,
  onProgress?: (percent: number) => void
): Promise<string> {
  const report = (pct: number) => {
    if (onProgress) {
      onProgress(Math.max(0, Math.min(100, Math.round(pct))));
    }
  };

  report(8);

  // Read file with live progress (8% -> 50%)
  const rawDataUrl = await readFileAsDataUrlWithProgress(file, report, 8, 50);

  // If SVG or icon, return directly with smooth progress completion
  if (file.type === 'image/svg+xml' || file.type.includes('icon') || file.name.endsWith('.ico')) {
    report(85);
    await new Promise((r) => setTimeout(r, 80));
    report(100);
    return rawDataUrl;
  }

  report(65);

  return new Promise((resolve) => {
    const img = new Image();
    img.onload = () => {
      let { width, height } = img;
      if (width > maxDimension || height > maxDimension) {
        if (width > height) {
          height = Math.round((height * maxDimension) / width);
          width = maxDimension;
        } else {
          width = Math.round((width * maxDimension) / height);
          height = maxDimension;
        }
      }

      const canvas = document.createElement('canvas');
      canvas.width = width;
      canvas.height = height;
      let ctx: CanvasRenderingContext2D | null = null;
      try {
        ctx = canvas.getContext('2d', { colorSpace: 'srgb' });
      } catch {
        ctx = canvas.getContext('2d');
      }
      if (!ctx) {
        report(100);
        resolve(stripJpegIccProfileClient(rawDataUrl));
        return;
      }

      report(82);
      ctx.drawImage(img, 0, 0, width, height);

      // Use PNG only for small transparent branding logos (< 450px); otherwise use JPEG to stay well under Firestore 1MB limit
      const usePng = file.type === 'image/png' && maxDimension <= 450;
      let compressedDataUrl = canvas.toDataURL(usePng ? 'image/png' : 'image/jpeg', quality);

      // Self-healing size cap: if Base64 exceeds 240KB, re-encode as compact JPEG so thumbnail + banner never exceed Firestore 1MB limit
      if (compressedDataUrl.length > 240 * 1024) {
        compressedDataUrl = canvas.toDataURL('image/jpeg', 0.72);
      }
      if (compressedDataUrl.length > 240 * 1024) {
        const smallerCanvas = document.createElement('canvas');
        smallerCanvas.width = Math.round(width * 0.75);
        smallerCanvas.height = Math.round(height * 0.75);
        let sCtx: CanvasRenderingContext2D | null = null;
        try {
          sCtx = smallerCanvas.getContext('2d', { colorSpace: 'srgb' });
        } catch {
          sCtx = smallerCanvas.getContext('2d');
        }
        if (sCtx) {
          sCtx.drawImage(img, 0, 0, smallerCanvas.width, smallerCanvas.height);
          compressedDataUrl = smallerCanvas.toDataURL('image/jpeg', 0.68);
        }
      }

      const cleanDataUrl = stripJpegIccProfileClient(compressedDataUrl);
      report(100);
      resolve(cleanDataUrl);
    };
    img.onerror = () => {
      report(100);
      resolve(stripJpegIccProfileClient(rawDataUrl));
    };
    img.src = rawDataUrl;
  });
}

/**
 * Uploads an image (Thumbnail, Banner, or Branding) with real-time 0% -> 100% progress.
 */
export async function uploadImageMedia(
  file: File,
  folder: 'thumbnails' | 'banners' | 'branding' | 'general' = 'thumbnails',
  options: UploadOptions = {}
): Promise<StorageUploadResult> {
  const validation = validateImageFile(file);
  if (!validation.valid) {
    throw new Error(validation.error);
  }

  const maxDim = folder === 'banners' ? 1400 : folder === 'branding' ? 800 : 950;
  const dataUrl = await compressImageToDataUrl(file, maxDim, 0.85, options.onProgress);

  let folderPath: string = STORAGE_PATHS.COURSE_THUMBNAILS;
  if (folder === 'banners') {
    folderPath = STORAGE_PATHS.COURSE_BANNERS;
  } else if (folder === 'branding') {
    folderPath = STORAGE_PATHS.BRANDING;
  }

  const sanitizedFileName = (options.customFileName || file.name)
    .replace(/[^a-zA-Z0-9._-]/g, '_')
    .toLowerCase();
  const storagePath = `${folderPath}/${Date.now()}_${sanitizedFileName}`;

  return {
    downloadUrl: dataUrl,
    storagePath,
    fileName: file.name,
    fileSizeBytes: file.size,
    contentType: file.type || 'image/jpeg',
  };
}

/**
 * Convenient helper to upload a thumbnail and return the download URL directly
 */
export async function uploadThumbnailImage(
  file: File,
  _subfolder: string = 'general',
  options: UploadOptions = {}
): Promise<string> {
  return await uploadImageWithFallback(file, 'thumbnails', options);
}

/**
 * Robust image uploader that compresses and returns an optimized Data URL
 * while reporting smooth 0% -> 100% upload progress.
 */
export async function uploadImageWithFallback(
  file: File,
  folder: 'thumbnails' | 'banners' | 'branding' | 'general' = 'thumbnails',
  options: UploadOptions = {}
): Promise<string> {
  const validation = validateImageFile(file);
  if (!validation.valid) {
    throw new Error(validation.error);
  }

  const maxDim = folder === 'banners' ? 1400 : folder === 'branding' ? 800 : 950;
  return await compressImageToDataUrl(file, maxDim, 0.85, options.onProgress);
}

/**
 * Convenient helper to upload branding images (Logo, Footer Logo, Favicon).
 */
export async function uploadBrandingImage(
  file: File,
  type: 'logo' | 'footer' | 'favicon',
  options: UploadOptions = {}
): Promise<string> {
  const validation = validateImageFile(file);
  if (!validation.valid) {
    throw new Error(validation.error);
  }

  const maxDim = type === 'favicon' ? 128 : type === 'logo' ? 600 : 800;
  return await compressImageToDataUrl(file, maxDim, 0.9, options.onProgress);
}

/**
 * Convenient helper to upload a banner and return the download URL directly
 */
export async function uploadBannerImage(
  file: File,
  options: UploadOptions = {}
): Promise<string> {
  return await uploadImageWithFallback(file, 'banners', options);
}

/**
 * Deletes a stored file from Cloud Firestore chunk storage + backend cache.
 */
export async function deleteStorageFile(storagePathOrUrl: string): Promise<void> {
  if (!storagePathOrUrl) return;

  // Extract fileId if stored in stored_files/{fileId} or /api/storage/pdf/{fileId}
  let fileId = '';
  if (storagePathOrUrl.startsWith('stored_files/')) {
    fileId = storagePathOrUrl.replace('stored_files/', '').trim();
  } else if (storagePathOrUrl.includes('/api/storage/pdf/') || storagePathOrUrl.includes('/api/storage/file/')) {
    fileId = storagePathOrUrl.split('/').pop()?.split('?')[0] || '';
  }

  if (!fileId) return;

  try {
    await fetch(`/api/storage/file/${fileId}`, { method: 'DELETE' }).catch(() => {});
  } catch {
    // Ignore API delete error
  }

  const db = getFirestoreDb();
  if (!db) return;

  try {
    const snap = await getDoc(doc(db, 'stored_files', fileId));
    const totalChunks = snap.exists() ? Number(snap.data()?.totalChunks) || 10 : 10;
    await deleteDoc(doc(db, 'stored_files', fileId)).catch(() => {});
    for (let i = 0; i < totalChunks; i++) {
      await deleteDoc(doc(db, 'stored_file_chunks', `${fileId}_chunk_${i}`)).catch(() => {});
    }
  } catch (err) {
    console.warn('[StorageService] Delete file warning:', err);
  }
}
