/**
 * Axon Nursing Academy - Firebase Services Facade
 */
export * from '@/src/lib/firebase/config';
export * from '@/src/lib/firebase/firebase';
export * from '@/src/lib/firebase/auth';
export * from '@/src/lib/firebase/firestore';
export * from '@/src/lib/firebase/storage';
export * from './authService';
export * from './userService';
export * from './batchService';
export * from './subjectService';
export * from './chapterService';
export * from './classService';
export * from './adminBatchService';
export * from './adminSubjectService';
export * from './adminChapterService';
export * from './adminClassService';
export * from './adminStatsService';
export * from './adminPdfNotesService';
export * from './pdfNotesService';
export * from './storageService';
export * from './auditService';
export * from './seedService';
export * from './curriculumResetService';
export * from './couponService';
export * from './enrollmentService';
