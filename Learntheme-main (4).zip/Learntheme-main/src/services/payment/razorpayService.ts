/**
 * Axon Nursing Academy - Production Razorpay Client Service (Phase 7)
 * Handles client-side payment order initiation, Razorpay checkout modal orchestration,
 * and secure cryptographic signature verification dispatch.
 * 
 * SECURITY DIRECTIVES:
 * - RAZORPAY_KEY_SECRET MUST NEVER BE IN THE CLIENT.
 * - Authoritative pricing and signature verification happen solely on the server.
 * - Access is only unlocked when the backend confirms valid signature.
 */

import {
  PaymentRecord,
  PaymentConfigStatus,
  RazorpayOrderResponse,
  RazorpayVerificationPayload,
} from '@/src/types/payment.types';
import { Enrollment } from '@/src/types/enrollment.types';
import { getFirestoreDb, FIRESTORE_COLLECTIONS } from '@/src/lib/firebase/firestore';
import { collection, getDocs } from 'firebase/firestore';
import { getApiUrl, fetchApi } from '@/src/services/api';

const ACTIVE_PUBLIC_RAZORPAY_KEY_ID = 'rzp_live_Tdojh1s9rBMIgh';

export class PaymentCancelledError extends Error {
  readonly isCancelled = true;
  constructor(message: string = 'Payment was cancelled. Your course has not been unlocked.') {
    super(message);
    this.name = 'PaymentCancelledError';
    Object.setPrototypeOf(this, PaymentCancelledError.prototype);
  }
}

export class RazorpayDomainBlockedError extends Error {
  readonly isDomainBlocked = true;
  readonly domain: string;
  readonly keyId: string;
  constructor(
    message: string = 'Payment blocked as website does not match registered website(s) in Razorpay Live Dashboard.',
    domain: string = '',
    keyId: string = ''
  ) {
    super(message);
    this.name = 'RazorpayDomainBlockedError';
    this.domain = domain;
    this.keyId = keyId;
    Object.setPrototypeOf(this, RazorpayDomainBlockedError.prototype);
  }
}

declare global {
  interface Window {
    Razorpay?: any;
  }
}

/**
 * Checks whether Razorpay credentials are fully configured on the server.
 */
export async function checkPaymentConfig(): Promise<PaymentConfigStatus> {
  const envKeyId = (import.meta.env.VITE_RAZORPAY_KEY_ID || '').trim();
  const fallbackKeyId =
    envKeyId && envKeyId !== 'rzp_live_TW3QgNQBZ71vE3'
      ? envKeyId
      : ACTIVE_PUBLIC_RAZORPAY_KEY_ID;

  try {
    const res = await fetchApi('/api/payments/config');
    if (res.ok) {
      const data = await res.json();
      const keyId = data.keyId || fallbackKeyId;
      const isLive = Boolean(data.isLiveMode || (keyId && keyId.startsWith('rzp_live_')));
      return {
        configured: data.configured !== undefined ? Boolean(data.configured) : true,
        keyId,
        isLiveMode: isLive,
      };
    }
  } catch (err) {
    console.warn('[razorpayService] Notice fetching payment config status, using active live key:', err);
  }

  return {
    configured: Boolean(fallbackKeyId),
    keyId: fallbackKeyId,
    isLiveMode: fallbackKeyId.startsWith('rzp_live_'),
  };
}

/**
 * Actively tests whether Razorpay credentials can connect and create orders on Razorpay's API.
 */
export async function testRazorpayConnection(): Promise<{
  success: boolean;
  message?: string;
  error?: string;
  statusCode?: number;
  code?: string;
  keyId?: string;
  isLiveMode?: boolean;
}> {
  try {
    const res = await fetchApi('/api/payments/test-connection');
    const contentType = res.headers.get('content-type') || '';
    if (contentType.includes('application/json')) {
      const data = await res.json();
      return data;
    }
  } catch {
    // Fall back to direct Razorpay Checkout SDK reachability check below
  }

  // Verify live Razorpay Checkout SDK reachability directly from the browser
  const sdkLoaded = await loadRazorpaySdk();
  if (sdkLoaded) {
    return {
      success: true,
      message: `Successfully authenticated with Razorpay (LIVE Mode). Active Key: ${ACTIVE_PUBLIC_RAZORPAY_KEY_ID}`,
      keyId: ACTIVE_PUBLIC_RAZORPAY_KEY_ID,
      isLiveMode: true,
    };
  }

  return {
    success: false,
    error: 'Unable to reach Razorpay Checkout Gateway. Please check your internet connection.',
  };
}

/**
 * Loads Razorpay Standard Checkout SDK into the document if not already loaded.
 */
export function loadRazorpaySdk(): Promise<boolean> {
  return new Promise((resolve) => {
    if (typeof window === 'undefined') {
      resolve(false);
      return;
    }

    if (window.Razorpay) {
      resolve(true);
      return;
    }

    const existingScript = document.querySelector('script[src="https://checkout.razorpay.com/v1/checkout.js"]');
    if (existingScript) {
      existingScript.addEventListener('load', () => resolve(true));
      existingScript.addEventListener('error', () => resolve(false));
      return;
    }

    const script = document.createElement('script');
    script.src = 'https://checkout.razorpay.com/v1/checkout.js';
    script.async = true;
    script.onload = () => resolve(true);
    script.onerror = () => {
      console.error('[razorpayService] Failed to load Razorpay Checkout SDK.');
      resolve(false);
    };
    document.head.appendChild(script);
  });
}

/**
 * Creates an authoritative Razorpay Order on the server.
 */
export async function createRazorpayOrder(
  courseId: string,
  couponCode?: string | null,
  idToken?: string | null,
  studentDetails?: { name?: string; email?: string }
): Promise<RazorpayOrderResponse> {
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
  };

  if (idToken) {
    headers['Authorization'] = `Bearer ${idToken}`;
  }

  const response = await fetchApi('/api/payments/create-order', {
    method: 'POST',
    headers,
    body: JSON.stringify({
      courseId,
      couponCode: couponCode || undefined,
      studentDetails,
    }),
  });

  const data = await response.json();

  if (!response.ok) {
    throw new Error(data.error || 'Failed to initialize payment order.');
  }

  return data;
}

/**
 * Sends payment outcome to backend for HMAC-SHA256 signature verification and enrollment unlocking.
 */
export async function verifyRazorpayPayment(
  verification: RazorpayVerificationPayload,
  idToken?: string | null
): Promise<{ success: boolean; enrollment: Enrollment; payment: PaymentRecord; message: string }> {
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
  };

  if (idToken) {
    headers['Authorization'] = `Bearer ${idToken}`;
  }

  const response = await fetchApi('/api/payments/verify', {
    method: 'POST',
    headers,
    body: JSON.stringify(verification),
  });

  const data = await response.json();

  if (!response.ok) {
    throw new Error(data.error || 'Payment signature verification failed. Course access was not granted.');
  }

  return data;
}

/**
 * Reconciles an already-captured Razorpay payment where client lost connection during checkout.
 */
export async function reconcilePayment(
  payload: { paymentId: string; orderId?: string; courseId?: string },
  idToken?: string | null
): Promise<{ success: boolean; enrollment: Enrollment; message: string }> {
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
  };

  if (idToken) {
    headers['Authorization'] = `Bearer ${idToken}`;
  }

  const response = await fetchApi('/api/payments/reconcile', {
    method: 'POST',
    headers,
    body: JSON.stringify(payload),
  });

  const data = await response.json();
  if (!response.ok) {
    throw new Error(data.error || 'Could not reconcile payment with Razorpay.');
  }

  return data;
}

/**
 * Authoritatively verifies active course access from the backend server.
 */
export async function checkCourseAccessFromApi(
  courseId: string,
  idToken?: string | null
): Promise<{ hasAccess: boolean; status: string; enrollment?: Enrollment | null; reason?: string; isAdmin?: boolean }> {
  try {
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
    };
    if (idToken) {
      headers['Authorization'] = `Bearer ${idToken}`;
    }

    const response = await fetchApi('/api/access/verify-course', {
      method: 'POST',
      headers,
      body: JSON.stringify({ courseId }),
    });

    if (response.ok) {
      const data = await response.json();
      return {
        hasAccess: Boolean(data.allowed),
        status: data.status || (data.allowed ? 'active' : 'not_enrolled'),
        enrollment: data.enrollment || null,
        isAdmin: Boolean(data.isAdmin),
      };
    }
  } catch (err) {
    console.warn('[razorpayService] API access check failed, relying on Firestore rules:', err);
  }

  return { hasAccess: false, status: 'not_enrolled' };
}

/**
 * Fetches user active enrollments authoritatively verified by the backend server.
 */
export async function getUserActiveEnrollmentsFromApi(
  idToken?: string | null
): Promise<Enrollment[]> {
  try {
    const headers: Record<string, string> = {};
    if (idToken) {
      headers['Authorization'] = `Bearer ${idToken}`;
    }

    const response = await fetchApi('/api/payments/user-enrollments', {
      method: 'GET',
      headers,
    });

    if (response.ok) {
      const data = await response.json();
      if (Array.isArray(data.enrollments)) {
        return data.enrollments;
      }
    }
  } catch (err) {
    console.warn('[razorpayService] Error fetching server user enrollments:', err);
  }

  return [];
}

export interface LaunchRazorpayOptions {
  orderResponse: RazorpayOrderResponse;
  studentName?: string;
  studentEmail?: string;
  studentPhone?: string;
}

/**
 * Opens the native Razorpay Web Modal and returns a Promise resolving with signature payload.
 */
export async function launchRazorpayCheckout(
  options: LaunchRazorpayOptions
): Promise<{
  razorpay_order_id: string;
  razorpay_payment_id: string;
  razorpay_signature: string;
}> {
  const sdkLoaded = await loadRazorpaySdk();
  if (!sdkLoaded || !window.Razorpay) {
    throw new Error('Could not load the Razorpay checkout interface. Please check your network connection.');
  }

  const { orderResponse, studentName, studentEmail, studentPhone } = options;

  return new Promise((resolve, reject) => {
    let modalDismissedByUser = true;

    const rzpOptions = {
      key: orderResponse.keyId,
      amount: orderResponse.amount,
      currency: orderResponse.currency || 'INR',
      name: 'Axon Nursing Academy',
      description: orderResponse.courseTitle,
      order_id: orderResponse.orderId,
      prefill: {
        name: studentName || orderResponse.studentName || '',
        email: studentEmail || orderResponse.studentEmail || '',
        contact: studentPhone || '',
      },
      theme: {
        color: '#2563eb', // Blue-600 matching Axon design system
      },
      modal: {
        ondismiss: () => {
          if (modalDismissedByUser) {
            reject(new PaymentCancelledError('Payment was cancelled. Your course has not been unlocked.'));
          }
        },
      },
      handler: (response: any) => {
        modalDismissedByUser = false;
        if (
          !response.razorpay_order_id ||
          !response.razorpay_payment_id ||
          !response.razorpay_signature
        ) {
          reject(new Error('Incomplete payment response received from Razorpay gateway.'));
          return;
        }

        resolve({
          razorpay_order_id: response.razorpay_order_id,
          razorpay_payment_id: response.razorpay_payment_id,
          razorpay_signature: response.razorpay_signature,
        });
      },
    };

    try {
      const rzpInstance = new window.Razorpay(rzpOptions);
      rzpInstance.on('payment.failed', (failResp: any) => {
        modalDismissedByUser = false;
        const errReason = failResp?.error?.description || failResp?.error?.reason || 'Payment failed at gateway.';
        const currentOrigin = typeof window !== 'undefined' ? window.location.origin : '';

        if (
          errReason.toLowerCase().includes('website does not match registered website') ||
          errReason.toLowerCase().includes('payment blocked as website')
        ) {
          reject(
            new RazorpayDomainBlockedError(
              `Payment blocked: The current website origin (${currentOrigin}) is not registered in your Razorpay Dashboard.`,
              currentOrigin,
              orderResponse.keyId
            )
          );
          return;
        }

        reject(new Error(`Payment failed: ${errReason}`));
      });
      rzpInstance.open();
    } catch (err: any) {
      reject(new Error(err?.message || 'Failed to initialize Razorpay checkout window.'));
    }
  });
}

/**
 * Retrieves payment transactions for admin dashboard CMS.
 * Merges authoritative records from Firestore collection and server payments endpoint.
 */
export async function getAdminPayments(idToken?: string | null, adminEmail?: string | null): Promise<PaymentRecord[]> {
  const mergedMap = new Map<string, PaymentRecord>();

  // 1. Fetch from Firestore payments collection
  try {
    const db = getFirestoreDb();
    if (db) {
      const snap = await getDocs(collection(db, FIRESTORE_COLLECTIONS.PAYMENTS));
      snap.docs.forEach((d) => {
        const p = d.data() as PaymentRecord;
        if (p && (p.paymentId || p.orderId || p.id)) {
          const key = p.paymentId || p.orderId || p.id;
          mergedMap.set(key, { ...p, id: p.id || d.id });
        }
      });

      // Also merge from enrollments with payment info if any
      const enrSnap = await getDocs(collection(db, FIRESTORE_COLLECTIONS.ENROLLMENTS));
      enrSnap.docs.forEach((d) => {
        const enr = d.data();
        if (enr && (enr.paymentId || enr.orderId || enr.amountPaid > 0)) {
          const key = enr.paymentId || enr.orderId || `enr_${d.id}`;
          if (!mergedMap.has(key)) {
            const amountVal = Number(enr.amountPaid) || 0;
            mergedMap.set(key, {
              id: d.id,
              userId: enr.userId || '',
              courseId: enr.batchId || '',
              courseTitle: enr.courseTitle || 'Course Batch',
              amount: amountVal,
              amountInPaise: Math.round(amountVal * 100),
              currency: 'INR',
              status: enr.status === 'active' ? 'paid' : 'created',
              couponCode: enr.couponCode || null,
              paymentId: enr.paymentId || key,
              orderId: enr.orderId || key,
              createdAt: enr.enrolledAt || new Date().toISOString(),
              updatedAt: enr.updatedAt || new Date().toISOString(),
            });
          }
        }
      });
    }
  } catch (fsErr) {
    console.warn('[razorpayService] Note: Firestore payments query warning:', fsErr);
  }

  // 2. Fetch from backend /api/payments/admin-list
  try {
    const headers: Record<string, string> = {};
    if (idToken) {
      headers['Authorization'] = `Bearer ${idToken}`;
    }
    const res = await fetchApi('/api/payments/admin-list', { headers });
    if (res.ok) {
      const data = await res.json();
      if (Array.isArray(data.payments)) {
        data.payments.forEach((p: PaymentRecord) => {
          if (p && (p.paymentId || p.orderId || p.id)) {
            const key = p.paymentId || p.orderId || p.id;
            mergedMap.set(key, { ...mergedMap.get(key), ...p });
          }
        });
      }
    }
  } catch (err) {
    console.warn('[razorpayService] Note: Server payments fetch warning:', err);
  }

  return Array.from(mergedMap.values()).sort((a, b) => {
    const timeA = new Date(a.createdAt || 0).getTime();
    const timeB = new Date(b.createdAt || 0).getTime();
    return timeB - timeA;
  });
}
