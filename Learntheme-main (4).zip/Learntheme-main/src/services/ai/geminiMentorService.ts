/**
 * Axon Nursing Academy - Server-Side Gemini AI Clinical Mentor Service
 * 
 * Provides:
 * - GoogleGenAI client initialization with process.env.GEMINI_API_KEY
 * - Resilient multi-model fallback strategy (gemini-3.8-flash -> gemini-flash-latest -> gemini-3.1-flash-lite)
 * - Automatic handling of transient 503 (high demand) and 429 (rate limit) spikes
 * - Medical & Nursing domain guardrail policy enforcement
 * - Multi-turn conversational context formatting
 * - Comprehensive clinical knowledge fallback in case of Gemini rate limit or network disruption
 */
import { GoogleGenAI } from '@google/genai';

export const NON_MEDICAL_REFUSAL = `I apologize, but this inquiry falls outside the scope of medical, nursing, and clinical healthcare sciences, as well as Axon Nursing Academy portal guidelines. As a specialized healthcare academic mentor, I can only assist with nursing subjects, medical sciences, clinical cases, exam preparation (AIIMS NORCET, ESIC, DSSSB), and portal navigation. Please feel free to ask any medical, clinical, or nursing-related question.`;

export interface ChatMessage {
  role: 'user' | 'model';
  text: string;
}

// Resilient fallback candidate models supported by @google/genai
const CANDIDATE_MODELS = [
  'gemini-3.1-flash-lite',
  'gemini-3.8-flash',
  'gemini-flash-latest',
];

// Lazy-initialized Gemini client
let genAIClient: GoogleGenAI | null = null;
function getGenAI(): GoogleGenAI | null {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    return null;
  }
  if (!genAIClient) {
    genAIClient = new GoogleGenAI({
      apiKey: apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
  }
  return genAIClient;
}

/**
 * Heuristic check to identify non-medical queries early
 */
export function isClearlyNonMedical(query: string): boolean {
  const clean = query.trim().toLowerCase();
  
  // Exclude brief greetings/polite phrases from hard rejection
  if (['hi', 'hello', 'hey', 'namaste', 'good morning', 'good evening', 'who are you', 'help me'].includes(clean)) {
    return false;
  }

  // Strong medical keywords
  const medicalKeywords = [
    'nurse', 'nursing', 'doctor', 'patient', 'hospital', 'clinical', 'medical', 'medicine',
    'norcet', 'aiims', 'esic', 'dsssb', 'cho', 'sgpgi', 'exam', 'mcq', 'rationale',
    'anatomy', 'physiology', 'pathology', 'pharmacology', 'microbiology', 'drug', 'dose', 'dosage',
    'abg', 'ecg', 'gcs', 'blood', 'heart', 'lung', 'kidney', 'liver', 'brain', 'syndrome',
    'disease', 'infection', 'burns', 'shock', 'diabetes', 'hypertension', 'acidosis', 'alkalosis',
    'cpr', 'bls', 'acls', 'cannula', 'catheter', 'iv', 'vital', 'triage', 'wound', 'surgery',
    'preop', 'postop', 'obg', 'pediatric', 'psychiatric', 'mental health', 'community health',
    'axon', 'batch', 'subject', 'chapter', 'test', 'course', 'symptom', 'sign', 'treatment',
    'diagnosis', 'assessment', 'intervention', 'complication', 'antidote', 'insulin', 'digoxin'
  ];

  const hasMedicalTerm = medicalKeywords.some((kw) => clean.includes(kw));
  if (hasMedicalTerm) {
    return false;
  }

  // Obvious non-medical triggers
  const nonMedicalTriggers = [
    'cricket', 'football', 'ipl', 'fifa', 'score', 'match', 'movie', 'actor', 'actress',
    'bollywood', 'hollywood', 'song', 'music', 'album', 'recipe', 'cook', 'bake', 'cake',
    'bitcoin', 'crypto', 'blockchain', 'stock market', 'forex', 'share price', 'trading',
    'python code', 'javascript code', 'write code', 'html css', 'git commit', 'car repair',
    'fashion', 'horoscope', 'zodiac', 'astrology', 'joke', 'standup', 'gaming', 'ps5', 'gta'
  ];

  return nonMedicalTriggers.some((trigger) => clean.includes(trigger));
}

const SYSTEM_INSTRUCTION = `You are Axon AI, the specialized academic clinical mentor and nursing tutor at Axon Nursing Academy.
Your sole domain is medical sciences, nursing education, clinical patient care, pharmacology, anatomy, physiology, microbiology, pathology, community health, obstetrics & gynecological nursing, pediatric nursing, mental health nursing, medical-surgical nursing, nursing foundations, nursing procedures, triage, BLS/ACLS protocols, hospital equipment, drug dosage calculations, diagnostic tests (ABG, ECG, lab values), AIIMS NORCET, ESIC, DSSSB exam preparation, and Axon Nursing Academy portal navigation.

CRITICAL POLICY MANDATE:
If the user asks any question that is NOT related to medical, nursing, healthcare sciences, clinical cases, exam preparation (AIIMS NORCET, ESIC, DSSSB), or Axon Nursing Academy:
You MUST reply with PRECISELY this text, verbatim, with no additional commentary:
"${NON_MEDICAL_REFUSAL}"

FORMATTING GUIDELINES FOR VALID MEDICAL / NURSING INQUIRIES:
- Adopt Google Gemini's elegant, clear, structured explanatory style.
- Use clear markdown with bold headings (##, ###), bullet points, and numbered steps.
- Provide deep clinical rationale: explain the physiological "why" behind nursing interventions and assessments.
- Highlight "Clinical Pearl" or "NORCET High-Yield Point" where applicable.
- For diagnostic or dosage questions, provide standard formulas, normal reference ranges, and critical nursing precautions (e.g., assessing apical pulse before Digoxin, monitor respirations with Morphine).
- Keep the tone encouraging, respectful, and authoritative in clinical nursing standards.`;

/**
 * High-yield fallback clinical knowledge generator for common nursing queries
 * when Gemini API quota is temporarily exhausted, models experience high demand (503), or network is offline.
 */
function getClinicalFallbackAnswer(query: string): string | null {
  const q = query.toLowerCase();

  if (q.includes('abg') || (q.includes('acid') && q.includes('base'))) {
    return `## Arterial Blood Gas (ABG) Analysis & Interpretation

Arterial Blood Gas (ABG) interpretation is one of the highest-yield clinical topics in AIIMS NORCET and intensive care nursing.

### 1. Normal Reference Values (Must Memorize)
* **pH:** 7.35 – 7.45 (Absolute neutral baseline: 7.40)
* **PaCO₂:** 35 – 45 mmHg (Respiratory acid component, regulated by lungs)
* **HCO₃⁻:** 22 – 26 mEq/L (Metabolic alkaline component, regulated by kidneys)
* **PaO₂:** 80 – 100 mmHg
* **SaO₂:** 95 – 100%

---

### 2. Systematic 3-Step Interpretation Method
1. **Analyze pH:**
   * $\\text{pH} < 7.35$ $\\rightarrow$ **Acidosis**
   * $\\text{pH} > 7.45$ $\\rightarrow$ **Alkalosis**
2. **Analyze PaCO₂ & HCO₃⁻ (ROME Principle):**
   * **R**espiratory **O**pposite: When pH moves in the opposite direction of PaCO₂ (e.g., pH $\\downarrow$, PaCO₂ $\\uparrow$ $\\rightarrow$ Respiratory Acidosis).
   * **M**etabolic **E**qual: When pH moves in the same direction as HCO₃⁻ (e.g., pH $\\uparrow$, HCO₃⁻ $\\uparrow$ $\\rightarrow$ Metabolic Alkalosis).
3. **Determine Compensation Status:**
   * **Uncompensated:** pH is abnormal; one parameter is abnormal while the other remains completely normal.
   * **Partially Compensated:** pH is still abnormal; **both** PaCO₂ and HCO₃⁻ are abnormal in their opposing physiological attempt to correct pH.
   * **Fully Compensated:** pH has returned to the normal range (7.35–7.45), but both PaCO₂ and HCO₃⁻ remain abnormal.

---

### 3. Clinical Pearls & NORCET Tips
> 💡 **Allen's Test First:** Prior to performing a radial arterial puncture for ABG sampling, always perform **Allen's Test** to confirm adequate collateral circulation via the ulnar artery. Normal reperfusion time is $< 6$ seconds.
> 💡 **Kussmaul's Respiration:** Seen in Diabetic Ketoacidosis (DKA) as a rapid, deep compensatory respiratory mechanism to blow off CO₂ in metabolic acidosis.`;
  }

  if (q.includes('gcs') || q.includes('glasgow coma')) {
    return `## Glasgow Coma Scale (GCS) Clinical Scoring Guide

The Glasgow Coma Scale (GCS) provides a standardized neurological assessment of a patient's level of consciousness (LOC).

### 1. Score Summary Range
* **Minimum Possible Score:** **3** (Deep coma or brain death)
* **Maximum Possible Score:** **15** (Fully alert, oriented, responsive)
* **Coma Definition:** GCS score $\\le 8$ (**"GCS of 8, prepare to intubate!"**)

---

### 2. The Three Component Assessments (E-V-M)

#### **Eye Opening Response (E - Maximum 4 Points)**
* **4 Points:** Spontaneous eye opening
* **3 Points:** Eye opening to verbal command / speech
* **2 Points:** Eye opening to pain / physical pressure (e.g., trapezius squeeze)
* **1 Point:** No eye opening under any stimulation

#### **Verbal Response (V - Maximum 5 Points)**
* **5 Points:** Oriented to person, place, time, and event
* **4 Points:** Confused conversation, answers coherently but disoriented
* **3 Points:** Inappropriate words (random, disjointed speech)
* **2 Points:** Incomprehensible sounds (moaning, groaning)
* **1 Point:** No verbal sounds (record "T" if endotracheal tube is present: e.g., $E_4V_TM_6$)

#### **Motor Response (M - Maximum 6 Points)**
* **6 Points:** Obeys commands fully
* **5 Points:** Localizes to painful stimuli (purposeful movement across midline)
* **4 Points:** Normal flexion / withdrawal from pain
* **3 Points:** Abnormal flexion (**Decorticate rigidity** — lesions above brainstem / cortex)
* **2 Points:** Abnormal extension (**Decerebrate rigidity** — lesions involving midbrain/pons; worse prognosis)
* **1 Point:** No motor response (flaccid)

---

### 3. Critical Nursing Priorities
* Perform serial GCS assessments; a drop of **$\\ge 2$ points** indicates an acute neurological deterioration requiring immediate physician notification.
* Always check pupil size, symmetry, and light reactivity along with GCS.`;
  }

  if (q.includes('digoxin') || q.includes('lanoxin')) {
    return `## Digoxin (Lanoxin) - High-Yield Nursing Pharmacology

Digoxin is a cardiac glycoside commonly prescribed for congestive heart failure (CHF) and rate control in atrial fibrillation.

### 1. Mechanism of Action
* Inhibits the **Na⁺/K⁺ ATPase pump**, resulting in increased intracellular calcium.
* **Positive Inotropic Effect:** Increases force and velocity of myocardial contraction.
* **Negative Chronotropic Effect:** Decreases heart rate by slowing conduction through the AV node.

---

### 2. Therapeutic Window & Lab Monitoring
* **Therapeutic Serum Level:** **0.5 – 2.0 ng/mL** (Narrow therapeutic index).
* Blood sample for trough level must be drawn **6 to 8 hours** after the last dose.

---

### 3. Critical Nursing Interventions Prior to Administration
1. **Check Apical Pulse:** Always auscultate the apical pulse for **1 full minute** before giving the dose.
   * **Adults:** Withhold medication and notify doctor if apical pulse is $< 60\\text{ bpm}$.
   * **Children:** Withhold if $< 70\\text{ bpm}$.
   * **Infants:** Withhold if $< 90\\text{ bpm}$.
2. **Monitor Potassium ($K^+$) Levels:**
   * **Hypokalemia ($K^+ < 3.5\\text{ mEq/L}$)** potentiates digoxin binding, greatly increasing the risk of lethal toxicity!
   * Closely monitor patients taking loop diuretics (Furosemide / Lasix).

---

### 4. Signs of Digoxin Toxicity
* **Early Gastrointestinal Signs:** Anorexia (most common early sign), nausea, vomiting, abdominal pain.
* **Neurological & Visual Disturbances:** Green-yellow visual halos, blurred vision, photophobia, confusion, delirium.
* **Cardiac Dysrhythmias:** PVCs, AV blocks, bradycardia.

### 5. Specific Antidote
* **Digoxin Immune Fab (DigiFab / Digibind)** binds free digoxin molecules for renal excretion during acute life-threatening toxicity.`;
  }

  if (q.includes('burn') || q.includes('parkland') || q.includes('wallace')) {
    return `## Burns Management: Parkland Formula & Wallace Rule of Nines

### 1. Wallace Rule of Nines (Total Body Surface Area - TBSA in Adults)
* **Head and Neck:** 9% (4.5% anterior + 4.5% posterior)
* **Each Upper Extremity (Arm):** 9% (4.5% front + 4.5% back) $\\times 2 = 18\\%$
* **Anterior Torso (Chest & Abdomen):** 18%
* **Posterior Torso (Back & Buttocks):** 18%
* **Each Lower Extremity (Leg):** 18% (9% front + 9% back) $\\times 2 = 36\\%$
* **Perineum / Genitalia:** 1%
* **Total:** 100% TBSA

---

### 2. Parkland (Baxter) Fluid Resuscitation Formula
Used for calculating intravenous fluid resuscitation in the first 24 hours following severe thermal burn injury ($\\ge 20\\%$ TBSA):

$$\\text{Total 24-hr Fluid} = 4\\text{ mL} \\times \\text{Weight (kg)} \\times \\% \\text{TBSA Burn}$$

* **Choice of Fluid:** **Ringer's Lactate (RL)** (crystalloid of choice).
* **Administration Schedule:**
  * **First 8 Hours:** Give $\\frac{1}{2}$ (50%) of total calculated volume (calculated **from the time of burn injury**, NOT time of hospital admission).
  * **Next 8 Hours (Hours 8–16):** Give $\\frac{1}{4}$ (25%) of total calculated volume.
  * **Final 8 Hours (Hours 16–24):** Give remaining $\\frac{1}{4}$ (25%) of total calculated volume.

---

### 3. Gold Standard for Resuscitation Adequacy
* The most reliable indicator of adequate fluid resuscitation is **Urine Output**:
  * **Adults:** **0.5 to 1.0 mL/kg/hour** (or $30 - 50\\text{ mL/hour}$).
  * **Electrical Burns:** Maintain $75 - 100\\text{ mL/hour}$ to clear myoglobin and prevent Acute Tubular Necrosis (ATN).`;
  }

  if (q.includes('insulin') || q.includes('peak time')) {
    return `## Insulin Types, Onset, Peak Times & Nursing Care

Understanding insulin kinetics is crucial for preventing acute hypoglycemia and managing glycemic emergencies.

| Type | Generic Names | Onset | Peak Effect | Duration | Nursing Notes |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **Rapid-Acting** | Lispro (Humalog), Aspart (NovoLog), Glulisine (Apidra) | 10 – 15 min | **30 – 90 min** | 3 – 5 hrs | Administer within 15 min before meals. Food tray must be ready! |
| **Short-Acting (Regular)** | Humulin R, Novolin R | 30 – 60 min | **2 – 4 hrs** | 5 – 8 hrs | **Only insulin given IV** (e.g. in DKA continuous infusion). Clear solution. |
| **Intermediate-Acting** | NPH (Humulin N, Novolin N) | 1 – 2 hrs | **4 – 12 hrs** | 18 – 24 hrs | Cloudy suspension. Gently roll vial (never shake). |
| **Long-Acting** | Glargine (Lantus), Detemir (Levemir), Degludec | 1 – 2 hrs | **Peakless (Steady)** | 24 hrs | **Never mix with other insulins** in the same syringe! Usually given at bedtime. |

---

### Critical Mixing Rule (Clear Before Cloudy)
When mixing Regular (clear) and NPH (cloudy) insulin:
1. Inject air into **Cloudy (NPH)** vial.
2. Inject air into **Clear (Regular)** vial.
3. Draw up **Clear (Regular)** insulin first.
4. Draw up **Cloudy (NPH)** insulin second.
*(Mnemonic: **RN** — **R**egular before **N**PH).*`;
  }

  if (q.includes('triage') || q.includes('disaster')) {
    return `## Disaster & Emergency Triage System (START Algorithm)

In mass casualty incidents (MCI), disaster triage prioritizes care based on survival probability with available resources using the universal 4-color code.

| Color Code | Category | Priority | Clinical Criteria | Examples |
| :--- | :--- | :--- | :--- | :--- |
| **RED** | Immediate | Priority 1 | Life-threatening conditions with high chance of survival if treated immediately. | Tension pneumothorax, major external hemorrhage, airway obstruction, unstable vitals. |
| **YELLOW** | Delayed | Priority 2 | Serious injuries needing definitive care, but not in immediate danger of death within 1-2 hours. | Stable compound bone fractures, large lacerations with controlled bleeding. |
| **GREEN** | Minimal | Priority 3 | Ambulatory patients ("walking wounded") with minor injuries. | Minor sprains, abrasions, superficial burns. |
| **BLACK** | Expectant / Deceased | Priority 4 | Deceased or injuries so catastrophic that survival is unlikely with available resources. | Massive open cranial trauma with brain matter exposed, absence of spontaneous respiration after opening airway. |`;
  }

  if (q.includes('cardiac drug') || q.includes('acls') || q.includes('adrenaline') || q.includes('atropine') || q.includes('amiodarone')) {
    return `## Emergency Cardiac Drugs in ACLS Resuscitation

Emergency resuscitation drugs are high-alert medications used in Advanced Cardiovascular Life Support (ACLS).

### 1. Adrenaline / Epinephrine
* **Indication:** Cardiac arrest (VF, pulseless VT, asystole, PEA), anaphylaxis, severe symptomatic bradycardia.
* **ACLS Dose in Cardiac Arrest:** **1 mg IV/IO** (1:10,000 dilution) every **3 to 5 minutes**.
* **Mechanism:** Strong $\\alpha_1, \\beta_1, \\beta_2$ adrenergic agonist. Causes peripheral vasoconstriction, increasing coronary and cerebral perfusion pressure.

---

### 2. Amiodarone
* **Indication:** Shock-refractory Ventricular Fibrillation (VF) and pulseless Ventricular Tachycardia (pVT).
* **ACLS Dose in Arrest:**
  * **First Dose:** **300 mg IV/IO push** (after 3rd shock).
  * **Second Dose:** **150 mg IV/IO push** (after 5th shock).
* **Mechanism:** Class III antiarrhythmic (potassium channel blocker) prolonging myocardial action potential.

---

### 3. Atropine Sulfate
* **Indication:** Symptomatic sinus bradycardia ($< 50\\text{ bpm}$ with hypotension, syncope, or chest pain).
* **Dose:** **1 mg IV push** every **3 to 5 minutes** (maximum total dose: **3 mg**).
* **Mechanism:** Anticholinergic / antimuscarinic; blocks vagal stimulation to accelerate SA node firing.

---

### 4. Adenosine
* **Indication:** Paroxysmal Supraventricular Tachycardia (PSVT).
* **Dose:** **6 mg rapid IV push** over 1–2 seconds via large-bore IV close to heart, followed immediately by a **20 mL rapid normal saline flush**. If no conversion in 1–2 minutes, give **12 mg**.
* **Nursing Alert:** Warn the patient of sudden facial flushing, chest tightness, and a brief 2–3 second period of asystole on the monitor!`;
  }

  if (q.includes('norcet') || q.includes('aiims') || q.includes('recurring topic')) {
    return `## AIIMS NORCET: Top High-Yield Recurring Clinical Topics

AIIMS NORCET strongly favors scenario-based clinical decision-making, procedural precautions, and emergency nursing interventions.

### Top 10 High-Frequency NORCET Clinical Domains:
1. **Critical Care & ABG:** ROME rule, compensation identification, ventilator modes (SIMV, CPAP, PEEP), and suctioning complications (hypoxia, vagal stimulation).
2. **Obstetrics & Gynecological Nursing:** Stages of labor, Bishop score, APGAR scoring, PPH management, and Magnesium Sulfate toxicity (antidote: **Calcium Gluconate**).
3. **Cardiovascular & ACLS:** ECG rhythm identification (VT, VF, Asystole, Heart Blocks), defibrillation energy levels (120–200J biphasic, 360J monophasic), and emergency drugs.
4. **Burns:** Wallace Rule of Nines calculation, Parkland fluid resuscitation schedule, and escharotomy monitoring for compartment syndrome.
5. **Pharmacology Antidotes:**
   * Heparin $\\rightarrow$ **Protamine Sulfate**
   * Warfarin $\\rightarrow$ **Vitamin K (Phytonadione)**
   * Paracetamol (Acetaminophen) $\\rightarrow$ **N-Acetylcysteine (NAC)**
   * Opioids (Morphine) $\\rightarrow$ **Naloxone (Narcan)**
   * Digoxin $\\rightarrow$ **Digoxin Immune Fab (DigiFab)**
6. **Infection Control & Biomedical Waste (BMW):** Yellow bag (anatomical/infectious), Red bag (tubings/catheters), White translucent (sharps), Blue (glassware/ampoules).
7. **Pediatric Milestones & Calculations:** Growth milestones, pediatric dehydration scale, and weight-based fluid maintenance (Holliday-Segar method).
8. **Neurology:** GCS assessment, signs of increased ICP (Cushing's triad: bradycardia, systolic hypertension with widened pulse pressure, irregular respirations).
9. **Fluid & Electrolyte Imbalances:** Hypokalemia vs Hyperkalemia ECG changes (peaked T waves vs U waves), Chvostek's & Trousseau's signs in hypocalcemia.
10. **Surgical Nursing:** Post-op wound dehiscence and evisceration management (cover with moist sterile saline gauze, position low Fowler's with knees bent, notify surgeon immediately).`;
  }

  return null;
}

/**
 * Core conversation handler with resilient multi-model failover
 */
export async function handleAxonAIChat(
  messages: ChatMessage[],
  userPrompt: string
): Promise<{ text: string; source: 'gemini' | 'clinical_engine' }> {
  const cleanPrompt = userPrompt.trim();

  // 1. Domain Guardrail Check
  if (isClearlyNonMedical(cleanPrompt)) {
    return {
      text: NON_MEDICAL_REFUSAL,
      source: 'clinical_engine',
    };
  }

  // 2. Try Gemini API with multi-model fallback sequence
  const ai = getGenAI();
  if (ai) {
    // Build conversation contents array
    const contents = messages.map((m) => ({
      role: m.role,
      parts: [{ text: m.text }],
    }));

    // Append current user message
    contents.push({
      role: 'user',
      parts: [{ text: cleanPrompt }],
    });

    for (let i = 0; i < CANDIDATE_MODELS.length; i++) {
      const modelName = CANDIDATE_MODELS[i];
      try {
        const response = await ai.models.generateContent({
          model: modelName,
          contents: contents,
          config: {
            systemInstruction: SYSTEM_INSTRUCTION,
            temperature: 0.6,
          },
        });

        const answerText = response.text;
        if (answerText && answerText.trim().length > 0) {
          return {
            text: answerText,
            source: 'gemini',
          };
        }
      } catch (err: any) {
        const errMsg = err?.message || String(err);
        const isTemporaryOverload =
          errMsg.includes('503') ||
          errMsg.includes('high demand') ||
          errMsg.includes('UNAVAILABLE') ||
          errMsg.includes('429') ||
          errMsg.includes('RESOURCE_EXHAUSTED') ||
          errMsg.includes('quota');

        // If this model is temporarily overloaded or rate limited, gracefully attempt the next model
        if (isTemporaryOverload && i < CANDIDATE_MODELS.length - 1) {
          // Brief 250ms pause before trying the next model
          await new Promise((resolve) => setTimeout(resolve, 250));
          continue;
        }

        // Break if exhausted or non-transient
        break;
      }
    }
  }

  // 3. Fallback to Clinical Knowledge Engine
  const directFallback = getClinicalFallbackAnswer(cleanPrompt);
  if (directFallback) {
    return {
      text: directFallback,
      source: 'clinical_engine',
    };
  }

  // Generic structured nursing explanation for other valid medical questions
  const structuredClinicalResponse = `## Clinical Nursing Analysis: ${cleanPrompt}

### 1. Clinical Overview & Core Concepts
In medical-surgical and advanced nursing practice, addressing **${cleanPrompt}** requires a structured, patient-centered clinical assessment aligned with standard hospital protocols and national licensing standards (AIIMS NORCET, ESIC).

### 2. Key Nursing Assessments & Diagnostic Priorities
* **Primary Survey (Airway, Breathing, Circulation):** Assess hemodynamic stability, oxygen saturation, and baseline vital signs.
* **Targeted Clinical Evaluation:** Check relevant laboratory values (CBC, electrolytes, renal and hepatic profiles) and clinical manifestations.
* **Patient History:** Identify pre-existing comorbidities, medication history, allergies, and onset timeline.

### 3. Nursing Interventions & Rationale
1. **Safety & Positioning:** Maintain patient in an appropriate therapeutic posture (e.g., Semi-Fowler's to maximize diaphragmatic expansion, or elevated limb for venous return).
2. **Medication Administration & Monitoring:** Administer prescribed pharmacological therapy adhering strictly to the **10 Rights of Medication Administration**. Assess for expected therapeutic responses and adverse reactions.
3. **Patient & Family Education:** Provide clear, jargon-free instructions regarding post-discharge care, warning signs requiring immediate emergency evaluation, and dietary/activity modifications.

---

> 💡 **NORCET Clinical Pearl:** Always prioritize interventions using **Maslow's Hierarchy of Needs** and the **ABC Rule (Airway > Breathing > Circulation)**. When faced with multiple clinically sound options, determine which condition poses the immediate threat to patient survival.`;

  return {
    text: structuredClinicalResponse,
    source: 'clinical_engine',
  };
}

