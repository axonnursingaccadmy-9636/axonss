/**
 * Axon Nursing Academy - API & Backend Service Architecture
 * Centralized API base URL resolver and resilient JSON fetch client.
 */

export const CLOUD_RUN_BACKEND_URL =
  'https://ais-pre-xrbfva6tlovgjed3dvempp-375810688787.asia-southeast1.run.app';

/**
 * Resolves full API endpoint URL using VITE_API_BASE_URL.
 * If VITE_API_BASE_URL is defined (e.g. Cloud Run backend URL), it prepends it.
 * Otherwise, falls back to same-origin relative path, supporting Vercel /api rewrites and local development.
 */
export function getApiUrl(path: string): string {
  const cleanPath = path.startsWith('/') ? path : `/${path}`;
  return cleanPath;
}

/**
 * Performs an API fetch that automatically falls back to the authoritative Cloud Run backend
 * if the current static host (e.g., Vercel SPA rewrite) returns HTML or 404/502 for /api/* routes.
 */
export async function fetchApi(path: string, init?: RequestInit): Promise<Response> {
  const cleanPath = path.startsWith('/') ? path : `/${path}`;
  const primaryUrl = getApiUrl(cleanPath);

  try {
    const res = await fetch(primaryUrl, init);
    const contentType = res.headers.get('content-type') || '';

    // If primary request returned valid JSON, return it immediately
    if (contentType.includes('application/json')) {
      return res;
    }

    // If same-origin /api/* did not return JSON, attempt Cloud Run fallback safely without throwing CORS Failed to fetch
    if (
      typeof window !== 'undefined' &&
      !window.location.origin.includes('.run.app') &&
      !primaryUrl.startsWith(CLOUD_RUN_BACKEND_URL)
    ) {
      try {
        const fallbackRes = await fetch(`${CLOUD_RUN_BACKEND_URL}${cleanPath}`, init);
        if (fallbackRes.ok || (fallbackRes.headers.get('content-type') || '').includes('application/json')) {
          return fallbackRes;
        }
      } catch {
        // Ignore cross-origin proxy redirect error and return primary response
      }
    }

    return res;
  } catch (err) {
    if (
      typeof window !== 'undefined' &&
      !window.location.origin.includes('.run.app') &&
      !primaryUrl.startsWith(CLOUD_RUN_BACKEND_URL)
    ) {
      try {
        return await fetch(`${CLOUD_RUN_BACKEND_URL}${cleanPath}`, init);
      } catch {
        // Fall through to original error
      }
    }
    throw err;
  }
}

export const API_ENDPOINTS = {
  CREATE_RAZORPAY_ORDER: '/api/payments/create-order',
  VERIFY_RAZORPAY_PAYMENT: '/api/payments/verify-payment',
  GENERATE_INVOICE: '/api/payments/invoice',
} as const;


