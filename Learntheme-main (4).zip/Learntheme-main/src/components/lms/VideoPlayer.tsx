/**
 * Axon Nursing Academy - Production Video Player Component
 * Supports responsive YouTube educational embedding, Vimeo, and direct MP4 streams.
 */
import React, { useState } from 'react';
import { AlertCircle, VideoOff, Play } from 'lucide-react';
import {
  extractYouTubeVideoId,
  getYouTubeEmbedUrl,
  getYouTubeThumbnailUrl,
} from '@/src/lib/utils/youtubeUtils';

export interface VideoPlayerProps {
  videoUrl?: string;
  youtubeVideoId?: string;
  title?: string;
  poster?: string;
  autoPlay?: boolean;
  className?: string;
}

/**
 * Parses Vimeo video ID from Vimeo URL
 */
function getVimeoEmbedUrl(url: string): string | null {
  try {
    const regExp = /(?:www\.|player\.)?vimeo.com\/(?:channels\/(?:\w+\/)?|groups\/(?:[^\/]*)\/videos\/|album\/(?:\d+)\/video\/|video\/|)(\d+)(?:[a-zA-Z0-9_\-]+)?/;
    const match = url.match(regExp);
    if (match && match[1]) {
      return `https://player.vimeo.com/video/${match[1]}?autoplay=1`;
    }
  } catch {
    // fallback
  }
  return null;
}

export function VideoPlayer({
  videoUrl = '',
  youtubeVideoId,
  title = 'Axon Nursing Lecture',
  poster,
  autoPlay = false,
  className = '',
}: VideoPlayerProps) {
  const [hasError, setHasError] = useState(false);

  // 1. YouTube embedding (Primary Phase 5 Architecture)
  const effectiveYtId = youtubeVideoId || extractYouTubeVideoId(videoUrl);
  if (effectiveYtId) {
    const embedUrl = getYouTubeEmbedUrl(effectiveYtId, {
      autoPlay,
      rel: 0,
      modestbranding: 1,
      controls: 1,
    });

    return (
      <div className={`w-full aspect-video bg-black rounded-2xl overflow-hidden shadow-2xl border border-slate-800 relative ${className}`}>
        <iframe
          src={embedUrl || `https://www.youtube-nocookie.com/embed/${effectiveYtId}?rel=0&modestbranding=1`}
          title={title}
          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
          allowFullScreen
          className="w-full h-full border-0"
        />
      </div>
    );
  }

  // 2. Empty / No Video state
  if (!videoUrl || videoUrl.trim() === '') {
    return (
      <div className={`w-full aspect-video bg-slate-900 rounded-2xl flex flex-col items-center justify-center text-slate-400 p-6 text-center border border-slate-800 ${className}`}>
        <VideoOff className="w-10 h-10 text-slate-600 mb-2" />
        <h4 className="text-sm font-bold text-slate-300">Video Lecture Coming Soon</h4>
        <p className="text-xs text-slate-500 max-w-sm mt-1">
          Faculty is compiling high-yield clinical lecture notes and recording the video stream.
        </p>
      </div>
    );
  }

  // 3. Vimeo Embed
  const vimeoEmbed = getVimeoEmbedUrl(videoUrl);
  if (vimeoEmbed) {
    return (
      <div className={`w-full aspect-video bg-black rounded-2xl overflow-hidden shadow-2xl border border-slate-800 relative ${className}`}>
        <iframe
          src={vimeoEmbed}
          title={title}
          allow="autoplay; fullscreen; picture-in-picture"
          allowFullScreen
          className="w-full h-full border-0"
        />
      </div>
    );
  }

  // 4. Playback Error State
  if (hasError) {
    return (
      <div className={`w-full aspect-video bg-slate-900 rounded-2xl flex flex-col items-center justify-center text-slate-400 p-6 text-center border border-slate-800 ${className}`}>
        <AlertCircle className="w-10 h-10 text-amber-500 mb-2" />
        <h4 className="text-sm font-bold text-slate-300">Playback Unavailable</h4>
        <p className="text-xs text-slate-500 max-w-sm mt-1">
          Unable to decode direct media stream from provided URL.
        </p>
      </div>
    );
  }

  // 5. HTML5 Direct MP4 Video Stream
  return (
    <div className={`w-full aspect-video bg-black rounded-2xl overflow-hidden shadow-2xl border border-slate-800 relative ${className}`}>
      <video
        src={videoUrl}
        poster={poster}
        controls
        controlsList="nodownload"
        autoPlay={autoPlay}
        playsInline
        onError={() => setHasError(true)}
        className="w-full h-full object-contain"
      >
        Your browser does not support HTML5 video playback.
      </video>
    </div>
  );
}

export default VideoPlayer;
