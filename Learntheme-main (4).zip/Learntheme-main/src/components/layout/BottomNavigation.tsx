/**
 * Axon Nursing Academy - Bottom Navigation Bar
 * Optimized for Mobile Touch Targets with Active Route Highlighting.
 */
import React from 'react';
import { NavLink } from 'react-router-dom';
import { Home, BookOpen, Grid, MessageSquare, User, Sparkles, LucideIcon } from 'lucide-react';
import { STUDENT_BOTTOM_NAV_ITEMS } from '@/src/constants/navigation.constants';
import { cn } from '@/src/lib/utils/cn';

const iconComponents: Record<string, LucideIcon> = {
  Home,
  BookOpen,
  Grid,
  MessageSquare,
  User,
  Sparkles,
};

export function BottomNavigation() {
  return (
    <nav
      aria-label="Student Mobile Navigation"
      className="fixed bottom-0 left-0 right-0 z-40 bg-white border-t border-slate-200 shadow-lg md:hidden pb-[env(safe-area-inset-bottom)]"
    >
      <div className="grid grid-cols-5 h-16 max-w-md mx-auto px-1 items-center">
        {STUDENT_BOTTOM_NAV_ITEMS.map((item) => {
          const Icon = iconComponents[item.iconName] || Home;

          return (
            <NavLink
              key={item.id}
              to={item.path}
              end={item.path === '/student'}
              className={({ isActive }) =>
                cn(
                  'flex flex-col items-center justify-center h-full w-full py-1 text-center select-none transition-colors relative min-h-[48px]',
                  isActive ? 'text-blue-600 font-bold' : 'text-slate-500 hover:text-slate-800'
                )
              }
            >
              {({ isActive }) => (
                <>
                  <div className="relative flex items-center justify-center">
                    <Icon
                      className={cn(
                        'w-5 h-5 transition-transform duration-150',
                        isActive ? 'scale-110 stroke-[2.4px]' : 'stroke-[1.8px]'
                      )}
                    />
                    {item.badge && (
                      <span className="absolute -top-1.5 -right-2.5 bg-rose-600 text-white text-[10px] font-bold px-1.5 py-0.2 rounded-full leading-tight ring-2 ring-white">
                        {item.badge}
                      </span>
                    )}
                  </div>
                  <span
                    className={cn(
                      'text-[10px] mt-1 tracking-tight leading-none truncate max-w-[62px]',
                      isActive ? 'font-bold' : 'font-medium'
                    )}
                  >
                    {item.label}
                  </span>
                  {isActive && (
                    <span className="absolute bottom-1 w-6 h-0.5 bg-blue-600 rounded-full" />
                  )}
                </>
              )}
            </NavLink>
          );
        })}
      </div>
    </nav>
  );
}
