/**
 * Axon Nursing Academy - Admin Mobile Bottom Navigation
 * Ultra-accessible mobile navigation bar for smartphones and compact screens.
 */
import React from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import {
  LayoutDashboard,
  BookMarked,
  Layers,
  Video,
  Menu,
} from 'lucide-react';
import { ROUTES } from '@/src/config/routes.config';
import { cn } from '@/src/lib/utils/cn';

export interface AdminMobileBottomNavProps {
  onOpenMenu: () => void;
}

export function AdminMobileBottomNav({ onOpenMenu }: AdminMobileBottomNavProps) {
  const location = useLocation();

  const navItems = [
    {
      label: 'Dashboard',
      path: ROUTES.ADMIN.DASHBOARD,
      icon: LayoutDashboard,
      exact: true,
    },
    {
      label: 'Batches',
      path: ROUTES.ADMIN.BATCHES,
      icon: BookMarked,
    },
    {
      label: 'Subjects',
      path: ROUTES.ADMIN.SUBJECTS,
      icon: Layers,
    },
    {
      label: 'Classes',
      path: ROUTES.ADMIN.CLASSES,
      icon: Video,
    },
  ];

  return (
    <nav
      className="lg:hidden fixed bottom-0 left-0 right-0 z-40 bg-slate-900 border-t border-slate-800 px-2 py-1 flex items-center justify-around shadow-2xl safe-bottom"
      aria-label="Admin mobile navigation"
    >
      {navItems.map((item) => {
        const Icon = item.icon;
        const isActive = item.exact
          ? location.pathname === item.path
          : location.pathname.startsWith(item.path);

        return (
          <NavLink
            key={item.path}
            to={item.path}
            className={cn(
              'flex flex-col items-center justify-center py-1.5 px-3 rounded-xl transition-all select-none min-w-[56px]',
              isActive
                ? 'text-blue-400 font-bold scale-105'
                : 'text-slate-400 hover:text-slate-200'
            )}
          >
            <div
              className={cn(
                'w-8 h-8 rounded-lg flex items-center justify-center transition-colors',
                isActive ? 'bg-blue-600/20 text-blue-400' : 'text-slate-400'
              )}
            >
              <Icon className="w-4 h-4" />
            </div>
            <span className="text-[10px] mt-0.5 tracking-tight font-medium">
              {item.label}
            </span>
          </NavLink>
        );
      })}

      {/* Menu / Drawer trigger button */}
      <button
        type="button"
        onClick={onOpenMenu}
        className="flex flex-col items-center justify-center py-1.5 px-3 rounded-xl text-slate-400 hover:text-slate-200 transition-all select-none min-w-[56px]"
        aria-label="Open all modules menu"
      >
        <div className="w-8 h-8 rounded-lg flex items-center justify-center bg-slate-800 text-slate-300">
          <Menu className="w-4 h-4" />
        </div>
        <span className="text-[10px] mt-0.5 tracking-tight font-medium text-slate-300">
          Menu
        </span>
      </button>
    </nav>
  );
}

export default AdminMobileBottomNav;
