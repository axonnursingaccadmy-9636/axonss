/**
 * Axon Nursing Academy - Admin Responsive Sidebar & Mobile Drawer
 * Seamlessly adapts across Mobile, Tablet, and Desktop screens.
 */
import React from 'react';
import { NavLink } from 'react-router-dom';
import {
  LayoutDashboard,
  BookMarked,
  BookOpen,
  Layers,
  FolderTree,
  Video,
  FileText,
  History,
  Users,
  FileQuestion,
  BellRing,
  Stethoscope,
  GraduationCap,
  ExternalLink,
  X,
  PanelLeftClose,
  PanelLeftOpen,
  Award,
  FileCheck,
  Tag,
  CreditCard,
  Image as ImageIcon,
} from 'lucide-react';
import { ADMIN_SIDEBAR_NAV_ITEMS } from '@/src/constants/navigation.constants';
import { SITE_CONFIG } from '@/src/config/site.config';
import { ROUTES } from '@/src/config/routes.config';
import { cn } from '@/src/lib/utils/cn';
import { useSiteSettings } from '@/src/contexts/SiteSettingsContext';

const iconMap = {
  LayoutDashboard,
  BookMarked,
  BookOpen,
  Layers,
  FolderTree,
  Video,
  FileText,
  History,
  Users,
  FileQuestion,
  BellRing,
  Award,
  FileCheck,
  Tag,
  CreditCard,
  Image: ImageIcon,
};


export interface AdminSidebarProps {
  isMobileOpen: boolean;
  onCloseMobile: () => void;
  isCollapsed: boolean;
  onToggleCollapse: () => void;
}

export function AdminSidebar({
  isMobileOpen,
  onCloseMobile,
  isCollapsed,
  onToggleCollapse,
}: AdminSidebarProps) {
  const { settings } = useSiteSettings();

  // Navigation list component used in both desktop sidebar and mobile drawer
  const renderNavContent = (isMobile = false) => {
    const showText = isMobile || !isCollapsed;

    return (
      <div className="flex flex-col justify-between h-full min-h-0 select-none">
        <div className="flex-1 flex flex-col min-h-0">
          {/* Header & Branding */}
          <div className="h-16 flex items-center justify-between px-4 border-b border-slate-800/80 shrink-0">
            <div className="flex items-center gap-3 min-w-0">
              {settings.logoUrl ? (
                <img
                  src={settings.logoUrl}
                  alt={settings.shortName}
                  className="w-10 h-10 rounded-xl object-contain bg-slate-900 p-0.5 border border-slate-700/60 shrink-0 shadow-lg shadow-blue-500/10"
                />
              ) : (
                <div className="w-10 h-10 rounded-xl bg-blue-600 flex items-center justify-center text-white shrink-0 shadow-lg shadow-blue-500/20">
                  <Stethoscope className="w-5 h-5" />
                </div>
              )}
              {showText && (
                <div className="flex flex-col min-w-0">
                  <span className="font-extrabold text-sm text-white tracking-tight truncate">
                    {settings.shortName || SITE_CONFIG.shortName}
                  </span>
                  <span className="text-[10px] font-bold text-blue-400 uppercase tracking-wider flex items-center gap-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
                    Admin CMS
                  </span>
                </div>
              )}
            </div>

            {/* Mobile close button */}
            {isMobile ? (
              <button
                type="button"
                onClick={onCloseMobile}
                className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
                aria-label="Close menu"
              >
                <X className="w-5 h-5" />
              </button>
            ) : (
              /* Desktop collapse toggle */
              <button
                type="button"
                onClick={onToggleCollapse}
                className="hidden lg:flex p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
                title={isCollapsed ? 'Expand Sidebar' : 'Collapse Sidebar'}
              >
                {isCollapsed ? (
                  <PanelLeftOpen className="w-4 h-4" />
                ) : (
                  <PanelLeftClose className="w-4 h-4" />
                )}
              </button>
            )}
          </div>

          {/* Nav Items List */}
          <div className="p-3 space-y-6 overflow-y-auto flex-1 custom-scrollbar">
            <div>
              {showText && (
                <p className="px-3 text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-2">
                  Core CMS Modules
                </p>
              )}
              <nav className="space-y-1">
                {ADMIN_SIDEBAR_NAV_ITEMS.map((item) => {
                  const Icon = iconMap[item.iconName as keyof typeof iconMap] || LayoutDashboard;

                  return (
                    <NavLink
                      key={item.id}
                      to={item.path}
                      onClick={() => isMobile && onCloseMobile()}
                      title={!showText ? item.label : undefined}
                      className={({ isActive }) =>
                        cn(
                          'flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-semibold transition-all',
                          isActive
                            ? 'bg-blue-600 text-white shadow-md shadow-blue-600/30'
                            : 'text-slate-400 hover:text-slate-100 hover:bg-slate-800/70',
                          !showText && 'justify-center px-0'
                        )
                      }
                    >
                      <Icon className="w-4 h-4 shrink-0" />
                      {showText && <span className="truncate">{item.label}</span>}
                    </NavLink>
                  );
                })}
              </nav>
            </div>

            {/* Upcoming Modules Section */}
            {showText && (
              <div>
                <p className="px-3 text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-2">
                  Upcoming Features
                </p>
                <div className="space-y-1 text-slate-400">
                  <div className="flex items-center justify-between px-3 py-2 rounded-xl text-xs font-medium text-slate-400 opacity-70">
                    <div className="flex items-center gap-2.5">
                      <Video className="w-4 h-4" />
                      <span>Live Faculty Stream</span>
                    </div>
                    <span className="text-[9px] px-1.5 py-0.5 rounded bg-slate-800 text-slate-400 border border-slate-700">Soon</span>
                  </div>
                  <div className="flex items-center justify-between px-3 py-2 rounded-xl text-xs font-medium text-slate-400 opacity-70">
                    <div className="flex items-center gap-2.5">
                      <BellRing className="w-4 h-4" />
                      <span>Push Broadcasts</span>
                    </div>
                    <span className="text-[9px] px-1.5 py-0.5 rounded bg-slate-800 text-slate-400 border border-slate-700">Soon</span>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Footer Switcher */}
        <div className="p-3 border-t border-slate-800/80 shrink-0">
          <NavLink
            to={ROUTES.STUDENT.ROOT}
            onClick={() => isMobile && onCloseMobile()}
            title={!showText ? 'Exit to Student App' : undefined}
            className={cn(
              'flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-xs font-semibold text-slate-300 hover:text-white bg-slate-800/80 hover:bg-slate-800 border border-slate-700/50 transition-colors',
              !showText && 'justify-center px-0'
            )}
          >
            <GraduationCap className="w-4 h-4 text-blue-400 shrink-0" />
            {showText && (
              <div className="flex items-center justify-between w-full">
                <span>Exit to Student App</span>
                <ExternalLink className="w-3.5 h-3.5 text-slate-400" />
              </div>
            )}
          </NavLink>
        </div>
      </div>
    );
  };

  return (
    <>
      {/* 1. Desktop & Laptop Sidebar (Fixed alongside main content on lg+ screens) */}
      <aside
        className={cn(
          'hidden lg:flex bg-slate-900 text-slate-100 min-h-screen border-r border-slate-800 flex-col justify-between shrink-0 z-20',
          isCollapsed ? 'w-20' : 'w-64'
        )}
      >
        {renderNavContent(false)}
      </aside>

      {/* 2. Mobile & Tablet Slide-over Drawer (< lg screens) */}
      {isMobileOpen && (
        <div className="fixed inset-0 z-50 lg:hidden animate-in fade-in duration-200">
          {/* Backdrop overlay */}
          <div
            onClick={onCloseMobile}
            className="fixed inset-0 bg-slate-950/75 transition-opacity"
            aria-hidden="true"
          />

          {/* Slide-in sidebar container */}
          <div className="fixed inset-y-0 left-0 w-72 max-w-[85vw] bg-slate-900 text-slate-100 shadow-2xl transition-transform duration-250 ease-out z-50 flex flex-col">
            {renderNavContent(true)}
          </div>
        </div>
      )}
    </>
  );
}

export default AdminSidebar;
