/**
 * Axon Nursing Academy - Top Navigation Header
 * Designed for mobile-first with responsive desktop scalability.
 */
import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, Bell, Search, Shield, Stethoscope, Sparkles } from 'lucide-react';
import { SITE_CONFIG } from '@/src/config/site.config';
import { ROUTES } from '@/src/config/routes.config';
import { Avatar } from '@/src/components/ui/Avatar';
import { useAuth } from '@/src/contexts/AuthContext';
import { useSiteSettings } from '@/src/contexts/SiteSettingsContext';

export interface TopHeaderProps {
  onMenuClick?: () => void;
  title?: string;
  showSearch?: boolean;
}

export function TopHeader({ onMenuClick, title, showSearch = true }: TopHeaderProps) {
  const { currentUser, profile, isAdmin } = useAuth();
  const { settings } = useSiteSettings();
  const [hasUnreadNotifications] = useState(true);
  const location = useLocation();

  const displayName = profile?.fullName || currentUser?.displayName || currentUser?.email?.split('@')[0] || 'Aspirant';

  return (
    <header className="sticky top-0 z-40 bg-white border-b border-slate-200/80 shadow-xs transition-all">
      <div className="max-w-7xl mx-auto px-3.5 sm:px-6 h-14 sm:h-16 flex items-center justify-between gap-3">
        {/* Left Side: Hamburger & Academy Branding */}
        <div className="flex items-center gap-2.5 sm:gap-4">
          <button
            type="button"
            onClick={onMenuClick}
            className="p-2 -ml-1 text-slate-700 hover:text-blue-700 hover:bg-slate-100 rounded-xl transition-colors active:scale-95 flex items-center justify-center cursor-pointer"
            aria-label="Open Navigation Menu"
          >
            <Menu className="w-5 h-5 sm:w-6 sm:h-6" />
          </button>

          <Link to={ROUTES.STUDENT.ROOT} className="flex items-center gap-2 group select-none">
            {settings.logoUrl ? (
              <img
                src={settings.logoUrl}
                alt={settings.shortName || SITE_CONFIG.shortName}
                className="h-8 sm:h-9 w-auto max-w-[160px] object-contain"
              />
            ) : (
              <>
                <div className="w-8 h-8 sm:w-9 sm:h-9 rounded-xl bg-blue-600 flex items-center justify-center text-white shadow-xs group-hover:bg-blue-700 transition-colors">
                  <Stethoscope className="w-5 h-5" />
                </div>
                <div className="flex flex-col">
                  <div className="flex items-center gap-1.5">
                    <span className="font-extrabold text-sm sm:text-base tracking-tight text-slate-900 leading-none">
                      {settings.shortName || SITE_CONFIG.shortName}
                    </span>
                    <span className="hidden sm:inline-block text-[10px] font-bold bg-blue-50 text-blue-700 px-1.5 py-0.5 rounded border border-blue-100">
                      LMS
                    </span>
                  </div>
                  <span className="text-[10px] text-slate-500 font-medium leading-tight hidden xs:block">
                    Nursing Education Portal
                  </span>
                </div>
              </>
            )}
          </Link>
        </div>

        {/* Center: Desktop Navigation Quick Links */}
        <nav className="hidden md:flex items-center gap-1 lg:gap-2">
          <Link
            to={ROUTES.STUDENT.ROOT}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
              location.pathname === ROUTES.STUDENT.ROOT
                ? 'bg-blue-50 text-blue-700'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
            }`}
          >
            Home
          </Link>
          <Link
            to={ROUTES.STUDENT.COURSES}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
              location.pathname === ROUTES.STUDENT.COURSES
                ? 'bg-blue-50 text-blue-700'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
            }`}
          >
            My Courses
          </Link>
          <Link
            to={ROUTES.STUDENT.ALL_COURSES}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
              location.pathname === ROUTES.STUDENT.ALL_COURSES
                ? 'bg-blue-50 text-blue-700'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
            }`}
          >
            All Courses
          </Link>
          <Link
            to={ROUTES.STUDENT.CHATS}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
              location.pathname === ROUTES.STUDENT.CHATS
                ? 'bg-blue-50 text-blue-700'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
            }`}
          >
            Doubt Room
          </Link>
        </nav>

        {/* Right Side: Notification, Search & Profile */}
        <div className="flex items-center gap-1.5 sm:gap-2.5">
          {showSearch && (
            <Link
              to={ROUTES.STUDENT.ALL_COURSES}
              className="p-2 text-slate-600 hover:text-blue-600 hover:bg-slate-100 rounded-xl transition-colors"
              aria-label="Search courses"
            >
              <Search className="w-4 h-4 sm:w-5 sm:h-5" />
            </Link>
          )}

          {/* Notifications button */}
          <button
            type="button"
            className="relative p-2 text-slate-600 hover:text-blue-600 hover:bg-slate-100 rounded-xl transition-colors cursor-pointer"
            aria-label="Notifications"
          >
            <Bell className="w-4 h-4 sm:w-5 sm:h-5" />
            {hasUnreadNotifications && (
              <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-rose-500 rounded-full ring-2 ring-white" />
            )}
          </button>

          {/* Quick link to Admin Portal only visible to designated admin (pmgautamjaipur@gmail.com) */}
          {isAdmin && (
            <Link
              to={ROUTES.ADMIN.DASHBOARD}
              className="hidden lg:flex items-center gap-1.5 text-xs font-bold text-blue-700 bg-blue-50 hover:bg-blue-100 px-3 py-1.5 rounded-xl transition-all border border-blue-200/80 shadow-xs"
              title="Admin CMS Portal"
            >
              <Shield className="w-3.5 h-3.5 text-blue-700" />
              <span>Admin Portal</span>
            </Link>
          )}

          {/* Student Profile Quick Access */}
          <Link to={ROUTES.STUDENT.PROFILE} className="flex items-center ml-1">
            <Avatar name={displayName} size="sm" />
          </Link>
        </div>
      </div>
    </header>
  );
}
