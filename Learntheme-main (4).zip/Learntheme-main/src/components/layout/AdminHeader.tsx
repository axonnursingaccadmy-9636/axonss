/**
 * Axon Nursing Academy - Production Responsive Admin Header Bar
 * Optimized for Mobile, Tablet, and Desktop screen viewports.
 */
import React, { useState } from 'react';
import {
  ShieldCheck,
  LogOut,
  ExternalLink,
  User,
  Menu,
  PanelLeftClose,
  PanelLeftOpen,
  GraduationCap,
} from 'lucide-react';
import { useAuth } from '@/src/contexts/AuthContext';
import { Avatar } from '@/src/components/ui/Avatar';
import { Badge } from '@/src/components/ui/Badge';
import { Link, useNavigate } from 'react-router-dom';
import { ROUTES } from '@/src/config/routes.config';

export interface AdminHeaderProps {
  title?: string;
  onOpenMobileMenu?: () => void;
  isCollapsed?: boolean;
  onToggleCollapse?: () => void;
}

export function AdminHeader({
  title = 'Axon CMS Controller',
  onOpenMobileMenu,
  isCollapsed = false,
  onToggleCollapse,
}: AdminHeaderProps) {
  const { currentUser, profile, logout } = useAuth();
  const navigate = useNavigate();
  const [menuOpen, setMenuOpen] = useState(false);

  const handleLogout = async () => {
    await logout();
    navigate(ROUTES.LOGIN);
  };

  const adminName =
    profile?.fullName ||
    currentUser?.displayName ||
    currentUser?.email?.split('@')[0] ||
    'Admin Controller';
  const adminEmail = currentUser?.email || profile?.email || 'pmgautamjaipur@gmail.com';

  return (
    <header className="h-16 bg-white border-b border-slate-200 px-3.5 sm:px-6 flex items-center justify-between sticky top-0 z-30">
      {/* Left side: Navigation Toggle + Title */}
      <div className="flex items-center gap-2.5 sm:gap-3 min-w-0">
        {/* Mobile menu trigger */}
        <button
          type="button"
          onClick={onOpenMobileMenu}
          className="lg:hidden p-2 -ml-1 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-xl transition-colors"
          aria-label="Open mobile navigation menu"
        >
          <Menu className="w-5 h-5" />
        </button>

        {/* Desktop collapse toggle */}
        {onToggleCollapse && (
          <button
            type="button"
            onClick={onToggleCollapse}
            className="hidden lg:flex p-2 text-slate-500 hover:text-slate-900 hover:bg-slate-100 rounded-xl transition-colors"
            title={isCollapsed ? 'Expand sidebar' : 'Collapse sidebar'}
            aria-label="Toggle sidebar width"
          >
            {isCollapsed ? (
              <PanelLeftOpen className="w-5 h-5" />
            ) : (
              <PanelLeftClose className="w-5 h-5" />
            )}
          </button>
        )}

        <div className="flex items-center gap-2 min-w-0">
          <h1 className="text-sm sm:text-base md:text-lg font-extrabold text-slate-900 tracking-tight truncate max-w-[160px] sm:max-w-xs md:max-w-md">
            {title}
          </h1>
          <Badge
            variant="emerald"
            size="sm"
            className="hidden md:inline-flex items-center gap-1 font-bold shrink-0"
          >
            <ShieldCheck className="w-3 h-3" />
            Super Admin
          </Badge>
        </div>
      </div>

      {/* Right side: Exit to Student App + Profile Menu */}
      <div className="flex items-center gap-2 sm:gap-3 shrink-0">
        {/* Student View link for Desktop/Tablet */}
        <Link
          to={ROUTES.STUDENT.ROOT}
          className="hidden sm:inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold text-slate-600 bg-slate-100 hover:bg-slate-200 hover:text-slate-900 transition-colors"
        >
          <GraduationCap className="w-3.5 h-3.5 text-blue-600" />
          <span>Student View</span>
          <ExternalLink className="w-3 h-3 text-slate-400" />
        </Link>

        {/* Admin Profile Dropdown */}
        <div className="relative">
          <button
            type="button"
            onClick={() => setMenuOpen(!menuOpen)}
            className="flex items-center gap-2 p-1 sm:p-1.5 rounded-xl hover:bg-slate-100 transition-colors text-left"
          >
            <Avatar name={adminName} size="sm" />
            <div className="hidden sm:flex flex-col text-left">
              <span className="text-xs font-bold text-slate-900 leading-tight truncate max-w-[120px] md:max-w-[160px]">
                {adminName}
              </span>
              <span className="text-[10px] text-blue-600 font-semibold uppercase tracking-wider">
                Admin
              </span>
            </div>
          </button>

          {menuOpen && (
            <>
              <div
                className="fixed inset-0 z-40"
                onClick={() => setMenuOpen(false)}
              />
              <div className="absolute right-0 mt-2 w-60 bg-white rounded-2xl border border-slate-200 shadow-xl p-2 z-50 animate-in fade-in zoom-in-95 duration-150">
                <div className="px-3 py-2.5 border-b border-slate-100">
                  <p className="text-xs font-bold text-slate-900 truncate">
                    {adminName}
                  </p>
                  <p className="text-[11px] text-slate-500 truncate font-mono">
                    {adminEmail}
                  </p>
                  <span className="inline-block mt-1 text-[10px] font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md border border-emerald-200">
                    Active Super Admin
                  </span>
                </div>
                <div className="py-1">
                  <Link
                    to={ROUTES.STUDENT.ROOT}
                    onClick={() => setMenuOpen(false)}
                    className="flex items-center gap-2 px-3 py-2 text-xs font-medium text-slate-700 hover:bg-slate-100 rounded-lg sm:hidden"
                  >
                    <GraduationCap className="w-4 h-4 text-blue-600" />
                    <span>Switch to Student App</span>
                  </Link>
                  <Link
                    to={ROUTES.STUDENT.PROFILE}
                    onClick={() => setMenuOpen(false)}
                    className="flex items-center gap-2 px-3 py-2 text-xs font-medium text-slate-700 hover:bg-slate-100 rounded-lg"
                  >
                    <User className="w-4 h-4 text-slate-400" />
                    <span>My Profile</span>
                  </Link>
                  <button
                    type="button"
                    onClick={handleLogout}
                    className="w-full flex items-center gap-2 px-3 py-2 text-xs font-semibold text-rose-600 hover:bg-rose-50 rounded-lg text-left"
                  >
                    <LogOut className="w-4 h-4 text-rose-500" />
                    <span>Sign Out</span>
                  </button>
                </div>
              </div>
            </>
          )}
        </div>
      </div>
    </header>
  );
}

export default AdminHeader;
