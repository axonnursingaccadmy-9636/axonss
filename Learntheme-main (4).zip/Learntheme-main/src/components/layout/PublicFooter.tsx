/**
 * Axon Nursing Academy - Public Footer
 */
import React from 'react';
import { Link } from 'react-router-dom';
import { Stethoscope, Mail, Phone, Heart } from 'lucide-react';
import { SITE_CONFIG } from '@/src/config/site.config';
import { ROUTES } from '@/src/config/routes.config';
import { useSiteSettings } from '@/src/contexts/SiteSettingsContext';

export function PublicFooter() {
  const { settings } = useSiteSettings();
  const effectiveFooterLogo = settings.footerLogoUrl || settings.logoUrl;

  return (
    <footer className="bg-slate-900 text-slate-300 border-t border-slate-800 text-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-10">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Brand Col */}
          <div className="space-y-3 md:col-span-2">
            <div className="flex items-center gap-2 text-white">
              {effectiveFooterLogo ? (
                <img
                  src={effectiveFooterLogo}
                  alt={settings.siteName || SITE_CONFIG.name}
                  className="h-9 w-auto max-w-[180px] object-contain"
                />
              ) : (
                <>
                  <div className="w-8 h-8 rounded-lg bg-blue-600 flex items-center justify-center text-white">
                    <Stethoscope className="w-4 h-4" />
                  </div>
                  <span className="font-bold text-base">{settings.siteName || SITE_CONFIG.name}</span>
                </>
              )}
            </div>
            <p className="text-slate-400 text-xs max-w-sm leading-relaxed">
              {settings.footerText || SITE_CONFIG.description}
            </p>
            <div className="flex items-center gap-4 pt-2 text-slate-400">
              <div className="flex items-center gap-1.5">
                <Mail className="w-3.5 h-3.5 text-blue-400" />
                <span>{settings.supportEmail || SITE_CONFIG.supportEmail}</span>
              </div>
              <div className="flex items-center gap-1.5">
                <Phone className="w-3.5 h-3.5 text-emerald-400" />
                <span>{settings.supportPhone || SITE_CONFIG.supportPhone}</span>
              </div>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-bold text-white mb-3 uppercase tracking-wider text-[11px]">
              Portals & Courses
            </h4>
            <ul className="space-y-2">
              <li>
                <Link to={ROUTES.STUDENT.ROOT} className="hover:text-blue-400 transition-colors">
                  Student Learning Portal
                </Link>
              </li>
              <li>
                <Link to={ROUTES.STUDENT.ALL_COURSES} className="hover:text-blue-400 transition-colors">
                  NORCET / AIIMS Batches
                </Link>
              </li>
              <li>
                <Link to={ROUTES.STUDENT.ALL_COURSES} className="hover:text-blue-400 transition-colors">
                  NCLEX-RN Masterclass
                </Link>
              </li>
              <li>
                <Link to={ROUTES.STUDENT.ALL_COURSES} className="hover:text-blue-400 transition-colors">
                  State CHO & Staff Nurse
                </Link>
              </li>
            </ul>
          </div>

          {/* Legal / Info */}
          <div>
            <h4 className="font-bold text-white mb-3 uppercase tracking-wider text-[11px]">
              Academy Policies
            </h4>
            <ul className="space-y-2 text-slate-400">
              <li>Terms of Service</li>
              <li>Privacy & Data Security</li>
              <li>Refund & Cancellation</li>
              <li>Student Honor Code</li>
            </ul>
          </div>
        </div>

        <div className="mt-8 pt-6 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-2 text-slate-500 text-[11px]">
          <p>© {new Date().getFullYear()} {SITE_CONFIG.name}. All rights reserved.</p>
          <p className="flex items-center gap-1">
            <span>Built with precision for nursing professionals</span>
          </p>
        </div>
      </div>
    </footer>
  );
}
