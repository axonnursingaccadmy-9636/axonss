/**
 * Axon Nursing Academy - Mobile Slide-Out Drawer Navigation
 */
import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import {
  X,
  User,
  BookOpen,
  Grid,
  FileCheck,
  Video,
  PhoneCall,
  Shield,
  LogOut,
  LogIn,
  ChevronRight,
  Stethoscope,
  Sparkles,
} from 'lucide-react';
import { ROUTES } from '@/src/config/routes.config';
import { SITE_CONFIG } from '@/src/config/site.config';
import { useScrollLock } from '@/src/hooks/useScrollLock';
import { Avatar } from '@/src/components/ui/Avatar';
import { Badge } from '@/src/components/ui/Badge';
import { useAuth } from '@/src/contexts/AuthContext';
import { useSiteSettings } from '@/src/contexts/SiteSettingsContext';

export interface DrawerMenuProps {
  isOpen: boolean;
  onClose: () => void;
}

export function DrawerMenu({ isOpen, onClose }: DrawerMenuProps) {
  useScrollLock(isOpen);
  const navigate = useNavigate();
  const { currentUser, profile, isAuthenticated, isAdmin, logout } = useAuth();
  const { settings } = useSiteSettings();

  if (!isOpen) return null;

  const displayName = profile?.fullName || currentUser?.displayName || currentUser?.email?.split('@')[0] || 'Nursing Aspirant';
  const email = profile?.email || currentUser?.email || 'Student Portal Access';

  const handleLogout = async () => {
    onClose();
    try {
      await logout();
      navigate(ROUTES.LOGIN, { replace: true });
    } catch (error) {
      console.error('Logout error:', error);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden animate-in fade-in duration-200">
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-slate-900/70 transition-opacity"
        onClick={onClose}
        aria-hidden="true"
      />

      <div className="fixed inset-y-0 left-0 max-w-xs w-full bg-white shadow-2xl z-10 flex flex-col justify-between overflow-y-auto animate-in slide-in-from-left duration-250">
        <div>
          {/* Header & User Card */}
          <div className="bg-gradient-to-br from-blue-700 to-indigo-900 text-white p-5">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                {settings.logoUrl ? (
                  <img
                    src={settings.logoUrl}
                    alt={settings.shortName || SITE_CONFIG.shortName}
                    className="h-8 w-auto max-w-[140px] object-contain rounded bg-white/10 p-1"
                  />
                ) : (
                  <>
                    <div className="w-8 h-8 rounded-lg bg-white/20 flex items-center justify-center text-white">
                      <Stethoscope className="w-5 h-5" />
                    </div>
                    <span className="font-bold text-sm tracking-tight">{settings.shortName || SITE_CONFIG.shortName}</span>
                  </>
                )}
              </div>
              <button
                type="button"
                onClick={onClose}
                className="p-1.5 text-white/80 hover:text-white rounded-lg hover:bg-white/10"
                aria-label="Close menu"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="flex items-center gap-3 pt-2">
              <Avatar name={displayName} size="lg" className="border-2 border-white/40" />
              <div className="min-w-0 flex-1">
                <h3 className="font-bold text-sm leading-snug truncate">{displayName}</h3>
                <p className="text-xs text-blue-200/90 truncate font-mono">{email}</p>
                <Badge variant="emerald" size="sm" className="mt-1.5 bg-emerald-500/20 text-emerald-300 border-emerald-400/30">
                  {isAuthenticated ? 'Active Student' : 'Guest'}
                </Badge>
              </div>
            </div>
          </div>

          {/* Navigation Links */}
          <div className="p-3 space-y-1">
            <div className="px-3 py-2 text-[11px] font-bold uppercase tracking-wider text-slate-400">
              Learning Portal
            </div>

            <Link
              to={ROUTES.STUDENT.ROOT}
              onClick={onClose}
              className="flex items-center justify-between px-3 py-2.5 rounded-xl text-sm font-medium text-slate-700 hover:text-blue-700 hover:bg-blue-50 transition-colors"
            >
              <div className="flex items-center gap-3">
                <BookOpen className="w-4 h-4 text-blue-600" />
                <span>Student Home</span>
              </div>
              <ChevronRight className="w-4 h-4 text-slate-400" />
            </Link>

            <Link
              to={ROUTES.STUDENT.COURSES}
              onClick={onClose}
              className="flex items-center justify-between px-3 py-2.5 rounded-xl text-sm font-medium text-slate-700 hover:text-blue-700 hover:bg-blue-50 transition-colors"
            >
              <div className="flex items-center gap-3">
                <Grid className="w-4 h-4 text-blue-600" />
                <span>My Enrolled Batches</span>
              </div>
              <ChevronRight className="w-4 h-4 text-slate-400" />
            </Link>

            <Link
              to={ROUTES.STUDENT.ALL_COURSES}
              onClick={onClose}
              className="flex items-center justify-between px-3 py-2.5 rounded-xl text-sm font-medium text-slate-700 hover:text-blue-700 hover:bg-blue-50 transition-colors"
            >
              <div className="flex items-center gap-3">
                <FileCheck className="w-4 h-4 text-amber-600" />
                <span>All Courses & Test Series</span>
              </div>
              <ChevronRight className="w-4 h-4 text-slate-400" />
            </Link>

            <Link
              to={ROUTES.STUDENT.CHATS}
              onClick={onClose}
              className="flex items-center justify-between px-3 py-2.5 rounded-xl text-sm font-medium text-slate-700 hover:text-blue-700 hover:bg-blue-50 transition-colors"
            >
              <div className="flex items-center gap-3">
                <Sparkles className="w-4 h-4 text-blue-600" />
                <span>Axon AI (Doubt Room)</span>
              </div>
              <span className="text-xs font-bold text-blue-600 bg-blue-50 px-2 py-0.5 rounded-full border border-blue-100">AI Mentor</span>
            </Link>

            <Link
              to={ROUTES.STUDENT.PROFILE}
              onClick={onClose}
              className="flex items-center justify-between px-3 py-2.5 rounded-xl text-sm font-medium text-slate-700 hover:text-blue-700 hover:bg-blue-50 transition-colors"
            >
              <div className="flex items-center gap-3">
                <User className="w-4 h-4 text-slate-600" />
                <span>My Profile & Settings</span>
              </div>
              <ChevronRight className="w-4 h-4 text-slate-400" />
            </Link>

            <div className="pt-3 px-3 py-2 text-[11px] font-bold uppercase tracking-wider text-slate-400">
              Support & Help
            </div>

            {isAdmin && (
              <Link
                to={ROUTES.ADMIN.DASHBOARD}
                onClick={onClose}
                className="flex items-center justify-between px-3 py-2.5 rounded-xl text-sm font-bold text-blue-700 bg-blue-50/80 hover:bg-blue-100 transition-colors border border-blue-200/70"
              >
                <div className="flex items-center gap-3">
                  <Shield className="w-4 h-4 text-blue-700" />
                  <span>Admin Portal CMS</span>
                </div>
                <Badge variant="purple" size="sm">Admin</Badge>
              </Link>
            )}

            <a
              href={`tel:${SITE_CONFIG.supportPhone}`}
              className="flex items-center justify-between px-3 py-2.5 rounded-xl text-sm font-medium text-slate-700 hover:text-blue-700 hover:bg-blue-50 transition-colors"
            >
              <div className="flex items-center gap-3">
                <PhoneCall className="w-4 h-4 text-emerald-600" />
                <span>Student Helpline</span>
              </div>
              <ChevronRight className="w-4 h-4 text-slate-400" />
            </a>
          </div>
        </div>

        {/* Footer info & Logout action */}
        <div className="p-4 border-t border-slate-100 bg-slate-50/50">
          {isAuthenticated ? (
            <button
              type="button"
              onClick={handleLogout}
              className="w-full flex items-center gap-2.5 text-xs font-semibold text-rose-600 hover:text-rose-700 p-2 rounded-lg hover:bg-rose-50 transition-colors cursor-pointer"
            >
              <LogOut className="w-4 h-4" />
              <span>Sign Out Account</span>
            </button>
          ) : (
            <Link
              to={ROUTES.LOGIN}
              onClick={onClose}
              className="flex items-center gap-2.5 text-xs font-semibold text-blue-600 hover:text-blue-700 p-2 rounded-lg hover:bg-blue-50 transition-colors"
            >
              <LogIn className="w-4 h-4" />
              <span>Student Sign In</span>
            </Link>
          )}
          <div className="text-[10px] text-slate-400 mt-2 text-center">
            {SITE_CONFIG.name} • Nursing Learning Portal
          </div>
        </div>
      </div>
    </div>
  );
}

export default DrawerMenu;
