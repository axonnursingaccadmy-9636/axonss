/**
 * Axon Nursing Academy - Reusable Authentication Layout Component
 *
 * Implements:
 * - Responsive, screen-centered card container with polished backdrop
 * - App metadata branding (Axon Nursing Academy, logo, tagline, exam prep badges)
 * - Notice banners for error/warning states (Firebase configuration alerts, server validation errors)
 * - Reusable slot for login, signup, and forgot-password form children
 * - Links to alternative auth actions and support contacts
 */
import React, { ReactNode } from 'react';
import { Link } from 'react-router-dom';
import { Stethoscope, AlertCircle, ShieldCheck, CheckCircle2 } from 'lucide-react';
import { SITE_CONFIG } from '@/src/config/site.config';
import { ROUTES } from '@/src/config/routes.config';
import { useSiteSettings } from '@/src/contexts/SiteSettingsContext';
import { useAuth } from '@/src/contexts/AuthContext';

export interface AuthLayoutProps {
  /** Main title displayed at top of the auth card */
  title: string;
  /** Subtitle providing context or instructions */
  subtitle?: string;
  /** Primary form or screen content */
  children: ReactNode;
  /** Optional alert message to display above form (e.g. from server or client validation) */
  errorMessage?: string | null;
  /** Optional success message to display */
  successMessage?: string | null;
  /** Alternative action prompt at bottom of card */
  footerAction?: {
    prompt: string;
    actionText: string;
    href: string;
  };
  /** Additional custom footer elements */
  footerExtra?: ReactNode;
  /** Max card width (default max-w-md: 28rem / 448px) */
  maxWidth?: 'sm' | 'md' | 'lg';
  /** Whether to show the top back-to-home link */
  showBackToHome?: boolean;
}

export function AuthLayout({
  title,
  subtitle,
  children,
  errorMessage,
  successMessage,
  footerAction,
  footerExtra,
  maxWidth = 'md',
  showBackToHome = true,
}: AuthLayoutProps) {
  const { settings } = useSiteSettings();
  const { isFirebaseReady } = useAuth();

  const brandName = settings.siteName || SITE_CONFIG.name;
  const brandShortName = settings.shortName || SITE_CONFIG.shortName;
  const brandTagline = settings.tagline || SITE_CONFIG.tagline;
  const brandLogo = settings.logoUrl;

  const maxWidthClass = {
    sm: 'max-w-sm',
    md: 'max-w-md',
    lg: 'max-w-lg',
  }[maxWidth];

  return (
    <div
      id="auth-layout-container"
      className="min-h-[82vh] sm:min-h-[86vh] flex items-center justify-center p-4 sm:p-6 my-auto"
    >
      <div className={`w-full ${maxWidthClass} mx-auto`}>
        {/* Optional Back to Home Navigation */}
        {showBackToHome && (
          <div className="mb-4 flex items-center justify-between text-xs text-slate-500 px-1">
            <Link
              to={ROUTES.HOME}
              className="inline-flex items-center gap-1.5 hover:text-blue-600 transition-colors font-medium"
            >
              <span>← Back to {brandShortName}</span>
            </Link>
            <span className="text-[11px] text-slate-400 font-mono">Secure Auth</span>
          </div>
        )}

        {/* Central Auth Card */}
        <div
          id="auth-card"
          className="bg-white rounded-3xl border border-slate-200/90 p-6 sm:p-8 shadow-xl shadow-slate-200/50 relative overflow-hidden"
        >
          {/* Subtle Top Accent Border */}
          <div className="absolute top-0 left-0 right-0 h-1.5 bg-gradient-to-r from-blue-600 via-indigo-600 to-emerald-500" />

          {/* Branding Header */}
          <div className="text-center mb-6 pt-1">
            <Link
              to={ROUTES.HOME}
              className="inline-flex flex-col items-center group transition-transform duration-150 hover:scale-[1.02]"
            >
              {brandLogo ? (
                <img
                  src={brandLogo}
                  alt={brandName}
                  className="h-12 w-auto max-w-[220px] object-contain mx-auto mb-3"
                />
              ) : (
                <div className="w-13 h-13 rounded-2xl bg-blue-600 text-white flex items-center justify-center mx-auto mb-3 shadow-md shadow-blue-500/20 group-hover:bg-blue-700 transition-colors">
                  <Stethoscope className="w-7 h-7" />
                </div>
              )}
              <span className="text-xs font-bold uppercase tracking-widest text-blue-600 mb-1">
                {brandShortName}
              </span>
            </Link>

            <h1 className="text-xl sm:text-2xl font-extrabold text-slate-900 tracking-tight">
              {title}
            </h1>

            {subtitle ? (
              <p className="text-xs text-slate-500 mt-1.5 leading-relaxed max-w-sm mx-auto">
                {subtitle}
              </p>
            ) : (
              <p className="text-xs text-slate-500 mt-1.5">
                {brandTagline}
              </p>
            )}
          </div>

          {/* Configuration / Health Notice if Firebase credentials missing */}
          {!isFirebaseReady && (
            <div
              id="auth-firebase-notice"
              role="status"
              className="mb-5 p-3.5 bg-amber-50 border border-amber-200 rounded-2xl text-xs text-amber-800 flex items-start gap-2.5"
            >
              <AlertCircle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
              <div>
                <p className="font-bold">Authentication Service Unavailable</p>
                <p className="text-[11px] text-amber-700 mt-0.5">
                  Authentication service is not configured correctly. Please contact support.
                </p>
              </div>
            </div>
          )}

          {/* Form-Level Error State Notification */}
          {errorMessage && (
            <div
              id="auth-error-banner"
              role="alert"
              className="mb-5 p-3.5 bg-rose-50 border border-rose-200 rounded-2xl text-xs text-rose-800 flex items-start gap-2.5 animate-in fade-in duration-200"
            >
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
              <div className="flex-1 font-medium">{errorMessage}</div>
            </div>
          )}

          {/* Form-Level Success State Notification */}
          {successMessage && (
            <div
              id="auth-success-banner"
              role="status"
              className="mb-5 p-3.5 bg-emerald-50 border border-emerald-200 rounded-2xl text-xs text-emerald-800 flex items-start gap-2.5 animate-in fade-in duration-200"
            >
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              <div className="flex-1 font-medium">{successMessage}</div>
            </div>
          )}

          {/* Form Body Slot */}
          <div id="auth-form-content">{children}</div>

          {/* Footer Action Slot (e.g. "Don't have an account? Sign Up") */}
          {footerAction && (
            <div
              id="auth-footer-action"
              className="mt-6 pt-5 border-t border-slate-100 text-center text-xs text-slate-600"
            >
              <span>{footerAction.prompt} </span>
              <Link
                to={footerAction.href}
                className="font-bold text-blue-600 hover:text-blue-700 hover:underline transition-colors"
              >
                {footerAction.actionText}
              </Link>
            </div>
          )}

          {footerExtra}
        </div>

        {/* Bottom Trust & Compliance Badge */}
        <div className="mt-6 text-center text-[11px] text-slate-400 flex items-center justify-center gap-2">
          <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
          <span>Encrypted 256-Bit SSL • Axon Academic Cloud</span>
        </div>
      </div>
    </div>
  );
}

export default AuthLayout;
