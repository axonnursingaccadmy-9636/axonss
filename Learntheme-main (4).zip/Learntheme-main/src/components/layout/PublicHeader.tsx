/**
 * Axon Nursing Academy - Public Landing Header
 */
import React from 'react';
import { Link } from 'react-router-dom';
import { Stethoscope, LogIn, ArrowRight, User } from 'lucide-react';
import { SITE_CONFIG } from '@/src/config/site.config';
import { ROUTES } from '@/src/config/routes.config';
import { Button } from '@/src/components/ui/Button';
import { useAuth } from '@/src/contexts/AuthContext';
import { useSiteSettings } from '@/src/contexts/SiteSettingsContext';

export function PublicHeader() {
  const { isAuthenticated, currentUser } = useAuth();
  const { settings } = useSiteSettings();
  const displayName = currentUser?.displayName || currentUser?.email?.split('@')[0] || 'My Account';

  return (
    <header className="sticky top-0 z-40 bg-white border-b border-slate-200/80 shadow-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between">
        {/* Brand */}
        <Link to={ROUTES.HOME} className="flex items-center gap-2.5">
          {settings.logoUrl ? (
            <img
              src={settings.logoUrl}
              alt={settings.siteName || SITE_CONFIG.name}
              className="h-10 w-auto max-w-[200px] object-contain"
            />
          ) : (
            <>
              <div className="w-9 h-9 rounded-xl bg-blue-600 flex items-center justify-center text-white shadow-xs">
                <Stethoscope className="w-5 h-5" />
              </div>
              <div>
                <span className="font-extrabold text-base tracking-tight text-slate-900 leading-none">
                  {settings.shortName || SITE_CONFIG.shortName}
                </span>
                <p className="text-[10px] text-slate-500 font-medium leading-tight">
                  {settings.tagline || 'Nursing LMS & Competitive Academy'}
                </p>
              </div>
            </>
          )}
        </Link>

        {/* Public Navigation */}
        <div className="flex items-center gap-3">
          {isAuthenticated ? (
            <Link to={ROUTES.STUDENT.ROOT}>
              <Button variant="primary" size="sm" rightIcon={<ArrowRight className="w-3.5 h-3.5" />}>
                Student Portal
              </Button>
            </Link>
          ) : (
            <>
              <Link to={ROUTES.SIGNUP}>
                <Button variant="outline" size="sm">
                  Register
                </Button>
              </Link>
              <Link to={ROUTES.LOGIN}>
                <Button variant="primary" size="sm" leftIcon={<LogIn className="w-3.5 h-3.5" />}>
                  Sign In
                </Button>
              </Link>
            </>
          )}
        </div>
      </div>
    </header>
  );
}

export default PublicHeader;
