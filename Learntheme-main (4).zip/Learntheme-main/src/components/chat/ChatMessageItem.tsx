/**
 * Axon Nursing Academy - ChatMessageItem Component
 * Renders individual user query or Google Gemini-style AI response with markdown formatting & action buttons.
 */
import React, { useState } from 'react';
import ReactMarkdown from 'react-markdown';
import { Sparkles, Copy, Check, Volume2, VolumeX, ThumbsUp, ThumbsDown, RotateCcw, User } from 'lucide-react';

export interface ChatMessageData {
  id: string;
  role: 'user' | 'model';
  text: string;
  timestamp: string;
  source?: 'gemini' | 'clinical_engine';
}

interface ChatMessageItemProps {
  message: ChatMessageData;
  studentName?: string;
  onRetry?: (text: string) => void;
  isLast?: boolean;
}

export function ChatMessageItem({
  message,
  studentName = 'Student',
  onRetry,
  isLast = false,
}: ChatMessageItemProps) {
  const [copied, setCopied] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);
  const [feedback, setFeedback] = useState<'up' | 'down' | null>(null);

  const isUser = message.role === 'user';

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(message.text);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error('Failed to copy text', err);
    }
  };

  const handleToggleSpeech = () => {
    if (!('speechSynthesis' in window)) return;

    if (isPlaying) {
      window.speechSynthesis.cancel();
      setIsPlaying(false);
      return;
    }

    window.speechSynthesis.cancel();
    // Clean markdown symbols for cleaner TTS narration
    const cleanText = message.text
      .replace(/[*#>`_~]/g, '')
      .replace(/\[(.*?)\]\(.*?\)/g, '$1')
      .trim();

    const utterance = new SpeechSynthesisUtterance(cleanText);
    utterance.rate = 1.0;
    utterance.pitch = 1.0;
    utterance.onend = () => setIsPlaying(false);
    utterance.onerror = () => setIsPlaying(false);

    setIsPlaying(true);
    window.speechSynthesis.speak(utterance);
  };

  if (isUser) {
    return (
      <div className="flex justify-end items-start gap-3 my-4 group animate-in fade-in slide-in-from-bottom-2 duration-200">
        <div className="max-w-2xl bg-blue-600 text-white px-4 py-3 rounded-2xl rounded-tr-xs shadow-xs text-sm sm:text-base leading-relaxed break-words font-medium">
          {message.text}
        </div>
        <div className="w-8 h-8 rounded-full bg-blue-100 text-blue-700 flex items-center justify-center shrink-0 text-xs font-bold ring-2 ring-blue-50">
          <User className="w-4 h-4" />
        </div>
      </div>
    );
  }

  return (
    <div className="flex justify-start items-start gap-3 sm:gap-4 my-6 group animate-in fade-in slide-in-from-bottom-2 duration-200 max-w-4xl">
      {/* Gemini Sparkles Avatar */}
      <div className="w-8 h-8 sm:w-9 sm:h-9 rounded-full bg-gradient-to-tr from-blue-600 via-indigo-600 to-sky-400 text-white flex items-center justify-center shrink-0 shadow-xs ring-2 ring-blue-100 mt-1">
        <Sparkles className="w-4 h-4 sm:w-4.5 sm:h-4.5" />
      </div>

      <div className="flex-1 min-w-0 space-y-3">
        {/* Author header */}
        <div className="flex items-center gap-2">
          <span className="text-xs sm:text-sm font-bold text-slate-900 tracking-tight">
            Axon AI
          </span>
          <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-blue-50 text-blue-700 border border-blue-100/60">
            Nursing & Clinical Mentor
          </span>
          <span className="text-[11px] text-slate-400">
            {new Date(message.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
          </span>
        </div>

        {/* Formatted Markdown Content */}
        <div className="text-slate-800 text-sm sm:text-[15px] leading-relaxed space-y-3 prose prose-slate max-w-none prose-headings:font-bold prose-headings:text-slate-900 prose-h2:text-lg prose-h2:mt-4 prose-h2:mb-2 prose-h3:text-base prose-h3:mt-3 prose-h3:mb-1.5 prose-p:my-2 prose-ul:my-2 prose-li:my-0.5 prose-strong:text-slate-900 prose-strong:font-bold prose-blockquote:border-l-4 prose-blockquote:border-blue-500 prose-blockquote:bg-blue-50/50 prose-blockquote:py-1 prose-blockquote:px-3 prose-blockquote:rounded-r-lg prose-blockquote:text-slate-700 prose-blockquote:not-italic prose-table:my-3 prose-th:bg-slate-100 prose-th:p-2 prose-td:p-2 prose-td:border prose-th:border">
          <ReactMarkdown>{message.text}</ReactMarkdown>
        </div>

        {/* Action Buttons Toolbar (Gemini Style) */}
        <div className="flex items-center gap-1 sm:gap-2 pt-2 border-t border-slate-100 text-slate-500">
          <button
            onClick={handleCopy}
            className="p-1.5 rounded-lg hover:bg-slate-100 hover:text-slate-800 transition-colors flex items-center gap-1 text-xs font-medium"
            title="Copy response"
          >
            {copied ? (
              <>
                <Check className="w-3.5 h-3.5 text-emerald-600" />
                <span className="text-[11px] text-emerald-600 font-semibold">Copied</span>
              </>
            ) : (
              <>
                <Copy className="w-3.5 h-3.5" />
                <span className="hidden sm:inline text-[11px]">Copy</span>
              </>
            )}
          </button>

          {'speechSynthesis' in window && (
            <button
              onClick={handleToggleSpeech}
              className={`p-1.5 rounded-lg hover:bg-slate-100 transition-colors flex items-center gap-1 text-xs font-medium ${
                isPlaying ? 'text-blue-600 bg-blue-50' : 'hover:text-slate-800'
              }`}
              title={isPlaying ? 'Stop speaking' : 'Read aloud'}
            >
              {isPlaying ? (
                <>
                  <VolumeX className="w-3.5 h-3.5" />
                  <span className="text-[11px]">Stop</span>
                </>
              ) : (
                <>
                  <Volume2 className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline text-[11px]">Listen</span>
                </>
              )}
            </button>
          )}

          <div className="h-3 w-px bg-slate-200 mx-1" />

          <button
            onClick={() => setFeedback(feedback === 'up' ? null : 'up')}
            className={`p-1.5 rounded-lg hover:bg-slate-100 transition-colors ${
              feedback === 'up' ? 'text-emerald-600 bg-emerald-50' : 'hover:text-slate-800'
            }`}
            title="Good clinical answer"
          >
            <ThumbsUp className="w-3.5 h-3.5" />
          </button>

          <button
            onClick={() => setFeedback(feedback === 'down' ? null : 'down')}
            className={`p-1.5 rounded-lg hover:bg-slate-100 transition-colors ${
              feedback === 'down' ? 'text-rose-600 bg-rose-50' : 'hover:text-slate-800'
            }`}
            title="Needs improvement"
          >
            <ThumbsDown className="w-3.5 h-3.5" />
          </button>

          {isLast && onRetry && (
            <button
              onClick={() => onRetry(message.text)}
              className="p-1.5 rounded-lg hover:bg-slate-100 hover:text-slate-800 transition-colors ml-auto flex items-center gap-1 text-xs text-slate-500"
              title="Regenerate response"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span className="hidden sm:inline text-[11px]">Regenerate</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
export default ChatMessageItem;
