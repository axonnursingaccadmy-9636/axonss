/**
 * Axon Nursing Academy - ChatSidebar Component
 * Google Gemini-style collapsible sidebar for managing conversation history & starting new chats.
 */
import React from 'react';
import { Link } from 'react-router-dom';
import {
  Plus,
  MessageSquare,
  Trash2,
  X,
  Sparkles,
  ArrowLeft,
  BookOpen,
  User,
  ShieldCheck,
} from 'lucide-react';

export interface ChatSession {
  id: string;
  title: string;
  createdAt: string;
  updatedAt: string;
  preview: string;
}

interface ChatSidebarProps {
  isOpen: boolean;
  onClose: () => void;
  sessions: ChatSession[];
  currentSessionId: string | null;
  onSelectSession: (sessionId: string) => void;
  onNewChat: () => void;
  onDeleteSession: (sessionId: string, e: React.MouseEvent) => void;
}

export function ChatSidebar({
  isOpen,
  onClose,
  sessions,
  currentSessionId,
  onSelectSession,
  onNewChat,
  onDeleteSession,
}: ChatSidebarProps) {
  return (
    <>
      {/* Mobile Backdrop */}
      {isOpen && (
        <div
          onClick={onClose}
          className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs z-40 md:hidden transition-opacity"
        />
      )}

      {/* Sidebar Container */}
      <aside
        className={`fixed md:static inset-y-0 left-0 z-50 w-72 sm:w-80 bg-slate-900 text-slate-100 flex flex-col transition-transform duration-200 ease-in-out shadow-xl md:shadow-none ${
          isOpen ? 'translate-x-0' : '-translate-x-full md:translate-x-0 md:w-72'
        }`}
      >
        {/* Top Header */}
        <div className="p-4 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-blue-500 to-sky-400 text-white flex items-center justify-center shadow-xs">
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-white tracking-tight">Axon AI</h2>
              <p className="text-[11px] text-slate-400">Nursing & Clinical Mentor</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 md:hidden transition-colors"
            title="Close sidebar"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* New Chat Primary Button (Gemini Style) */}
        <div className="p-3">
          <button
            onClick={() => {
              onNewChat();
              if (window.innerWidth < 768) onClose();
            }}
            className="w-full py-2.5 px-4 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white font-semibold text-xs flex items-center justify-center gap-2 shadow-sm transition-all duration-150"
          >
            <Plus className="w-4 h-4 stroke-[2.5]" />
            <span>New Clinical Chat</span>
          </button>
        </div>

        {/* Recent Conversations List */}
        <div className="flex-1 overflow-y-auto px-3 py-2 space-y-1">
          <div className="px-2 py-1.5 text-[11px] font-bold text-slate-400 uppercase tracking-wider">
            Recent Conversations
          </div>

          {sessions.length === 0 ? (
            <div className="p-4 text-center text-xs text-slate-500">
              No previous conversations yet. Ask your first clinical question!
            </div>
          ) : (
            sessions.map((session) => {
              const isSelected = session.id === currentSessionId;
              return (
                <div
                  key={session.id}
                  onClick={() => {
                    onSelectSession(session.id);
                    if (window.innerWidth < 768) onClose();
                  }}
                  className={`group relative flex items-center justify-between p-2.5 rounded-xl cursor-pointer text-xs font-medium transition-colors ${
                    isSelected
                      ? 'bg-slate-800 text-white font-semibold'
                      : 'text-slate-300 hover:bg-slate-800/60 hover:text-white'
                  }`}
                >
                  <div className="flex items-center gap-2.5 min-w-0 pr-2">
                    <MessageSquare className={`w-3.5 h-3.5 shrink-0 ${isSelected ? 'text-blue-400' : 'text-slate-500'}`} />
                    <span className="truncate">{session.title || 'New Nursing Doubt'}</span>
                  </div>

                  <button
                    onClick={(e) => onDeleteSession(session.id, e)}
                    className="opacity-0 group-hover:opacity-100 p-1 rounded-md hover:bg-slate-700 text-slate-400 hover:text-rose-400 transition-opacity"
                    title="Delete conversation"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              );
            })
          )}
        </div>

        {/* Portal Shortcuts & Scope Guardrail Notice */}
        <div className="p-3 border-t border-slate-800 space-y-2 bg-slate-950/40">
          <div className="flex items-center gap-2 text-[10px] text-slate-400 bg-slate-800/60 p-2 rounded-lg">
            <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>Strict Medical & Nursing Domain Guardrails Active</span>
          </div>

          <div className="flex items-center justify-between text-xs pt-1">
            <Link
              to="/student"
              className="flex items-center gap-1.5 text-slate-400 hover:text-white transition-colors"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>Back to Portal</span>
            </Link>

            <Link
              to="/student/courses"
              className="flex items-center gap-1.5 text-slate-400 hover:text-white transition-colors"
            >
              <BookOpen className="w-3.5 h-3.5" />
              <span>My Courses</span>
            </Link>
          </div>
        </div>
      </aside>
    </>
  );
}
export default ChatSidebar;
