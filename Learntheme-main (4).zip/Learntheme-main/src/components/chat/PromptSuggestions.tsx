/**
 * Axon Nursing Academy - PromptSuggestions Component
 * Renders Google Gemini-style empty state with greeting and prompt starter cards.
 */
import React from 'react';
import { Sparkles, Stethoscope, Pill, Brain, Flame, Activity, ShieldAlert, Award } from 'lucide-react';

interface PromptSuggestionsProps {
  studentName?: string;
  onSelectPrompt: (promptText: string) => void;
}

const HIGH_YIELD_PROMPTS = [
  {
    id: 'abg',
    icon: Stethoscope,
    title: 'ABG Analysis & Compensation',
    desc: 'Step-by-step interpretation of pH, PaCO2, HCO3 with ROME rationale & uncompensated vs compensated states.',
    prompt: 'Explain ABG analysis step-by-step with ROME principle, normal values, and how to identify partial vs full compensation.',
    tag: 'Critical Care',
  },
  {
    id: 'digoxin',
    icon: Pill,
    title: 'Digoxin Toxicity & Nursing Care',
    desc: 'Therapeutic window, signs of toxicity, hypokalemia risk, apical pulse threshold & DigiFab antidote.',
    prompt: 'What are the high-yield nursing points for Digoxin (Lanoxin)? Explain mechanism, therapeutic levels, toxicity signs, and nursing precautions.',
    tag: 'Pharmacology',
  },
  {
    id: 'gcs',
    icon: Brain,
    title: 'Glasgow Coma Scale (GCS)',
    desc: 'Breakdown of Eye (4), Verbal (5), and Motor (6) scoring, intubation criteria & serial monitoring.',
    prompt: 'Provide a complete breakdown of the Glasgow Coma Scale (GCS) scoring criteria, decorticate vs decerebrate posturing, and intubation threshold.',
    tag: 'Neurology',
  },
  {
    id: 'parkland',
    icon: Flame,
    title: 'Parkland Burns Fluid Formula',
    desc: 'Wallace Rule of Nines, 24-hr Ringer Lactate fluid volume calculation, and urine output targets.',
    prompt: 'How to calculate 24-hour fluid resuscitation in burns using the Parkland formula? Include Wallace Rule of Nines and urine output goals.',
    tag: 'Medical-Surgical',
  },
];

const TOPIC_CHIPS = [
  { label: 'AIIMS NORCET High-Yield', icon: Award, prompt: 'What are the top 5 high-yield recurring clinical topics in AIIMS NORCET exam?' },
  { label: 'Emergency Cardiac Drugs', icon: Activity, prompt: 'List emergency cardiac drugs used in ACLS (Adrenaline, Atropine, Amiodarone) with dosages and nursing precautions.' },
  { label: 'Insulin Types & Peak Times', icon: Pill, prompt: 'Compare Rapid, Short, Intermediate, and Long-acting insulin types with their onset, peak times, and hypoglycemia risks.' },
  { label: 'Triage Color Coding', icon: ShieldAlert, prompt: 'Explain the Disaster Triage color coding system (Red, Yellow, Green, Black) with clinical criteria.' },
];

export function PromptSuggestions({
  studentName = 'Aspirant',
  onSelectPrompt,
}: PromptSuggestionsProps) {
  return (
    <div className="max-w-3xl mx-auto py-6 sm:py-10 px-2 animate-in fade-in duration-300">
      {/* Gemini Header */}
      <div className="mb-8 sm:mb-10 text-left">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-50 border border-blue-200/60 text-blue-700 text-xs font-semibold mb-3">
          <Sparkles className="w-3.5 h-3.5 text-blue-600" />
          <span>Axon AI 2.0 • Nursing Academic Mentor</span>
        </div>

        <h1 className="text-3xl sm:text-4xl md:text-5xl font-extrabold tracking-tight bg-gradient-to-r from-blue-700 via-indigo-600 to-sky-500 bg-clip-text text-transparent">
          Hello, {studentName}
        </h1>
        <p className="text-xl sm:text-2xl font-bold text-slate-400 mt-1 sm:mt-2">
          How can I assist your nursing & clinical studies today?
        </p>
      </div>

      {/* 4 Prompt Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4 mb-6">
        {HIGH_YIELD_PROMPTS.map((item) => {
          const Icon = item.icon;
          return (
            <button
              key={item.id}
              onClick={() => onSelectPrompt(item.prompt)}
              className="group text-left p-4 rounded-2xl bg-white border border-slate-200/90 hover:border-blue-500 hover:shadow-md hover:bg-blue-50/20 transition-all duration-200 flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between mb-2">
                  <div className="w-8 h-8 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center group-hover:bg-blue-600 group-hover:text-white transition-colors">
                    <Icon className="w-4 h-4" />
                  </div>
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-slate-100 text-slate-600 group-hover:bg-blue-100 group-hover:text-blue-800 transition-colors">
                    {item.tag}
                  </span>
                </div>
                <h3 className="text-sm font-bold text-slate-900 group-hover:text-blue-700 transition-colors">
                  {item.title}
                </h3>
                <p className="text-xs text-slate-500 mt-1 line-clamp-2 leading-relaxed">
                  {item.desc}
                </p>
              </div>

              <div className="mt-3 pt-2 border-t border-slate-100 flex items-center text-[11px] font-semibold text-blue-600">
                <span>Ask this clinical doubt</span>
                <span className="ml-1 transform group-hover:translate-x-1 transition-transform">→</span>
              </div>
            </button>
          );
        })}
      </div>

      {/* Quick Topic Chips */}
      <div>
        <p className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2.5">
          Explore High-Yield Subjects
        </p>
        <div className="flex flex-wrap gap-2">
          {TOPIC_CHIPS.map((chip, idx) => {
            const Icon = chip.icon;
            return (
              <button
                key={idx}
                onClick={() => onSelectPrompt(chip.prompt)}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white border border-slate-200 hover:border-blue-400 hover:bg-slate-50 text-xs font-semibold text-slate-700 hover:text-blue-700 transition-all shadow-2xs"
              >
                <Icon className="w-3.5 h-3.5 text-slate-500" />
                <span>{chip.label}</span>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}
export default PromptSuggestions;
