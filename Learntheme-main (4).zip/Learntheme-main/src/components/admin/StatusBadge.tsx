/**
 * Axon Nursing Academy - Admin Status Badge & Indicators
 */
import React from 'react';
import { Badge } from '@/src/components/ui/Badge';
import { CheckCircle2, AlertCircle, Eye, EyeOff, Sparkles } from 'lucide-react';

export interface PublishStatusBadgeProps {
  isPublished: boolean;
  size?: 'sm' | 'md';
}

export function PublishStatusBadge({ isPublished, size = 'sm' }: PublishStatusBadgeProps) {
  if (isPublished) {
    return (
      <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-200">
        <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
        Published
      </span>
    );
  }

  return (
    <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-bold bg-slate-100 text-slate-600 border border-slate-200">
      <span className="w-1.5 h-1.5 rounded-full bg-slate-400"></span>
      Draft / Hidden
    </span>
  );
}

export interface FreeBadgeProps {
  isFree: boolean;
}

export function FreeBadge({ isFree }: FreeBadgeProps) {
  if (isFree) {
    return (
      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold bg-purple-50 text-purple-700 border border-purple-200">
        <Sparkles className="w-3 h-3" />
        Free Preview
      </span>
    );
  }
  return null;
}
