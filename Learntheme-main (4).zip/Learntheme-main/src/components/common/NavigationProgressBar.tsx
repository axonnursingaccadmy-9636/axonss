/**
 * Axon Nursing Academy - Top Navigation Progress Bar & Viewport Repaint Stabilizer
 * Provides visual route transition feedback, resets scroll position, and forces clean
 * compositor tile invalidation when toggling "Desktop site" mode on mobile browsers.
 */
import { useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import NProgress from 'nprogress';

NProgress.configure({
  showSpinner: false,
  trickleSpeed: 150,
  minimum: 0.15,
});

export function NavigationProgressBar() {
  const location = useLocation();

  useEffect(() => {
    NProgress.start();
    // Ensure all scroll containers reset cleanly on route transition
    window.scrollTo({ top: 0, left: 0, behavior: 'instant' as ScrollBehavior });
    document.documentElement.scrollTop = 0;
    document.body.scrollTop = 0;

    const timer = setTimeout(() => {
      NProgress.done();
    }, 180);

    return () => {
      clearTimeout(timer);
      NProgress.done();
    };
  }, [location.pathname, location.search]);

  // Stabilize compositor tiles when switching between Mobile view and "Desktop site" mode on mobile browsers
  useEffect(() => {
    let lastWidth = window.innerWidth;

    const handleViewportChange = () => {
      const currentWidth = window.innerWidth;
      if (Math.abs(currentWidth - lastWidth) > 100) {
        lastWidth = currentWidth;
        document.documentElement.style.removeProperty('overflow');
        document.body.style.removeProperty('overflow');
        // Trigger clean layout & paint invalidation across the full viewport height
        const root = document.getElementById('root');
        if (root) {
          root.style.minHeight = `${window.innerHeight}px`;
          requestAnimationFrame(() => {
            root.style.minHeight = '';
          });
        }
      }
    };

    window.addEventListener('resize', handleViewportChange, { passive: true });
    window.visualViewport?.addEventListener('resize', handleViewportChange, { passive: true });

    return () => {
      window.removeEventListener('resize', handleViewportChange);
      window.visualViewport?.removeEventListener('resize', handleViewportChange);
    };
  }, []);

  return null;
}

export default NavigationProgressBar;
