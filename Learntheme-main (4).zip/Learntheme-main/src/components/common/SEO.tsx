/**
 * Axon Nursing Academy - Reusable SEO & Metadata Component
 * Dynamically synchronizes document title, meta tags, OpenGraph, Twitter cards,
 * canonical URLs, and structured Schema.org JSON-LD data for SPA routing.
 */
import React, { useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import { SITE_CONFIG } from '@/src/config/site.config';

export interface SEOProps {
  /**
   * Page title. Will be formatted as `${title} | ${SITE_CONFIG.name}` if appendBrand is true.
   */
  title?: string;
  /**
   * Overrides the complete title without appending brand name.
   */
  fullTitle?: string;
  /**
   * Page meta description (120-160 characters recommended).
   */
  description?: string;
  /**
   * Keywords for meta tag.
   */
  keywords?: string[];
  /**
   * OpenGraph image URL for social preview cards.
   */
  ogImage?: string;
  /**
   * OpenGraph type (website, article, etc.). Defaults to 'website'.
   */
  ogType?: 'website' | 'article' | 'profile';
  /**
   * Whether to append site name to title. Defaults to true.
   */
  appendBrand?: boolean;
  /**
   * Custom Schema.org JSON-LD object for rich snippets.
   */
  structuredData?: Record<string, unknown>;
  /**
   * Prevent search engines from indexing this page (e.g. admin or private pages).
   */
  noIndex?: boolean;
}

export const SEO: React.FC<SEOProps> = ({
  title,
  fullTitle,
  description = 'Axon Nursing Academy provides premier preparation for NORCET, NCLEX-RN, State CHO & MSc Nursing competitive exams with interactive live classes, mock tests, and AI mentors.',
  keywords = [
    'nursing academy',
    'NORCET exam preparation',
    'NCLEX-RN prep',
    'CHO exam',
    'MSc nursing coaching',
    'nursing test series',
    'medical mock tests',
  ],
  ogImage = '/banner.jpg',
  ogType = 'website',
  appendBrand = true,
  structuredData,
  noIndex = false,
}) => {
  const location = useLocation();

  useEffect(() => {
    // 1. Resolve Document Title
    const brandName = SITE_CONFIG.name || 'Axon Nursing Academy';
    const computedTitle = fullTitle
      ? fullTitle
      : title
      ? appendBrand
        ? `${title} | ${brandName}`
        : title
      : `${brandName} | Premier Online Nursing Education`;

    document.title = computedTitle;

    // 2. Canonical URL
    const canonicalUrl =
      typeof window !== 'undefined'
        ? `${window.location.origin}${location.pathname}`
        : '';

    // Helper to get or create meta tags
    const setMetaTag = (selector: string, attrName: string, attrValue: string, content: string) => {
      let element = document.querySelector(selector) as HTMLMetaElement | null;
      if (!element) {
        element = document.createElement('meta');
        element.setAttribute(attrName, attrValue);
        document.head.appendChild(element);
      }
      element.setAttribute('content', content);
    };

    // Helper to get or create link tags
    const setLinkTag = (rel: string, href: string) => {
      let element = document.querySelector(`link[rel="${rel}"]`) as HTMLLinkElement | null;
      if (!element) {
        element = document.createElement('link');
        element.setAttribute('rel', rel);
        document.head.appendChild(element);
      }
      element.setAttribute('href', href);
    };

    // 3. Set standard meta tags
    setMetaTag('meta[name="description"]', 'name', 'description', description);
    if (keywords && keywords.length > 0) {
      setMetaTag('meta[name="keywords"]', 'name', 'keywords', keywords.join(', '));
    }
    setMetaTag(
      'meta[name="robots"]',
      'name',
      'robots',
      noIndex ? 'noindex, nofollow' : 'index, follow, max-image-preview:large'
    );

    // 4. OpenGraph Tags
    setMetaTag('meta[property="og:title"]', 'property', 'og:title', computedTitle);
    setMetaTag('meta[property="og:description"]', 'property', 'og:description', description);
    setMetaTag('meta[property="og:type"]', 'property', 'og:type', ogType);
    setMetaTag('meta[property="og:site_name"]', 'property', 'og:site_name', brandName);
    if (canonicalUrl) {
      setMetaTag('meta[property="og:url"]', 'property', 'og:url', canonicalUrl);
      setLinkTag('canonical', canonicalUrl);
    }
    if (ogImage) {
      const absoluteImage = ogImage.startsWith('http')
        ? ogImage
        : typeof window !== 'undefined'
        ? `${window.location.origin}${ogImage}`
        : ogImage;
      setMetaTag('meta[property="og:image"]', 'property', 'og:image', absoluteImage);
    }

    // 5. Twitter Card Tags
    setMetaTag('meta[name="twitter:card"]', 'name', 'twitter:card', 'summary_large_image');
    setMetaTag('meta[name="twitter:title"]', 'name', 'twitter:title', computedTitle);
    setMetaTag('meta[name="twitter:description"]', 'name', 'twitter:description', description);
    if (ogImage) {
      const absoluteImage = ogImage.startsWith('http')
        ? ogImage
        : typeof window !== 'undefined'
        ? `${window.location.origin}${ogImage}`
        : ogImage;
      setMetaTag('meta[name="twitter:image"]', 'name', 'twitter:image', absoluteImage);
    }

    // 6. Schema.org JSON-LD Structured Data
    const scriptId = 'axon-structured-data';
    let scriptElement = document.getElementById(scriptId) as HTMLScriptElement | null;

    const defaultStructuredData = structuredData || {
      '@context': 'https://schema.org',
      '@type': 'EducationalOrganization',
      name: brandName,
      url: typeof window !== 'undefined' ? window.location.origin : '',
      description: description,
      sameAs: [
        SITE_CONFIG.socialLinks?.youtube || '',
        SITE_CONFIG.socialLinks?.telegram || '',
        SITE_CONFIG.socialLinks?.instagram || '',
      ].filter(Boolean),
    };

    if (!scriptElement) {
      scriptElement = document.createElement('script');
      scriptElement.id = scriptId;
      scriptElement.type = 'application/ld+json';
      document.head.appendChild(scriptElement);
    }
    scriptElement.textContent = JSON.stringify(defaultStructuredData);

    // Cleanup: reset document title on unmount if needed
    return () => {
      // Keep title in place or let next component overwrite
    };
  }, [
    title,
    fullTitle,
    description,
    keywords,
    ogImage,
    ogType,
    appendBrand,
    structuredData,
    noIndex,
    location.pathname,
  ]);

  return null;
};

export default SEO;
