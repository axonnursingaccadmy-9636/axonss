/**
 * Axon Nursing Academy - Production Image Upload Field Component
 * Supports direct file picking from computer/phone, drag-and-drop,
 * real-time 0% -> 100% upload progress bar, preview, remove, and fallback URL entry.
 */
import React, { useRef, useState } from 'react';
import {
  Upload,
  Trash2,
  RefreshCw,
  AlertCircle,
  CheckCircle2,
  ExternalLink,
  Link2,
} from 'lucide-react';
import {
  uploadImageWithFallback,
  uploadBrandingImage,
  validateImageFile,
} from '@/src/services/firebase/storageService';

export interface ImageUploadFieldProps {
  label: string;
  value: string;
  onChange: (url: string) => void;
  helperText?: string;
  placeholder?: string;
  aspectRatio?: 'video' | 'banner' | 'square' | 'wide' | 'auto';
  folder?: 'thumbnails' | 'banners' | 'branding' | 'general';
  brandingType?: 'logo' | 'footer' | 'favicon';
  required?: boolean;
  disabled?: boolean;
  maxSizeMB?: number;
  previewBg?: 'light' | 'dark';
}

export function ImageUploadField({
  label,
  value,
  onChange,
  helperText,
  placeholder = 'Select or drop a photo here...',
  aspectRatio = 'video',
  folder = 'thumbnails',
  brandingType,
  required = false,
  disabled = false,
  maxSizeMB = 10,
  previewBg = 'light',
}: ImageUploadFieldProps) {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState<number | null>(null);
  const [lastUploadedName, setLastUploadedName] = useState<string>('');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [showUrlInput, setShowUrlInput] = useState(false);

  // Aspect ratio styling
  const aspectClasses = {
    video: 'aspect-video w-full max-w-sm',
    banner: 'aspect-[3/1] w-full max-w-lg',
    square: 'w-24 h-24 sm:w-28 sm:h-28',
    wide: 'aspect-[16/7] w-full max-w-md',
    auto: 'h-32 w-auto max-w-xs',
  }[aspectRatio];

  const handleFileSelect = async (file: File) => {
    if (!file) return;

    setErrorMessage(null);

    // Validation
    const validation = validateImageFile(file);
    if (!validation.valid) {
      setErrorMessage(validation.error || 'Invalid image file.');
      return;
    }

    if (file.size > maxSizeMB * 1024 * 1024) {
      setErrorMessage(`Image size exceeds limit of ${maxSizeMB}MB.`);
      return;
    }

    setLastUploadedName(file.name);
    setIsUploading(true);
    setUploadProgress(5);

    try {
      let finalUrl = '';
      if (folder === 'branding' && brandingType) {
        finalUrl = await uploadBrandingImage(file, brandingType, {
          onProgress: (p) => setUploadProgress(p),
        });
      } else {
        finalUrl = await uploadImageWithFallback(file, folder, {
          onProgress: (p) => setUploadProgress(p),
        });
      }

      setUploadProgress(100);
      onChange(finalUrl);
      await new Promise((r) => setTimeout(r, 350));
    } catch (err: any) {
      console.error('Photo upload error:', err);
      setErrorMessage(err.message || 'Failed to process photo.');
      setUploadProgress(null);
    } finally {
      setIsUploading(false);
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    if (!disabled && !isUploading) {
      setIsDragging(true);
    }
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (disabled || isUploading) return;

    const droppedFile = e.dataTransfer.files?.[0];
    if (droppedFile) {
      handleFileSelect(droppedFile);
    }
  };

  const handleClear = (e: React.MouseEvent) => {
    e.stopPropagation();
    onChange('');
    setUploadProgress(null);
    setLastUploadedName('');
    setErrorMessage(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  return (
    <div className="space-y-1.5 w-full">
      {/* Label and Top Actions */}
      <div className="flex items-center justify-between">
        <label className="text-xs sm:text-sm font-bold text-slate-800 flex items-center gap-1">
          {label}
          {required && <span className="text-rose-500">*</span>}
        </label>
        <button
          type="button"
          onClick={() => setShowUrlInput(!showUrlInput)}
          className="text-[11px] font-semibold text-blue-600 hover:text-blue-800 hover:underline flex items-center gap-1 transition-colors"
        >
          <Link2 className="w-3 h-3" />
          {showUrlInput ? 'Hide URL input' : 'Paste link instead'}
        </button>
      </div>

      {/* Hidden File Input */}
      <input
        ref={fileInputRef}
        type="file"
        accept="image/jpeg,image/png,image/webp,image/svg+xml,image/x-icon"
        className="hidden"
        disabled={disabled || isUploading}
        onChange={(e) => {
          const file = e.target.files?.[0];
          if (file) handleFileSelect(file);
        }}
      />

      {/* Dropzone & Preview Box */}
      <div
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
        className={`relative border-2 border-dashed rounded-xl transition-all p-3 ${
          isDragging
            ? 'border-blue-500 bg-blue-50/70 scale-[1.005]'
            : 'border-slate-200 hover:border-slate-300 bg-slate-50/50'
        } ${disabled ? 'opacity-60 pointer-events-none' : ''}`}
      >
        {value ? (
          /* Has Image Preview */
          <div className="flex flex-col sm:flex-row items-center gap-3">
            <div
              className={`relative overflow-hidden rounded-lg border border-slate-200 shadow-xs shrink-0 flex items-center justify-center ${aspectClasses} ${
                previewBg === 'dark' ? 'bg-slate-900' : 'bg-white'
              }`}
            >
              <img
                src={value}
                alt={label}
                className="w-full h-full object-contain"
                onError={(e) => {
                  (e.target as HTMLImageElement).src =
                    'data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="100" height="100" viewBox="0 0 24 24" fill="none" stroke="%2394a3b8" stroke-width="2"><rect width="18" height="18" x="3" y="3" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><path d="m21 15-5-5L5 21"/></svg>';
                }}
              />
              {isUploading && (
                <div className="absolute inset-0 bg-slate-900/75 flex flex-col items-center justify-center text-white p-2">
                  <RefreshCw className="w-5 h-5 animate-spin text-blue-400 mb-1" />
                  <span className="text-xs font-extrabold">{uploadProgress ?? 0}%</span>
                  <span className="text-[10px] font-semibold text-slate-200">Uploading...</span>
                </div>
              )}
            </div>

            <div className="flex-1 min-w-0 w-full space-y-2">
              <div className="flex items-center gap-1.5 text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-lg text-xs font-bold w-fit border border-emerald-200">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                <span>
                  {uploadProgress === 100
                    ? '100% Uploaded • Photo Ready'
                    : 'Photo Attached'}
                </span>
              </div>
              <p className="text-[11px] text-slate-500 truncate max-w-full font-mono">
                {lastUploadedName
                  ? `${lastUploadedName} (100% Uploaded)`
                  : value.startsWith('data:')
                  ? 'Custom Photo Uploaded'
                  : value}
              </p>
              <div className="flex items-center gap-2 pt-1">
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  disabled={isUploading}
                  className="px-3 py-1.5 text-xs font-bold text-blue-700 bg-blue-50 hover:bg-blue-100 rounded-lg border border-blue-200 flex items-center gap-1.5 transition-colors cursor-pointer active:scale-95"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${isUploading ? 'animate-spin' : ''}`} />
                  Change Photo
                </button>
                <button
                  type="button"
                  onClick={handleClear}
                  disabled={isUploading}
                  className="px-3 py-1.5 text-xs font-bold text-rose-700 bg-rose-50 hover:bg-rose-100 rounded-lg border border-rose-200 flex items-center gap-1.5 transition-colors cursor-pointer active:scale-95"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  Remove
                </button>
              </div>
            </div>
          </div>
        ) : (
          /* Empty State - Photo Upload Button */
          <div className="flex flex-col items-center justify-center py-4 px-2 text-center">
            <div className="w-11 h-11 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center mb-2.5 shadow-xs border border-blue-100">
              {isUploading ? (
                <RefreshCw className="w-5 h-5 animate-spin text-blue-600" />
              ) : (
                <Upload className="w-5 h-5 text-blue-600" />
              )}
            </div>

            <p className="text-xs sm:text-sm font-bold text-slate-800 mb-0.5">
              {isUploading ? `Uploading photo... ${uploadProgress ?? 0}%` : placeholder}
            </p>
            <p className="text-[11px] text-slate-500 mb-3 max-w-xs">
              Drag and drop an image, or click below to select from your device.
            </p>

            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              disabled={isUploading}
              className="px-4 py-2 text-xs sm:text-sm font-extrabold text-white bg-blue-600 hover:bg-blue-700 rounded-xl shadow-xs hover:shadow-md transition-all active:scale-95 flex items-center gap-2 cursor-pointer"
            >
              <Upload className="w-4 h-4" />
              {isUploading ? `Uploading (${uploadProgress ?? 0}%)` : 'Upload Photo'}
            </button>
          </div>
        )}

        {/* Live Upload Progress Bar (0% -> 100%) */}
        {(isUploading || (uploadProgress !== null && uploadProgress > 0 && uploadProgress < 100)) && (
          <div className="mt-3 pt-2.5 border-t border-slate-200/80 space-y-1.5">
            <div className="flex items-center justify-between text-xs font-extrabold">
              <span className="text-blue-700 flex items-center gap-1.5">
                <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                Uploading file...
              </span>
              <span className="text-blue-700 font-mono">{uploadProgress ?? 0}%</span>
            </div>
            <div className="w-full h-2.5 bg-slate-200 rounded-full overflow-hidden">
              <div
                className="h-full bg-blue-600 rounded-full transition-all duration-150"
                style={{ width: `${uploadProgress ?? 0}%` }}
              />
            </div>
          </div>
        )}
      </div>

      {/* Optional Direct URL Input Field */}
      {showUrlInput && (
        <div className="pt-1.5 animate-in fade-in slide-in-from-top-1 duration-150">
          <div className="flex items-center gap-2">
            <input
              type="url"
              value={value}
              onChange={(e) => onChange(e.target.value)}
              placeholder="https://example.com/image.jpg"
              className="flex-1 px-3 py-1.5 text-xs rounded-lg border border-slate-300 focus:outline-hidden focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 bg-white font-mono"
            />
            {value && (
              <a
                href={value}
                target="_blank"
                rel="noreferrer"
                className="p-2 text-slate-500 hover:text-slate-800 bg-slate-100 rounded-lg hover:bg-slate-200 transition-colors"
                title="Open image in new tab"
              >
                <ExternalLink className="w-3.5 h-3.5" />
              </a>
            )}
          </div>
        </div>
      )}

      {/* Helper Text & Error Notice */}
      {errorMessage && (
        <div className="flex items-center gap-1.5 text-rose-600 text-xs font-semibold pt-0.5">
          <AlertCircle className="w-3.5 h-3.5 shrink-0" />
          <span>{errorMessage}</span>
        </div>
      )}

      {helperText && !errorMessage && (
        <p className="text-[11px] text-slate-500">{helperText}</p>
      )}
    </div>
  );
}
