/**
 * Axon Nursing Academy - Error State Component
 */
import React from 'react';
import { AlertCircle, RotateCcw } from 'lucide-react';
import { Button } from '@/src/components/ui/Button';

export interface ErrorStateProps {
  title?: string;
  description?: string;
  onRetry?: () => void;
  actionText?: string;
  compact?: boolean;
}

export function ErrorState({
  title = 'Unable to load content',
  description = 'An error occurred while fetching information. Please check your network and try again.',
  onRetry,
  actionText = 'Try Again',
  compact = false,
}: ErrorStateProps) {
  return (
    <div
      className={`bg-white rounded-2xl border border-rose-100 p-6 sm:p-8 text-center ${
        compact ? 'py-6' : 'my-4 shadow-sm'
      }`}
    >
      <div className="w-12 h-12 bg-rose-50 text-rose-600 rounded-full flex items-center justify-center mx-auto mb-3 border border-rose-100">
        <AlertCircle className="w-6 h-6" />
      </div>
      <h3 className="text-base sm:text-lg font-bold text-slate-900 mb-1">{title}</h3>
      <p className="text-slate-600 text-sm max-w-md mx-auto mb-5 leading-relaxed">
        {description}
      </p>
      {onRetry && (
        <Button
          variant="outline"
          size="sm"
          onClick={onRetry}
          leftIcon={<RotateCcw className="w-4 h-4" />}
        >
          {actionText}
        </Button>
      )}
    </div>
  );
}
