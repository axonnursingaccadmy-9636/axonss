/**
 * Axon Nursing Academy - Loading State Component
 */
import React, { useEffect } from 'react';
import { Loader2 } from 'lucide-react';
import NProgress from 'nprogress';

export interface LoadingStateProps {
  message?: string;
  fullScreen?: boolean;
  size?: 'sm' | 'md' | 'lg';
}

export function LoadingState({
  message = 'Loading nursing courses...',
  fullScreen = false,
  size = 'md',
}: LoadingStateProps) {
  useEffect(() => {
    if (fullScreen) {
      if (!NProgress.isStarted()) {
        NProgress.start();
      }
      return () => {
        NProgress.done();
      };
    }
  }, [fullScreen]);
  const sizeClasses = {
    sm: 'w-5 h-5',
    md: 'w-8 h-8',
    lg: 'w-12 h-12',
  };

  const content = (
    <div className="flex flex-col items-center justify-center p-6 text-center">
      <div className="relative flex items-center justify-center">
        <Loader2 className={`${sizeClasses[size]} animate-spin text-blue-600`} />
      </div>
      {message && (
        <p className="mt-3 text-sm font-medium text-slate-600 animate-pulse">
          {message}
        </p>
      )}
    </div>
  );

  if (fullScreen) {
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-50">
        {content}
      </div>
    );
  }

  return <div className="py-12 flex justify-center">{content}</div>;
}
