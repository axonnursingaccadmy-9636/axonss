/**
 * Axon Nursing Academy - Phase 3 Reusable BatchCard Component
 * Displays Firestore Batch / Course data with dynamic pricing, discount calculation, and navigation.
 */
import React from 'react';
import { Link } from 'react-router-dom';
import { Clock, BookOpen, Sparkles, ArrowRight, ShieldCheck, Tag } from 'lucide-react';
import { Batch } from '@/src/types/lms.types';
import { formatCurrency } from '@/src/lib/utils/formatters';
import { Badge } from '@/src/components/ui/Badge';
import { Button } from '@/src/components/ui/Button';

export interface BatchCardProps {
  batch: Batch;
  variant?: 'grid' | 'horizontal' | 'compact';
  customLink?: string;
}

export function BatchCard({ batch, variant = 'grid', customLink }: BatchCardProps) {
  const targetUrl = customLink || `/course/${batch.id}`;
  const [imgSrc, setImgSrc] = React.useState<string>(
    batch.thumbnailUrl ||
    'https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?w=800&auto=format&fit=crop&q=80'
  );

  // Safe discount calculation (Section 25)
  const hasDiscount = batch.originalPrice > batch.price && batch.originalPrice > 0;
  const discountPercentage = hasDiscount
    ? Math.round(((batch.originalPrice - batch.price) / batch.originalPrice) * 100)
    : 0;

  const handleImageError = () => {
    setImgSrc('https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?w=800&auto=format&fit=crop&q=80');
  };

  if (variant === 'horizontal') {
    return (
      <div className="bg-white rounded-2xl border border-slate-200/80 p-3 sm:p-4 flex flex-col sm:flex-row gap-4 shadow-xs sm:hover:shadow-md transition-shadow">
        <div className="relative sm:w-52 h-36 shrink-0 rounded-xl overflow-hidden bg-slate-100">
          <img
            src={imgSrc}
            alt={batch.title}
            className="w-full h-full object-cover"
            loading="lazy"
            decoding="async"
            onError={handleImageError}
          />
          <div className="absolute top-2 left-2 flex gap-1">
            {batch.isFree ? (
              <Badge variant="emerald" size="sm">
                Free Batch
              </Badge>
            ) : (
              <Badge variant="blue" size="sm">
                Full Batch
              </Badge>
            )}
            {batch.isFeatured && (
              <Badge variant="amber" size="sm">
                Featured
              </Badge>
            )}
          </div>
        </div>

        <div className="flex-1 flex flex-col justify-between">
          <div>
            <h3 className="font-bold text-slate-900 text-sm sm:text-base line-clamp-1 mb-1">
              {batch.title}
            </h3>
            <p className="text-slate-600 text-xs line-clamp-2 mb-2">
              {batch.shortDescription || batch.description}
            </p>
          </div>

          <div className="flex items-center justify-between pt-2 border-t border-slate-100">
            <div className="flex items-baseline gap-2">
              {batch.isFree ? (
                <span className="text-base font-bold text-emerald-600">FREE</span>
              ) : (
                <>
                  <span className="text-base font-bold text-blue-700">
                    {formatCurrency(batch.price)}
                  </span>
                  {hasDiscount && (
                    <span className="text-xs text-slate-400 line-through">
                      {formatCurrency(batch.originalPrice)}
                    </span>
                  )}
                </>
              )}
            </div>
            <Link to={targetUrl}>
              <Button size="sm" variant="primary" rightIcon={<ArrowRight className="w-3.5 h-3.5" />}>
                View Course
              </Button>
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="group bg-white rounded-2xl border border-slate-200/80 overflow-hidden shadow-xs sm:hover:shadow-md transition-shadow duration-200 flex flex-col justify-between relative">
      <div>
        {/* Batch Thumbnail */}
        <div
          className="relative aspect-[16/10] w-full overflow-hidden bg-slate-100"
          style={{ aspectRatio: '16 / 10' }}
        >
          <img
            src={imgSrc}
            alt={batch.title}
            className="w-full h-full object-cover"
            loading="lazy"
            onError={handleImageError}
          />
          <div className="absolute inset-0 bg-gradient-to-t from-slate-950/60 via-transparent to-transparent" />

          {/* Top Badges */}
          <div className="absolute top-2.5 left-2.5 flex flex-wrap gap-1.5">
            {batch.isFree ? (
              <Badge variant="emerald" size="sm">
                FREE BATCH
              </Badge>
            ) : (
              <Badge variant="blue" size="sm">
                PREMIUM
              </Badge>
            )}
            {batch.isFeatured && (
              <Badge variant="amber" size="sm">
                <Sparkles className="w-3 h-3 mr-0.5 inline" />
                Featured
              </Badge>
            )}
          </div>

          {/* Duration Badge */}
          {batch.durationDays > 0 && (
            <div className="absolute bottom-2 left-2.5 flex items-center gap-1 bg-slate-950/80 text-white text-[11px] font-semibold px-2 py-0.5 rounded-md">
              <Clock className="w-3 h-3 text-blue-300" />
              <span>{batch.durationDays} Days Validity</span>
            </div>
          )}
        </div>

        {/* Content */}
        <div className="p-3.5 sm:p-4">
          <h3 className="font-bold text-slate-900 text-sm sm:text-base leading-snug line-clamp-2 mb-1.5 group-hover:text-blue-600 transition-colors">
            {batch.title}
          </h3>

          <p className="text-xs text-slate-500 line-clamp-2 mb-3">
            {batch.shortDescription || batch.description || 'Comprehensive nursing officer preparation batch.'}
          </p>

          <div className="flex items-center gap-2 text-[11px] text-slate-500 font-medium pb-2 border-b border-slate-100">
            <div className="flex items-center gap-1 text-slate-700">
              <BookOpen className="w-3.5 h-3.5 text-blue-600" />
              <span>LMS Curriculum</span>
            </div>
            <span className="text-slate-300">•</span>
            <div className="flex items-center gap-1 text-slate-700">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
              <span>Exam Oriented</span>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Pricing & Navigation */}
      <div className="px-3.5 pb-3.5 sm:px-4 sm:pb-4 pt-1 flex items-center justify-between">
        <div>
          {batch.isFree ? (
            <div className="flex items-baseline gap-1.5">
              <span className="text-base sm:text-lg font-extrabold text-emerald-600">FREE</span>
            </div>
          ) : (
            <>
              <div className="flex items-baseline gap-1.5">
                <span className="text-base sm:text-lg font-bold text-slate-900">
                  {formatCurrency(batch.price)}
                </span>
                {hasDiscount && (
                  <span className="text-xs text-slate-400 line-through">
                    {formatCurrency(batch.originalPrice)}
                  </span>
                )}
              </div>
              {hasDiscount && (
                <span className="text-[10px] font-bold text-emerald-600 bg-emerald-50 px-1.5 py-0.5 rounded">
                  {discountPercentage}% OFF
                </span>
              )}
            </>
          )}
        </div>

        <Link to={targetUrl}>
          <Button size="sm" variant="primary" rightIcon={<ArrowRight className="w-3.5 h-3.5" />}>
            View Course
          </Button>
        </Link>
      </div>
    </div>
  );
}
