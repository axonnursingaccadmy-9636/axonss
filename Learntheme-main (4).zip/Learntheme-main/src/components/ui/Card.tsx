/**
 * Axon Nursing Academy - Production Card Component
 */
import React, { HTMLAttributes, ReactNode } from 'react';
import { cn } from '@/src/lib/utils/cn';

export interface CardProps extends React.HTMLAttributes<HTMLDivElement> {
  children: ReactNode;
  className?: string;
  hoverEffect?: boolean;
  padding?: 'none' | 'sm' | 'md' | 'lg';
  bordered?: boolean;
}

export function Card({
  children,
  hoverEffect = false,
  padding = 'md',
  bordered = true,
  className,
  ...props
}: CardProps) {
  const paddingStyles = {
    none: '',
    sm: 'p-3 sm:p-4',
    md: 'p-4 sm:p-6',
    lg: 'p-6 sm:p-8',
  };

  return (
    <div
      className={cn(
        'bg-white rounded-2xl transition-all duration-200',
        bordered ? 'border border-slate-100 shadow-xs' : '',
        hoverEffect ? 'hover:shadow-md hover:border-slate-200 hover:-translate-y-0.5' : '',
        paddingStyles[padding],
        className
      )}
      {...props}
    >
      {children}
    </div>
  );
}
