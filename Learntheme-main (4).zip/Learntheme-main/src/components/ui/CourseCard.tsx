/**
 * Axon Nursing Academy - Production Course Card Component
 */
import React from 'react';
import { Link } from 'react-router-dom';
import { Star, Video, FileText, CheckCircle2, ShieldCheck, ArrowRight } from 'lucide-react';
import { Course } from '@/src/types/course.types';
import { formatCurrency } from '@/src/lib/utils/formatters';
import { Badge } from '@/src/components/ui/Badge';
import { Button } from '@/src/components/ui/Button';

export interface CourseCardProps {
  key?: React.Key;
  course: Course;
  isEnrolled?: boolean;
  variant?: 'grid' | 'horizontal' | 'compact';
}

export function CourseCard({ course, isEnrolled = false, variant = 'grid' }: CourseCardProps) {
  const discountPercent = Math.round(
    ((course.originalPrice - course.discountedPrice) / course.originalPrice) * 100
  );

  if (variant === 'horizontal') {
    return (
      <div className="bg-white rounded-2xl border border-slate-200/80 p-3 sm:p-4 flex flex-col sm:flex-row gap-4 shadow-xs hover:shadow-md transition-shadow">
        <div className="relative sm:w-48 h-36 shrink-0 rounded-xl overflow-hidden bg-slate-100">
          <img
            src={course.thumbnailUrl}
            alt={course.title}
            className="w-full h-full object-cover"
            loading="lazy"
          />
          <div className="absolute top-2 left-2">
            <Badge variant="blue" size="sm">
              {course.category.replace('_', ' ')}
            </Badge>
          </div>
        </div>

        <div className="flex-1 flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-1 text-amber-500 text-xs font-semibold mb-1">
              <Star className="w-3.5 h-3.5 fill-amber-400" />
              <span>{course.rating}</span>
              <span className="text-slate-400 font-normal">({course.totalRatingsCount})</span>
            </div>
            <h3 className="font-bold text-slate-900 text-sm sm:text-base line-clamp-1 mb-1">
              {course.title}
            </h3>
            <p className="text-slate-600 text-xs line-clamp-2 mb-2">
              {course.subtitle || course.description}
            </p>
          </div>

          <div className="flex items-center justify-between pt-2 border-t border-slate-100">
            <div className="flex items-baseline gap-2">
              <span className="text-base font-bold text-blue-700">
                {formatCurrency(course.discountedPrice)}
              </span>
              <span className="text-xs text-slate-400 line-through">
                {formatCurrency(course.originalPrice)}
              </span>
            </div>
            <Link to={`/student/all-courses`}>
              <Button size="sm" variant="primary">
                View Batch
              </Button>
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="group bg-white rounded-2xl border border-slate-200/80 overflow-hidden shadow-xs sm:hover:shadow-md transition-shadow duration-200 flex flex-col justify-between">
      <div>
        {/* Course Thumbnail */}
        <div
          className="relative aspect-[16/10] w-full overflow-hidden bg-slate-100"
          style={{ aspectRatio: '16 / 10' }}
        >
          <img
            src={course.thumbnailUrl}
            alt={course.title}
            className="w-full h-full object-cover"
            loading="lazy"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-slate-950/60 via-transparent to-transparent" />

          {/* Top badges */}
          <div className="absolute top-2.5 left-2.5 flex flex-wrap gap-1.5">
            <Badge variant="blue" size="sm">
              {course.category.replace('_', ' ')}
            </Badge>
            {course.isTrending && (
              <Badge variant="amber" size="sm">
                Trending
              </Badge>
            )}
          </div>

          {/* Rating in bottom left of image */}
          <div className="absolute bottom-2 left-2.5 flex items-center gap-1 bg-slate-950/80 text-white text-[11px] font-semibold px-2 py-0.5 rounded-md">
            <Star className="w-3 h-3 text-amber-400 fill-amber-400" />
            <span>{course.rating}</span>
            <span className="text-slate-300">({course.totalRatingsCount})</span>
          </div>

          {course.isPurchased && (
            <div className="absolute bottom-2 right-2.5 bg-emerald-600 text-white text-[11px] font-bold px-2 py-0.5 rounded-md flex items-center gap-1">
              <CheckCircle2 className="w-3 h-3" />
              <span>Enrolled</span>
            </div>
          )}
        </div>

        {/* Content */}
        <div className="p-3.5 sm:p-4">
          <h3 className="font-bold text-slate-900 text-sm sm:text-base leading-snug line-clamp-2 mb-1.5 group-hover:text-blue-600 transition-colors">
            {course.title}
          </h3>

          <p className="text-xs text-slate-500 line-clamp-2 mb-3">
            {course.subtitle || course.description}
          </p>

          {/* Key Deliverables Chips */}
          <div className="flex items-center gap-3 text-[11px] text-slate-600 font-medium pb-3 border-b border-slate-100">
            <div className="flex items-center gap-1">
              <Video className="w-3.5 h-3.5 text-blue-600" />
              <span>{course.totalLectures} Lectures</span>
            </div>
            <div className="flex items-center gap-1">
              <FileText className="w-3.5 h-3.5 text-amber-600" />
              <span>{course.totalPdfs} PDFs</span>
            </div>
            <div className="flex items-center gap-1">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
              <span>{course.totalTests} Tests</span>
            </div>
          </div>

          {/* Faculty designation */}
          <div className="mt-2.5 text-[11px] text-slate-500 flex items-center justify-between">
            <span className="font-medium text-slate-700 truncate">{course.faculty.name}</span>
            <span className="text-slate-400 shrink-0">{course.language}</span>
          </div>
        </div>
      </div>

      {/* Bottom Pricing & Action */}
      <div className="px-3.5 pb-3.5 sm:px-4 sm:pb-4 pt-1 flex items-center justify-between">
        {course.isPurchased || isEnrolled ? (
          <Link to="/student/courses" className="w-full">
            <Button variant="outline" size="sm" fullWidth rightIcon={<ArrowRight className="w-3.5 h-3.5" />}>
              Continue Learning
            </Button>
          </Link>
        ) : (
          <>
            <div>
              <div className="flex items-baseline gap-1.5">
                <span className="text-base sm:text-lg font-bold text-slate-900">
                  {formatCurrency(course.discountedPrice)}
                </span>
                <span className="text-xs text-slate-400 line-through">
                  {formatCurrency(course.originalPrice)}
                </span>
              </div>
              <span className="text-[10px] font-bold text-emerald-600 bg-emerald-50 px-1.5 py-0.5 rounded">
                {discountPercent}% OFF
              </span>
            </div>

            <Link to="/student/all-courses">
              <Button size="sm" variant="primary">
                Explore Batch
              </Button>
            </Link>
          </>
        )}
      </div>
    </div>
  );
}
