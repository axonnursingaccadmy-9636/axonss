/**
 * Axon Nursing Academy - Testimonial Card Component
 */
import React from 'react';
import { Star, Quote, Award } from 'lucide-react';
import { Testimonial } from '@/src/types/content.types';
import { Avatar } from '@/src/components/ui/Avatar';

export interface TestimonialCardProps {
  key?: React.Key;
  testimonial: Testimonial;
}

export function TestimonialCard({ testimonial }: TestimonialCardProps) {
  return (
    <div className="bg-white rounded-2xl border border-slate-200/80 p-4 sm:p-5 shadow-xs flex flex-col justify-between h-full">
      <div>
        {/* Rating Stars & Quote Icon */}
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-1 text-amber-400">
            {Array.from({ length: testimonial.rating }).map((_, i) => (
              <Star key={i} className="w-3.5 h-3.5 fill-amber-400" />
            ))}
          </div>
          <Quote className="w-5 h-5 text-blue-200" />
        </div>

        {/* Testimonial Quote */}
        <p className="text-xs sm:text-sm text-slate-700 leading-relaxed italic mb-4">
          "{testimonial.testimonial}"
        </p>
      </div>

      {/* Student Profile Info */}
      <div className="flex items-center gap-3 pt-3 border-t border-slate-100">
        <Avatar src={testimonial.avatarUrl} name={testimonial.name} size="md" />
        <div className="min-w-0">
          <h4 className="text-xs sm:text-sm font-bold text-slate-900 truncate">
            {testimonial.name}
          </h4>
          <div className="flex items-center gap-1 text-[11px] text-blue-700 font-medium mt-0.5">
            <Award className="w-3 h-3 text-blue-600 shrink-0" />
            <span className="truncate">{testimonial.rankOrPost}</span>
          </div>
        </div>
      </div>
    </div>
  );
}
