/**
 * Axon Nursing Academy - Promotional Banner Card Component
 */
import React from 'react';
import { Link } from 'react-router-dom';
import { Sparkles, ArrowRight } from 'lucide-react';
import { Banner } from '@/src/types/content.types';
import { cn } from '@/src/lib/utils/cn';

export interface BannerCardProps {
  key?: React.Key;
  banner: Banner;
  className?: string;
}

export function BannerCard({ banner, className }: BannerCardProps) {
  const gradientClass = banner.backgroundColorClass || 'from-blue-700 via-blue-800 to-indigo-900';

  return (
    <div
      className={cn(
        'relative rounded-2xl sm:rounded-3xl overflow-hidden p-4 sm:p-6 text-white bg-gradient-to-r shadow-md flex flex-col justify-between min-h-[160px] sm:min-h-[190px]',
        gradientClass,
        className
      )}
    >
      {/* Background visual elements */}
      <div className="absolute right-0 top-0 bottom-0 w-1/2 opacity-10 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-white to-transparent pointer-events-none" />
      <div className="absolute -bottom-10 -right-10 w-44 h-44 rounded-full bg-white/10 blur-2xl pointer-events-none" />

      {/* Top Banner Content */}
      <div className="relative z-10">
        {banner.badge && (
          <span className="inline-flex items-center gap-1 bg-white/20 text-white text-[11px] font-bold px-2.5 py-0.5 rounded-full mb-2.5 border border-white/20">
            <Sparkles className="w-3 h-3 text-amber-300" />
            {banner.badge}
          </span>
        )}
        <h2 className="text-base sm:text-xl md:text-2xl font-extrabold tracking-tight leading-snug max-w-md">
          {banner.title}
        </h2>
        {banner.subtitle && (
          <p className="text-xs sm:text-sm text-blue-100/90 mt-1 max-w-sm line-clamp-2">
            {banner.subtitle}
          </p>
        )}
      </div>

      {/* Bottom CTA Button */}
      <div className="relative z-10 mt-4 flex items-center">
        <Link
          to={banner.targetRoute}
          className="inline-flex items-center gap-1.5 bg-white hover:bg-blue-50 text-blue-900 text-xs sm:text-sm font-bold px-4 py-2 rounded-xl shadow-xs transition-colors"
        >
          <span>{banner.ctaText}</span>
          <ArrowRight className="w-3.5 h-3.5" />
        </Link>
      </div>
    </div>
  );
}
