/**
 * Axon Nursing Academy - Category Card Component
 */
import React from 'react';
import { Link } from 'react-router-dom';
import { Hospital, Globe, GraduationCap, Stethoscope, BookMarked, FileCheck2, ArrowRight } from 'lucide-react';
import { CategoryCardItem } from '@/src/types/content.types';
import { cn } from '@/src/lib/utils/cn';

export interface CategoryCardProps {
  key?: React.Key;
  category: CategoryCardItem;
}

const iconMap: Record<string, React.ComponentType<{ className?: string }>> = {
  Hospital,
  Globe,
  GraduationCap,
  Stethoscope,
  BookMarked,
  FileCheck2,
};

export function CategoryCard({ category }: CategoryCardProps) {
  const IconComponent = iconMap[category.iconName] || BookMarked;

  return (
    <Link
      to={category.route}
      className={cn(
        'group p-3.5 sm:p-4 rounded-2xl border transition-all duration-200 hover:shadow-md flex items-start gap-3 bg-white',
        category.bgClass
      )}
    >
      <div
        className={cn(
          'w-11 h-11 rounded-xl flex items-center justify-center shrink-0 shadow-xs group-hover:scale-105 transition-transform bg-white',
          category.colorClass
        )}
      >
        <IconComponent className="w-6 h-6" />
      </div>

      <div className="flex-1 min-w-0">
        <h3 className="text-xs sm:text-sm font-bold text-slate-900 truncate group-hover:text-blue-600 transition-colors">
          {category.title}
        </h3>
        {category.subtitle && (
          <p className="text-[11px] text-slate-500 truncate mt-0.5">{category.subtitle}</p>
        )}
        {category.countLabel && (
          <span className="inline-block mt-1.5 text-[10px] font-semibold text-blue-700 bg-blue-100/60 px-1.5 py-0.5 rounded">
            {category.countLabel}
          </span>
        )}
      </div>

      <ArrowRight className="w-4 h-4 text-slate-300 group-hover:text-blue-600 group-hover:translate-x-0.5 transition-all shrink-0 mt-1" />
    </Link>
  );
}
