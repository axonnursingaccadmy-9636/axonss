/**
 * Axon Nursing Academy - Toast Notification Item Component
 * Features clean clinical/educational aesthetic, progress bar, pause-on-hover, and dismiss transitions.
 */
import React, { useEffect, useState, useRef, useCallback } from 'react';
import {
  CheckCircle2,
  AlertCircle,
  AlertTriangle,
  Info,
  X,
} from 'lucide-react';
import { ToastItemData, ToastType } from '@/src/types/toast.types';

interface ToastItemProps {
  toast: ToastItemData;
  onDismiss: (id: string) => void;
}

const TYPE_CONFIG: Record<
  ToastType,
  {
    icon: React.ComponentType<{ className?: string }>;
    iconBg: string;
    iconColor: string;
    border: string;
    progressBar: string;
    badgeLabel: string;
  }
> = {
  success: {
    icon: CheckCircle2,
    iconBg: 'bg-emerald-50 text-emerald-600',
    iconColor: 'text-emerald-600',
    border: 'border-emerald-200/80 shadow-emerald-500/5',
    progressBar: 'bg-emerald-500',
    badgeLabel: 'Success',
  },
  error: {
    icon: AlertCircle,
    iconBg: 'bg-rose-50 text-rose-600',
    iconColor: 'text-rose-600',
    border: 'border-rose-200/80 shadow-rose-500/5',
    progressBar: 'bg-rose-500',
    badgeLabel: 'Error',
  },
  warning: {
    icon: AlertTriangle,
    iconBg: 'bg-amber-50 text-amber-600',
    iconColor: 'text-amber-600',
    border: 'border-amber-200/80 shadow-amber-500/5',
    progressBar: 'bg-amber-500',
    badgeLabel: 'Notice',
  },
  info: {
    icon: Info,
    iconBg: 'bg-blue-50 text-blue-600',
    iconColor: 'text-blue-600',
    border: 'border-blue-200/80 shadow-blue-500/5',
    progressBar: 'bg-blue-600',
    badgeLabel: 'Info',
  },
};

export const ToastItem: React.FC<ToastItemProps> = ({ toast, onDismiss }) => {
  const { id, type, title, message, duration, dismissible, action, icon, onDismiss: customOnDismiss } = toast;
  const config = TYPE_CONFIG[type] || TYPE_CONFIG.info;
  const IconComponent = config.icon;

  const [isHovered, setIsHovered] = useState(false);
  const [progress, setProgress] = useState(100);
  const [isClosing, setIsClosing] = useState(false);

  const startTimeRef = useRef<number>(Date.now());
  const remainingTimeRef = useRef<number>(duration);
  const timerRef = useRef<NodeJS.Timeout | null>(null);
  const progressAnimRef = useRef<number | null>(null);

  const handleClose = useCallback(() => {
    setIsClosing(true);
    setTimeout(() => {
      if (customOnDismiss) customOnDismiss();
      onDismiss(id);
    }, 200);
  }, [id, onDismiss, customOnDismiss]);

  // Handle countdown & progress bar with hover pause
  useEffect(() => {
    if (duration <= 0 || duration === Infinity) {
      return;
    }

    if (isHovered) {
      if (timerRef.current) clearTimeout(timerRef.current);
      if (progressAnimRef.current) cancelAnimationFrame(progressAnimRef.current);
      return;
    }

    startTimeRef.current = Date.now();
    const currentRemaining = remainingTimeRef.current;

    // Timeout for auto-close
    timerRef.current = setTimeout(() => {
      handleClose();
    }, currentRemaining);

    // Smooth animation frame for progress bar
    const updateProgress = () => {
      const elapsed = Date.now() - startTimeRef.current;
      const newRemaining = Math.max(0, currentRemaining - elapsed);
      remainingTimeRef.current = newRemaining;
      const pct = (newRemaining / duration) * 100;
      setProgress(pct);

      if (newRemaining > 0 && !isHovered) {
        progressAnimRef.current = requestAnimationFrame(updateProgress);
      }
    };

    progressAnimRef.current = requestAnimationFrame(updateProgress);

    return () => {
      if (timerRef.current) clearTimeout(timerRef.current);
      if (progressAnimRef.current) cancelAnimationFrame(progressAnimRef.current);
    };
  }, [duration, isHovered, handleClose]);

  return (
    <div
      role="status"
      aria-live={type === 'error' ? 'assertive' : 'polite'}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      className={`group relative pointer-events-auto w-full max-w-sm sm:max-w-md bg-white/95 backdrop-blur-md border ${
        config.border
      } rounded-2xl shadow-xl p-3.5 sm:p-4 text-slate-800 transition-all duration-200 overflow-hidden ${
        isClosing
          ? 'opacity-0 scale-95 translate-y-1'
          : 'opacity-100 scale-100 translate-y-0 animate-in fade-in slide-in-from-top-2 duration-150'
      }`}
    >
      <div className="flex items-start gap-3">
        {/* Toast Icon */}
        <div
          className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 shadow-xs ${config.iconBg}`}
        >
          {icon ? (
            <span className="w-5 h-5 flex items-center justify-center">{icon}</span>
          ) : (
            <IconComponent className="w-5 h-5" />
          )}
        </div>

        {/* Content Body */}
        <div className="flex-1 min-w-0 pr-1 pt-0.5">
          {title && (
            <h4 className="text-xs sm:text-sm font-bold text-slate-900 leading-tight mb-0.5">
              {title}
            </h4>
          )}
          <div className="text-xs text-slate-600 font-medium leading-relaxed break-words">
            {message}
          </div>

          {/* Action button if provided */}
          {action && (
            <div className="mt-2.5 flex items-center gap-2">
              <button
                type="button"
                onClick={() => {
                  action.onClick();
                  handleClose();
                }}
                className={`text-xs font-semibold px-2.5 py-1 rounded-lg transition-colors shadow-xs ${
                  action.variant === 'danger'
                    ? 'bg-rose-600 hover:bg-rose-700 text-white'
                    : action.variant === 'secondary'
                    ? 'bg-slate-100 hover:bg-slate-200 text-slate-800'
                    : 'bg-blue-600 hover:bg-blue-700 text-white'
                }`}
              >
                {action.label}
              </button>
            </div>
          )}
        </div>

        {/* Dismiss Button */}
        {dismissible && (
          <button
            type="button"
            onClick={handleClose}
            aria-label="Dismiss notification"
            className="w-7 h-7 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 flex items-center justify-center shrink-0 transition-colors -mr-1 -mt-1"
          >
            <X className="w-4 h-4" />
          </button>
        )}
      </div>

      {/* Progress Bar (countdown indicator) */}
      {duration > 0 && duration !== Infinity && (
        <div className="absolute bottom-0 left-0 right-0 h-1 bg-slate-100 overflow-hidden">
          <div
            className={`h-full transition-all duration-75 ease-linear ${config.progressBar}`}
            style={{ width: `${progress}%` }}
          />
        </div>
      )}
    </div>
  );
};
