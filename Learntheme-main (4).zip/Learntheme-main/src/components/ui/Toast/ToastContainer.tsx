/**
 * Axon Nursing Academy - Toast Container Viewport
 * Fixed overlay positioning portal for displaying stacked toast notifications.
 */
import React from 'react';
import { ToastItemData, ToastPosition } from '@/src/types/toast.types';
import { ToastItem } from './ToastItem';

interface ToastContainerProps {
  toasts: ToastItemData[];
  onDismiss: (id: string) => void;
  position: ToastPosition;
}

const POSITION_STYLES: Record<ToastPosition, string> = {
  'top-right': 'top-4 right-4 items-end',
  'top-center': 'top-4 left-1/2 -translate-x-1/2 items-center',
  'top-left': 'top-4 left-4 items-start',
  'bottom-right': 'bottom-4 right-4 items-end',
  'bottom-center': 'bottom-4 left-1/2 -translate-x-1/2 items-center',
  'bottom-left': 'bottom-4 left-4 items-start',
};

export const ToastContainer: React.FC<ToastContainerProps> = ({
  toasts,
  onDismiss,
  position,
}) => {
  if (toasts.length === 0) {
    return null;
  }

  // Group toasts by individual position or fallback to global position
  const groupedByPos = toasts.reduce<Record<ToastPosition, ToastItemData[]>>(
    (acc, toast) => {
      const pos = toast.position || position;
      if (!acc[pos]) {
        acc[pos] = [];
      }
      acc[pos].push(toast);
      return acc;
    },
    {} as Record<ToastPosition, ToastItemData[]>
  );

  return (
    <div
      id="toast-notifications-portal"
      aria-live="polite"
      className="fixed inset-0 pointer-events-none z-[9999] overflow-hidden"
    >
      {(Object.keys(groupedByPos) as ToastPosition[]).map((pos) => {
        const posToasts = groupedByPos[pos];
        if (!posToasts || posToasts.length === 0) return null;

        const isBottom = pos.startsWith('bottom');

        return (
          <div
            key={pos}
            className={`fixed flex flex-col gap-2.5 max-w-sm sm:max-w-md w-full p-4 pointer-events-none ${
              POSITION_STYLES[pos]
            } ${isBottom ? 'flex-col-reverse' : 'flex-col'}`}
          >
            {posToasts.map((toast) => (
              <ToastItem
                key={toast.id}
                toast={toast}
                onDismiss={onDismiss}
              />
            ))}
          </div>
        );
      })}
    </div>
  );
};
