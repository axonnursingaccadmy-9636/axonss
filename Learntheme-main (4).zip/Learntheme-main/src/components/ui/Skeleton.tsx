/**
 * Axon Nursing Academy - Skeleton Placeholder Component
 */
import React from 'react';
import { cn } from '@/src/lib/utils/cn';

export interface SkeletonProps {
  className?: string;
  variant?: 'text' | 'rectangular' | 'circular';
}

export function Skeleton({ className, variant = 'rectangular' }: SkeletonProps) {
  const variantStyles = {
    text: 'h-4 w-full rounded-md',
    rectangular: 'rounded-xl',
    circular: 'rounded-full',
  };

  return (
    <div
      className={cn(
        'animate-pulse bg-slate-200/80',
        variantStyles[variant],
        className
      )}
    />
  );
}

export function CourseCardSkeleton() {
  return (
    <div className="bg-white rounded-2xl border border-slate-100 p-4 shadow-xs">
      <Skeleton className="h-44 w-full rounded-xl mb-3.5" />
      <Skeleton className="h-4 w-24 mb-2" variant="text" />
      <Skeleton className="h-5 w-full mb-1.5" variant="text" />
      <Skeleton className="h-4 w-3/4 mb-4" variant="text" />
      <div className="flex justify-between items-center pt-3 border-t border-slate-100">
        <Skeleton className="h-6 w-20" />
        <Skeleton className="h-9 w-24 rounded-lg" />
      </div>
    </div>
  );
}
