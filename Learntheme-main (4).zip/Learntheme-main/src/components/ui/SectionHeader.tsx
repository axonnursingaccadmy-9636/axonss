/**
 * Axon Nursing Academy - Section Header Component
 */
import React, { ReactNode } from 'react';
import { Link } from 'react-router-dom';
import { ChevronRight } from 'lucide-react';
import { cn } from '@/src/lib/utils/cn';

export interface SectionHeaderProps {
  title: string;
  subtitle?: string;
  badgeText?: string;
  viewAllLink?: string;
  viewAllText?: string;
  actionButton?: ReactNode;
  className?: string;
}

export function SectionHeader({
  title,
  subtitle,
  badgeText,
  viewAllLink,
  viewAllText = 'View All',
  actionButton,
  className,
}: SectionHeaderProps) {
  return (
    <div className={cn('flex items-center justify-between mb-3.5 sm:mb-4.5', className)}>
      <div>
        <div className="flex items-center gap-2">
          <h2 className="text-base sm:text-lg font-bold text-slate-900 tracking-tight">
            {title}
          </h2>
          {badgeText && (
            <span className="text-[11px] font-bold bg-blue-50 text-blue-600 px-2 py-0.5 rounded-md border border-blue-100">
              {badgeText}
            </span>
          )}
        </div>
        {subtitle && (
          <p className="text-xs sm:text-sm text-slate-500 mt-0.5">{subtitle}</p>
        )}
      </div>

      <div className="flex items-center gap-2 shrink-0">
        {viewAllLink && (
          <Link
            to={viewAllLink}
            className="text-xs sm:text-sm font-semibold text-blue-600 hover:text-blue-700 flex items-center gap-0.5 hover:underline py-1 px-1.5 -mr-1.5"
          >
            <span>{viewAllText}</span>
            <ChevronRight className="w-4 h-4" />
          </Link>
        )}
        {actionButton}
      </div>
    </div>
  );
}
