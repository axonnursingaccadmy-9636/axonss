/**
 * Axon Nursing Academy - Production Responsive Admin Dashboard
 * Real-time Firestore analytics, recent LMS activity, and quick CMS shortcuts.
 */
import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import {
  Users,
  BookMarked,
  BookOpen,
  Layers,
  FolderTree,
  Video,
  History,
  Plus,
  ArrowRight,
  ShieldCheck,
  RefreshCw,
  Eye,
  EyeOff,
  Sparkles,
  ExternalLink,
  Database,
  Award,
  FileCheck,
  Tag,
  CreditCard,
  Trash2,
} from 'lucide-react';
import { ROUTES } from '@/src/config/routes.config';
import { formatCurrency } from '@/src/lib/utils/formatters';
import { Badge } from '@/src/components/ui/Badge';
import { Button } from '@/src/components/ui/Button';
import { PublishStatusBadge } from '@/src/components/admin/StatusBadge';
import { ConfirmationModal } from '@/src/components/admin/ConfirmationModal';
import { getAdminDashboardMetrics, subscribeToAdminMetrics, AdminDashboardMetrics } from '@/src/services/firebase/adminStatsService';
import { getAllBatchesAdmin, subscribeToBatchesAdmin, toggleBatchPublish } from '@/src/services/firebase/adminBatchService';
import { getRecentAuditLogs } from '@/src/services/firebase/auditService';
import { seedInitialLmsData, seedDevelopmentLmsData } from '@/src/services/firebase/seedService';
import { deleteAllCurriculumFromFirestoreAndLocal } from '@/src/services/firebase/curriculumResetService';
import { Batch } from '@/src/types/lms.types';
import { AuditLog } from '@/src/types/audit.types';
import { Enrollment } from '@/src/types/enrollment.types';
import { getAllEnrollmentsAdmin } from '@/src/services/firebase/enrollmentService';
import { formatDate } from '@/src/lib/utils/formatters';
import { useAuth } from '@/src/contexts/AuthContext';

export function AdminDashboardPage() {
  const { currentUser } = useAuth();
  const navigate = useNavigate();
  const [metrics, setMetrics] = useState<AdminDashboardMetrics | null>(null);
  const [batches, setBatches] = useState<Batch[]>([]);
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>([]);
  const [recentEnrollments, setRecentEnrollments] = useState<Enrollment[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [isPurgeModalOpen, setIsPurgeModalOpen] = useState(false);
  const [purging, setPurging] = useState(false);
  const [seedSuccess, setSeedSuccess] = useState<string | null>(null);
  const [isBuildingDb, setIsBuildingDb] = useState(false);

  const handleBuildDatabase = async () => {
    setIsBuildingDb(true);
    try {
      const res = await seedDevelopmentLmsData(true);
      setSeedSuccess(res.message);
      await handleRefresh();
    } catch (err: any) {
      setSeedSuccess(`Database build status: ${err?.message || err}`);
    } finally {
      setIsBuildingDb(false);
    }
  };

  // Set up real-time Firestore listeners for Metrics and Batches
  useEffect(() => {
    // 1. Initial audit logs & enrollments
    getRecentAuditLogs(8).then(setAuditLogs).catch(console.warn);
    getAllEnrollmentsAdmin().then((list) => setRecentEnrollments(list.slice(0, 5))).catch(console.warn);

    // 2. Realtime listener for metrics
    const unsubMetrics = subscribeToAdminMetrics(
      (m) => {
        setMetrics(m);
        setLoading(false);
        setRefreshing(false);
      },
      (err) => {
        console.warn('[AdminDashboardPage] Metrics subscription notice:', err);
        setLoading(false);
        setRefreshing(false);
      }
    );

    // 3. Realtime listener for batches
    const unsubBatches = subscribeToBatchesAdmin(
      (b) => {
        setBatches(b);
      },
      (err) => {
        console.warn('[AdminDashboardPage] Batches subscription notice:', err);
      }
    );

    return () => {
      unsubMetrics();
      unsubBatches();
    };
  }, []);

  const handleRefresh = async () => {
    setRefreshing(true);
    try {
      const [m, b, a, enrs] = await Promise.all([
        getAdminDashboardMetrics(),
        getAllBatchesAdmin(),
        getRecentAuditLogs(8),
        getAllEnrollmentsAdmin(),
      ]);
      setMetrics(m);
      setBatches(b);
      setAuditLogs(a);
      setRecentEnrollments(enrs.slice(0, 5));
    } catch (err) {
      console.warn('[AdminDashboardPage] Error on manual refresh:', err);
    } finally {
      setRefreshing(false);
    }
  };

  const handleToggleBatch = async (batch: Batch) => {
    if (!currentUser) return;
    try {
      await toggleBatchPublish(
        batch.id,
        !batch.isPublished,
        batch.title,
        currentUser.uid,
        currentUser.email || undefined
      );
      // Realtime listener will automatically update batches & metrics!
    } catch (err) {
      console.error('Failed to toggle batch status:', err);
    }
  };

  const handlePurgeAllCurriculum = async () => {
    setPurging(true);
    try {
      const res = await deleteAllCurriculumFromFirestoreAndLocal(
        currentUser?.uid,
        currentUser?.email || undefined
      );
      setSeedSuccess(res.message);
      setIsPurgeModalOpen(false);
      await handleRefresh();
    } catch (err: any) {
      setSeedSuccess(`Purge status: ${err?.message || err}`);
    } finally {
      setPurging(false);
    }
  };

  return (
    <div className="space-y-4 sm:space-y-6 font-['Plus_Jakarta_Sans',sans-serif]">
      {/* Top Banner Notice */}
      <div className="bg-white rounded-2xl border border-slate-200 p-4 sm:p-5 md:p-6 flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1.5">
            <Badge variant="blue" size="sm">
              Axon LMS CMS
            </Badge>
            <span className="text-xs font-semibold text-slate-500">
              Live Firestore Cloud Architecture
            </span>
          </div>
          <h1 className="text-lg sm:text-xl md:text-2xl font-extrabold text-slate-900 tracking-tight">
            Academy Management & Content Controller
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
            Full administrative control over courses, syllabus hierarchy, video lectures, and student records.
          </p>
        </div>

        <div className="flex items-center gap-2 sm:gap-2.5 flex-wrap">
          <Button
            variant="outline"
            size="sm"
            onClick={handleRefresh}
            isLoading={refreshing}
            leftIcon={<RefreshCw className="w-3.5 h-3.5" />}
          >
            Refresh
          </Button>

          <Button
            variant="outline"
            size="sm"
            onClick={handleBuildDatabase}
            isLoading={isBuildingDb}
            leftIcon={<Database className="w-3.5 h-3.5 text-blue-600" />}
            className="border-blue-200 hover:bg-blue-50 text-blue-700 font-semibold"
          >
            Build / Sync Database
          </Button>

          <Button
            variant="danger"
            size="sm"
            onClick={() => setIsPurgeModalOpen(true)}
            isLoading={purging}
            leftIcon={<Trash2 className="w-3.5 h-3.5" />}
          >
            Delete All Data (Clean Slate)
          </Button>

          <Link to={ROUTES.ADMIN.BATCHES}>
            <Button variant="primary" size="sm" leftIcon={<Plus className="w-3.5 h-3.5" />}>
              Create Batch
            </Button>
          </Link>
        </div>
      </div>

      {seedSuccess && (
        <div className="p-3.5 sm:p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-semibold flex items-center justify-between">
          <span>{seedSuccess}</span>
          <button
            type="button"
            onClick={() => setSeedSuccess(null)}
            className="text-emerald-600 hover:text-emerald-900 font-bold ml-2 shrink-0"
          >
            Dismiss
          </button>
        </div>
      )}

      {/* KPI Cards Grid - Responsive 2-columns on mobile, 4-columns on desktop */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        {/* Batches KPI */}
        <Link
          to={ROUTES.ADMIN.BATCHES}
          className="block min-w-0 bg-white rounded-2xl border border-slate-200 p-3.5 sm:p-5 hover:border-blue-300 transition-colors"
        >
          <div className="flex items-center justify-between mb-2 sm:mb-3">
            <span className="text-[10px] sm:text-xs font-bold text-slate-500 uppercase tracking-wider truncate">
              Batches / Courses
            </span>
            <div className="w-7 h-7 sm:w-9 sm:h-9 rounded-xl flex items-center justify-center bg-blue-50 text-blue-600 shrink-0">
              <BookMarked className="w-4 h-4 sm:w-5 sm:h-5" />
            </div>
          </div>
          <div className="text-xl sm:text-2xl font-extrabold text-slate-900">
            {metrics ? metrics.totalBatches : '...'}
          </div>
          <div className="flex items-center gap-1.5 mt-1 sm:mt-1.5 text-[10px] sm:text-xs text-slate-500 font-medium overflow-hidden">
            <span className="text-emerald-600 font-bold whitespace-nowrap">{metrics?.publishedBatches || 0} Live</span>
            <span>•</span>
            <span className="whitespace-nowrap">{metrics?.draftBatches || 0} Draft</span>
          </div>
        </Link>

        {/* Total Students KPI */}
        <Link
          to={ROUTES.ADMIN.STUDENTS}
          className="block min-w-0 bg-white rounded-2xl border border-slate-200 p-3.5 sm:p-5 hover:border-amber-300 transition-colors"
        >
          <div className="flex items-center justify-between mb-2 sm:mb-3">
            <span className="text-[10px] sm:text-xs font-bold text-slate-500 uppercase tracking-wider truncate">
              Total Students
            </span>
            <div className="w-7 h-7 sm:w-9 sm:h-9 rounded-xl flex items-center justify-center bg-amber-50 text-amber-600 shrink-0">
              <Users className="w-4 h-4 sm:w-5 sm:h-5" />
            </div>
          </div>
          <div className="text-xl sm:text-2xl font-extrabold text-slate-900">
            {metrics ? metrics.totalStudents : '...'}
          </div>
          <p className="text-[10px] sm:text-xs font-medium text-slate-500 mt-1 sm:mt-1.5 truncate">
            Registered accounts
          </p>
        </Link>

        {/* Enrollments & Purchases KPI */}
        <Link
          to={ROUTES.ADMIN.PAYMENTS}
          className="block min-w-0 bg-white rounded-2xl border border-slate-200 p-3.5 sm:p-5 hover:border-indigo-300 transition-colors"
        >
          <div className="flex items-center justify-between mb-2 sm:mb-3">
            <span className="text-[10px] sm:text-xs font-bold text-slate-500 uppercase tracking-wider truncate">
              Course Purchases
            </span>
            <div className="w-7 h-7 sm:w-9 sm:h-9 rounded-xl flex items-center justify-center bg-indigo-50 text-indigo-600 shrink-0">
              <CreditCard className="w-4 h-4 sm:w-5 sm:h-5" />
            </div>
          </div>
          <div className="text-xl sm:text-2xl font-extrabold text-slate-900">
            {metrics ? metrics.totalPaidPurchases : '...'}
          </div>
          <div className="flex items-center gap-1.5 mt-1 sm:mt-1.5 text-[10px] sm:text-xs text-slate-500 font-medium overflow-hidden">
            <span className="text-indigo-600 font-bold whitespace-nowrap">{metrics?.totalEnrollments || 0} Total Enrolled</span>
          </div>
        </Link>

        {/* Total Collected Revenue KPI */}
        <Link
          to={ROUTES.ADMIN.PAYMENTS}
          className="block min-w-0 bg-white rounded-2xl border border-slate-200 p-3.5 sm:p-5 hover:border-emerald-300 transition-colors"
        >
          <div className="flex items-center justify-between mb-2 sm:mb-3">
            <span className="text-[10px] sm:text-xs font-bold text-slate-500 uppercase tracking-wider truncate">
              Total Revenue
            </span>
            <div className="w-7 h-7 sm:w-9 sm:h-9 rounded-xl flex items-center justify-center bg-emerald-50 text-emerald-600 shrink-0">
              <Sparkles className="w-4 h-4 sm:w-5 sm:h-5" />
            </div>
          </div>
          <div className="text-xl sm:text-2xl font-extrabold text-emerald-700">
            {metrics ? formatCurrency(metrics.totalRevenue) : '...'}
          </div>
          <p className="text-[10px] sm:text-xs font-medium text-emerald-600 mt-1 sm:mt-1.5 truncate">
            Direct student orders
          </p>
        </Link>
      </div>

      {/* Quick Access Matrix */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 sm:gap-3">
        <Link
          to={ROUTES.ADMIN.BATCHES}
          className="bg-white p-3 sm:p-3.5 rounded-xl border border-slate-200 hover:border-blue-400 transition-colors flex items-center gap-2.5 sm:gap-3"
        >
          <div className="w-8 h-8 rounded-lg bg-blue-100 text-blue-700 flex items-center justify-center shrink-0">
            <BookMarked className="w-4 h-4" />
          </div>
          <div className="min-w-0">
            <div className="text-xs font-bold text-slate-900 truncate">Batches</div>
            <div className="text-[10px] text-slate-500 truncate">Manage courses</div>
          </div>
        </Link>

        <Link
          to={ROUTES.ADMIN.SUBJECTS}
          className="bg-white p-3 sm:p-3.5 rounded-xl border border-slate-200 hover:border-emerald-400 transition-colors flex items-center gap-2.5 sm:gap-3"
        >
          <div className="w-8 h-8 rounded-lg bg-emerald-100 text-emerald-700 flex items-center justify-center shrink-0">
            <Layers className="w-4 h-4" />
          </div>
          <div className="min-w-0">
            <div className="text-xs font-bold text-slate-900 truncate">Subjects</div>
            <div className="text-[10px] text-slate-500 truncate">Syllabus modules</div>
          </div>
        </Link>

        <Link
          to={ROUTES.ADMIN.CHAPTERS}
          className="bg-white p-3 sm:p-3.5 rounded-xl border border-slate-200 hover:border-amber-400 transition-colors flex items-center gap-2.5 sm:gap-3"
        >
          <div className="w-8 h-8 rounded-lg bg-amber-100 text-amber-700 flex items-center justify-center shrink-0">
            <FolderTree className="w-4 h-4" />
          </div>
          <div className="min-w-0">
            <div className="text-xs font-bold text-slate-900 truncate">Chapters</div>
            <div className="text-[10px] text-slate-500 truncate">Unit topics</div>
          </div>
        </Link>

        <Link
          to={ROUTES.ADMIN.CLASSES}
          className="bg-white p-3 sm:p-3.5 rounded-xl border border-slate-200 hover:border-purple-400 transition-colors flex items-center gap-2.5 sm:gap-3"
        >
          <div className="w-8 h-8 rounded-lg bg-purple-100 text-purple-700 flex items-center justify-center shrink-0">
            <BookOpen className="w-4 h-4" />
          </div>
          <div className="min-w-0">
            <div className="text-xs font-bold text-slate-900 truncate">Classes</div>
            <div className="text-[10px] text-slate-500 truncate">Class names</div>
          </div>
        </Link>

        <Link
          to={ROUTES.ADMIN.VIDEO_CLASSES}
          className="bg-white p-3 sm:p-3.5 rounded-xl border border-slate-200 hover:border-red-400 transition-colors flex items-center gap-2.5 sm:gap-3"
        >
          <div className="w-8 h-8 rounded-lg bg-red-100 text-red-700 flex items-center justify-center shrink-0">
            <Video className="w-4 h-4" />
          </div>
          <div className="min-w-0">
            <div className="text-xs font-bold text-slate-900 truncate">Video Classes</div>
            <div className="text-[10px] text-slate-500 truncate">Video lectures</div>
          </div>
        </Link>

        <Link
          to={ROUTES.ADMIN.WEEKLY_WARRIOR}
          className="bg-white p-3 sm:p-3.5 rounded-xl border border-slate-200 hover:border-rose-400 transition-colors flex items-center gap-2.5 sm:gap-3"
        >
          <div className="w-8 h-8 rounded-lg bg-rose-100 text-rose-700 flex items-center justify-center shrink-0">
            <Award className="w-4 h-4" />
          </div>
          <div className="min-w-0">
            <div className="text-xs font-bold text-slate-900 truncate">Weekly Warrior</div>
            <div className="text-[10px] text-slate-500 truncate">Full Mock Tests</div>
          </div>
        </Link>

        <Link
          to={ROUTES.ADMIN.UNIT_TESTS}
          className="bg-white p-3 sm:p-3.5 rounded-xl border border-slate-200 hover:border-indigo-400 transition-colors flex items-center gap-2.5 sm:gap-3"
        >
          <div className="w-8 h-8 rounded-lg bg-indigo-100 text-indigo-700 flex items-center justify-center shrink-0">
            <FileCheck className="w-4 h-4" />
          </div>
          <div className="min-w-0">
            <div className="text-xs font-bold text-slate-900 truncate">Unit Tests</div>
            <div className="text-[10px] text-slate-500 truncate">Chapter MCQs</div>
          </div>
        </Link>

        <Link
          to={ROUTES.ADMIN.COUPONS}
          className="bg-white p-3 sm:p-3.5 rounded-xl border border-slate-200 hover:border-teal-400 transition-colors flex items-center gap-2.5 sm:gap-3"
        >
          <div className="w-8 h-8 rounded-lg bg-teal-100 text-teal-700 flex items-center justify-center shrink-0">
            <Tag className="w-4 h-4" />
          </div>
          <div className="min-w-0">
            <div className="text-xs font-bold text-slate-900 truncate">Coupons</div>
            <div className="text-[10px] text-slate-500 truncate">Discounts</div>
          </div>
        </Link>

        <Link
          to={ROUTES.ADMIN.PAYMENTS}
          className="bg-white p-3 sm:p-3.5 rounded-xl border border-slate-200 hover:border-sky-400 transition-colors flex items-center gap-2.5 sm:gap-3"
        >
          <div className="w-8 h-8 rounded-lg bg-sky-100 text-sky-700 flex items-center justify-center shrink-0">
            <CreditCard className="w-4 h-4" />
          </div>
          <div className="min-w-0">
            <div className="text-xs font-bold text-slate-900 truncate">Payments</div>
            <div className="text-[10px] text-slate-500 truncate">Orders & Revenue</div>
          </div>
        </Link>
      </div>

      {/* Main Content Grid: Batches Catalog & Audit Trail */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 sm:gap-6">
        {/* Batches Table (2 Cols) */}
        <div className="lg:col-span-2 bg-white rounded-2xl border border-slate-200 overflow-hidden">
          <div className="p-4 sm:p-5 border-b border-slate-100 flex items-center justify-between gap-2">
            <div>
              <h2 className="text-sm sm:text-base font-extrabold text-slate-900">
                Course Batches Registry
              </h2>
              <p className="text-[11px] sm:text-xs text-slate-500">Live in Firestore</p>
            </div>
            <Link to={ROUTES.ADMIN.BATCHES}>
              <Button variant="outline" size="sm" rightIcon={<ArrowRight className="w-3.5 h-3.5" />}>
                <span className="hidden sm:inline">View All Batches</span>
                <span className="sm:hidden">All</span>
              </Button>
            </Link>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs min-w-[500px]">
              <thead className="bg-slate-50/80 text-slate-500 uppercase text-[10px] font-bold border-b border-slate-100">
                <tr>
                  <th className="px-4 sm:px-5 py-3">Course / Batch</th>
                  <th className="px-4 sm:px-5 py-3">Price</th>
                  <th className="px-4 sm:px-5 py-3">Status</th>
                  <th className="px-4 sm:px-5 py-3 text-right">Quick Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 font-medium text-slate-700">
                {batches.length === 0 ? (
                  <tr>
                    <td colSpan={4} className="px-5 py-8 text-center text-slate-400">
                      No batches found. Click "Sync Syllabus" above to populate course catalog.
                    </td>
                  </tr>
                ) : (
                  batches.slice(0, 5).map((batch) => (
                    <tr key={batch.id} className="hover:bg-slate-50/60 transition-colors">
                      <td className="px-4 sm:px-5 py-3.5">
                        <div className="flex items-center gap-3">
                          <img
                            src={batch.thumbnailUrl}
                            alt=""
                            className="w-10 h-8 rounded-lg object-cover bg-slate-100 shrink-0 border border-slate-200"
                          />
                          <div className="min-w-0">
                            <span className="font-bold text-slate-900 block truncate max-w-[180px] sm:max-w-[220px]">
                              {batch.title}
                            </span>
                            <span className="text-[10px] text-slate-400 font-mono truncate block">
                              /{batch.slug}
                            </span>
                          </div>
                        </div>
                      </td>
                      <td className="px-4 sm:px-5 py-3.5 font-bold text-slate-900 whitespace-nowrap">
                        {batch.isFree ? (
                          <span className="text-emerald-600">FREE</span>
                        ) : (
                          formatCurrency(batch.price)
                        )}
                      </td>
                      <td className="px-4 sm:px-5 py-3.5 whitespace-nowrap">
                        <PublishStatusBadge isPublished={batch.isPublished} />
                      </td>
                      <td className="px-4 sm:px-5 py-3.5 text-right whitespace-nowrap">
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            type="button"
                            onClick={() => handleToggleBatch(batch)}
                            title={batch.isPublished ? 'Unpublish' : 'Publish'}
                            className={`p-1.5 rounded-lg border transition-colors ${
                              batch.isPublished
                                ? 'border-emerald-200 text-emerald-600 hover:bg-emerald-50'
                                : 'border-slate-200 text-slate-400 hover:bg-slate-100'
                            }`}
                          >
                            {batch.isPublished ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
                          </button>
                          <Link to={`/admin/subjects?batchId=${batch.id}`}>
                            <Button variant="ghost" size="sm">
                              Curriculum
                            </Button>
                          </Link>
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* Live Audit Log Stream (1 Col) */}
        <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs flex flex-col">
          <div className="p-4 sm:p-5 border-b border-slate-100 flex items-center justify-between">
            <div>
              <h2 className="text-sm sm:text-base font-extrabold text-slate-900 flex items-center gap-2">
                <History className="w-4 h-4 text-blue-600" />
                <span>Audit Trail</span>
              </h2>
              <p className="text-[11px] sm:text-xs text-slate-500">Recent administrator actions</p>
            </div>
            <Link to={ROUTES.ADMIN.AUDIT_LOGS}>
              <Button variant="ghost" size="sm">
                Full Log
              </Button>
            </Link>
          </div>

          <div className="p-3 sm:p-4 flex-1 overflow-y-auto max-h-[380px] space-y-2.5">
            {auditLogs.length === 0 ? (
              <div className="py-8 text-center text-slate-400 text-xs">
                No recorded actions yet.
              </div>
            ) : (
              auditLogs.map((log) => (
                <div
                  key={log.id}
                  className="p-2.5 rounded-xl bg-slate-50 border border-slate-100 text-xs space-y-1"
                >
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-slate-900 text-[11px] truncate max-w-[140px]">
                      {log.action.replace('_', ' ')}
                    </span>
                    <span className="text-[10px] text-slate-400">
                      {log.timestamp ? 'Just now' : 'Logged'}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-600 truncate">
                    {log.resourceTitle || log.resourceId}
                  </p>
                  <div className="text-[10px] text-slate-400 flex items-center justify-between pt-0.5">
                    <span className="truncate max-w-[140px]">{log.actorEmail}</span>
                    <Badge variant="blue" size="sm" className="text-[9px] py-0 px-1.5 uppercase">
                      {log.resourceType}
                    </Badge>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>

      {/* Recent Course Purchases & Student Orders Section */}
      <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden">
        <div className="p-4 sm:p-5 border-b border-slate-100 flex items-center justify-between gap-2">
          <div>
            <h2 className="text-sm sm:text-base font-extrabold text-slate-900 flex items-center gap-2">
              <CreditCard className="w-4 h-4 text-indigo-600" />
              <span>Recent Student Course Purchases & Enrollments</span>
            </h2>
            <p className="text-[11px] sm:text-xs text-slate-500">Live student purchases and course unlocks</p>
          </div>
          <Link to={ROUTES.ADMIN.STUDENTS}>
            <Button variant="outline" size="sm" rightIcon={<ArrowRight className="w-3.5 h-3.5" />}>
              <span className="hidden sm:inline">Student Directory</span>
              <span className="sm:hidden">Directory</span>
            </Button>
          </Link>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs min-w-[550px]">
            <thead className="bg-slate-50/80 text-slate-500 uppercase text-[10px] font-bold border-b border-slate-100">
              <tr>
                <th className="px-4 sm:px-5 py-3">Course / Batch</th>
                <th className="px-4 sm:px-5 py-3">Student UID</th>
                <th className="px-4 sm:px-5 py-3">Amount</th>
                <th className="px-4 sm:px-5 py-3">Date Purchased</th>
                <th className="px-4 sm:px-5 py-3 text-right">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-medium text-slate-700">
              {recentEnrollments.length === 0 ? (
                <tr>
                  <td colSpan={5} className="px-5 py-8 text-center text-slate-400">
                    No student purchases recorded yet. Newly purchased courses will appear here in real time.
                  </td>
                </tr>
              ) : (
                recentEnrollments.map((enr) => (
                  <tr key={enr.id} className="hover:bg-slate-50/60 transition-colors">
                    <td className="px-4 sm:px-5 py-3.5">
                      <span className="font-extrabold text-slate-900 block truncate max-w-[200px] sm:max-w-[240px]">
                        {enr.courseTitle || 'Course Batch'}
                      </span>
                      {enr.couponCode && (
                        <span className="text-[10px] text-indigo-600 font-mono font-bold block">
                          Coupon: {enr.couponCode}
                        </span>
                      )}
                    </td>
                    <td className="px-4 sm:px-5 py-3.5 font-mono text-[11px] text-slate-500">
                      {enr.userId ? `${enr.userId.slice(0, 12)}...` : 'Registered Student'}
                    </td>
                    <td className="px-4 sm:px-5 py-3.5 font-extrabold text-slate-900 whitespace-nowrap">
                      {enr.isFree ? (
                        <span className="text-emerald-600">FREE</span>
                      ) : (
                        formatCurrency(enr.amountPaid || 0)
                      )}
                    </td>
                    <td className="px-4 sm:px-5 py-3.5 whitespace-nowrap text-slate-600">
                      {enr.enrolledAt ? formatDate(enr.enrolledAt) : 'Recently'}
                    </td>
                    <td className="px-4 sm:px-5 py-3.5 text-right whitespace-nowrap">
                      <Badge
                        variant={enr.status === 'active' ? 'emerald' : 'amber'}
                        size="sm"
                        className="capitalize font-bold"
                      >
                        {enr.status}
                      </Badge>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Wipe / Purge All Curriculum Confirmation Modal */}
      <ConfirmationModal
        isOpen={isPurgeModalOpen}
        onCancel={() => !purging && setIsPurgeModalOpen(false)}
        onConfirm={handlePurgeAllCurriculum}
        title="Delete All Data (Real & Fake)?"
        message="Are you sure you want to permanently delete all courses, subjects, chapters, classes, PDF notes, tests, and mock records from both Firebase Firestore and local storage? Everything will be completely cleared so you can build your academy from scratch."
        confirmLabel="Yes, Delete Everything"
        isDestructive={true}
        isLoading={purging}
      />
    </div>
  );
}

export default AdminDashboardPage;
