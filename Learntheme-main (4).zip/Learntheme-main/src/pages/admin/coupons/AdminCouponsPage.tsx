/**
 * Axon Nursing Academy - Admin Coupon Management CMS (Phase 6.1)
 * Real, simple, admin-managed discount coupons.
 * Full CRUD, status toggle, date limits, usage bounds, and course assignment.
 */
import React, { useState, useEffect, useMemo } from 'react';
import {
  Tag,
  Plus,
  Search,
  Filter,
  RefreshCw,
  Edit2,
  Trash2,
  CheckCircle2,
  XCircle,
  Clock,
  Percent,
  IndianRupee,
  Layers,
  AlertTriangle,
  X,
  Calendar,
} from 'lucide-react';
import { useAuth } from '@/src/contexts/AuthContext';
import { Coupon, CouponFormData, CouponDiscountType } from '@/src/types/coupon.types';
import { Batch } from '@/src/types/lms.types';
import {
  getAllCouponsAdmin,
  createCoupon,
  updateCoupon,
  deleteCoupon,
  toggleCouponActive,
  normalizeCouponCode,
} from '@/src/services/firebase/couponService';
import { getAllBatchesAdmin } from '@/src/services/firebase/adminBatchService';

export const AdminCouponsPage: React.FC = () => {
  const { currentUser } = useAuth();
  const [coupons, setCoupons] = useState<Coupon[]>([]);
  const [batches, setBatches] = useState<Batch[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'active' | 'inactive' | 'expired'>('all');

  // Modal State
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingCoupon, setEditingCoupon] = useState<Coupon | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);

  // Form State
  const [formData, setFormData] = useState<CouponFormData>({
    code: '',
    discountType: 'percentage',
    discountValue: 10,
    isActive: true,
    validFrom: new Date().toISOString().split('T')[0],
    validUntil: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
    usageLimit: 100,
    applicableCourseIds: ['all'],
    description: '',
  });

  // Delete Confirmation State
  const [deleteTarget, setDeleteTarget] = useState<Coupon | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);

  const fetchData = async () => {
    try {
      const [fetchedCoupons, fetchedBatches] = await Promise.all([
        getAllCouponsAdmin(),
        getAllBatchesAdmin(),
      ]);
      setCoupons(fetchedCoupons);
      setBatches(fetchedBatches);
    } catch (err) {
      console.error('[AdminCouponsPage] Error fetching data:', err);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleRefresh = () => {
    setRefreshing(true);
    fetchData();
  };

  // Open Create Modal
  const handleOpenCreate = () => {
    setEditingCoupon(null);
    setFormData({
      code: '',
      discountType: 'percentage',
      discountValue: 10,
      isActive: true,
      validFrom: new Date().toISOString().split('T')[0],
      validUntil: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      usageLimit: 100,
      applicableCourseIds: ['all'],
      description: '',
    });
    setFormError(null);
    setIsModalOpen(true);
  };

  // Open Edit Modal
  const handleOpenEdit = (coupon: Coupon) => {
    setEditingCoupon(coupon);
    setFormData({
      code: coupon.code,
      discountType: coupon.discountType,
      discountValue: coupon.discountValue,
      isActive: coupon.isActive,
      validFrom: coupon.validFrom ? coupon.validFrom.split('T')[0] : '',
      validUntil: coupon.validUntil ? coupon.validUntil.split('T')[0] : '',
      usageLimit: coupon.usageLimit,
      applicableCourseIds: coupon.applicableCourseIds.length > 0 ? coupon.applicableCourseIds : ['all'],
      description: coupon.description || '',
    });
    setFormError(null);
    setIsModalOpen(true);
  };

  // Form Submission
  const handleFormSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) return;

    const normalizedCode = normalizeCouponCode(formData.code);
    if (!normalizedCode || normalizedCode.length < 3) {
      setFormError('Coupon code must be at least 3 alphanumeric characters.');
      return;
    }

    if (formData.discountValue <= 0) {
      setFormError('Discount value must be greater than 0.');
      return;
    }

    if (formData.discountType === 'percentage' && formData.discountValue > 100) {
      setFormError('Percentage discount cannot exceed 100%.');
      return;
    }

    if (new Date(formData.validUntil).getTime() <= new Date(formData.validFrom).getTime()) {
      setFormError('Valid until date must be after valid from date.');
      return;
    }

    setSubmitting(true);
    setFormError(null);

    try {
      const actorEmail = currentUser.email || 'pmgautamjaipur@gmail.com';
      if (editingCoupon) {
        await updateCoupon(editingCoupon.id, formData, currentUser.uid, actorEmail);
      } else {
        await createCoupon(formData, currentUser.uid, actorEmail);
      }

      await fetchData();
      setIsModalOpen(false);
    } catch (err: any) {
      setFormError(err?.message || 'Failed to save coupon. Please verify fields.');
    } finally {
      setSubmitting(false);
    }
  };

  // Toggle Active status directly
  const handleToggleActive = async (coupon: Coupon) => {
    if (!currentUser) return;
    try {
      await toggleCouponActive(
        coupon.id,
        coupon.isActive,
        currentUser.uid,
        currentUser.email || 'pmgautamjaipur@gmail.com'
      );
      setCoupons((prev) =>
        prev.map((c) => (c.id === coupon.id ? { ...c, isActive: !c.isActive } : c))
      );
    } catch (err) {
      console.error('[AdminCouponsPage] Error toggling status:', err);
    }
  };

  // Delete Action
  const handleDeleteConfirm = async () => {
    if (!deleteTarget || !currentUser) return;
    setIsDeleting(true);
    try {
      await deleteCoupon(
        deleteTarget.id,
        currentUser.uid,
        currentUser.email || 'pmgautamjaipur@gmail.com'
      );
      setCoupons((prev) => prev.filter((c) => c.id !== deleteTarget.id));
      setDeleteTarget(null);
    } catch (err) {
      console.error('[AdminCouponsPage] Error deleting coupon:', err);
    } finally {
      setIsDeleting(false);
    }
  };

  // Filtered Coupons
  const filteredCoupons = useMemo(() => {
    const now = Date.now();
    return coupons.filter((coupon) => {
      // Search
      const matchesSearch =
        coupon.code.toLowerCase().includes(searchQuery.toLowerCase()) ||
        (coupon.description || '').toLowerCase().includes(searchQuery.toLowerCase());

      if (!matchesSearch) return false;

      // Status
      const isExpired = coupon.validUntil && new Date(coupon.validUntil).getTime() < now;
      if (statusFilter === 'active') return coupon.isActive && !isExpired;
      if (statusFilter === 'inactive') return !coupon.isActive;
      if (statusFilter === 'expired') return isExpired;
      return true;
    });
  }, [coupons, searchQuery, statusFilter]);

  return (
    <div id="admin-coupons-page" className="space-y-6">
      {/* Header Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-6 bg-white rounded-2xl border border-slate-200/80 shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <div className="p-2 bg-blue-50 text-blue-600 rounded-xl">
              <Tag className="w-5 h-5" />
            </div>
            <h1 className="text-xl font-bold text-slate-900 tracking-tight">
              Coupons Management
            </h1>
          </div>
          <p className="mt-1 text-xs text-slate-500">
            Admin-managed discount codes for course enrollment. Strictly zero-trust live validation.
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            id="refresh-coupons-btn"
            onClick={handleRefresh}
            disabled={refreshing}
            className="p-2.5 rounded-xl border border-slate-200 text-slate-600 hover:bg-slate-50 hover:text-slate-900 transition-colors disabled:opacity-50"
            title="Refresh coupons"
          >
            <RefreshCw className={`w-4 h-4 ${refreshing ? 'animate-spin' : ''}`} />
          </button>

          <button
            id="create-coupon-btn"
            onClick={handleOpenCreate}
            className="flex items-center gap-2 px-4 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-semibold shadow-xs transition-colors"
          >
            <Plus className="w-4 h-4" />
            Create Coupon
          </button>
        </div>
      </div>

      {/* Metrics Row */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-4 bg-white rounded-xl border border-slate-200/80">
          <p className="text-[11px] font-medium text-slate-500 uppercase tracking-wider">Total Coupons</p>
          <p className="mt-1 text-2xl font-bold text-slate-900">{coupons.length}</p>
        </div>

        <div className="p-4 bg-white rounded-xl border border-slate-200/80">
          <p className="text-[11px] font-medium text-slate-500 uppercase tracking-wider">Active Coupons</p>
          <p className="mt-1 text-2xl font-bold text-emerald-600">
            {coupons.filter((c) => c.isActive && (!c.validUntil || new Date(c.validUntil).getTime() > Date.now())).length}
          </p>
        </div>

        <div className="p-4 bg-white rounded-xl border border-slate-200/80">
          <p className="text-[11px] font-medium text-slate-500 uppercase tracking-wider">Total Redemptions</p>
          <p className="mt-1 text-2xl font-bold text-blue-600">
            {coupons.reduce((acc, c) => acc + (c.usedCount || 0), 0)}
          </p>
        </div>

        <div className="p-4 bg-white rounded-xl border border-slate-200/80">
          <p className="text-[11px] font-medium text-slate-500 uppercase tracking-wider">Course Batches</p>
          <p className="mt-1 text-2xl font-bold text-slate-700">{batches.length}</p>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 p-3 bg-white rounded-xl border border-slate-200/80">
        <div className="relative w-full sm:w-72">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            id="coupon-search-input"
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search code or description..."
            className="w-full pl-9 pr-3 py-1.5 text-xs rounded-lg border border-slate-200 focus:outline-hidden focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
          />
        </div>

        <div className="flex items-center gap-1.5 w-full sm:w-auto overflow-x-auto">
          {(['all', 'active', 'inactive', 'expired'] as const).map((tab) => (
            <button
              key={tab}
              onClick={() => setStatusFilter(tab)}
              className={`px-3 py-1.5 text-xs rounded-lg font-medium capitalize transition-colors whitespace-nowrap ${
                statusFilter === tab
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'text-slate-600 hover:bg-slate-100'
              }`}
            >
              {tab}
            </button>
          ))}
        </div>
      </div>

      {/* Coupons Table / Grid */}
      {loading ? (
        <div className="p-12 text-center bg-white rounded-2xl border border-slate-200">
          <RefreshCw className="w-6 h-6 text-blue-600 animate-spin mx-auto mb-2" />
          <p className="text-xs text-slate-500">Loading coupons...</p>
        </div>
      ) : filteredCoupons.length === 0 ? (
        <div className="p-12 text-center bg-white rounded-2xl border border-slate-200">
          <Tag className="w-10 h-10 text-slate-300 mx-auto mb-3" />
          <h3 className="text-sm font-bold text-slate-800">No coupons found</h3>
          <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
            {searchQuery || statusFilter !== 'all'
              ? 'No coupons match your filter criteria.'
              : 'Create your first discount coupon to offer student concessions.'}
          </p>
          <button
            onClick={handleOpenCreate}
            className="mt-4 inline-flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-xl text-xs font-semibold hover:bg-blue-700 transition-colors"
          >
            <Plus className="w-4 h-4" />
            Create Coupon
          </button>
        </div>
      ) : (
        <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-xs">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50/75 border-b border-slate-200 text-[11px] font-semibold text-slate-600 uppercase tracking-wider">
                <tr>
                  <th className="py-3.5 px-4">Coupon Code</th>
                  <th className="py-3.5 px-4">Discount</th>
                  <th className="py-3.5 px-4">Status</th>
                  <th className="py-3.5 px-4">Redemptions</th>
                  <th className="py-3.5 px-4">Validity</th>
                  <th className="py-3.5 px-4">Applicability</th>
                  <th className="py-3.5 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-slate-700">
                {filteredCoupons.map((coupon) => {
                  const isExpired =
                    coupon.validUntil && new Date(coupon.validUntil).getTime() < Date.now();
                  const isExhausted =
                    coupon.usageLimit > 0 && coupon.usedCount >= coupon.usageLimit;

                  return (
                    <tr key={coupon.id} className="hover:bg-slate-50/50 transition-colors">
                      {/* Code */}
                      <td className="py-3.5 px-4 font-mono font-bold text-slate-900">
                        <div className="flex items-center gap-2">
                          <span className="px-2.5 py-1 bg-slate-100 rounded-lg border border-slate-200 tracking-wider">
                            {coupon.code}
                          </span>
                        </div>
                        {coupon.description && (
                          <p className="mt-1 text-[11px] font-normal text-slate-500 max-w-xs truncate">
                            {coupon.description}
                          </p>
                        )}
                      </td>

                      {/* Discount */}
                      <td className="py-3.5 px-4 font-medium">
                        <span className="inline-flex items-center gap-1 font-bold text-slate-900">
                          {coupon.discountType === 'percentage' ? (
                            <>
                              <Percent className="w-3.5 h-3.5 text-blue-600" />
                              {coupon.discountValue}% OFF
                            </>
                          ) : (
                            <>
                              <IndianRupee className="w-3.5 h-3.5 text-emerald-600" />
                              ₹{coupon.discountValue} OFF
                            </>
                          )}
                        </span>
                      </td>

                      {/* Status */}
                      <td className="py-3.5 px-4">
                        <button
                          onClick={() => handleToggleActive(coupon)}
                          className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-semibold transition-colors ${
                            !coupon.isActive
                              ? 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                              : isExpired
                              ? 'bg-amber-50 text-amber-700 border border-amber-200'
                              : isExhausted
                              ? 'bg-rose-50 text-rose-700 border border-rose-200'
                              : 'bg-emerald-50 text-emerald-700 border border-emerald-200 hover:bg-emerald-100'
                          }`}
                          title="Click to toggle active status"
                        >
                          {!coupon.isActive ? (
                            <>
                              <XCircle className="w-3 h-3" /> Inactive
                            </>
                          ) : isExpired ? (
                            <>
                              <Clock className="w-3 h-3" /> Expired
                            </>
                          ) : isExhausted ? (
                            <>
                              <AlertTriangle className="w-3 h-3" /> Limit Reached
                            </>
                          ) : (
                            <>
                              <CheckCircle2 className="w-3 h-3" /> Active
                            </>
                          )}
                        </button>
                      </td>

                      {/* Redemptions */}
                      <td className="py-3.5 px-4">
                        <span className="font-semibold text-slate-800">{coupon.usedCount}</span>
                        <span className="text-slate-400">
                          {' '}
                          / {coupon.usageLimit > 0 ? coupon.usageLimit : '∞'}
                        </span>
                      </td>

                      {/* Validity */}
                      <td className="py-3.5 px-4 text-slate-600 text-[11px]">
                        <div>From: {coupon.validFrom ? new Date(coupon.validFrom).toLocaleDateString() : 'Immediate'}</div>
                        <div>Until: {coupon.validUntil ? new Date(coupon.validUntil).toLocaleDateString() : 'No expiry'}</div>
                      </td>

                      {/* Applicability */}
                      <td className="py-3.5 px-4 text-slate-600">
                        {coupon.applicableCourseIds.includes('all') || coupon.applicableCourseIds.length === 0 ? (
                          <span className="px-2 py-0.5 bg-blue-50 text-blue-700 rounded-md font-medium text-[11px]">
                            All Courses
                          </span>
                        ) : (
                          <span className="px-2 py-0.5 bg-slate-100 text-slate-700 rounded-md font-medium text-[11px]">
                            {coupon.applicableCourseIds.length} Specific Batch(es)
                          </span>
                        )}
                      </td>

                      {/* Actions */}
                      <td className="py-3.5 px-4 text-right space-x-1">
                        <button
                          onClick={() => handleOpenEdit(coupon)}
                          className="p-1.5 rounded-lg text-slate-500 hover:text-blue-600 hover:bg-blue-50 transition-colors"
                          title="Edit coupon"
                        >
                          <Edit2 className="w-4 h-4" />
                        </button>

                        <button
                          onClick={() => setDeleteTarget(coupon)}
                          className="p-1.5 rounded-lg text-slate-500 hover:text-rose-600 hover:bg-rose-50 transition-colors"
                          title="Delete coupon"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Create / Edit Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs animate-in fade-in duration-150">
          <div className="w-full max-w-lg bg-white rounded-2xl border border-slate-200 shadow-xl overflow-hidden">
            <div className="flex items-center justify-between p-5 border-b border-slate-100 bg-slate-50/50">
              <div className="flex items-center gap-2">
                <Tag className="w-5 h-5 text-blue-600" />
                <h3 className="font-bold text-slate-900 text-sm">
                  {editingCoupon ? `Edit Coupon: ${editingCoupon.code}` : 'Create New Coupon'}
                </h3>
              </div>
              <button
                onClick={() => setIsModalOpen(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100 transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {formError && (
              <div className="mx-5 mt-4 p-3 rounded-xl bg-rose-50 border border-rose-200 flex items-center gap-2 text-rose-700 text-xs">
                <AlertTriangle className="w-4 h-4 shrink-0" />
                <span>{formError}</span>
              </div>
            )}

            <form onSubmit={handleFormSubmit} className="p-5 space-y-4 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {/* Code */}
                <div className="sm:col-span-2 space-y-1">
                  <label className="font-bold text-slate-700">Coupon Code *</label>
                  <input
                    type="text"
                    required
                    value={formData.code}
                    onChange={(e) =>
                      setFormData({ ...formData, code: normalizeCouponCode(e.target.value) })
                    }
                    placeholder="e.g. AXON50"
                    className="w-full px-3.5 py-2 rounded-xl border border-slate-200 uppercase font-mono font-bold tracking-wider text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
                  />
                  <p className="text-[11px] text-slate-500">
                    Codes are normalized to uppercase alphanumeric characters automatically.
                  </p>
                </div>

                {/* Discount Type */}
                <div className="space-y-1">
                  <label className="font-bold text-slate-700">Discount Type *</label>
                  <select
                    value={formData.discountType}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        discountType: e.target.value as CouponDiscountType,
                      })
                    }
                    className="w-full px-3.5 py-2 rounded-xl border border-slate-200 bg-white font-medium focus:outline-hidden focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
                  >
                    <option value="percentage">Percentage (%)</option>
                    <option value="fixed">Flat Amount (₹)</option>
                  </select>
                </div>

                {/* Discount Value */}
                <div className="space-y-1">
                  <label className="font-bold text-slate-700">
                    Discount Value {formData.discountType === 'percentage' ? '(%)' : '(₹)'} *
                  </label>
                  <input
                    type="number"
                    min={1}
                    max={formData.discountType === 'percentage' ? 100 : 50000}
                    required
                    value={formData.discountValue}
                    onChange={(e) =>
                      setFormData({ ...formData, discountValue: Number(e.target.value) })
                    }
                    className="w-full px-3.5 py-2 rounded-xl border border-slate-200 font-bold focus:outline-hidden focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
                  />
                </div>

                {/* Valid From */}
                <div className="space-y-1">
                  <label className="font-bold text-slate-700">Valid From *</label>
                  <input
                    type="date"
                    required
                    value={formData.validFrom}
                    onChange={(e) => setFormData({ ...formData, validFrom: e.target.value })}
                    className="w-full px-3.5 py-2 rounded-xl border border-slate-200 focus:outline-hidden focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
                  />
                </div>

                {/* Valid Until */}
                <div className="space-y-1">
                  <label className="font-bold text-slate-700">Valid Until *</label>
                  <input
                    type="date"
                    required
                    value={formData.validUntil}
                    onChange={(e) => setFormData({ ...formData, validUntil: e.target.value })}
                    className="w-full px-3.5 py-2 rounded-xl border border-slate-200 focus:outline-hidden focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
                  />
                </div>

                {/* Usage Limit */}
                <div className="space-y-1">
                  <label className="font-bold text-slate-700">Usage Limit (Max Uses) *</label>
                  <input
                    type="number"
                    min={1}
                    required
                    value={formData.usageLimit}
                    onChange={(e) =>
                      setFormData({ ...formData, usageLimit: Number(e.target.value) })
                    }
                    className="w-full px-3.5 py-2 rounded-xl border border-slate-200 focus:outline-hidden focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
                  />
                </div>

                {/* Applicable Batch */}
                <div className="space-y-1">
                  <label className="font-bold text-slate-700">Applicable Course *</label>
                  <select
                    value={formData.applicableCourseIds[0] || 'all'}
                    onChange={(e) =>
                      setFormData({ ...formData, applicableCourseIds: [e.target.value] })
                    }
                    className="w-full px-3.5 py-2 rounded-xl border border-slate-200 bg-white focus:outline-hidden focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
                  >
                    <option value="all">All Courses & Batches</option>
                    {batches.map((b) => (
                      <option key={b.id} value={b.id}>
                        {b.title}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Description */}
                <div className="sm:col-span-2 space-y-1">
                  <label className="font-bold text-slate-700">Description / Campaign Notes</label>
                  <textarea
                    rows={2}
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    placeholder="e.g. Special festive 50% discount for NORCET 2026 aspirants"
                    className="w-full px-3.5 py-2 rounded-xl border border-slate-200 focus:outline-hidden focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
                  />
                </div>

                {/* Is Active Toggle */}
                <div className="sm:col-span-2">
                  <label className="flex items-center gap-2.5 p-3 rounded-xl border border-slate-200 bg-slate-50 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={formData.isActive}
                      onChange={(e) => setFormData({ ...formData, isActive: e.target.checked })}
                      className="w-4 h-4 text-blue-600 rounded-md border-slate-300 focus:ring-blue-500"
                    />
                    <div>
                      <p className="font-bold text-slate-800">Activate this coupon immediately</p>
                      <p className="text-[11px] text-slate-500">Students can apply this code during checkout when active.</p>
                    </div>
                  </label>
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 rounded-xl border border-slate-200 text-slate-600 hover:bg-slate-50 font-medium"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={submitting}
                  className="px-5 py-2 bg-blue-600 text-white rounded-xl font-semibold hover:bg-blue-700 disabled:opacity-50 transition-colors shadow-xs"
                >
                  {submitting ? 'Saving...' : editingCoupon ? 'Update Coupon' : 'Create Coupon'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {deleteTarget && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs">
          <div className="w-full max-w-md bg-white rounded-2xl border border-slate-200 p-6 shadow-xl space-y-4 text-xs">
            <div className="flex items-center gap-3 text-rose-600">
              <div className="p-2.5 bg-rose-50 rounded-xl">
                <AlertTriangle className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-slate-900">Delete Coupon</h3>
                <p className="text-slate-500">Are you sure you want to permanently delete coupon?</p>
              </div>
            </div>

            <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
              <p className="font-mono font-bold text-slate-800 text-sm">{deleteTarget.code}</p>
              <p className="text-slate-500 mt-1">
                Discount: {deleteTarget.discountType === 'percentage' ? `${deleteTarget.discountValue}%` : `₹${deleteTarget.discountValue}`} • Used {deleteTarget.usedCount} times
              </p>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                onClick={() => setDeleteTarget(null)}
                className="px-4 py-2 rounded-xl border border-slate-200 text-slate-600 hover:bg-slate-50 font-medium"
              >
                Cancel
              </button>
              <button
                onClick={handleDeleteConfirm}
                disabled={isDeleting}
                className="px-4 py-2 bg-rose-600 text-white rounded-xl font-semibold hover:bg-rose-700 disabled:opacity-50 transition-colors"
              >
                {isDeleting ? 'Deleting...' : 'Delete Coupon'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
