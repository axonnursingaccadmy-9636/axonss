/**
 * Axon Nursing Academy - Admin Batches CMS
 * Complete Course/Batch creation, editing, publishing, and curriculum navigation.
 */
import React, { useState, useEffect } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import {
  BookMarked,
  Plus,
  Search,
  Filter,
  Edit2,
  Trash2,
  Eye,
  EyeOff,
  Layers,
  ExternalLink,
  RefreshCw,
  Sparkles,
  Check,
  X,
} from 'lucide-react';
import { ROUTES } from '@/src/config/routes.config';
import { formatCurrency } from '@/src/lib/utils/formatters';
import { Badge } from '@/src/components/ui/Badge';
import { Button } from '@/src/components/ui/Button';
import { AdminPageHeader } from '@/src/components/admin/AdminPageHeader';
import { PublishStatusBadge, FreeBadge } from '@/src/components/admin/StatusBadge';
import { ConfirmationModal } from '@/src/components/admin/ConfirmationModal';
import { ImageUploadField } from '@/src/components/common/ImageUploadField';
import { fallbackStore } from '@/src/services/fallback/fallbackStore';
import {
  getAllBatchesAdmin,
  subscribeToBatchesAdmin,
  createBatch,
  updateBatch,
  deleteBatch,
  toggleBatchPublish,
  BatchFormData,
  generateSlug,
} from '@/src/services/firebase/adminBatchService';
import { Batch } from '@/src/types/lms.types';
import { useAuth } from '@/src/contexts/AuthContext';

export function AdminBatchesPage() {
  const { currentUser } = useAuth();
  const initialBatches = fallbackStore.getBatches();
  const [batches, setBatches] = useState<Batch[]>(() => initialBatches);
  const [loading, setLoading] = useState(() => initialBatches.length === 0);
  const [refreshing, setRefreshing] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'published' | 'draft' | 'free' | 'paid'>('all');

  // Modal State
  const [isFormModalOpen, setIsFormModalOpen] = useState(false);
  const [editingBatch, setEditingBatch] = useState<Batch | null>(null);
  const [formData, setFormData] = useState<BatchFormData>({
    title: '',
    slug: '',
    shortDescription: '',
    description: '',
    thumbnailUrl: '',
    bannerUrl: '',
    price: 3499,
    originalPrice: 7999,
    durationDays: 180,
    isFree: false,
    isFeatured: true,
    isPublished: true,
    order: 1,
  });
  const [submitting, setSubmitting] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);

  // Delete State
  const [deleteTarget, setDeleteTarget] = useState<Batch | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);

  useEffect(() => {
    const unsubscribe = subscribeToBatchesAdmin(
      (data) => {
        setBatches(data);
        setLoading(false);
        setRefreshing(false);
      },
      (err) => {
        console.warn('[AdminBatchesPage] Realtime subscription notice:', err);
        setLoading(false);
        setRefreshing(false);
      }
    );

    return () => unsubscribe();
  }, []);

  const handleRefresh = async () => {
    setRefreshing(true);
    try {
      const data = await getAllBatchesAdmin();
      setBatches(data);
    } catch (err) {
      console.warn('[AdminBatchesPage] Refresh notice:', err);
    } finally {
      setRefreshing(false);
    }
  };

  // Open Create Modal
  const handleOpenCreate = () => {
    setEditingBatch(null);
    setFormData({
      title: '',
      slug: '',
      shortDescription: '',
      description: '',
      thumbnailUrl: 'https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?w=800&auto=format&fit=crop&q=80',
      bannerUrl: 'https://images.unsplash.com/photo-1584515979956-d9f6e5d09982?w=1200&auto=format&fit=crop&q=80',
      price: 3499,
      originalPrice: 7999,
      durationDays: 180,
      duration: '6 Months',
      isFree: false,
      isFeatured: true,
      isPublished: true,
      order: batches.length + 1,
    });
    setFormError(null);
    setIsFormModalOpen(true);
  };

  // Open Edit Modal
  const handleOpenEdit = (batch: Batch) => {
    setEditingBatch(batch);
    setFormData({
      title: batch.title,
      slug: batch.slug,
      shortDescription: batch.shortDescription,
      description: batch.description,
      thumbnailUrl: batch.thumbnailUrl,
      bannerUrl: batch.bannerUrl,
      price: batch.price,
      originalPrice: batch.originalPrice,
      durationDays: batch.durationDays,
      duration: batch.duration || (batch.durationDays ? `${batch.durationDays} Days` : '180 Days'),
      isFree: batch.isFree,
      isFeatured: batch.isFeatured,
      isPublished: batch.isPublished,
      order: batch.order,
    });
    setFormError(null);
    setIsFormModalOpen(true);
  };

  // Title change auto-slug
  const handleTitleChange = (val: string) => {
    setFormData((prev) => ({
      ...prev,
      title: val,
      slug: editingBatch ? prev.slug : generateSlug(val),
    }));
  };

  // Form submit
  const handleFormSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) return;
    if (!formData.title.trim()) {
      setFormError('Batch title is required.');
      return;
    }

    setSubmitting(true);
    setFormError(null);

    try {
      if (editingBatch) {
        const batchId = editingBatch.id;
        await updateBatch(
          batchId,
          formData,
          currentUser.uid,
          currentUser.email || undefined
        );

        const updatedBatch: Batch = {
          ...editingBatch,
          ...formData,
          slug: formData.slug || editingBatch.slug,
          updatedAt: new Date().toISOString(),
        };

        setBatches((prev) =>
          prev.map((b) => (b.id === batchId ? updatedBatch : b))
        );
        setIsFormModalOpen(false);
      } else {
        const saved = await createBatch(
          formData,
          currentUser.uid,
          currentUser.email || undefined
        );

        setBatches((prev) => [...prev, saved]);
        setIsFormModalOpen(false);
      }
    } catch (err: any) {
      console.error('Error saving batch:', err);
      setFormError(err?.message || 'Failed to save batch in Firestore. Please check your connection and admin privileges.');
    } finally {
      setSubmitting(false);
    }
  };

  // Toggle publish
  const handleTogglePublish = async (batch: Batch) => {
    if (!currentUser) return;
    const newStatus = !batch.isPublished;
    // Instant optimistic update
    setBatches((prev) =>
      prev.map((b) => (b.id === batch.id ? { ...b, isPublished: newStatus } : b))
    );

    try {
      await toggleBatchPublish(
        batch.id,
        newStatus,
        batch.title,
        currentUser.uid,
        currentUser.email || undefined
      );
    } catch (err) {
      console.error('Failed to toggle publish status:', err);
      // Revert if error
      setBatches((prev) =>
        prev.map((b) => (b.id === batch.id ? { ...b, isPublished: batch.isPublished } : b))
      );
    }
  };

  // Delete
  const handleConfirmDelete = async () => {
    if (!deleteTarget || !currentUser) return;
    const targetId = deleteTarget.id;
    const targetTitle = deleteTarget.title;

    // Instant optimistic UI update
    setBatches((prev) => prev.filter((b) => b.id !== targetId));
    setDeleteTarget(null);

    setIsDeleting(true);
    try {
      await deleteBatch(
        targetId,
        targetTitle,
        currentUser.uid,
        currentUser.email || undefined
      );
    } catch (err) {
      console.error('Failed to delete batch:', err);
      handleRefresh();
    } finally {
      setIsDeleting(false);
    }
  };

  // Filtered batches
  const filteredBatches = batches.filter((b) => {
    const matchesSearch =
      b.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      b.slug.toLowerCase().includes(searchQuery.toLowerCase()) ||
      b.shortDescription.toLowerCase().includes(searchQuery.toLowerCase());

    if (!matchesSearch) return false;

    if (statusFilter === 'published') return b.isPublished;
    if (statusFilter === 'draft') return !b.isPublished;
    if (statusFilter === 'free') return b.isFree;
    if (statusFilter === 'paid') return !b.isFree;
    return true;
  });

  return (
    <div className="space-y-6 font-['Plus_Jakarta_Sans',sans-serif]">
      <AdminPageHeader
        title="Course Batches Management"
        description="Create, configure, and publish nursing coaching programs and batches in Firestore."
        breadcrumbs={[{ label: 'Admin', path: ROUTES.ADMIN.DASHBOARD }, { label: 'Batches' }]}
        actions={
          <>
            <Button
              variant="outline"
              size="sm"
              onClick={handleRefresh}
              isLoading={refreshing}
              leftIcon={<RefreshCw className="w-3.5 h-3.5" />}
            >
              Refresh
            </Button>
            <Button
              variant="primary"
              size="sm"
              onClick={handleOpenCreate}
              leftIcon={<Plus className="w-4 h-4" />}
            >
              Create New Batch
            </Button>
          </>
        }
      />

      {/* Filter and Search Bar */}
      <div className="bg-white rounded-2xl border border-slate-200/80 p-4 shadow-xs flex flex-col md:flex-row items-center justify-between gap-3">
        <div className="relative w-full md:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search batches by title or slug..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
          />
        </div>

        {/* Filter Pills */}
        <div className="flex items-center gap-1.5 overflow-x-auto w-full md:w-auto pb-1 md:pb-0">
          {(['all', 'published', 'draft', 'free', 'paid'] as const).map((filterKey) => (
            <button
              key={filterKey}
              type="button"
              onClick={() => setStatusFilter(filterKey)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold capitalize transition-all select-none ${
                statusFilter === filterKey
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              {filterKey}
            </button>
          ))}
        </div>
      </div>

      {/* Batches Table */}
      <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs min-w-[650px]">
            <thead className="bg-slate-50/80 text-slate-500 uppercase text-[10px] font-bold border-b border-slate-100">
              <tr>
                <th className="px-5 py-3.5">Order</th>
                <th className="px-5 py-3.5">Batch / Course Title</th>
                <th className="px-5 py-3.5">Price & Validity</th>
                <th className="px-5 py-3.5">Featured</th>
                <th className="px-5 py-3.5">Status</th>
                <th className="px-5 py-3.5 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-medium text-slate-700">
              {loading ? (
                <tr>
                  <td colSpan={6} className="px-5 py-12 text-center text-slate-400">
                    <RefreshCw className="w-5 h-5 animate-spin mx-auto mb-2 text-blue-600" />
                    Loading batches from Firestore...
                  </td>
                </tr>
              ) : filteredBatches.length === 0 ? (
                <tr>
                  <td colSpan={6} className="px-5 py-12 text-center text-slate-400">
                    No batches match your filter. Click "Create New Batch" to add one.
                  </td>
                </tr>
              ) : (
                filteredBatches.map((batch) => (
                  <tr key={batch.id} className="hover:bg-slate-50/70 transition-colors">
                    <td className="px-5 py-4 font-bold text-slate-400 font-mono">
                      #{batch.order}
                    </td>
                    <td className="px-5 py-4">
                      <div className="flex items-center gap-3">
                        <img
                          src={batch.thumbnailUrl}
                          alt=""
                          className="w-12 h-9 rounded-lg object-cover bg-slate-100 border border-slate-200 shrink-0"
                        />
                        <div className="min-w-0">
                          <span className="font-extrabold text-slate-900 block truncate max-w-xs text-sm">
                            {batch.title}
                          </span>
                          <span className="text-[11px] text-slate-400 font-mono block truncate">
                            /{batch.slug}
                          </span>
                        </div>
                      </div>
                    </td>
                    <td className="px-5 py-4">
                      <div className="font-bold text-slate-900">
                        {batch.isFree ? (
                          <span className="text-emerald-600 font-extrabold">FREE</span>
                        ) : (
                          <span>{formatCurrency(batch.price)}</span>
                        )}
                      </div>
                      <div className="text-[11px] text-slate-400">
                        {batch.durationDays} Days Access
                      </div>
                    </td>
                    <td className="px-5 py-4">
                      {batch.isFeatured ? (
                        <span className="inline-flex items-center gap-1 text-[11px] font-bold text-amber-600">
                          <Sparkles className="w-3.5 h-3.5 fill-amber-500 text-amber-500" />
                          Featured
                        </span>
                      ) : (
                        <span className="text-slate-400 text-[11px]">Standard</span>
                      )}
                    </td>
                    <td className="px-5 py-4">
                      <PublishStatusBadge isPublished={batch.isPublished} />
                    </td>
                    <td className="px-5 py-4 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        {/* Student Preview Link */}
                        <Link
                          to={`/course/${batch.id}`}
                          target="_blank"
                          title="Open student preview"
                          className="p-1.5 rounded-lg border border-slate-200 text-slate-500 hover:bg-slate-100 transition-colors"
                        >
                          <ExternalLink className="w-3.5 h-3.5" />
                        </Link>

                        {/* Toggle Publish */}
                        <button
                          type="button"
                          onClick={() => handleTogglePublish(batch)}
                          title={batch.isPublished ? 'Unpublish batch' : 'Publish batch'}
                          className={`p-1.5 rounded-lg border transition-colors ${
                            batch.isPublished
                              ? 'border-emerald-200 text-emerald-600 hover:bg-emerald-50'
                              : 'border-slate-200 text-slate-400 hover:bg-slate-100'
                          }`}
                        >
                          {batch.isPublished ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
                        </button>

                        {/* Manage Curriculum Drilldown */}
                        <Link to={`/admin/subjects?batchId=${batch.id}`}>
                          <Button
                            variant="outline"
                            size="sm"
                            leftIcon={<Layers className="w-3 h-3 text-blue-600" />}
                          >
                            Subjects
                          </Button>
                        </Link>

                        {/* Edit */}
                        <button
                          type="button"
                          onClick={() => handleOpenEdit(batch)}
                          title="Edit batch properties"
                          className="p-1.5 rounded-lg border border-slate-200 text-slate-600 hover:bg-slate-100 transition-colors"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>

                        {/* Delete */}
                        <button
                          type="button"
                          onClick={() => setDeleteTarget(batch)}
                          title="Delete batch"
                          className="p-1.5 rounded-lg border border-rose-200 text-rose-600 hover:bg-rose-50 transition-colors"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Create / Edit Batch Modal */}
      {isFormModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 overflow-y-auto">
          <div
            className="fixed inset-0 bg-slate-900/70"
            onClick={() => !submitting && setIsFormModalOpen(false)}
          />

          <div className="relative bg-white rounded-2xl border border-slate-200 shadow-2xl max-w-2xl w-full p-6 space-y-5 my-8 max-h-[90vh] overflow-y-auto animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div>
                <h3 className="text-lg font-extrabold text-slate-900">
                  {editingBatch ? 'Edit Course Batch' : 'Create New Course Batch'}
                </h3>
                <p className="text-xs text-slate-500">
                  Manage batch metadata, tuition fees, and visibility
                </p>
              </div>
              <button
                type="button"
                onClick={() => setIsFormModalOpen(false)}
                disabled={submitting}
                className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {formError && (
              <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs font-semibold">
                {formError}
              </div>
            )}

            <form onSubmit={handleFormSubmit} className="space-y-4 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {/* Title */}
                <div className="sm:col-span-2 space-y-1">
                  <label className="font-bold text-slate-700">Batch / Course Title *</label>
                  <input
                    type="text"
                    required
                    value={formData.title}
                    onChange={(e) => handleTitleChange(e.target.value)}
                    placeholder="e.g. NORCET 8.0 Crash Course 2026"
                    className="w-full px-3.5 py-2 rounded-xl border border-slate-200 focus:outline-hidden focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 font-medium"
                  />
                </div>

                {/* Slug */}
                <div className="space-y-1">
                  <label className="font-bold text-slate-700">URL Slug</label>
                  <input
                    type="text"
                    value={formData.slug}
                    onChange={(e) => setFormData({ ...formData, slug: e.target.value })}
                    placeholder="norcet-8-crash-course"
                    className="w-full px-3.5 py-2 rounded-xl border border-slate-200 font-mono text-slate-600 focus:outline-hidden focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
                  />
                </div>

                {/* Order */}
                <div className="space-y-1">
                  <label className="font-bold text-slate-700">Display Order</label>
                  <input
                    type="number"
                    value={formData.order}
                    onChange={(e) => setFormData({ ...formData, order: Number(e.target.value) })}
                    className="w-full px-3.5 py-2 rounded-xl border border-slate-200 focus:outline-hidden focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
                  />
                </div>

                {/* Short Description */}
                <div className="sm:col-span-2 space-y-1">
                  <label className="font-bold text-slate-700">Short Summary</label>
                  <input
                    type="text"
                    value={formData.shortDescription}
                    onChange={(e) => setFormData({ ...formData, shortDescription: e.target.value })}
                    placeholder="Brief 1-sentence highlight for course cards"
                    className="w-full px-3.5 py-2 rounded-xl border border-slate-200 focus:outline-hidden focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
                  />
                </div>

                {/* Description */}
                <div className="sm:col-span-2 space-y-1">
                  <label className="font-bold text-slate-700">Detailed Description & Syllabus</label>
                  <textarea
                    rows={3}
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    placeholder="Comprehensive description of faculty, schedule, topics, tests..."
                    className="w-full px-3.5 py-2 rounded-xl border border-slate-200 focus:outline-hidden focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 font-medium"
                  />
                </div>

                {/* Thumbnail Photo Upload */}
                <ImageUploadField
                  label="Batch Thumbnail Photo"
                  value={formData.thumbnailUrl}
                  onChange={(url) => setFormData({ ...formData, thumbnailUrl: url })}
                  aspectRatio="video"
                  folder="thumbnails"
                  placeholder="Upload batch cover photo (16:9 ratio recommended)"
                  helperText="Recommended size: 800x450px. Supports JPG, PNG, WebP."
                  required
                />

                {/* Banner Photo Upload */}
                <ImageUploadField
                  label="Header Banner Photo"
                  value={formData.bannerUrl}
                  onChange={(url) => setFormData({ ...formData, bannerUrl: url })}
                  aspectRatio="banner"
                  folder="banners"
                  placeholder="Upload wide header banner photo"
                  helperText="Recommended size: 1200x400px. Used in course landing top banner."
                />

                {/* Price */}
                <div className="space-y-1">
                  <label className="font-bold text-slate-700">Discounted Price (INR ₹)</label>
                  <input
                    type="number"
                    value={formData.price}
                    onChange={(e) => setFormData({ ...formData, price: Number(e.target.value) })}
                    className="w-full px-3.5 py-2 rounded-xl border border-slate-200 focus:outline-hidden focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
                  />
                </div>

                {/* Original Price */}
                <div className="space-y-1">
                  <label className="font-bold text-slate-700">Original MRP (INR ₹)</label>
                  <input
                    type="number"
                    value={formData.originalPrice}
                    onChange={(e) =>
                      setFormData({ ...formData, originalPrice: Number(e.target.value) })
                    }
                    className="w-full px-3.5 py-2 rounded-xl border border-slate-200 focus:outline-hidden focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
                  />
                </div>

                {/* Validity Days */}
                <div className="space-y-1">
                  <label className="font-bold text-slate-700">Course Validity (Days)</label>
                  <input
                    type="number"
                    min={0}
                    value={formData.durationDays}
                    onChange={(e) =>
                      setFormData({ ...formData, durationDays: Math.max(0, Number(e.target.value)) })
                    }
                    className="w-full px-3.5 py-2 rounded-xl border border-slate-200 focus:outline-hidden focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
                  />
                </div>

                {/* Duration Display Label */}
                <div className="space-y-1">
                  <label className="font-bold text-slate-700">Duration Display Label</label>
                  <input
                    type="text"
                    value={formData.duration || ''}
                    onChange={(e) =>
                      setFormData({ ...formData, duration: e.target.value })
                    }
                    placeholder="e.g. 6 Months / 1 Year"
                    className="w-full px-3.5 py-2 rounded-xl border border-slate-200 focus:outline-hidden focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
                  />
                </div>
              </div>

              {/* Toggles */}
              <div className="pt-3 border-t border-slate-100 grid grid-cols-1 sm:grid-cols-3 gap-3">
                <label className="flex items-center gap-2 p-2.5 rounded-xl border border-slate-200 bg-slate-50 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={formData.isPublished}
                    onChange={(e) => setFormData({ ...formData, isPublished: e.target.checked })}
                    className="rounded text-blue-600 focus:ring-blue-500"
                  />
                  <span className="font-bold text-slate-800 text-xs">Publish to Students</span>
                </label>

                <label className="flex items-center gap-2 p-2.5 rounded-xl border border-slate-200 bg-slate-50 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={formData.isFeatured}
                    onChange={(e) => setFormData({ ...formData, isFeatured: e.target.checked })}
                    className="rounded text-blue-600 focus:ring-blue-500"
                  />
                  <span className="font-bold text-slate-800 text-xs">Feature on Home</span>
                </label>

                <label className="flex items-center gap-2 p-2.5 rounded-xl border border-slate-200 bg-slate-50 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={formData.isFree}
                    onChange={(e) => setFormData({ ...formData, isFree: e.target.checked })}
                    className="rounded text-blue-600 focus:ring-blue-500"
                  />
                  <span className="font-bold text-slate-800 text-xs">Free / Open Access</span>
                </label>
              </div>

              <div className="flex items-center justify-end gap-2.5 pt-4 border-t border-slate-100">
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => setIsFormModalOpen(false)}
                  disabled={submitting}
                >
                  Cancel
                </Button>
                <Button type="submit" variant="primary" size="sm" isLoading={submitting}>
                  {editingBatch ? 'Save Changes' : 'Create Batch'}
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      <ConfirmationModal
        isOpen={Boolean(deleteTarget)}
        title={`Delete Batch: ${deleteTarget?.title}`}
        message={`Are you sure you want to delete this batch from Firestore? Any nested subjects, chapters, and classes must also be reviewed.`}
        confirmLabel="Delete Batch"
        isDestructive
        isLoading={isDeleting}
        onConfirm={handleConfirmDelete}
        onCancel={() => setDeleteTarget(null)}
      />
    </div>
  );
}

export default AdminBatchesPage;
