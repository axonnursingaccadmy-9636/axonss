/**
 * Axon Nursing Academy - Production Admin Student Directory & Course Purchases CMS
 * Displays live registered students, their created date, purchased courses,
 * price paid, purchase date, and role controls with fast memoized search.
 */
import React, { useState, useEffect, useMemo } from 'react';
import {
  Users,
  Search,
  Mail,
  Phone,
  ShieldCheck,
  GraduationCap,
  RefreshCw,
  MapPin,
  Target,
  Edit2,
  X,
  CreditCard,
  BookOpen,
  Calendar,
  CheckCircle2,
  Clock,
  Layers,
  Sparkles,
  ChevronDown,
  ChevronUp,
} from 'lucide-react';
import { collection, getDocs, onSnapshot } from 'firebase/firestore';
import { getFirestoreDb } from '@/src/lib/firebase/firestore';
import { UserProfile } from '@/src/types/user.types';
import { Enrollment } from '@/src/types/enrollment.types';
import { Badge } from '@/src/components/ui/Badge';
import { Button } from '@/src/components/ui/Button';
import { AdminPageHeader } from '@/src/components/admin/AdminPageHeader';
import { ROUTES } from '@/src/config/routes.config';
import { updateUserProfile } from '@/src/services/firebase/userService';
import { getAllEnrollmentsAdmin } from '@/src/services/firebase/enrollmentService';
import { formatCurrency, formatDate } from '@/src/lib/utils/formatters';
import { useAuth } from '@/src/contexts/AuthContext';
import { useToast } from '@/src/hooks/useToast';

export function AdminStudentsPage() {
  const { currentUser } = useAuth();
  const { toast } = useToast();
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [enrollments, setEnrollments] = useState<Enrollment[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [roleFilter, setRoleFilter] = useState<'all' | 'student' | 'admin' | 'purchased'>('all');
  const [expandedUserUid, setExpandedUserUid] = useState<string | null>(null);

  // Role Edit Modal
  const [editingUser, setEditingUser] = useState<UserProfile | null>(null);
  const [newRole, setNewRole] = useState<'student' | 'admin'>('student');
  const [isUpdating, setIsUpdating] = useState(false);

  // Group enrollments by student UID for fast lookup
  const enrollmentsByUser = useMemo(() => {
    const map = new Map<string, Enrollment[]>();
    enrollments.forEach((e) => {
      const list = map.get(e.userId) || [];
      list.push(e);
      map.set(e.userId, list);
    });
    return map;
  }, [enrollments]);

  // Load real data from Firestore
  const loadData = async () => {
    const db = getFirestoreDb();
    if (!db) {
      setUsers([]);
      setEnrollments([]);
      setLoading(false);
      setRefreshing(false);
      return;
    }

    try {
      const [usersSnap, enrList] = await Promise.all([
        getDocs(collection(db, 'users')).catch(() => ({ empty: true, docs: [] } as any)),
        getAllEnrollmentsAdmin(),
      ]);

      if (!usersSnap.empty) {
        const list: UserProfile[] = usersSnap.docs.map((d: any) => {
          const data = d.data();
          return {
            uid: d.id,
            email: data.email || '',
            fullName: data.fullName || 'Registered Student',
            phone: data.phone || '',
            role: data.role || 'student',
            targetExam: data.targetExam || 'NORCET / Nursing',
            state: data.state || 'India',
            qualification: data.qualification || 'B.Sc. Nursing',
            createdAt: data.createdAt,
            updatedAt: data.updatedAt,
          };
        });
        setUsers(list);
      } else if (currentUser) {
        setUsers([
          {
            uid: currentUser.uid,
            email: currentUser.email || '',
            fullName: currentUser.displayName || 'Administrator',
            role: 'admin',
            isActive: true,
          },
        ]);
      } else {
        setUsers([]);
      }
      setEnrollments(enrList);
    } catch (err) {
      console.warn('[AdminStudentsPage] Load error:', err);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    loadData();

    // Set up real-time listener for users collection
    const db = getFirestoreDb();
    if (db) {
      const unsub = onSnapshot(
        collection(db, 'users'),
        (snap) => {
          if (!snap.empty) {
            const list: UserProfile[] = snap.docs.map((d) => {
              const data = d.data();
              return {
                uid: d.id,
                email: data.email || '',
                fullName: data.fullName || 'Registered Student',
                phone: data.phone || '',
                role: data.role || 'student',
                targetExam: data.targetExam || 'NORCET / Nursing',
                state: data.state || 'India',
                qualification: data.qualification || 'B.Sc. Nursing',
                createdAt: data.createdAt,
                updatedAt: data.updatedAt,
              };
            });
            setUsers(list);
          }
        },
        (err) => {
          console.warn('[AdminStudentsPage] Realtime users listener notice:', err?.message || err);
        }
      );
      return () => unsub();
    }
  }, []);

  const handleRefresh = async () => {
    setRefreshing(true);
    await loadData();
  };

  const handleUpdateRole = async () => {
    if (!editingUser) return;
    setIsUpdating(true);
    try {
      await updateUserProfile(editingUser.uid, { role: newRole as any });
      toast.success(
        `Role for ${editingUser.fullName || editingUser.email} updated to ${newRole.toUpperCase()}.`,
        { title: 'User Updated' }
      );
      setEditingUser(null);
      await handleRefresh();
    } catch (err: any) {
      console.error('Failed to update role:', err);
      toast.error(err?.message || 'Failed to update student role.', {
        title: 'Update Error',
      });
    } finally {
      setIsUpdating(false);
    }
  };

  // Fast Memoized Search & Filter
  const filteredUsers = useMemo(() => {
    const term = searchQuery.toLowerCase().trim();
    return users.filter((u) => {
      const userEnrs = enrollmentsByUser.get(u.uid) || [];

      // Filter by role or purchase status
      if (roleFilter === 'student' && u.role !== 'student') return false;
      if (roleFilter === 'admin' && u.role !== 'admin') return false;
      if (roleFilter === 'purchased' && userEnrs.length === 0) return false;

      // Filter by search term
      if (!term) return true;

      const hasCourseMatch = userEnrs.some((e) =>
        e.courseTitle?.toLowerCase().includes(term)
      );

      return (
        u.fullName.toLowerCase().includes(term) ||
        u.email.toLowerCase().includes(term) ||
        (u.phone && u.phone.includes(term)) ||
        (u.targetExam && u.targetExam.toLowerCase().includes(term)) ||
        (u.state && u.state.toLowerCase().includes(term)) ||
        hasCourseMatch
      );
    });
  }, [users, enrollmentsByUser, searchQuery, roleFilter]);

  // Aggregate stats
  const totalStudents = users.filter((u) => u.role === 'student').length;
  const studentsWithCourses = users.filter((u) => (enrollmentsByUser.get(u.uid) || []).length > 0).length;

  return (
    <div className="space-y-6 font-['Plus_Jakarta_Sans',sans-serif]">
      <AdminPageHeader
        title="Student & User Directory"
        description="Comprehensive directory of registered accounts, registration dates, purchased courses, and financial details."
        breadcrumbs={[{ label: 'Admin', path: ROUTES.ADMIN.DASHBOARD }, { label: 'Students' }]}
        actions={
          <Button
            variant="outline"
            size="sm"
            onClick={handleRefresh}
            isLoading={refreshing}
            leftIcon={<RefreshCw className="w-3.5 h-3.5" />}
          >
            Refresh Data
          </Button>
        }
      />

      {/* Quick Overview Summary Metrics */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 sm:gap-4">
        <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 mb-1">
            <span className="text-xs font-bold uppercase tracking-wider">Total Accounts</span>
            <Users className="w-4 h-4 text-blue-600" />
          </div>
          <div className="text-2xl font-extrabold text-slate-900">{users.length}</div>
          <div className="text-[11px] text-slate-400 mt-0.5">Registered in system</div>
        </div>

        <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 mb-1">
            <span className="text-xs font-bold uppercase tracking-wider">Total Students</span>
            <GraduationCap className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-2xl font-extrabold text-slate-900">{totalStudents}</div>
          <div className="text-[11px] text-slate-400 mt-0.5">Student learners</div>
        </div>

        <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 mb-1">
            <span className="text-xs font-bold uppercase tracking-wider">With Courses</span>
            <CreditCard className="w-4 h-4 text-indigo-600" />
          </div>
          <div className="text-2xl font-extrabold text-indigo-600">{studentsWithCourses}</div>
          <div className="text-[11px] text-slate-400 mt-0.5">Active enrollments</div>
        </div>

        <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 mb-1">
            <span className="text-xs font-bold uppercase tracking-wider">Course Enrollments</span>
            <BookOpen className="w-4 h-4 text-amber-600" />
          </div>
          <div className="text-2xl font-extrabold text-amber-600">{enrollments.length}</div>
          <div className="text-[11px] text-slate-400 mt-0.5">Total course unlocks</div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white rounded-2xl border border-slate-200/80 p-4 shadow-xs flex flex-col md:flex-row items-center justify-between gap-3">
        <div className="flex items-center gap-1.5 overflow-x-auto w-full md:w-auto">
          {(
            [
              { id: 'all', label: 'All Accounts' },
              { id: 'student', label: 'Students Only' },
              { id: 'purchased', label: 'Enrolled / Paid' },
              { id: 'admin', label: 'Admins' },
            ] as const
          ).map((item) => (
            <button
              key={item.id}
              type="button"
              onClick={() => setRoleFilter(item.id)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all select-none whitespace-nowrap ${
                roleFilter === item.id
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              {item.label}
            </button>
          ))}
        </div>

        <div className="relative w-full md:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search student, email, course title..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
          />
        </div>
      </div>

      {/* Students & Courses Table */}
      <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs min-w-[750px]">
            <thead className="bg-slate-50/80 text-slate-500 uppercase text-[10px] font-bold border-b border-slate-100">
              <tr>
                <th className="px-5 py-3.5">Student / User</th>
                <th className="px-5 py-3.5">Registered On</th>
                <th className="px-5 py-3.5">Enrolled Courses</th>
                <th className="px-5 py-3.5">Role</th>
                <th className="px-5 py-3.5 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-medium text-slate-700">
              {loading ? (
                <tr>
                  <td colSpan={5} className="px-5 py-12 text-center text-slate-400">
                    <RefreshCw className="w-5 h-5 animate-spin mx-auto mb-2 text-blue-600" />
                    Loading registered student records from Firestore...
                  </td>
                </tr>
              ) : filteredUsers.length === 0 ? (
                <tr>
                  <td colSpan={5} className="px-5 py-12 text-center text-slate-400">
                    No students or users found matching criteria.
                  </td>
                </tr>
              ) : (
                filteredUsers.map((u) => {
                  const userEnrs = enrollmentsByUser.get(u.uid) || [];
                  const isExpanded = expandedUserUid === u.uid;

                  return (
                    <React.Fragment key={u.uid}>
                      <tr className="hover:bg-slate-50/70 transition-colors">
                        <td className="px-5 py-4">
                          <div className="flex items-start gap-3">
                            <div className="w-9 h-9 rounded-xl bg-blue-100 text-blue-700 flex items-center justify-center font-bold text-sm shrink-0">
                              {u.fullName?.charAt(0)?.toUpperCase() || 'S'}
                            </div>
                            <div className="min-w-0">
                              <span className="font-extrabold text-slate-900 block text-sm">
                                {u.fullName}
                              </span>
                              <div className="flex items-center gap-1.5 text-slate-500 text-[11px] mt-0.5">
                                <Mail className="w-3 h-3 text-slate-400" />
                                <span className="truncate">{u.email}</span>
                              </div>
                              {u.phone && (
                                <div className="flex items-center gap-1.5 text-slate-400 text-[11px]">
                                  <Phone className="w-3 h-3" />
                                  <span>{u.phone}</span>
                                </div>
                              )}
                              <div className="flex items-center gap-2 mt-1">
                                {u.targetExam && (
                                  <span className="inline-flex items-center gap-1 text-[10px] bg-slate-100 text-slate-600 px-2 py-0.5 rounded-md font-semibold">
                                    <Target className="w-3 h-3 text-blue-500" />
                                    {u.targetExam}
                                  </span>
                                )}
                                {u.state && (
                                  <span className="inline-flex items-center gap-1 text-[10px] bg-slate-100 text-slate-500 px-2 py-0.5 rounded-md">
                                    <MapPin className="w-3 h-3" />
                                    {u.state}
                                  </span>
                                )}
                              </div>
                            </div>
                          </div>
                        </td>

                        {/* Registered Date */}
                        <td className="px-5 py-4 whitespace-nowrap">
                          <div className="flex items-center gap-1.5 text-slate-700 font-semibold">
                            <Calendar className="w-3.5 h-3.5 text-slate-400" />
                            <span>
                              {u.createdAt
                                ? formatDate(
                                    typeof u.createdAt === 'object' && 'toDate' in u.createdAt
                                      ? (u.createdAt as any).toDate().toISOString()
                                      : u.createdAt
                                  )
                                : 'Recent'}
                            </span>
                          </div>
                          <span className="text-[10px] text-slate-400 font-mono block mt-0.5">
                            UID: {u.uid.slice(0, 10)}...
                          </span>
                        </td>

                        {/* Enrolled Courses / Purchases */}
                        <td className="px-5 py-4">
                          {userEnrs.length === 0 ? (
                            <span className="text-slate-400 text-xs italic">
                              No course purchased yet
                            </span>
                          ) : (
                            <div className="space-y-1.5">
                              <div className="flex items-center gap-2">
                                <Badge variant="emerald" size="sm" className="font-bold">
                                  {userEnrs.length} {userEnrs.length === 1 ? 'Course' : 'Courses'}
                                </Badge>
                                <button
                                  type="button"
                                  onClick={() => setExpandedUserUid(isExpanded ? null : u.uid)}
                                  className="text-[11px] text-blue-600 hover:text-blue-800 font-bold flex items-center gap-0.5"
                                >
                                  {isExpanded ? (
                                    <>
                                      Hide Details <ChevronUp className="w-3 h-3" />
                                    </>
                                  ) : (
                                    <>
                                      View Purchases <ChevronDown className="w-3 h-3" />
                                    </>
                                  )}
                                </button>
                              </div>

                              {/* Preview of first course */}
                              <div className="text-[11px] text-slate-800 font-semibold truncate max-w-xs">
                                {userEnrs[0].courseTitle || 'Course Batch'}
                                {userEnrs.length > 1 && (
                                  <span className="text-slate-400 font-normal ml-1">
                                    (+{userEnrs.length - 1} more)
                                  </span>
                                )}
                              </div>
                            </div>
                          )}
                        </td>

                        {/* Role */}
                        <td className="px-5 py-4 whitespace-nowrap">
                          <Badge
                            variant={u.role === 'admin' ? 'purple' : 'blue'}
                            size="sm"
                            className="capitalize font-bold"
                          >
                            {u.role === 'admin' ? 'Administrator' : 'Student'}
                          </Badge>
                        </td>

                        {/* Actions */}
                        <td className="px-5 py-4 text-right whitespace-nowrap">
                          <button
                            type="button"
                            onClick={() => {
                              setEditingUser(u);
                              setNewRole(u.role === 'admin' ? 'admin' : 'student');
                            }}
                            className="p-1.5 rounded-lg border border-slate-200 text-slate-600 hover:bg-slate-100 transition-colors"
                            title="Change user role"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>
                        </td>
                      </tr>

                      {/* Expanded View for Purchased Courses */}
                      {isExpanded && userEnrs.length > 0 && (
                        <tr className="bg-blue-50/40">
                          <td colSpan={5} className="px-5 py-3">
                            <div className="bg-white rounded-xl border border-blue-100 p-3.5 shadow-xs space-y-2.5">
                              <div className="flex items-center justify-between pb-1.5 border-b border-slate-100">
                                <span className="text-xs font-extrabold text-slate-900 flex items-center gap-1.5">
                                  <CreditCard className="w-3.5 h-3.5 text-blue-600" />
                                  Course Purchase History for {u.fullName}
                                </span>
                                <span className="text-[11px] font-bold text-slate-500">
                                  {userEnrs.length} Active {userEnrs.length === 1 ? 'Subscription' : 'Subscriptions'}
                                </span>
                              </div>

                              <div className="divide-y divide-slate-100">
                                {userEnrs.map((enr) => (
                                  <div
                                    key={enr.id}
                                    className="py-2 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs"
                                  >
                                    <div>
                                      <span className="font-extrabold text-slate-900 block">
                                        {enr.courseTitle || 'Course Batch'}
                                      </span>
                                      <div className="flex items-center gap-3 text-[11px] text-slate-500 mt-0.5">
                                        <span className="flex items-center gap-1">
                                          <Clock className="w-3 h-3 text-slate-400" />
                                          Purchased on: {formatDate(enr.enrolledAt)}
                                        </span>
                                        {enr.expiresAt && (
                                          <span className="text-amber-600">
                                            Expires: {formatDate(enr.expiresAt)}
                                          </span>
                                        )}
                                      </div>
                                    </div>

                                    <div className="flex items-center gap-3 shrink-0">
                                      <div className="text-right">
                                        <div className="font-extrabold text-slate-900 text-xs">
                                          {enr.isFree ? (
                                            <span className="text-emerald-600">FREE Access</span>
                                          ) : (
                                            formatCurrency(enr.amountPaid || 0)
                                          )}
                                        </div>
                                        {enr.couponCode && (
                                          <span className="text-[10px] text-indigo-600 font-semibold block">
                                            Coupon: {enr.couponCode}
                                          </span>
                                        )}
                                      </div>
                                      <Badge
                                        variant={enr.status === 'active' ? 'emerald' : 'amber'}
                                        size="sm"
                                        className="capitalize font-bold"
                                      >
                                        {enr.status}
                                      </Badge>
                                    </div>
                                  </div>
                                ))}
                              </div>
                            </div>
                          </td>
                        </tr>
                      )}
                    </React.Fragment>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Edit Role Modal */}
      {editingUser && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div
            className="fixed inset-0 bg-slate-900/70"
            onClick={() => setEditingUser(null)}
          />
          <div className="relative bg-white rounded-2xl border border-slate-200 shadow-2xl max-w-sm w-full p-6 space-y-4 animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <h3 className="text-base font-extrabold text-slate-900">Modify User Role</h3>
              <button
                type="button"
                onClick={() => setEditingUser(null)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div className="bg-slate-50 p-3 rounded-xl border border-slate-200/60">
                <span className="text-slate-500 block text-[10px]">User Email</span>
                <span className="font-bold text-slate-900 text-xs truncate block">
                  {editingUser.email}
                </span>
              </div>

              <div className="space-y-1">
                <label className="font-bold text-slate-700">Select Role</label>
                <select
                  value={newRole}
                  onChange={(e) => setNewRole(e.target.value as any)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 font-semibold"
                >
                  <option value="student">Student (Standard LMS Access)</option>
                  <option value="admin">Administrator (Full CMS Privileges)</option>
                </select>
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setEditingUser(null)}
                disabled={isUpdating}
              >
                Cancel
              </Button>
              <Button
                variant="primary"
                size="sm"
                onClick={handleUpdateRole}
                isLoading={isUpdating}
              >
                Save Role
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default AdminStudentsPage;
