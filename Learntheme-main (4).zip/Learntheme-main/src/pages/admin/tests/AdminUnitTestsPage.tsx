/**
 * Axon Nursing Academy - Admin Unit MCQ Test CMS
 * Manage Chapter/Unit-level practice MCQ assessments tied strictly to Subject and Chapter hierarchy.
 */
import React, { useState, useEffect } from 'react';
import { useSearchParams, Link } from 'react-router-dom';
import {
  FileCheck,
  Plus,
  Search,
  Edit2,
  Trash2,
  Eye,
  EyeOff,
  RefreshCw,
  X,
  FileQuestion,
  Clock,
  CheckCircle2,
  AlertCircle,
  HelpCircle,
  BarChart3,
  BookMarked,
  Layers,
  FolderTree,
} from 'lucide-react';
import { ROUTES } from '@/src/config/routes.config';
import { Button } from '@/src/components/ui/Button';
import { AdminPageHeader } from '@/src/components/admin/AdminPageHeader';
import { PublishStatusBadge } from '@/src/components/admin/StatusBadge';
import { ConfirmationModal } from '@/src/components/admin/ConfirmationModal';
import { getAllBatchesAdmin } from '@/src/services/firebase/adminBatchService';
import { getAllSubjectsAdmin, getSubjectsForBatchAdmin } from '@/src/services/firebase/adminSubjectService';
import { getAllChaptersAdmin, getChaptersForSubjectAdmin } from '@/src/services/firebase/adminChapterService';
import {
  getAllUnitTestsAdmin,
  createUnitTest,
  updateUnitTest,
  deleteUnitTest,
  toggleUnitTestPublish,
  getUnitTestAttemptsForAdmin,
  UnitTestFormData,
} from '@/src/services/firebase/unitTestService';
import { UnitTest, UnitTestAttempt } from '@/src/types/assessment.types';
import { Batch, Subject, Chapter } from '@/src/types/lms.types';
import { useAuth } from '@/src/contexts/AuthContext';

export function AdminUnitTestsPage() {
  const { currentUser } = useAuth();
  const [searchParams, setSearchParams] = useSearchParams();
  const selectedBatchId = searchParams.get('batchId') || '';
  const selectedSubjectId = searchParams.get('subjectId') || '';
  const selectedChapterId = searchParams.get('chapterId') || '';

  const [batches, setBatches] = useState<Batch[]>([]);
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [chapters, setChapters] = useState<Chapter[]>([]);
  const [tests, setTests] = useState<UnitTest[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  // Submissions Modal
  const [analyticsTest, setAnalyticsTest] = useState<UnitTest | null>(null);
  const [testAttempts, setTestAttempts] = useState<UnitTestAttempt[]>([]);
  const [loadingAttempts, setLoadingAttempts] = useState(false);

  // Modal State
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingTest, setEditingTest] = useState<UnitTest | null>(null);
  const [formData, setFormData] = useState<UnitTestFormData>({
    batchId: '',
    subjectId: '',
    chapterId: '',
    title: '',
    description: '',
    durationMinutes: 15,
    totalMarks: 20,
    passingMarks: 10,
    marksPerQuestion: 1,
    negativeMarksPerQuestion: 0.25,
    totalQuestions: 0,
    instructions: [
      'Answer all chapter review questions.',
      'Check detailed rationale after submission.',
    ],
    isPublished: true,
    order: 1,
    allowReviewAfterSubmission: true,
  });

  const [instructionsText, setInstructionsText] = useState(
    'Answer all chapter review questions.\nCheck detailed rationale after submission.'
  );

  // Delete State
  const [deletingTest, setDeletingTest] = useState<UnitTest | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);

  // Feedback Toast
  const [feedbackMsg, setFeedbackMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // 1. Initial Load of Batches
  useEffect(() => {
    loadBatches();
  }, []);

  // 2. Cascade Subjects when Batch changes
  useEffect(() => {
    if (selectedBatchId) {
      loadSubjectsForBatch(selectedBatchId);
    } else {
      setSubjects([]);
      setChapters([]);
    }
  }, [selectedBatchId]);

  // 3. Cascade Chapters when Subject changes
  useEffect(() => {
    if (selectedSubjectId) {
      loadChaptersForSubject(selectedSubjectId);
    } else {
      setChapters([]);
    }
  }, [selectedSubjectId]);

  // 4. Load Unit Tests whenever Chapter selection changes
  useEffect(() => {
    loadTests();
  }, [selectedChapterId]);

  const loadBatches = async () => {
    try {
      const allBatches = await getAllBatchesAdmin();
      setBatches(allBatches);
      if (allBatches.length > 0 && !selectedBatchId) {
        setSearchParams({ batchId: allBatches[0].id });
      }
    } catch (err) {
      console.error(err);
    }
  };

  const loadSubjectsForBatch = async (batchId: string) => {
    try {
      const bSubjects = await getSubjectsForBatchAdmin(batchId);
      setSubjects(bSubjects);
      if (bSubjects.length > 0 && (!selectedSubjectId || !bSubjects.some((s) => s.id === selectedSubjectId))) {
        setSearchParams((prev) => {
          prev.set('batchId', batchId);
          prev.set('subjectId', bSubjects[0].id);
          prev.delete('chapterId');
          return prev;
        });
      }
    } catch (err) {
      console.error(err);
    }
  };

  const loadChaptersForSubject = async (subjectId: string) => {
    try {
      const sChapters = await getChaptersForSubjectAdmin(subjectId);
      setChapters(sChapters);
      if (sChapters.length > 0 && (!selectedChapterId || !sChapters.some((c) => c.id === selectedChapterId))) {
        setSearchParams((prev) => {
          prev.set('chapterId', sChapters[0].id);
          return prev;
        });
      }
    } catch (err) {
      console.error(err);
    }
  };

  const loadTests = async () => {
    setLoading(true);
    try {
      const data = await getAllUnitTestsAdmin(selectedChapterId || undefined);
      setTests(data);
    } catch (err: any) {
      showFeedback('error', 'Failed to load unit tests.');
    } finally {
      setLoading(false);
    }
  };

  const handleRefresh = async () => {
    setRefreshing(true);
    await loadTests();
    setRefreshing(false);
    showFeedback('success', 'Unit tests synchronized.');
  };

  const showFeedback = (type: 'success' | 'error', text: string) => {
    setFeedbackMsg({ type, text });
    setTimeout(() => setFeedbackMsg(null), 4000);
  };

  const handleBatchChange = (bId: string) => {
    setSearchParams({ batchId: bId });
  };

  const handleSubjectChange = (sId: string) => {
    setSearchParams((prev) => {
      prev.set('subjectId', sId);
      prev.delete('chapterId');
      return prev;
    });
  };

  const handleChapterChange = (cId: string) => {
    setSearchParams((prev) => {
      prev.set('chapterId', cId);
      return prev;
    });
  };

  const openCreateModal = () => {
    setEditingTest(null);
    setFormData({
      batchId: selectedBatchId || (batches[0]?.id || ''),
      subjectId: selectedSubjectId || (subjects[0]?.id || ''),
      chapterId: selectedChapterId || (chapters[0]?.id || ''),
      title: '',
      description: '',
      durationMinutes: 15,
      totalMarks: 20,
      passingMarks: 10,
      marksPerQuestion: 1,
      negativeMarksPerQuestion: 0.25,
      totalQuestions: 0,
      instructions: [
        'Answer all chapter review questions.',
        'Check detailed rationale after submission.',
      ],
      isPublished: true,
      order: tests.length + 1,
      allowReviewAfterSubmission: true,
    });
    setInstructionsText(
      'Answer all chapter review questions.\nCheck detailed rationale after submission.'
    );
    setIsModalOpen(true);
  };

  const openEditModal = (t: UnitTest) => {
    setEditingTest(t);
    setFormData({
      batchId: t.batchId,
      subjectId: t.subjectId,
      chapterId: t.chapterId,
      title: t.title,
      description: t.description || '',
      durationMinutes: t.durationMinutes,
      totalMarks: t.totalMarks,
      passingMarks: t.passingMarks,
      marksPerQuestion: t.marksPerQuestion,
      negativeMarksPerQuestion: t.negativeMarksPerQuestion,
      totalQuestions: t.totalQuestions,
      instructions: t.instructions || [],
      isPublished: t.isPublished,
      order: t.order,
      allowReviewAfterSubmission: t.allowReviewAfterSubmission,
    });
    setInstructionsText((t.instructions || []).join('\n'));
    setIsModalOpen(true);
  };

  const handleSubmitModal = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.chapterId) {
      showFeedback('error', 'Please assign this test to a specific chapter.');
      return;
    }
    if (!formData.title.trim()) {
      showFeedback('error', 'Please enter a test title.');
      return;
    }

    const instructionsArray = instructionsText
      .split('\n')
      .map((i) => i.trim())
      .filter((i) => i.length > 0);

    const payload: UnitTestFormData = {
      ...formData,
      title: formData.title.trim(),
      instructions: instructionsArray,
    };

    try {
      if (editingTest) {
        await updateUnitTest(
          editingTest.id,
          payload,
          currentUser?.uid || 'admin',
          currentUser?.email || undefined
        );
        showFeedback('success', `Updated test "${payload.title}" successfully.`);
      } else {
        await createUnitTest(
          payload,
          currentUser?.uid || 'admin',
          currentUser?.email || undefined
        );
        showFeedback('success', `Created unit test "${payload.title}".`);
      }
      setIsModalOpen(false);
      await loadTests();
    } catch (err: any) {
      showFeedback('error', err.message || 'Operation failed.');
    }
  };

  const handleTogglePublish = async (test: UnitTest) => {
    try {
      const newState = !test.isPublished;
      await toggleUnitTestPublish(
        test.id,
        newState,
        test.title,
        currentUser?.uid || 'admin',
        currentUser?.email || undefined
      );
      setTests((prev) =>
        prev.map((t) => (t.id === test.id ? { ...t, isPublished: newState } : t))
      );
      showFeedback(
        'success',
        `Test "${test.title}" is now ${newState ? 'Published' : 'Unpublished (Draft)'}.`
      );
    } catch (err) {
      showFeedback('error', 'Failed to toggle status.');
    }
  };

  const confirmDelete = async () => {
    if (!deletingTest) return;
    setIsDeleting(true);
    try {
      await deleteUnitTest(
        deletingTest.id,
        deletingTest.title,
        currentUser?.uid || 'admin',
        currentUser?.email || undefined
      );
      setTests((prev) => prev.filter((t) => t.id !== deletingTest.id));
      showFeedback('success', `Deleted unit test "${deletingTest.title}".`);
      setDeletingTest(null);
    } catch (err) {
      showFeedback('error', 'Failed to delete test.');
    } finally {
      setIsDeleting(false);
    }
  };

  const openAnalytics = async (test: UnitTest) => {
    setAnalyticsTest(test);
    setLoadingAttempts(true);
    try {
      const atts = await getUnitTestAttemptsForAdmin(test.id);
      setTestAttempts(atts);
    } catch (err) {
      setTestAttempts([]);
    } finally {
      setLoadingAttempts(false);
    }
  };

  const filteredTests = tests.filter((t) => {
    if (selectedChapterId && t.chapterId !== selectedChapterId) return false;
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      return (
        t.title.toLowerCase().includes(q) ||
        (t.description && t.description.toLowerCase().includes(q))
      );
    }
    return true;
  });

  return (
    <div className="space-y-6">
      {/* Top Banner Header */}
      <AdminPageHeader
        title="Unit MCQ Tests (Chapter Assessments)"
        description="Chapter/Unit-level practice MCQ assessments strictly linked to Subject and Chapter hierarchy."
        breadcrumbs={[
          { label: 'Admin Dashboard', path: ROUTES.ADMIN.DASHBOARD },
          { label: 'Unit MCQ Tests' },
        ]}
        actions={
          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={handleRefresh}
              disabled={refreshing || loading}
              className="gap-2"
            >
              <RefreshCw className={`w-4 h-4 ${refreshing ? 'animate-spin' : ''}`} />
              Sync
            </Button>
            <Button size="sm" onClick={openCreateModal} className="gap-2 bg-blue-600 hover:bg-blue-700 text-white">
              <Plus className="w-4 h-4" />
              New Unit MCQ Test
            </Button>
          </div>
        }
      />

      {/* Notification Toast */}
      {feedbackMsg && (
        <div
          className={`p-4 rounded-xl text-xs font-semibold flex items-center justify-between shadow-sm animate-in fade-in slide-in-from-top-2 ${
            feedbackMsg.type === 'success'
              ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
              : 'bg-red-50 text-red-800 border border-red-200'
          }`}
        >
          <div className="flex items-center gap-2">
            {feedbackMsg.type === 'success' ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            ) : (
              <AlertCircle className="w-4 h-4 text-red-600" />
            )}
            <span>{feedbackMsg.text}</span>
          </div>
          <button onClick={() => setFeedbackMsg(null)} className="opacity-60 hover:opacity-100">
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Cascading Filter Controls Bar */}
      <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-xs space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          {/* 1. Batch */}
          <div>
            <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-500 mb-1 flex items-center gap-1.5">
              <BookMarked className="w-3.5 h-3.5 text-blue-600" />
              1. Course Batch
            </label>
            <select
              value={selectedBatchId}
              onChange={(e) => handleBatchChange(e.target.value)}
              className="w-full h-10 px-3 text-xs bg-slate-50 border border-slate-200 rounded-xl font-medium text-slate-800"
            >
              <option value="">Select Batch</option>
              {batches.map((b) => (
                <option key={b.id} value={b.id}>
                  {b.title}
                </option>
              ))}
            </select>
          </div>

          {/* 2. Subject */}
          <div>
            <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-500 mb-1 flex items-center gap-1.5">
              <Layers className="w-3.5 h-3.5 text-indigo-600" />
              2. Subject
            </label>
            <select
              value={selectedSubjectId}
              onChange={(e) => handleSubjectChange(e.target.value)}
              disabled={!selectedBatchId || subjects.length === 0}
              className="w-full h-10 px-3 text-xs bg-slate-50 border border-slate-200 rounded-xl font-medium text-slate-800 disabled:opacity-50"
            >
              <option value="">Select Subject</option>
              {subjects.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name}
                </option>
              ))}
            </select>
          </div>

          {/* 3. Chapter */}
          <div>
            <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-500 mb-1 flex items-center gap-1.5">
              <FolderTree className="w-3.5 h-3.5 text-emerald-600" />
              3. Chapter / Unit
            </label>
            <select
              value={selectedChapterId}
              onChange={(e) => handleChapterChange(e.target.value)}
              disabled={!selectedSubjectId || chapters.length === 0}
              className="w-full h-10 px-3 text-xs bg-slate-50 border border-slate-200 rounded-xl font-medium text-slate-800 disabled:opacity-50"
            >
              <option value="">Select Chapter</option>
              {chapters.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Search */}
        <div className="pt-2 border-t border-slate-100 flex items-center justify-between">
          <div className="relative w-full max-w-md">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="Search tests in this chapter..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full h-9 pl-9 pr-3 text-xs bg-slate-50 border border-slate-200 rounded-xl text-slate-800"
            />
          </div>
          <span className="text-xs font-bold text-slate-400">
            {filteredTests.length} Test{filteredTests.length === 1 ? '' : 's'}
          </span>
        </div>
      </div>

      {/* Tests Grid */}
      {loading ? (
        <div className="bg-white rounded-2xl border border-slate-200 p-12 text-center">
          <div className="w-10 h-10 border-3 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-3" />
          <p className="text-xs font-semibold text-slate-500">Loading chapter unit tests...</p>
        </div>
      ) : filteredTests.length === 0 ? (
        <div className="bg-white rounded-2xl border border-dashed border-slate-300 p-12 text-center">
          <div className="w-12 h-12 rounded-2xl bg-indigo-50 text-indigo-600 flex items-center justify-center mx-auto mb-3">
            <FileCheck className="w-6 h-6" />
          </div>
          <h3 className="text-base font-bold text-slate-800 mb-1">No Unit MCQ Tests in this Chapter</h3>
          <p className="text-xs text-slate-500 max-w-md mx-auto mb-5">
            Add chapter-level practice questions to test student concept mastery immediately after classes.
          </p>
          <Button onClick={openCreateModal} size="sm" className="gap-2 bg-blue-600 hover:bg-blue-700 text-white">
            <Plus className="w-4 h-4" />
            Create First Unit MCQ Test
          </Button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-5">
          {filteredTests.map((test) => (
            <div
              key={test.id}
              className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs hover:shadow-md transition-all flex flex-col justify-between"
            >
              <div>
                {/* Header info */}
                <div className="flex items-start justify-between gap-2 mb-3">
                  <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-[10px] font-bold bg-indigo-50 text-indigo-700 border border-indigo-100">
                    <FolderTree className="w-3 h-3 text-indigo-600" />
                    Chapter Unit Test
                  </span>
                  <PublishStatusBadge isPublished={test.isPublished} />
                </div>

                <h3 className="font-extrabold text-sm text-slate-900 mb-1.5 line-clamp-2">
                  {test.title}
                </h3>
                {test.description && (
                  <p className="text-xs text-slate-500 mb-4 line-clamp-2">{test.description}</p>
                )}

                {/* Metrics */}
                <div className="grid grid-cols-3 gap-2 p-3 bg-slate-50 rounded-xl mb-4 text-center">
                  <div>
                    <span className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                      Questions
                    </span>
                    <span className="font-extrabold text-xs text-slate-800">
                      {test.totalQuestions}
                    </span>
                  </div>
                  <div>
                    <span className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                      Duration
                    </span>
                    <span className="font-extrabold text-xs text-slate-800">
                      {test.durationMinutes}m
                    </span>
                  </div>
                  <div>
                    <span className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                      Total Marks
                    </span>
                    <span className="font-extrabold text-xs text-slate-800">
                      {test.totalMarks}
                    </span>
                  </div>
                </div>
              </div>

              {/* Actions */}
              <div className="flex flex-col gap-2 pt-2">
                <Link
                  to={ROUTES.ADMIN.UNIT_TEST_QUESTIONS(test.id)}
                  className="w-full"
                >
                  <Button
                    variant="primary"
                    size="sm"
                    className="w-full gap-2 bg-indigo-600 hover:bg-indigo-700 text-white"
                  >
                    <FileQuestion className="w-4 h-4" />
                    Manage Questions ({test.totalQuestions})
                  </Button>
                </Link>

                <div className="grid grid-cols-4 gap-1.5">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => openAnalytics(test)}
                    title="View Student Submissions"
                    className="p-0 flex items-center justify-center text-slate-600 hover:text-indigo-600"
                  >
                    <BarChart3 className="w-4 h-4" />
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleTogglePublish(test)}
                    title={test.isPublished ? 'Unpublish (Draft)' : 'Publish Test'}
                    className="p-0 flex items-center justify-center text-slate-600 hover:text-indigo-600"
                  >
                    {test.isPublished ? (
                      <EyeOff className="w-4 h-4 text-amber-600" />
                    ) : (
                      <Eye className="w-4 h-4 text-emerald-600" />
                    )}
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => openEditModal(test)}
                    title="Edit Test Settings"
                    className="p-0 flex items-center justify-center text-slate-600 hover:text-indigo-600"
                  >
                    <Edit2 className="w-4 h-4" />
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setDeletingTest(test)}
                    title="Delete Test"
                    className="p-0 flex items-center justify-center text-slate-600 hover:text-red-600 hover:border-red-200"
                  >
                    <Trash2 className="w-4 h-4 text-red-500" />
                  </Button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* CREATE / EDIT UNIT TEST MODAL */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/70">
          <div className="bg-white rounded-3xl border border-slate-200 w-full max-w-2xl max-h-[90vh] overflow-hidden shadow-2xl flex flex-col">
            <div className="p-6 border-b border-slate-100 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-indigo-50 text-indigo-600 flex items-center justify-center font-bold">
                  <FileCheck className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-extrabold text-base text-slate-900">
                    {editingTest ? 'Edit Unit MCQ Test' : 'Create Unit MCQ Test'}
                  </h3>
                  <p className="text-xs text-slate-500">
                    Chapter/Unit-level practice assessment
                  </p>
                </div>
              </div>
              <button
                onClick={() => setIsModalOpen(false)}
                className="p-2 rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-100"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmitModal} className="flex-1 overflow-y-auto p-6 space-y-4">
              {/* Hierarchy info */}
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 grid grid-cols-3 gap-2 text-xs">
                <div>
                  <span className="text-[10px] font-bold text-slate-400 uppercase">Batch</span>
                  <span className="font-bold text-slate-800 block truncate">
                    {batches.find((b) => b.id === formData.batchId)?.title || 'Selected Batch'}
                  </span>
                </div>
                <div>
                  <span className="text-[10px] font-bold text-slate-400 uppercase">Subject</span>
                  <span className="font-bold text-slate-800 block truncate">
                    {subjects.find((s) => s.id === formData.subjectId)?.name || 'Selected Subject'}
                  </span>
                </div>
                <div>
                  <span className="text-[10px] font-bold text-slate-400 uppercase">Chapter</span>
                  <span className="font-bold text-slate-800 block truncate">
                    {chapters.find((c) => c.id === formData.chapterId)?.name || 'Selected Chapter'}
                  </span>
                </div>
              </div>

              {/* Title */}
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5">
                  Test Title *
                </label>
                <input
                  type="text"
                  placeholder="e.g. Chapter 01 MCQ Practice: Cardiovascular Disorders"
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  required
                  className="w-full h-11 px-3.5 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-indigo-500 text-slate-800 font-semibold"
                />
              </div>

              {/* Description */}
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5">
                  Description
                </label>
                <textarea
                  rows={2}
                  placeholder="Unit revision questions for high-yield nursing exams..."
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  className="w-full p-3 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-indigo-500 text-slate-800"
                />
              </div>

              {/* Numerical settings */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">
                    Duration (Mins)
                  </label>
                  <input
                    type="number"
                    min={1}
                    value={formData.durationMinutes}
                    onChange={(e) =>
                      setFormData({ ...formData, durationMinutes: Number(e.target.value) || 15 })
                    }
                    className="w-full h-10 px-3 text-xs bg-slate-50 border border-slate-200 rounded-xl font-bold"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">
                    Total Marks
                  </label>
                  <input
                    type="number"
                    min={1}
                    value={formData.totalMarks}
                    onChange={(e) =>
                      setFormData({ ...formData, totalMarks: Number(e.target.value) || 20 })
                    }
                    className="w-full h-10 px-3 text-xs bg-slate-50 border border-slate-200 rounded-xl font-bold"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">
                    Passing Marks
                  </label>
                  <input
                    type="number"
                    min={1}
                    value={formData.passingMarks}
                    onChange={(e) =>
                      setFormData({ ...formData, passingMarks: Number(e.target.value) || 10 })
                    }
                    className="w-full h-10 px-3 text-xs bg-slate-50 border border-slate-200 rounded-xl font-bold"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">
                    Negative Marks
                  </label>
                  <input
                    type="number"
                    step="0.05"
                    min={0}
                    value={formData.negativeMarksPerQuestion}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        negativeMarksPerQuestion: Number(e.target.value) || 0,
                      })
                    }
                    className="w-full h-10 px-3 text-xs bg-slate-50 border border-slate-200 rounded-xl font-bold"
                  />
                </div>
              </div>

              {/* Instructions */}
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5">
                  Instructions
                </label>
                <textarea
                  rows={2}
                  value={instructionsText}
                  onChange={(e) => setInstructionsText(e.target.value)}
                  className="w-full p-3 text-xs bg-slate-50 border border-slate-200 rounded-xl font-mono text-slate-800"
                />
              </div>

              {/* Checkboxes */}
              <div className="flex flex-wrap items-center gap-6 pt-2">
                <label className="flex items-center gap-2 cursor-pointer select-none">
                  <input
                    type="checkbox"
                    checked={formData.isPublished}
                    onChange={(e) => setFormData({ ...formData, isPublished: e.target.checked })}
                    className="w-4 h-4 rounded text-indigo-600 focus:ring-indigo-500"
                  />
                  <span className="text-xs font-bold text-slate-700">Publish Immediately</span>
                </label>

                <label className="flex items-center gap-2 cursor-pointer select-none">
                  <input
                    type="checkbox"
                    checked={formData.allowReviewAfterSubmission}
                    onChange={(e) =>
                      setFormData({ ...formData, allowReviewAfterSubmission: e.target.checked })
                    }
                    className="w-4 h-4 rounded text-indigo-600 focus:ring-indigo-500"
                  />
                  <span className="text-xs font-bold text-slate-700">
                    Allow Solution & Rational Review
                  </span>
                </label>
              </div>

              <div className="p-4 bg-slate-50 rounded-2xl flex items-center justify-end gap-3 pt-4 border-t border-slate-100">
                <Button variant="outline" type="button" onClick={() => setIsModalOpen(false)}>
                  Cancel
                </Button>
                <Button type="submit" className="bg-indigo-600 hover:bg-indigo-700 text-white font-bold">
                  {editingTest ? 'Save Changes' : 'Create Unit Test'}
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Submissions Analytics Modal */}
      {analyticsTest && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/70">
          <div className="bg-white rounded-3xl border border-slate-200 w-full max-w-3xl max-h-[85vh] overflow-hidden shadow-2xl flex flex-col">
            <div className="p-6 border-b border-slate-100 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-indigo-50 text-indigo-600 flex items-center justify-center font-bold">
                  <BarChart3 className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-extrabold text-base text-slate-900">
                    Submissions & Scorecards
                  </h3>
                  <p className="text-xs text-slate-500">{analyticsTest.title}</p>
                </div>
              </div>
              <button
                onClick={() => setAnalyticsTest(null)}
                className="p-2 rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-100"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-6">
              {loadingAttempts ? (
                <div className="text-center py-12">
                  <div className="w-8 h-8 border-3 border-indigo-600 border-t-transparent rounded-full animate-spin mx-auto mb-2" />
                  <p className="text-xs text-slate-500">Loading student attempts...</p>
                </div>
              ) : testAttempts.length === 0 ? (
                <div className="text-center py-12 text-slate-400 text-xs">
                  No student attempts logged yet for this unit test.
                </div>
              ) : (
                <div className="space-y-3">
                  {testAttempts.map((att) => (
                    <div
                      key={att.id}
                      className="p-3.5 rounded-xl border border-slate-100 bg-slate-50 flex items-center justify-between text-xs"
                    >
                      <div>
                        <span className="font-bold text-slate-900 block">
                          {att.studentName || att.studentEmail || att.studentId}
                        </span>
                        <span className="text-[10px] text-slate-400">
                          Started: {new Date(att.startedAt).toLocaleString()}
                        </span>
                      </div>
                      <div className="flex items-center gap-3">
                        <span
                          className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                            att.status === 'completed'
                              ? 'bg-emerald-100 text-emerald-800'
                              : 'bg-amber-100 text-amber-800'
                          }`}
                        >
                          {att.status}
                        </span>
                        {att.score !== undefined && (
                          <span className="font-extrabold text-indigo-600">
                            Score: {att.score} / {att.totalMarks}
                          </span>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Delete Confirmation */}
      <ConfirmationModal
        isOpen={Boolean(deletingTest)}
        title="Delete Unit MCQ Test"
        message={`Are you sure you want to permanently delete "${deletingTest?.title}"? All associated questions will be removed.`}
        confirmLabel="Delete Test"
        isDestructive
        isLoading={isDeleting}
        onConfirm={confirmDelete}
        onCancel={() => setDeletingTest(null)}
      />
    </div>
  );
}

export default AdminUnitTestsPage;
