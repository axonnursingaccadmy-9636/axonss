/**
 * Axon Nursing Academy - Admin Weekly Warrior Test Management CMS
 * Manage Course-level competitive weekly tests, schedule parameters, and evaluation scoring.
 */
import React, { useState, useEffect } from 'react';
import { useSearchParams, Link } from 'react-router-dom';
import {
  Award,
  Plus,
  Search,
  Edit2,
  Trash2,
  Eye,
  EyeOff,
  RefreshCw,
  X,
  FileQuestion,
  Clock,
  CheckCircle2,
  AlertCircle,
  HelpCircle,
  BarChart3,
  BookMarked,
  Layers,
  Calendar,
} from 'lucide-react';
import { ROUTES } from '@/src/config/routes.config';
import { Badge } from '@/src/components/ui/Badge';
import { Button } from '@/src/components/ui/Button';
import { AdminPageHeader } from '@/src/components/admin/AdminPageHeader';
import { PublishStatusBadge } from '@/src/components/admin/StatusBadge';
import { ConfirmationModal } from '@/src/components/admin/ConfirmationModal';
import { getAllBatchesAdmin } from '@/src/services/firebase/adminBatchService';
import {
  getAllWeeklyWarriorTestsAdmin,
  createWeeklyWarriorTest,
  updateWeeklyWarriorTest,
  deleteWeeklyWarriorTest,
  toggleWeeklyWarriorPublish,
  getWeeklyWarriorAttemptsForAdmin,
  WeeklyWarriorTestFormData,
} from '@/src/services/firebase/weeklyWarriorTestService';
import { WeeklyWarriorTest, WeeklyWarriorAttempt } from '@/src/types/assessment.types';
import { Batch } from '@/src/types/lms.types';
import { useAuth } from '@/src/contexts/AuthContext';

export function AdminWeeklyWarriorPage() {
  const { currentUser } = useAuth();
  const [searchParams, setSearchParams] = useSearchParams();
  const selectedBatchId = searchParams.get('batchId') || '';

  const [batches, setBatches] = useState<Batch[]>([]);
  const [tests, setTests] = useState<WeeklyWarriorTest[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  // Submissions Analytics Modal
  const [analyticsTest, setAnalyticsTest] = useState<WeeklyWarriorTest | null>(null);
  const [testAttempts, setTestAttempts] = useState<WeeklyWarriorAttempt[]>([]);
  const [loadingAttempts, setLoadingAttempts] = useState(false);

  // Create / Edit Modal State
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingTest, setEditingTest] = useState<WeeklyWarriorTest | null>(null);
  const [formData, setFormData] = useState<WeeklyWarriorTestFormData>({
    batchId: '',
    title: '',
    description: '',
    durationMinutes: 60,
    totalMarks: 100,
    passingMarks: 50,
    marksPerQuestion: 1,
    negativeMarksPerQuestion: 0.25,
    totalQuestions: 0,
    instructions: [
      'Each question carries specified positive marks.',
      'Negative marking applies to incorrect answers.',
      'Submit the test before the countdown timer expires.',
    ],
    isPublished: true,
    order: 1,
    allowReviewAfterSubmission: true,
    maxAttempts: 0,
  });

  const [instructionsText, setInstructionsText] = useState(
    'Each question carries specified positive marks.\nNegative marking applies to incorrect answers.\nSubmit the test before the countdown timer expires.'
  );

  // Delete Modal State
  const [deletingTest, setDeletingTest] = useState<WeeklyWarriorTest | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);

  // Status Notification
  const [feedbackMsg, setFeedbackMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  useEffect(() => {
    loadData();
  }, [selectedBatchId]);

  const loadData = async () => {
    setLoading(true);
    try {
      const allBatches = await getAllBatchesAdmin();
      setBatches(allBatches);

      const allTests = await getAllWeeklyWarriorTestsAdmin(selectedBatchId || undefined);
      setTests(allTests);
    } catch (err: any) {
      console.error('Error loading tests:', err);
      showFeedback('error', 'Failed to load Weekly Warrior tests.');
    } finally {
      setLoading(false);
    }
  };

  const handleRefresh = async () => {
    setRefreshing(true);
    await loadData();
    setRefreshing(false);
    showFeedback('success', 'Test list synchronized.');
  };

  const showFeedback = (type: 'success' | 'error', text: string) => {
    setFeedbackMsg({ type, text });
    setTimeout(() => setFeedbackMsg(null), 4000);
  };

  const handleBatchFilterChange = (bId: string) => {
    if (bId) {
      setSearchParams({ batchId: bId });
    } else {
      setSearchParams({});
    }
  };

  const openCreateModal = () => {
    setEditingTest(null);
    const initialBatchId = selectedBatchId || (batches.length > 0 ? batches[0].id : '');
    setFormData({
      batchId: initialBatchId,
      title: '',
      description: '',
      durationMinutes: 60,
      totalMarks: 100,
      passingMarks: 50,
      marksPerQuestion: 1,
      negativeMarksPerQuestion: 0.25,
      totalQuestions: 0,
      instructions: [
        'Each question carries specified positive marks.',
        'Negative marking applies to incorrect answers.',
        'Submit the test before the countdown timer expires.',
      ],
      isPublished: true,
      order: tests.length + 1,
      allowReviewAfterSubmission: true,
      maxAttempts: 0,
    });
    setInstructionsText(
      'Each question carries specified positive marks.\nNegative marking applies to incorrect answers.\nSubmit the test before the countdown timer expires.'
    );
    setIsModalOpen(true);
  };

  const openEditModal = (test: WeeklyWarriorTest) => {
    setEditingTest(test);
    setFormData({
      batchId: test.batchId,
      title: test.title,
      description: test.description || '',
      durationMinutes: test.durationMinutes,
      totalMarks: test.totalMarks,
      passingMarks: test.passingMarks,
      marksPerQuestion: test.marksPerQuestion,
      negativeMarksPerQuestion: test.negativeMarksPerQuestion,
      totalQuestions: test.totalQuestions,
      instructions: test.instructions || [],
      isPublished: test.isPublished,
      order: test.order,
      allowReviewAfterSubmission: test.allowReviewAfterSubmission,
      maxAttempts: test.maxAttempts || 0,
    });
    setInstructionsText((test.instructions || []).join('\n'));
    setIsModalOpen(true);
  };

  const handleSubmitModal = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.batchId) {
      showFeedback('error', 'Please assign this test to a Course Batch.');
      return;
    }
    if (!formData.title.trim()) {
      showFeedback('error', 'Please enter a valid test title.');
      return;
    }

    const instructionsArray = instructionsText
      .split('\n')
      .map((i) => i.trim())
      .filter((i) => i.length > 0);

    const payload: WeeklyWarriorTestFormData = {
      ...formData,
      title: formData.title.trim(),
      instructions: instructionsArray,
    };

    try {
      if (editingTest) {
        await updateWeeklyWarriorTest(
          editingTest.id,
          payload,
          currentUser?.uid || 'admin',
          currentUser?.email || undefined
        );
        showFeedback('success', `Updated test "${payload.title}" successfully.`);
      } else {
        await createWeeklyWarriorTest(
          payload,
          currentUser?.uid || 'admin',
          currentUser?.email || undefined
        );
        showFeedback('success', `Created Weekly Warrior test "${payload.title}".`);
      }
      setIsModalOpen(false);
      await loadData();
    } catch (err: any) {
      showFeedback('error', err.message || 'Operation failed.');
    }
  };

  const handleTogglePublish = async (test: WeeklyWarriorTest) => {
    try {
      const newState = !test.isPublished;
      await toggleWeeklyWarriorPublish(
        test.id,
        newState,
        test.title,
        currentUser?.uid || 'admin',
        currentUser?.email || undefined
      );
      setTests((prev) =>
        prev.map((t) => (t.id === test.id ? { ...t, isPublished: newState } : t))
      );
      showFeedback(
        'success',
        `Test "${test.title}" is now ${newState ? 'Published' : 'Unpublished (Draft)'}.`
      );
    } catch (err: any) {
      showFeedback('error', 'Failed to toggle status.');
    }
  };

  const confirmDelete = async () => {
    if (!deletingTest) return;
    setIsDeleting(true);
    try {
      await deleteWeeklyWarriorTest(
        deletingTest.id,
        deletingTest.title,
        currentUser?.uid || 'admin',
        currentUser?.email || undefined
      );
      setTests((prev) => prev.filter((t) => t.id !== deletingTest.id));
      showFeedback('success', `Deleted test "${deletingTest.title}".`);
      setDeletingTest(null);
    } catch (err: any) {
      showFeedback('error', 'Failed to delete test.');
    } finally {
      setIsDeleting(false);
    }
  };

  const openAnalytics = async (test: WeeklyWarriorTest) => {
    setAnalyticsTest(test);
    setLoadingAttempts(true);
    try {
      const atts = await getWeeklyWarriorAttemptsForAdmin(test.id);
      setTestAttempts(atts);
    } catch (err) {
      setTestAttempts([]);
    } finally {
      setLoadingAttempts(false);
    }
  };

  const filteredTests = tests.filter((t) => {
    if (selectedBatchId && t.batchId !== selectedBatchId) return false;
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      return (
        t.title.toLowerCase().includes(q) ||
        (t.description && t.description.toLowerCase().includes(q))
      );
    }
    return true;
  });

  const getBatchTitle = (bId: string) => {
    return batches.find((b) => b.id === bId)?.title || 'Course Batch';
  };

  return (
    <div className="space-y-6">
      {/* Top Banner Header */}
      <AdminPageHeader
        title="Weekly Warrior Tests"
        description="Course-Level competitive weekly exams with negative marking, time controls, and zero-trust answer evaluation."
        breadcrumbs={[
          { label: 'Admin Dashboard', path: ROUTES.ADMIN.DASHBOARD },
          { label: 'Weekly Warrior' },
        ]}
        actions={
          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={handleRefresh}
              disabled={refreshing || loading}
              className="gap-2"
            >
              <RefreshCw className={`w-4 h-4 ${refreshing ? 'animate-spin' : ''}`} />
              Sync
            </Button>
            <Button size="sm" onClick={openCreateModal} className="gap-2 bg-blue-600 hover:bg-blue-700 text-white">
              <Plus className="w-4 h-4" />
              New Weekly Warrior
            </Button>
          </div>
        }
      />

      {/* Notification Toast */}
      {feedbackMsg && (
        <div
          className={`p-4 rounded-xl text-xs font-semibold flex items-center justify-between shadow-sm animate-in fade-in slide-in-from-top-2 ${
            feedbackMsg.type === 'success'
              ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
              : 'bg-red-50 text-red-800 border border-red-200'
          }`}
        >
          <div className="flex items-center gap-2">
            {feedbackMsg.type === 'success' ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            ) : (
              <AlertCircle className="w-4 h-4 text-red-600" />
            )}
            <span>{feedbackMsg.text}</span>
          </div>
          <button onClick={() => setFeedbackMsg(null)} className="opacity-60 hover:opacity-100">
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Controls Bar: Batch Filter & Search */}
      <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-xs flex flex-col md:flex-row items-center gap-4 justify-between">
        <div className="flex flex-col sm:flex-row items-center gap-3 w-full md:w-auto">
          <div className="w-full sm:w-72">
            <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-500 mb-1">
              Filter by Course Batch
            </label>
            <select
              value={selectedBatchId}
              onChange={(e) => handleBatchFilterChange(e.target.value)}
              className="w-full h-10 px-3 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-blue-500 font-medium text-slate-800"
            >
              <option value="">All Course Batches</option>
              {batches.map((b) => (
                <option key={b.id} value={b.id}>
                  {b.title}
                </option>
              ))}
            </select>
          </div>
        </div>

        <div className="w-full md:w-72">
          <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-500 mb-1">
            Search Test Title
          </label>
          <div className="relative">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="Search tests..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full h-10 pl-9 pr-3 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-blue-500 text-slate-800"
            />
          </div>
        </div>
      </div>

      {/* Test List Section */}
      {loading ? (
        <div className="bg-white rounded-2xl border border-slate-200 p-12 text-center">
          <div className="w-10 h-10 border-3 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-3" />
          <p className="text-xs font-semibold text-slate-500">Loading Weekly Warrior tests...</p>
        </div>
      ) : filteredTests.length === 0 ? (
        <div className="bg-white rounded-2xl border border-dashed border-slate-300 p-12 text-center">
          <div className="w-12 h-12 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center mx-auto mb-3">
            <Award className="w-6 h-6" />
          </div>
          <h3 className="text-base font-bold text-slate-800 mb-1">No Weekly Warrior Tests Found</h3>
          <p className="text-xs text-slate-500 max-w-md mx-auto mb-5">
            Create scheduled or practice course-level tests for your nursing cohorts. Questions and answer keys are configured per test.
          </p>
          <Button onClick={openCreateModal} size="sm" className="gap-2 bg-blue-600 hover:bg-blue-700 text-white">
            <Plus className="w-4 h-4" />
            Create First Weekly Warrior Test
          </Button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-5">
          {filteredTests.map((test) => (
            <div
              key={test.id}
              className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs hover:shadow-md transition-all flex flex-col justify-between"
            >
              <div>
                {/* Header info */}
                <div className="flex items-start justify-between gap-2 mb-3">
                  <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-[10px] font-bold bg-slate-100 text-slate-700 border border-slate-200">
                    <BookMarked className="w-3 h-3 text-blue-600" />
                    {getBatchTitle(test.batchId)}
                  </span>
                  <PublishStatusBadge isPublished={test.isPublished} />
                </div>

                <h3 className="font-extrabold text-sm text-slate-900 mb-1.5 line-clamp-2">
                  {test.title}
                </h3>
                {test.description && (
                  <p className="text-xs text-slate-500 mb-4 line-clamp-2">{test.description}</p>
                )}

                {/* Metrics Grid */}
                <div className="grid grid-cols-3 gap-2 p-3 bg-slate-50 rounded-xl mb-4 text-center">
                  <div>
                    <span className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                      Questions
                    </span>
                    <span className="font-extrabold text-xs text-slate-800">
                      {test.totalQuestions}
                    </span>
                  </div>
                  <div>
                    <span className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                      Duration
                    </span>
                    <span className="font-extrabold text-xs text-slate-800">
                      {test.durationMinutes}m
                    </span>
                  </div>
                  <div>
                    <span className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                      Total Marks
                    </span>
                    <span className="font-extrabold text-xs text-slate-800">
                      {test.totalMarks}
                    </span>
                  </div>
                </div>

                <div className="flex items-center justify-between text-[11px] text-slate-500 pb-3 border-b border-slate-100 mb-3">
                  <span className="flex items-center gap-1">
                    <span className="w-2 h-2 rounded-full bg-emerald-500" />
                    Pass: <strong>{test.passingMarks} M</strong>
                  </span>
                  <span className="flex items-center gap-1">
                    <span className="w-2 h-2 rounded-full bg-red-500" />
                    Neg: <strong>-{test.negativeMarksPerQuestion} M</strong>
                  </span>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex flex-col gap-2 pt-2">
                <Link
                  to={ROUTES.ADMIN.WEEKLY_WARRIOR_QUESTIONS(test.id)}
                  className="w-full"
                >
                  <Button
                    variant="primary"
                    size="sm"
                    className="w-full gap-2 bg-blue-600 hover:bg-blue-700 text-white"
                  >
                    <FileQuestion className="w-4 h-4" />
                    Manage Questions ({test.totalQuestions})
                  </Button>
                </Link>

                <div className="grid grid-cols-4 gap-1.5">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => openAnalytics(test)}
                    title="View Student Submissions"
                    className="p-0 flex items-center justify-center text-slate-600 hover:text-blue-600"
                  >
                    <BarChart3 className="w-4 h-4" />
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleTogglePublish(test)}
                    title={test.isPublished ? 'Unpublish (Draft)' : 'Publish Test'}
                    className="p-0 flex items-center justify-center text-slate-600 hover:text-blue-600"
                  >
                    {test.isPublished ? (
                      <EyeOff className="w-4 h-4 text-amber-600" />
                    ) : (
                      <Eye className="w-4 h-4 text-emerald-600" />
                    )}
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => openEditModal(test)}
                    title="Edit Test Settings"
                    className="p-0 flex items-center justify-center text-slate-600 hover:text-blue-600"
                  >
                    <Edit2 className="w-4 h-4" />
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setDeletingTest(test)}
                    title="Delete Test"
                    className="p-0 flex items-center justify-center text-slate-600 hover:text-red-600 hover:border-red-200"
                  >
                    <Trash2 className="w-4 h-4 text-red-500" />
                  </Button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* CREATE / EDIT TEST MODAL */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/70">
          <div className="bg-white rounded-3xl border border-slate-200 w-full max-w-2xl max-h-[90vh] overflow-hidden shadow-2xl flex flex-col">
            <div className="p-6 border-b border-slate-100 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center font-bold">
                  <Award className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-extrabold text-base text-slate-900">
                    {editingTest ? 'Edit Weekly Warrior Test' : 'Create Weekly Warrior Test'}
                  </h3>
                  <p className="text-xs text-slate-500">
                    Course-Level competitive test configuration
                  </p>
                </div>
              </div>
              <button
                onClick={() => setIsModalOpen(false)}
                className="p-2 rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-100"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmitModal} className="flex-1 overflow-y-auto p-6 space-y-4">
              {/* Batch Selector */}
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5">
                  Course Batch *
                </label>
                <select
                  value={formData.batchId}
                  onChange={(e) => setFormData({ ...formData, batchId: e.target.value })}
                  required
                  className="w-full h-11 px-3.5 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-blue-500 font-semibold text-slate-800"
                >
                  <option value="">Select Course Batch</option>
                  {batches.map((b) => (
                    <option key={b.id} value={b.id}>
                      {b.title}
                    </option>
                  ))}
                </select>
              </div>

              {/* Title */}
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5">
                  Test Title *
                </label>
                <input
                  type="text"
                  placeholder="e.g. Weekly Grand Mock Test 01 - AIIMS NORCET"
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  required
                  className="w-full h-11 px-3.5 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-blue-500 text-slate-800 font-semibold"
                />
              </div>

              {/* Description */}
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5">
                  Description / Topic Coverage
                </label>
                <textarea
                  rows={2}
                  placeholder="Covers Medical-Surgical Nursing, Pharmacology, and Nursing Foundations..."
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  className="w-full p-3 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-blue-500 text-slate-800"
                />
              </div>

              {/* Parameter Numbers */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">
                    Duration (Mins)
                  </label>
                  <input
                    type="number"
                    min={1}
                    value={formData.durationMinutes}
                    onChange={(e) =>
                      setFormData({ ...formData, durationMinutes: Number(e.target.value) || 30 })
                    }
                    className="w-full h-10 px-3 text-xs bg-slate-50 border border-slate-200 rounded-xl font-bold"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">
                    Total Marks
                  </label>
                  <input
                    type="number"
                    min={1}
                    value={formData.totalMarks}
                    onChange={(e) =>
                      setFormData({ ...formData, totalMarks: Number(e.target.value) || 100 })
                    }
                    className="w-full h-10 px-3 text-xs bg-slate-50 border border-slate-200 rounded-xl font-bold"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">
                    Passing Marks
                  </label>
                  <input
                    type="number"
                    min={1}
                    value={formData.passingMarks}
                    onChange={(e) =>
                      setFormData({ ...formData, passingMarks: Number(e.target.value) || 40 })
                    }
                    className="w-full h-10 px-3 text-xs bg-slate-50 border border-slate-200 rounded-xl font-bold"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">
                    Negative Marks
                  </label>
                  <input
                    type="number"
                    step="0.05"
                    min={0}
                    value={formData.negativeMarksPerQuestion}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        negativeMarksPerQuestion: Number(e.target.value) || 0,
                      })
                    }
                    className="w-full h-10 px-3 text-xs bg-slate-50 border border-slate-200 rounded-xl font-bold"
                  />
                </div>
              </div>

              {/* Instructions */}
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5">
                  Test Instructions (One rule per line)
                </label>
                <textarea
                  rows={3}
                  value={instructionsText}
                  onChange={(e) => setInstructionsText(e.target.value)}
                  className="w-full p-3 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-blue-500 font-mono text-slate-800"
                />
              </div>

              {/* Checkboxes & Settings */}
              <div className="flex flex-wrap items-center gap-6 pt-2">
                <label className="flex items-center gap-2 cursor-pointer select-none">
                  <input
                    type="checkbox"
                    checked={formData.isPublished}
                    onChange={(e) => setFormData({ ...formData, isPublished: e.target.checked })}
                    className="w-4 h-4 rounded text-blue-600 focus:ring-blue-500"
                  />
                  <span className="text-xs font-bold text-slate-700">Publish Immediately</span>
                </label>

                <label className="flex items-center gap-2 cursor-pointer select-none">
                  <input
                    type="checkbox"
                    checked={formData.allowReviewAfterSubmission}
                    onChange={(e) =>
                      setFormData({ ...formData, allowReviewAfterSubmission: e.target.checked })
                    }
                    className="w-4 h-4 rounded text-blue-600 focus:ring-blue-500"
                  />
                  <span className="text-xs font-bold text-slate-700">
                    Allow Solution & Rational Review
                  </span>
                </label>
              </div>

              <div className="p-4 bg-slate-50 rounded-2xl flex items-center justify-end gap-3 pt-4 border-t border-slate-100">
                <Button variant="outline" type="button" onClick={() => setIsModalOpen(false)}>
                  Cancel
                </Button>
                <Button type="submit" className="bg-blue-600 hover:bg-blue-700 text-white font-bold">
                  {editingTest ? 'Save Changes' : 'Create Test'}
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* SUBMISSIONS / ANALYTICS MODAL */}
      {analyticsTest && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/70">
          <div className="bg-white rounded-3xl border border-slate-200 w-full max-w-3xl max-h-[85vh] overflow-hidden shadow-2xl flex flex-col">
            <div className="p-6 border-b border-slate-100 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center font-bold">
                  <BarChart3 className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-extrabold text-base text-slate-900">
                    Submissions & Scorecards
                  </h3>
                  <p className="text-xs text-slate-500">{analyticsTest.title}</p>
                </div>
              </div>
              <button
                onClick={() => setAnalyticsTest(null)}
                className="p-2 rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-100"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-6">
              {loadingAttempts ? (
                <div className="text-center py-12">
                  <div className="w-8 h-8 border-3 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-2" />
                  <p className="text-xs text-slate-500">Loading student attempts...</p>
                </div>
              ) : testAttempts.length === 0 ? (
                <div className="text-center py-12 text-slate-400 text-xs">
                  No student attempts logged yet for this test.
                </div>
              ) : (
                <div className="space-y-3">
                  {testAttempts.map((att) => (
                    <div
                      key={att.id}
                      className="p-3.5 rounded-xl border border-slate-100 bg-slate-50 flex items-center justify-between text-xs"
                    >
                      <div>
                        <span className="font-bold text-slate-900 block">
                          {att.studentName || att.studentEmail || att.studentId}
                        </span>
                        <span className="text-[10px] text-slate-400">
                          Started: {new Date(att.startedAt).toLocaleString()}
                        </span>
                      </div>
                      <div className="flex items-center gap-3">
                        <span
                          className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                            att.status === 'completed'
                              ? 'bg-emerald-100 text-emerald-800'
                              : 'bg-amber-100 text-amber-800'
                          }`}
                        >
                          {att.status}
                        </span>
                        {att.score !== undefined && (
                          <span className="font-extrabold text-blue-600">
                            Score: {att.score} / {att.totalMarks}
                          </span>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      <ConfirmationModal
        isOpen={Boolean(deletingTest)}
        title="Delete Weekly Warrior Test"
        message={`Are you sure you want to permanently delete "${deletingTest?.title}"? All associated questions and test records will be removed.`}
        confirmLabel="Delete Test"
        isDestructive
        isLoading={isDeleting}
        onConfirm={confirmDelete}
        onCancel={() => setDeletingTest(null)}
      />
    </div>
  );
}

export default AdminWeeklyWarriorPage;
