/**
 * Axon Nursing Academy - Admin Unit Test Questions Manager CMS
 * Manage chapter-level MCQ questions, options, key designations, and clinical rationales.
 */
import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import {
  ArrowLeft,
  Plus,
  Edit2,
  Trash2,
  CheckCircle2,
  AlertCircle,
  RefreshCw,
  X,
  FileQuestion,
  BookOpen,
} from 'lucide-react';
import { ROUTES } from '@/src/config/routes.config';
import { Button } from '@/src/components/ui/Button';
import { AdminPageHeader } from '@/src/components/admin/AdminPageHeader';
import { ConfirmationModal } from '@/src/components/admin/ConfirmationModal';
import { ImageUploadField } from '@/src/components/common/ImageUploadField';
import {
  getUnitTestById,
  getUnitTestQuestionsAdmin,
  createUnitTestQuestion,
  updateUnitTestQuestion,
  deleteUnitTestQuestion,
  UnitTestQuestionFormData,
} from '@/src/services/firebase/unitTestService';
import {
  UnitTest,
  UnitTestQuestion,
} from '@/src/types/assessment.types';
import { useAuth } from '@/src/contexts/AuthContext';

export function AdminUnitTestQuestionsPage() {
  const { testId } = useParams<{ testId: string }>();
  const { currentUser } = useAuth();

  const [test, setTest] = useState<UnitTest | null>(null);
  const [questions, setQuestions] = useState<UnitTestQuestion[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  // Modal State
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingQuestion, setEditingQuestion] = useState<UnitTestQuestion | null>(null);

  const [formData, setFormData] = useState<UnitTestQuestionFormData>({
    testId: testId || '',
    chapterId: '',
    batchId: '',
    subjectId: '',
    questionText: '',
    questionImageUrl: '',
    options: [
      { id: 'A', text: '' },
      { id: 'B', text: '' },
      { id: 'C', text: '' },
      { id: 'D', text: '' },
    ],
    correctOptionId: 'A',
    marks: 1,
    negativeMarks: 0.25,
    explanation: '',
    explanationImageUrl: '',
    order: 1,
  });

  // Delete State
  const [deletingQuestion, setDeletingQuestion] = useState<UnitTestQuestion | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);

  // Status Toast
  const [feedbackMsg, setFeedbackMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  useEffect(() => {
    if (testId) {
      loadData();
    }
  }, [testId]);

  const loadData = async () => {
    if (!testId) return;
    setLoading(true);
    try {
      const testData = await getUnitTestById(testId);
      setTest(testData);

      const qList = await getUnitTestQuestionsAdmin(testId);
      setQuestions(qList);
    } catch (err: any) {
      showFeedback('error', 'Failed to load test questions.');
    } finally {
      setLoading(false);
    }
  };

  const handleRefresh = async () => {
    setRefreshing(true);
    await loadData();
    setRefreshing(false);
    showFeedback('success', 'Question bank synchronized.');
  };

  const showFeedback = (type: 'success' | 'error', text: string) => {
    setFeedbackMsg({ type, text });
    setTimeout(() => setFeedbackMsg(null), 4000);
  };

  const openCreateModal = () => {
    setEditingQuestion(null);
    setFormData({
      testId: testId || '',
      chapterId: test?.chapterId || '',
      batchId: test?.batchId || '',
      subjectId: test?.subjectId || '',
      questionText: '',
      questionImageUrl: '',
      options: [
        { id: 'A', text: '' },
        { id: 'B', text: '' },
        { id: 'C', text: '' },
        { id: 'D', text: '' },
      ],
      correctOptionId: 'A',
      marks: test?.marksPerQuestion || 1,
      negativeMarks: test?.negativeMarksPerQuestion ?? 0.25,
      explanation: '',
      explanationImageUrl: '',
      order: questions.length + 1,
    });
    setIsModalOpen(true);
  };

  const openEditModal = (q: UnitTestQuestion) => {
    setEditingQuestion(q);
    setFormData({
      testId: q.testId,
      chapterId: q.chapterId,
      batchId: q.batchId,
      subjectId: q.subjectId,
      questionText: q.questionText,
      questionImageUrl: q.questionImageUrl || '',
      options: q.options && q.options.length === 4 ? q.options : [
        { id: 'A', text: q.options[0]?.text || '' },
        { id: 'B', text: q.options[1]?.text || '' },
        { id: 'C', text: q.options[2]?.text || '' },
        { id: 'D', text: q.options[3]?.text || '' },
      ],
      correctOptionId: q.correctOptionId || 'A',
      marks: q.marks,
      negativeMarks: q.negativeMarks,
      explanation: q.explanation || '',
      explanationImageUrl: q.explanationImageUrl || '',
      order: q.order,
    });
    setIsModalOpen(true);
  };

  const handleOptionTextChange = (id: string, text: string) => {
    setFormData((prev) => ({
      ...prev,
      options: prev.options.map((opt) => (opt.id === id ? { ...opt, text } : opt)),
    }));
  };

  const handleSubmitModal = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.questionText.trim()) {
      showFeedback('error', 'Please enter question statement.');
      return;
    }

    const invalidOption = formData.options.find((opt) => !opt.text.trim());
    if (invalidOption) {
      showFeedback('error', `Please fill option (${invalidOption.id}).`);
      return;
    }

    const payload: UnitTestQuestionFormData = {
      ...formData,
      testId: testId || '',
      chapterId: test?.chapterId || '',
      batchId: test?.batchId || '',
      subjectId: test?.subjectId || '',
      questionText: formData.questionText.trim(),
      questionImageUrl: formData.questionImageUrl?.trim() || undefined,
      explanation: formData.explanation?.trim() || undefined,
      explanationImageUrl: formData.explanationImageUrl?.trim() || undefined,
    };

    try {
      if (editingQuestion) {
        await updateUnitTestQuestion(
          editingQuestion.id,
          payload,
          currentUser?.uid || 'admin',
          currentUser?.email || undefined
        );
        showFeedback('success', 'Question updated successfully.');
      } else {
        await createUnitTestQuestion(
          payload,
          currentUser?.uid || 'admin',
          currentUser?.email || undefined
        );
        showFeedback('success', 'Question added to unit test.');
      }
      setIsModalOpen(false);
      await loadData();
    } catch (err: any) {
      showFeedback('error', err.message || 'Operation failed.');
    }
  };

  const confirmDelete = async () => {
    if (!deletingQuestion || !testId) return;
    setIsDeleting(true);
    try {
      await deleteUnitTestQuestion(
        deletingQuestion.id,
        testId,
        currentUser?.uid || 'admin',
        currentUser?.email || undefined
      );
      setQuestions((prev) => prev.filter((q) => q.id !== deletingQuestion.id));
      showFeedback('success', 'Question removed.');
      setDeletingQuestion(null);
      if (test) {
        setTest({ ...test, totalQuestions: Math.max(0, test.totalQuestions - 1) });
      }
    } catch (err: any) {
      showFeedback('error', 'Failed to delete question.');
    } finally {
      setIsDeleting(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex items-center gap-3">
        <Link
          to={ROUTES.ADMIN.UNIT_TESTS}
          className="p-2 rounded-xl text-slate-500 hover:text-slate-800 hover:bg-slate-100 transition-colors"
        >
          <ArrowLeft className="w-5 h-5" />
        </Link>
        <div className="flex-1 min-w-0">
          <AdminPageHeader
            title={test ? `Questions: ${test.title}` : 'Unit MCQ Questions'}
            description="Manage chapter-level multiple choice questions, correct options, and clinical explanations."
            breadcrumbs={[
              { label: 'Admin Dashboard', path: ROUTES.ADMIN.DASHBOARD },
              { label: 'Unit Tests', path: ROUTES.ADMIN.UNIT_TESTS },
              { label: 'Questions' },
            ]}
            actions={
              <div className="flex items-center gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={handleRefresh}
                  disabled={refreshing || loading}
                  className="gap-2"
                >
                  <RefreshCw className={`w-4 h-4 ${refreshing ? 'animate-spin' : ''}`} />
                  Sync
                </Button>
                <Button
                  size="sm"
                  onClick={openCreateModal}
                  className="gap-2 bg-indigo-600 hover:bg-indigo-700 text-white"
                >
                  <Plus className="w-4 h-4" />
                  Add Question
                </Button>
              </div>
            }
          />
        </div>
      </div>

      {/* Notification Toast */}
      {feedbackMsg && (
        <div
          className={`p-4 rounded-xl text-xs font-semibold flex items-center justify-between shadow-sm animate-in fade-in slide-in-from-top-2 ${
            feedbackMsg.type === 'success'
              ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
              : 'bg-red-50 text-red-800 border border-red-200'
          }`}
        >
          <div className="flex items-center gap-2">
            {feedbackMsg.type === 'success' ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            ) : (
              <AlertCircle className="w-4 h-4 text-red-600" />
            )}
            <span>{feedbackMsg.text}</span>
          </div>
          <button onClick={() => setFeedbackMsg(null)} className="opacity-60 hover:opacity-100">
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Meta Bar */}
      {test && (
        <div className="p-4 bg-slate-900 text-white rounded-2xl flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="w-10 h-10 rounded-xl bg-indigo-600 flex items-center justify-center font-bold text-white">
              <BookOpen className="w-5 h-5" />
            </div>
            <div>
              <h4 className="font-extrabold text-sm tracking-tight">{test.title}</h4>
              <p className="text-xs text-slate-400">
                Chapter MCQ Test | {test.durationMinutes} Minutes Duration
              </p>
            </div>
          </div>

          <div className="flex items-center gap-5 text-xs">
            <div>
              <span className="text-slate-400 block text-[10px] font-bold uppercase tracking-wider">
                Questions
              </span>
              <span className="font-extrabold text-white">{questions.length}</span>
            </div>
            <div className="h-6 w-px bg-slate-800" />
            <div>
              <span className="text-slate-400 block text-[10px] font-bold uppercase tracking-wider">
                Marks / Q
              </span>
              <span className="font-extrabold text-emerald-400">+{test.marksPerQuestion}</span>
            </div>
            <div className="h-6 w-px bg-slate-800" />
            <div>
              <span className="text-slate-400 block text-[10px] font-bold uppercase tracking-wider">
                Penalty
              </span>
              <span className="font-extrabold text-red-400">
                -{test.negativeMarksPerQuestion}
              </span>
            </div>
          </div>
        </div>
      )}

      {/* Questions List */}
      {loading ? (
        <div className="bg-white rounded-2xl border border-slate-200 p-12 text-center">
          <div className="w-10 h-10 border-3 border-indigo-600 border-t-transparent rounded-full animate-spin mx-auto mb-3" />
          <p className="text-xs font-semibold text-slate-500">Loading questions...</p>
        </div>
      ) : questions.length === 0 ? (
        <div className="bg-white rounded-2xl border border-dashed border-slate-300 p-12 text-center">
          <div className="w-12 h-12 rounded-2xl bg-indigo-50 text-indigo-600 flex items-center justify-center mx-auto mb-3">
            <FileQuestion className="w-6 h-6" />
          </div>
          <h3 className="text-base font-bold text-slate-800 mb-1">No Questions Added Yet</h3>
          <p className="text-xs text-slate-500 max-w-md mx-auto mb-5">
            Add multiple choice questions for this chapter practice unit.
          </p>
          <Button onClick={openCreateModal} size="sm" className="gap-2 bg-indigo-600 hover:bg-indigo-700 text-white">
            <Plus className="w-4 h-4" />
            Add First Question
          </Button>
        </div>
      ) : (
        <div className="space-y-4">
          {questions.map((q, idx) => (
            <div
              key={q.id}
              className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs hover:border-slate-300 transition-all"
            >
              {/* Header */}
              <div className="flex items-start justify-between gap-3 mb-3">
                <span className="w-7 h-7 rounded-lg bg-indigo-50 text-indigo-700 font-extrabold text-xs flex items-center justify-center">
                  Q{idx + 1}
                </span>

                <div className="flex items-center gap-2">
                  <span className="text-[11px] font-bold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded">
                    +{q.marks} Marks
                  </span>
                  {q.negativeMarks > 0 && (
                    <span className="text-[11px] font-bold text-red-600 bg-red-50 px-2 py-0.5 rounded">
                      -{q.negativeMarks} Marks
                    </span>
                  )}
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => openEditModal(q)}
                    className="p-1.5 h-8 w-8"
                    title="Edit Question"
                  >
                    <Edit2 className="w-3.5 h-3.5 text-slate-600" />
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setDeletingQuestion(q)}
                    className="p-1.5 h-8 w-8 hover:bg-red-50 hover:border-red-200"
                    title="Delete Question"
                  >
                    <Trash2 className="w-3.5 h-3.5 text-red-500" />
                  </Button>
                </div>
              </div>

              {/* Statement */}
              <div className="text-sm font-bold text-slate-900 mb-3 whitespace-pre-wrap">
                {q.questionText}
              </div>

              {q.questionImageUrl && (
                <div className="mb-4">
                  <img
                    src={q.questionImageUrl}
                    alt="Question Diagram"
                    referrerPolicy="no-referrer"
                    className="max-h-48 rounded-xl border border-slate-200 object-contain"
                  />
                </div>
              )}

              {/* Options */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 mb-4">
                {q.options.map((opt) => {
                  const isCorrect = opt.id === q.correctOptionId;
                  return (
                    <div
                      key={opt.id}
                      className={`p-3 rounded-xl border text-xs font-medium flex items-start gap-2.5 transition-all ${
                        isCorrect
                          ? 'bg-emerald-50 border-emerald-300 text-emerald-950 font-bold shadow-xs'
                          : 'bg-slate-50 border-slate-200 text-slate-700'
                      }`}
                    >
                      <span
                        className={`w-5 h-5 rounded-md text-[10px] font-extrabold flex items-center justify-center shrink-0 ${
                          isCorrect
                            ? 'bg-emerald-600 text-white'
                            : 'bg-slate-200 text-slate-700'
                        }`}
                      >
                        {opt.id}
                      </span>
                      <span className="flex-1">{opt.text}</span>
                      {isCorrect && (
                        <span className="text-[10px] font-bold text-emerald-700 uppercase tracking-wider bg-emerald-100 px-1.5 py-0.5 rounded shrink-0">
                          Correct Key
                        </span>
                      )}
                    </div>
                  );
                })}
              </div>

              {/* Explanation */}
              {q.explanation && (
                <div className="p-3.5 bg-indigo-50/60 rounded-xl border border-indigo-100 text-xs text-slate-700">
                  <span className="font-extrabold text-indigo-900 block mb-1 flex items-center gap-1.5">
                    <BookOpen className="w-3.5 h-3.5 text-indigo-600" />
                    Rationale & Explanation
                  </span>
                  <p className="whitespace-pre-wrap leading-relaxed">{q.explanation}</p>
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      {/* CREATE / EDIT QUESTION MODAL */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/70">
          <div className="bg-white rounded-3xl border border-slate-200 w-full max-w-3xl max-h-[90vh] overflow-hidden shadow-2xl flex flex-col">
            <div className="p-6 border-b border-slate-100 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-indigo-50 text-indigo-600 flex items-center justify-center font-bold">
                  <FileQuestion className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-extrabold text-base text-slate-900">
                    {editingQuestion ? 'Edit Unit MCQ Question' : 'Add Unit MCQ Question'}
                  </h3>
                  <p className="text-xs text-slate-500">
                    Set up question, 4 options, answer key, and explanation
                  </p>
                </div>
              </div>
              <button
                onClick={() => setIsModalOpen(false)}
                className="p-2 rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-100"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmitModal} className="flex-1 overflow-y-auto p-6 space-y-4">
              {/* Question Statement */}
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5">
                  Question Statement *
                </label>
                <textarea
                  rows={3}
                  placeholder="Enter the question statement..."
                  value={formData.questionText}
                  onChange={(e) => setFormData({ ...formData, questionText: e.target.value })}
                  required
                  className="w-full p-3 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-indigo-500 font-semibold text-slate-900"
                />
              </div>

              {/* Optional Image */}
              <div>
                <ImageUploadField
                  label="Question Diagram (Optional)"
                  value={formData.questionImageUrl || ''}
                  onChange={(url) => setFormData({ ...formData, questionImageUrl: url })}
                  placeholder="Select or drop clinical diagram image..."
                  folder="general"
                  aspectRatio="video"
                />
              </div>

              {/* 4 Options & Correct Answer Selection */}
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-2">
                  4 Options & Correct Answer Key *
                </label>
                <div className="space-y-2.5">
                  {formData.options.map((opt) => {
                    const isSelectedKey = formData.correctOptionId === opt.id;
                    return (
                      <div
                        key={opt.id}
                        className={`p-3 rounded-xl border flex items-center gap-3 ${
                          isSelectedKey
                            ? 'bg-emerald-50 border-emerald-300'
                            : 'bg-slate-50 border-slate-200'
                        }`}
                      >
                        <button
                          type="button"
                          onClick={() => setFormData({ ...formData, correctOptionId: opt.id })}
                          className={`w-7 h-7 rounded-lg font-extrabold text-xs flex items-center justify-center shrink-0 transition-all ${
                            isSelectedKey
                              ? 'bg-emerald-600 text-white ring-2 ring-emerald-400 ring-offset-1'
                              : 'bg-slate-200 text-slate-700 hover:bg-slate-300'
                          }`}
                          title={`Click to set Option ${opt.id} as Correct Answer`}
                        >
                          {opt.id}
                        </button>
                        <input
                          type="text"
                          placeholder={`Option ${opt.id} text...`}
                          value={opt.text}
                          onChange={(e) => handleOptionTextChange(opt.id, e.target.value)}
                          required
                          className="flex-1 h-9 px-3 text-xs bg-white border border-slate-200 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-indigo-500 font-medium text-slate-800"
                        />
                        <button
                          type="button"
                          onClick={() => setFormData({ ...formData, correctOptionId: opt.id })}
                          className={`px-3 py-1.5 rounded-lg text-[11px] font-bold shrink-0 transition-all ${
                            isSelectedKey
                              ? 'bg-emerald-600 text-white'
                              : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-100'
                          }`}
                        >
                          {isSelectedKey ? '✓ Correct Key' : 'Set as Key'}
                        </button>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Marks & Negative Marks */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">
                    Positive Marks (+)
                  </label>
                  <input
                    type="number"
                    step="0.5"
                    min={0.5}
                    value={formData.marks}
                    onChange={(e) =>
                      setFormData({ ...formData, marks: Number(e.target.value) || 1 })
                    }
                    className="w-full h-10 px-3 text-xs bg-slate-50 border border-slate-200 rounded-xl font-bold text-slate-800"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">
                    Negative Penalty (-)
                  </label>
                  <input
                    type="number"
                    step="0.05"
                    min={0}
                    value={formData.negativeMarks}
                    onChange={(e) =>
                      setFormData({ ...formData, negativeMarks: Number(e.target.value) || 0 })
                    }
                    className="w-full h-10 px-3 text-xs bg-slate-50 border border-slate-200 rounded-xl font-bold text-slate-800"
                  />
                </div>
              </div>

              {/* Rationale */}
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5">
                  Clinical Rationale / Explanation
                </label>
                <textarea
                  rows={3}
                  placeholder="Detailed rationale for why this option is correct..."
                  value={formData.explanation}
                  onChange={(e) => setFormData({ ...formData, explanation: e.target.value })}
                  className="w-full p-3 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-indigo-500 font-medium text-slate-800"
                />
              </div>

              <div className="p-4 bg-slate-50 rounded-2xl flex items-center justify-end gap-3 pt-4 border-t border-slate-100">
                <Button variant="outline" type="button" onClick={() => setIsModalOpen(false)}>
                  Cancel
                </Button>
                <Button type="submit" className="bg-indigo-600 hover:bg-indigo-700 text-white font-bold">
                  {editingQuestion ? 'Save Changes' : 'Save Question'}
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Question Confirmation */}
      <ConfirmationModal
        isOpen={Boolean(deletingQuestion)}
        title="Delete Question"
        message="Are you sure you want to delete this MCQ question from the unit test?"
        confirmLabel="Delete Question"
        isDestructive
        isLoading={isDeleting}
        onConfirm={confirmDelete}
        onCancel={() => setDeletingQuestion(null)}
      />
    </div>
  );
}

export default AdminUnitTestQuestionsPage;
