/**
 * Axon Nursing Academy - Admin Branding & Media Assets Controller
 * Manage and upload Academy Logo, Footer Branding Image, Favicon, and Site Identity.
 */
import React, { useState, useEffect } from 'react';
import {
  Image,
  Globe,
  Layout,
  Save,
  CheckCircle2,
  AlertCircle,
  RefreshCw,
  Sparkles,
  Stethoscope,
  Eye,
  ExternalLink,
  ShieldCheck,
  RotateCcw,
} from 'lucide-react';
import { AdminPageHeader } from '@/src/components/admin/AdminPageHeader';
import { ConfirmationModal } from '@/src/components/admin/ConfirmationModal';
import { ImageUploadField } from '@/src/components/common/ImageUploadField';
import { useSiteSettings } from '@/src/contexts/SiteSettingsContext';
import { SITE_CONFIG } from '@/src/config/site.config';
import { ROUTES } from '@/src/config/routes.config';
import { Link } from 'react-router-dom';

export default function AdminBrandingPage() {
  const { settings, updateSettings, isSaving } = useSiteSettings();

  const [formData, setFormData] = useState({
    logoUrl: settings.logoUrl || '',
    footerLogoUrl: settings.footerLogoUrl || '',
    faviconUrl: settings.faviconUrl || '',
    siteName: settings.siteName || SITE_CONFIG.name,
    shortName: settings.shortName || SITE_CONFIG.shortName,
    tagline: settings.tagline || SITE_CONFIG.tagline,
    footerText: settings.footerText || SITE_CONFIG.description,
    supportEmail: settings.supportEmail || SITE_CONFIG.supportEmail,
    supportPhone: settings.supportPhone || SITE_CONFIG.supportPhone,
  });

  const [savedSuccess, setSavedSuccess] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [showResetModal, setShowResetModal] = useState(false);

  // Sync state when remote settings finish loading
  useEffect(() => {
    setFormData({
      logoUrl: settings.logoUrl || '',
      footerLogoUrl: settings.footerLogoUrl || '',
      faviconUrl: settings.faviconUrl || '',
      siteName: settings.siteName || SITE_CONFIG.name,
      shortName: settings.shortName || SITE_CONFIG.shortName,
      tagline: settings.tagline || SITE_CONFIG.tagline,
      footerText: settings.footerText || SITE_CONFIG.description,
      supportEmail: settings.supportEmail || SITE_CONFIG.supportEmail,
      supportPhone: settings.supportPhone || SITE_CONFIG.supportPhone,
    });
  }, [settings]);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);
    setSavedSuccess(false);

    try {
      await updateSettings(formData);
      setSavedSuccess(true);
      setTimeout(() => setSavedSuccess(false), 4000);
    } catch (err: any) {
      console.error('Error saving branding settings:', err);
      setErrorMessage(err.message || 'Failed to save branding settings.');
    }
  };

  const handleResetToDefaults = () => {
    setShowResetModal(true);
  };

  const confirmResetToDefaults = () => {
    setFormData({
      logoUrl: '',
      footerLogoUrl: '',
      faviconUrl: '',
      siteName: SITE_CONFIG.name,
      shortName: SITE_CONFIG.shortName,
      tagline: SITE_CONFIG.tagline,
      footerText: SITE_CONFIG.description,
      supportEmail: SITE_CONFIG.supportEmail,
      supportPhone: SITE_CONFIG.supportPhone,
    });
    setShowResetModal(false);
  };

  return (
    <div className="space-y-6 max-w-6xl mx-auto pb-16">
      {/* Header */}
      <AdminPageHeader
        title="Site Logo, Footer & Favicon"
        description="Upload your official Academy Logo, Footer banner image, and Browser tab Favicon."
        breadcrumbs={[
          { label: 'Admin CMS', path: ROUTES.ADMIN.DASHBOARD },
          { label: 'Logo, Footer & Favicon' },
        ]}
        actions={
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleResetToDefaults}
              className="px-3 py-2 rounded-xl border border-slate-200 text-slate-600 hover:bg-slate-100 text-xs font-bold transition-colors flex items-center gap-1.5 cursor-pointer"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              Reset Defaults
            </button>
            <button
              type="button"
              onClick={handleSave}
              disabled={isSaving}
              className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs sm:text-sm font-extrabold shadow-sm hover:shadow transition-all active:scale-95 flex items-center gap-2 cursor-pointer disabled:opacity-70"
            >
              {isSaving ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  Saving...
                </>
              ) : (
                <>
                  <Save className="w-4 h-4" />
                  Save Changes
                </>
              )}
            </button>
          </div>
        }
      />

      {/* Success Notification */}
      {savedSuccess && (
        <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200 flex items-center gap-3 text-emerald-800 animate-in fade-in slide-in-from-top-2 duration-200">
          <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
          <div>
            <p className="font-bold text-sm">Branding updated successfully!</p>
            <p className="text-xs text-emerald-700">
              Your Logo, Footer image, and Favicon are now active across all portal pages and headers.
            </p>
          </div>
        </div>
      )}

      {/* Error Notification */}
      {errorMessage && (
        <div className="p-4 rounded-xl bg-rose-50 border border-rose-200 flex items-center gap-3 text-rose-800">
          <AlertCircle className="w-5 h-5 text-rose-600 shrink-0" />
          <p className="text-xs sm:text-sm font-semibold">{errorMessage}</p>
        </div>
      )}

      <form onSubmit={handleSave} className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Columns: Media Upload Controls */}
        <div className="lg:col-span-2 space-y-6">
          {/* Card 1: Main Header Logo */}
          <div className="bg-white rounded-2xl border border-slate-200/80 p-5 sm:p-6 shadow-xs space-y-4">
            <div className="flex items-center gap-3 pb-2 border-b border-slate-100">
              <div className="w-9 h-9 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center font-bold">
                <Image className="w-5 h-5" />
              </div>
              <div>
                <h2 className="font-extrabold text-base text-slate-900">
                  1. Official Academy Logo
                </h2>
                <p className="text-xs text-slate-500">
                  Appears in public header, student navigation, and admin sidebar.
                </p>
              </div>
            </div>

            <ImageUploadField
              label="Logo Photo / Image"
              value={formData.logoUrl}
              onChange={(url) => setFormData({ ...formData, logoUrl: url })}
              aspectRatio="auto"
              folder="branding"
              brandingType="logo"
              placeholder="Upload Academy Logo (PNG with transparent background recommended)"
              helperText="Recommended: High-resolution PNG or SVG with transparent background (height 80–120px)."
            />

            {/* Live Header Logo Preview */}
            <div className="pt-2">
              <label className="text-xs font-bold text-slate-600 block mb-1.5">
                Live Header Preview:
              </label>
              <div className="bg-white border border-slate-200 rounded-xl p-3 flex items-center gap-3 shadow-xs">
                {formData.logoUrl ? (
                  <img
                    src={formData.logoUrl}
                    alt="Logo Preview"
                    className="h-10 w-auto max-w-[180px] object-contain"
                  />
                ) : (
                  <div className="flex items-center gap-2 text-blue-600">
                    <div className="w-9 h-9 rounded-xl bg-blue-600 text-white flex items-center justify-center">
                      <Stethoscope className="w-5 h-5" />
                    </div>
                    <span className="font-extrabold text-slate-900 text-base">
                      {formData.shortName || SITE_CONFIG.shortName}
                    </span>
                  </div>
                )}
                <div className="text-xs text-slate-400 ml-auto hidden sm:block">
                  Navbar preview
                </div>
              </div>
            </div>
          </div>

          {/* Card 2: Footer Logo & Branding Image */}
          <div className="bg-white rounded-2xl border border-slate-200/80 p-5 sm:p-6 shadow-xs space-y-4">
            <div className="flex items-center gap-3 pb-2 border-b border-slate-100">
              <div className="w-9 h-9 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center font-bold">
                <Layout className="w-5 h-5" />
              </div>
              <div>
                <h2 className="font-extrabold text-base text-slate-900">
                  2. Footer Logo / Brand Photo
                </h2>
                <p className="text-xs text-slate-500">
                  Displayed in the dark footer on public landing and portal pages.
                </p>
              </div>
            </div>

            <ImageUploadField
              label="Footer Logo Photo"
              value={formData.footerLogoUrl}
              onChange={(url) => setFormData({ ...formData, footerLogoUrl: url })}
              aspectRatio="auto"
              folder="branding"
              brandingType="footer"
              placeholder="Upload footer logo or brand badge"
              helperText="If empty, the Academy Header Logo will automatically be used in the footer."
              previewBg="dark"
            />

            {/* Live Footer Preview */}
            <div className="pt-2">
              <label className="text-xs font-bold text-slate-600 block mb-1.5">
                Live Dark Footer Preview:
              </label>
              <div className="bg-slate-900 text-white border border-slate-800 rounded-xl p-4 flex items-center gap-3 shadow-xs">
                {formData.footerLogoUrl || formData.logoUrl ? (
                  <img
                    src={formData.footerLogoUrl || formData.logoUrl}
                    alt="Footer Preview"
                    className="h-9 w-auto max-w-[160px] object-contain"
                  />
                ) : (
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-lg bg-blue-600 text-white flex items-center justify-center">
                      <Stethoscope className="w-4 h-4" />
                    </div>
                    <span className="font-bold text-white text-sm">
                      {formData.siteName || SITE_CONFIG.name}
                    </span>
                  </div>
                )}
                <span className="text-[11px] text-slate-400 ml-auto hidden sm:block">
                  Dark background contrast test
                </span>
              </div>
            </div>
          </div>

          {/* Card 3: Browser Favicon */}
          <div className="bg-white rounded-2xl border border-slate-200/80 p-5 sm:p-6 shadow-xs space-y-4">
            <div className="flex items-center gap-3 pb-2 border-b border-slate-100">
              <div className="w-9 h-9 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center font-bold">
                <Globe className="w-5 h-5" />
              </div>
              <div>
                <h2 className="font-extrabold text-base text-slate-900">
                  3. Website Browser Tab Favicon
                </h2>
                <p className="text-xs text-slate-500">
                  The small icon shown in browser tabs, bookmark bars, and mobile shortcuts.
                </p>
              </div>
            </div>

            <ImageUploadField
              label="Favicon Photo (.ico, .png, .svg)"
              value={formData.faviconUrl}
              onChange={(url) => setFormData({ ...formData, faviconUrl: url })}
              aspectRatio="square"
              folder="branding"
              brandingType="favicon"
              placeholder="Upload favicon photo (square format recommended)"
              helperText="Recommended: 32x32px or 64x64px square icon. Updates browser tab immediately!"
            />

            {/* Live Browser Tab Mockup */}
            <div className="pt-2">
              <label className="text-xs font-bold text-slate-600 block mb-1.5">
                Browser Tab Simulation:
              </label>
              <div className="bg-slate-200/90 rounded-t-xl p-2 flex items-center max-w-sm">
                <div className="bg-white rounded-lg px-3 py-1.5 flex items-center gap-2 shadow-xs text-xs font-medium text-slate-800 border border-slate-300/60 max-w-[240px] truncate">
                  {formData.faviconUrl ? (
                    <img
                      src={formData.faviconUrl}
                      alt="Favicon"
                      className="w-4 h-4 rounded-xs shrink-0 object-contain"
                    />
                  ) : (
                    <Stethoscope className="w-4 h-4 text-blue-600 shrink-0" />
                  )}
                  <span className="truncate text-[11px] font-semibold">
                    {formData.siteName}
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Right 1 Column: Academy Identity & Text Details */}
        <div className="space-y-6">
          <div className="bg-white rounded-2xl border border-slate-200/80 p-5 sm:p-6 shadow-xs space-y-4">
            <h3 className="font-extrabold text-slate-900 text-sm flex items-center gap-2 pb-2 border-b border-slate-100">
              <Sparkles className="w-4 h-4 text-blue-600" />
              Academy Details & Text
            </h3>

            {/* Academy Full Name */}
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-700">Academy Full Name</label>
              <input
                type="text"
                value={formData.siteName}
                onChange={(e) => setFormData({ ...formData, siteName: e.target.value })}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs sm:text-sm font-medium focus:outline-hidden focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
              />
            </div>

            {/* Short Name */}
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-700">Navbar Short Name</label>
              <input
                type="text"
                value={formData.shortName}
                onChange={(e) => setFormData({ ...formData, shortName: e.target.value })}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs sm:text-sm font-medium focus:outline-hidden focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
              />
            </div>

            {/* Tagline */}
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-700">Academy Tagline</label>
              <input
                type="text"
                value={formData.tagline}
                onChange={(e) => setFormData({ ...formData, tagline: e.target.value })}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs sm:text-sm font-medium focus:outline-hidden focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
              />
            </div>

            {/* Footer Text */}
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-700">Footer Description</label>
              <textarea
                rows={3}
                value={formData.footerText}
                onChange={(e) => setFormData({ ...formData, footerText: e.target.value })}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs sm:text-sm font-medium focus:outline-hidden focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
              />
            </div>

            {/* Support Email & Phone */}
            <div className="space-y-3 pt-2">
              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-700">Support Email</label>
                <input
                  type="email"
                  value={formData.supportEmail}
                  onChange={(e) => setFormData({ ...formData, supportEmail: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs font-medium"
                />
              </div>
              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-700">Support Phone</label>
                <input
                  type="text"
                  value={formData.supportPhone}
                  onChange={(e) => setFormData({ ...formData, supportPhone: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs font-medium"
                />
              </div>
            </div>

            {/* Save Button */}
            <div className="pt-3">
              <button
                type="submit"
                disabled={isSaving}
                className="w-full py-2.5 px-4 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-extrabold text-sm shadow-xs transition-all active:scale-95 flex items-center justify-center gap-2 cursor-pointer disabled:opacity-70"
              >
                {isSaving ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    Saving Branding...
                  </>
                ) : (
                  <>
                    <Save className="w-4 h-4" />
                    Save All Changes
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Quick Info Box */}
          <div className="p-4 rounded-2xl bg-blue-50/70 border border-blue-100 text-xs text-slate-600 space-y-2">
            <div className="flex items-center gap-2 font-bold text-blue-900">
              <ShieldCheck className="w-4 h-4 text-blue-600 shrink-0" />
              <span>Instant Real-Time Updates</span>
            </div>
            <p className="leading-relaxed">
              When you save changes here, all student portals, landing pages, headers, footers, and browser favicons are updated immediately.
            </p>
          </div>
        </div>
      </form>

      <ConfirmationModal
        isOpen={showResetModal}
        title="Reset Branding to Defaults"
        message="Are you sure you want to reset the Academy logo, footer branding, and favicon to their default settings? Custom uploaded assets will be removed."
        confirmLabel="Reset Defaults"
        cancelLabel="Cancel"
        isDestructive={true}
        onConfirm={confirmResetToDefaults}
        onCancel={() => setShowResetModal(false)}
      />
    </div>
  );
}
