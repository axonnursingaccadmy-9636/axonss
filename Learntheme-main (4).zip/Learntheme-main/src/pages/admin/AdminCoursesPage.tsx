/**
 * Axon Nursing Academy - Admin Courses Management Shell
 */
import React from 'react';
import { BookMarked, Plus, Search, Filter } from 'lucide-react';
import { DEMO_FEATURED_COURSES } from '@/src/data/demoData';
import { formatCurrency } from '@/src/lib/utils/formatters';
import { Badge } from '@/src/components/ui/Badge';
import { Button } from '@/src/components/ui/Button';

export function AdminCoursesPage() {
  return (
    <div className="space-y-6 animate-in fade-in duration-150">
      <div className="bg-white rounded-2xl border border-slate-200/80 p-5 shadow-xs flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-lg sm:text-xl font-extrabold text-slate-900">
            Course & Batch Management
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Create, edit, and organize subjects, chapters, video links, and PDF attachments
          </p>
        </div>
        <Button variant="primary" size="sm" leftIcon={<Plus className="w-4 h-4" />}>
          Add New Course
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {DEMO_FEATURED_COURSES.map((course) => (
          <div key={course.id} className="bg-white rounded-2xl border border-slate-200/80 p-4 shadow-xs">
            <img src={course.thumbnailUrl} alt="" className="w-full h-36 rounded-xl object-cover mb-3" />
            <Badge variant="blue" size="sm" className="mb-2">{course.category}</Badge>
            <h3 className="font-bold text-sm text-slate-900 line-clamp-1">{course.title}</h3>
            <p className="text-xs text-slate-500 line-clamp-2 mt-1">{course.subtitle}</p>

            <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
              <span className="font-bold text-blue-700">{formatCurrency(course.discountedPrice)}</span>
              <div className="flex gap-1.5">
                <Button variant="outline" size="sm">Edit</Button>
                <Button variant="primary" size="sm">Curriculum</Button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
export default AdminCoursesPage;
