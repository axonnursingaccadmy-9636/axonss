/**
 * Axon Nursing Academy - Admin Audit Trail CMS
 * Comprehensive immutable logs of administrative operations in Firestore.
 */
import React, { useState, useEffect } from 'react';
import {
  History,
  Search,
  Filter,
  RefreshCw,
  Eye,
  ShieldCheck,
  Calendar,
  User,
  X,
} from 'lucide-react';
import { ROUTES } from '@/src/config/routes.config';
import { Badge } from '@/src/components/ui/Badge';
import { Button } from '@/src/components/ui/Button';
import { AdminPageHeader } from '@/src/components/admin/AdminPageHeader';
import { getRecentAuditLogs } from '@/src/services/firebase/auditService';
import { AuditLog } from '@/src/types/audit.types';

export function AdminAuditLogsPage() {
  const [logs, setLogs] = useState<AuditLog[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [resourceFilter, setResourceFilter] = useState<string>('all');
  const [selectedLog, setSelectedLog] = useState<AuditLog | null>(null);

  const fetchLogs = async () => {
    try {
      const data = await getRecentAuditLogs(50);
      setLogs(data);
    } catch (err) {
      console.error('[AdminAuditLogsPage] Error loading audit logs:', err);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    fetchLogs();
  }, []);

  const handleRefresh = () => {
    setRefreshing(true);
    fetchLogs();
  };

  const getActionBadgeVariant = (action: string) => {
    if (action.includes('CREATED') || action.includes('SEEDED')) return 'emerald';
    if (action.includes('UPDATED') || action.includes('PUBLISHED')) return 'blue';
    if (action.includes('DELETED')) return 'rose';
    return 'slate';
  };

  const filteredLogs = logs.filter((l) => {
    const matchesSearch =
      l.action.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (l.resourceTitle && l.resourceTitle.toLowerCase().includes(searchQuery.toLowerCase())) ||
      (l.actorEmail && l.actorEmail.toLowerCase().includes(searchQuery.toLowerCase())) ||
      l.resourceId.toLowerCase().includes(searchQuery.toLowerCase());

    if (!matchesSearch) return false;
    if (resourceFilter !== 'all' && l.resourceType !== resourceFilter) return false;
    return true;
  });

  return (
    <div className="space-y-6 font-['Plus_Jakarta_Sans',sans-serif]">
      <AdminPageHeader
        title="Administrative Audit Trail"
        description="Tamper-evident activity logs recording course modifications, publishing actions, and data operations."
        breadcrumbs={[{ label: 'Admin', path: ROUTES.ADMIN.DASHBOARD }, { label: 'Audit Trail' }]}
        actions={
          <Button
            variant="outline"
            size="sm"
            onClick={handleRefresh}
            isLoading={refreshing}
            leftIcon={<RefreshCw className="w-3.5 h-3.5" />}
          >
            Refresh Logs
          </Button>
        }
      />

      {/* Filter and Search Bar */}
      <div className="bg-white rounded-2xl border border-slate-200/80 p-4 shadow-xs flex flex-col md:flex-row items-center justify-between gap-3">
        <div className="flex items-center gap-1.5 overflow-x-auto w-full md:w-auto">
          {['all', 'batch', 'subject', 'chapter', 'class', 'database'].map((res) => (
            <button
              key={res}
              type="button"
              onClick={() => setResourceFilter(res)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold capitalize transition-all select-none ${
                resourceFilter === res
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              {res}
            </button>
          ))}
        </div>

        <div className="relative w-full md:w-72">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search by actor, action, or ID..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-4 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
          />
        </div>
      </div>

      {/* Audit Log Table */}
      <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs min-w-[650px]">
            <thead className="bg-slate-50/80 text-slate-500 uppercase text-[10px] font-bold border-b border-slate-100">
              <tr>
                <th className="px-5 py-3.5">Timestamp</th>
                <th className="px-5 py-3.5">Action</th>
                <th className="px-5 py-3.5">Resource Target</th>
                <th className="px-5 py-3.5">Administrator</th>
                <th className="px-5 py-3.5 text-right">Details</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-medium text-slate-700">
              {loading ? (
                <tr>
                  <td colSpan={5} className="px-5 py-12 text-center text-slate-400">
                    <RefreshCw className="w-5 h-5 animate-spin mx-auto mb-2 text-blue-600" />
                    Loading audit stream from Firestore...
                  </td>
                </tr>
              ) : filteredLogs.length === 0 ? (
                <tr>
                  <td colSpan={5} className="px-5 py-12 text-center text-slate-400">
                    No matching audit records found.
                  </td>
                </tr>
              ) : (
                filteredLogs.map((log) => (
                  <tr key={log.id} className="hover:bg-slate-50/70 transition-colors">
                    <td className="px-5 py-3.5 text-slate-400 font-mono text-[11px]">
                      {log.timestamp ? 'Live' : 'Recent'}
                    </td>
                    <td className="px-5 py-3.5">
                      <Badge variant={getActionBadgeVariant(log.action)} size="sm">
                        {log.action}
                      </Badge>
                    </td>
                    <td className="px-5 py-3.5">
                      <div>
                        <span className="font-extrabold text-slate-900 block text-xs">
                          {log.resourceTitle || log.resourceId}
                        </span>
                        <span className="text-[10px] text-slate-400 font-mono uppercase">
                          {log.resourceType} • {log.resourceId}
                        </span>
                      </div>
                    </td>
                    <td className="px-5 py-3.5 text-slate-600">
                      <div className="flex items-center gap-1.5">
                        <User className="w-3.5 h-3.5 text-slate-400" />
                        <span className="font-semibold">{log.actorEmail}</span>
                      </div>
                    </td>
                    <td className="px-5 py-3.5 text-right">
                      <button
                        type="button"
                        onClick={() => setSelectedLog(log)}
                        className="p-1.5 rounded-lg border border-slate-200 text-slate-600 hover:bg-slate-100 transition-colors"
                        title="View payload"
                      >
                        <Eye className="w-3.5 h-3.5" />
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Details Inspector Modal */}
      {selectedLog && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div
            className="fixed inset-0 bg-slate-900/70"
            onClick={() => setSelectedLog(null)}
          />
          <div className="relative bg-white rounded-2xl border border-slate-200 shadow-2xl max-w-lg w-full p-6 space-y-4 animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h3 className="text-base font-extrabold text-slate-900">
                Audit Record Inspector
              </h3>
              <button
                type="button"
                onClick={() => setSelectedLog(null)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-2 text-xs">
              <div className="grid grid-cols-2 gap-2 bg-slate-50 p-3 rounded-xl border border-slate-200/60">
                <div>
                  <span className="text-slate-400 block text-[10px]">Action</span>
                  <span className="font-bold text-slate-900">{selectedLog.action}</span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[10px]">Resource Type</span>
                  <span className="font-bold text-slate-900 uppercase">
                    {selectedLog.resourceType}
                  </span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[10px]">Actor UID</span>
                  <span className="font-mono text-slate-600 text-[10px] truncate block">
                    {selectedLog.actorUid}
                  </span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[10px]">Resource ID</span>
                  <span className="font-mono text-slate-600 text-[10px] truncate block">
                    {selectedLog.resourceId}
                  </span>
                </div>
              </div>

              <div>
                <span className="font-bold text-slate-700 block mb-1">Payload Details:</span>
                <pre className="p-3 bg-slate-900 text-slate-200 rounded-xl font-mono text-[11px] overflow-x-auto max-h-48">
                  {JSON.stringify(selectedLog.details, null, 2)}
                </pre>
              </div>
            </div>

            <div className="flex justify-end pt-3 border-t border-slate-100">
              <Button variant="outline" size="sm" onClick={() => setSelectedLog(null)}>
                Close
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default AdminAuditLogsPage;
