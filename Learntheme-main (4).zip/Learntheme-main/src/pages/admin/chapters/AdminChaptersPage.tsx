/**
 * Axon Nursing Academy - Admin Chapters CMS
 * Manage unit chapters nested inside nursing subjects.
 */
import React, { useState, useEffect } from 'react';
import { useSearchParams, Link } from 'react-router-dom';
import {
  FolderTree,
  Plus,
  Search,
  Edit2,
  Trash2,
  Eye,
  EyeOff,
  Video,
  BookOpen,
  RefreshCw,
  X,
  Layers,
} from 'lucide-react';
import { ROUTES } from '@/src/config/routes.config';
import { Badge } from '@/src/components/ui/Badge';
import { Button } from '@/src/components/ui/Button';
import { AdminPageHeader } from '@/src/components/admin/AdminPageHeader';
import { PublishStatusBadge } from '@/src/components/admin/StatusBadge';
import { ConfirmationModal } from '@/src/components/admin/ConfirmationModal';
import { getAllBatchesAdmin } from '@/src/services/firebase/adminBatchService';
import { getAllSubjectsAdmin, getSubjectsForBatchAdmin } from '@/src/services/firebase/adminSubjectService';
import {
  getAllChaptersAdmin,
  getChaptersForSubjectAdmin,
  createChapter,
  updateChapter,
  deleteChapter,
  toggleChapterPublish,
  ChapterFormData,
} from '@/src/services/firebase/adminChapterService';
import { Chapter, Subject, Batch } from '@/src/types/lms.types';
import { useAuth } from '@/src/contexts/AuthContext';

export function AdminChaptersPage() {
  const { currentUser } = useAuth();
  const [searchParams, setSearchParams] = useSearchParams();
  const selectedBatchId = searchParams.get('batchId') || '';
  const selectedSubjectId = searchParams.get('subjectId') || '';

  const [batches, setBatches] = useState<Batch[]>([]);
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [chapters, setChapters] = useState<Chapter[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  // Modal State
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingChapter, setEditingChapter] = useState<Chapter | null>(null);
  const [formData, setFormData] = useState<ChapterFormData>({
    batchId: '',
    subjectId: '',
    name: '',
    description: '',
    order: 1,
    isPublished: true,
  });
  const [submitting, setSubmitting] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);

  // Delete State
  const [deleteTarget, setDeleteTarget] = useState<Chapter | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);

  const loadData = async () => {
    try {
      const bList = await getAllBatchesAdmin();
      setBatches(bList);

      const sList = selectedBatchId
        ? await getSubjectsForBatchAdmin(selectedBatchId)
        : await getAllSubjectsAdmin();
      setSubjects(sList);

      let cList: Chapter[] = [];
      if (selectedSubjectId) {
        cList = await getChaptersForSubjectAdmin(selectedSubjectId);
      } else {
        cList = await getAllChaptersAdmin();
        if (selectedBatchId) {
          cList = cList.filter((c) => c.batchId === selectedBatchId);
        }
      }
      setChapters(cList);
    } catch (err) {
      console.error('[AdminChaptersPage] Error loading data:', err);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    loadData();
  }, [selectedBatchId, selectedSubjectId]);

  const handleBatchChange = (batchId: string) => {
    setSearchParams(batchId ? { batchId } : {});
  };

  const handleSubjectChange = (subjectId: string) => {
    const params: Record<string, string> = {};
    if (selectedBatchId) params.batchId = selectedBatchId;
    if (subjectId) params.subjectId = subjectId;
    setSearchParams(params);
  };

  const handleOpenCreate = () => {
    setEditingChapter(null);
    const defaultBatch = selectedBatchId || batches[0]?.id || '';
    const defaultSubject = selectedSubjectId || subjects[0]?.id || '';

    setFormData({
      batchId: defaultBatch,
      subjectId: defaultSubject,
      name: '',
      description: '',
      order: chapters.length + 1,
      isPublished: true,
    });
    setFormError(null);
    setIsModalOpen(true);
  };

  const handleOpenEdit = (chapter: Chapter) => {
    setEditingChapter(chapter);
    setFormData({
      batchId: chapter.batchId,
      subjectId: chapter.subjectId,
      name: chapter.name,
      description: chapter.description,
      order: chapter.order,
      isPublished: chapter.isPublished,
    });
    setFormError(null);
    setIsModalOpen(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) return;
    if (!formData.name.trim()) {
      setFormError('Chapter name is required.');
      return;
    }
    if (!formData.subjectId) {
      setFormError('Please select a parent subject.');
      return;
    }

    setSubmitting(true);
    setFormError(null);

    try {
      const actorUid = currentUser?.uid || 'admin';
      const actorEmail = currentUser?.email || undefined;

      if (editingChapter) {
        const chapterId = editingChapter.id;
        const updatedChapter: Chapter = {
          ...editingChapter,
          ...formData,
          updatedAt: new Date().toISOString(),
        };

        setChapters((prev) =>
          prev.map((c) => (c.id === chapterId ? updatedChapter : c))
        );
        setIsModalOpen(false);

        await updateChapter(
          chapterId,
          formData,
          actorUid,
          actorEmail
        );
        loadData();
      } else {
        const newChap = await createChapter(formData, actorUid, actorEmail);
        setChapters((prev) => [...prev.filter((c) => c.id !== newChap.id), newChap]);
        setIsModalOpen(false);
        loadData();
      }
    } catch (err: any) {
      console.error('Error saving chapter:', err);
      setFormError(err?.message || 'Failed to save chapter.');
      loadData();
    } finally {
      setSubmitting(false);
    }
  };

  const handleTogglePublish = async (chapter: Chapter) => {
    const actorUid = currentUser?.uid || 'admin';
    const actorEmail = currentUser?.email || undefined;
    const newStatus = !chapter.isPublished;
    // Instant UI update
    setChapters((prev) =>
      prev.map((c) => (c.id === chapter.id ? { ...c, isPublished: newStatus } : c))
    );

    try {
      await toggleChapterPublish(
        chapter.id,
        newStatus,
        chapter.name,
        actorUid,
        actorEmail
      );
    } catch (err) {
      console.error('Failed to toggle chapter:', err);
      setChapters((prev) =>
        prev.map((c) => (c.id === chapter.id ? { ...c, isPublished: chapter.isPublished } : c))
      );
    }
  };

  const handleConfirmDelete = async () => {
    if (!deleteTarget) return;
    const targetId = deleteTarget.id;
    const targetName = deleteTarget.name;
    const actorUid = currentUser?.uid || 'admin';
    const actorEmail = currentUser?.email || undefined;

    // Instant UI removal
    setChapters((prev) => prev.filter((c) => c.id !== targetId));
    setDeleteTarget(null);

    setIsDeleting(true);
    try {
      await deleteChapter(
        targetId,
        targetName,
        actorUid,
        actorEmail
      );
    } catch (err) {
      console.error('Failed to delete chapter:', err);
      loadData();
    } finally {
      setIsDeleting(false);
    }
  };

  const getSubjectName = (subId: string) => {
    return subjects.find((s) => s.id === subId)?.name || subId;
  };

  const filteredChapters = chapters.filter((c) => {
    return (
      c.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      c.description.toLowerCase().includes(searchQuery.toLowerCase())
    );
  });

  return (
    <div className="space-y-6 font-['Plus_Jakarta_Sans',sans-serif]">
      <AdminPageHeader
        title="Chapters & Units"
        description="Structure nursing subjects into comprehensive learning units and chapters."
        breadcrumbs={[
          { label: 'Admin', path: ROUTES.ADMIN.DASHBOARD },
          { label: 'Subjects', path: ROUTES.ADMIN.SUBJECTS },
          { label: 'Chapters' },
        ]}
        actions={
          <>
            <Button
              variant="outline"
              size="sm"
              onClick={() => {
                setRefreshing(true);
                loadData();
              }}
              isLoading={refreshing}
              leftIcon={<RefreshCw className="w-3.5 h-3.5" />}
            >
              Refresh
            </Button>
            <Button
              variant="primary"
              size="sm"
              onClick={handleOpenCreate}
              leftIcon={<Plus className="w-4 h-4" />}
            >
              Add Chapter
            </Button>
          </>
        }
      />

      {/* Cascading Filter & Search Bar */}
      <div className="bg-white rounded-2xl border border-slate-200/80 p-3.5 sm:p-4 shadow-xs flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
        <div className="flex items-center gap-2.5 w-full md:w-auto flex-wrap">
          {/* Batch Selector */}
          <div className="flex items-center gap-2 w-full sm:w-auto">
            <span className="text-xs font-bold text-slate-500 whitespace-nowrap">Batch:</span>
            <select
              value={selectedBatchId}
              onChange={(e) => handleBatchChange(e.target.value)}
              className="flex-1 sm:flex-none px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-800 max-w-full sm:max-w-xs"
            >
              <option value="">All Batches</option>
              {batches.map((b) => (
                <option key={b.id} value={b.id}>
                  {b.title}
                </option>
              ))}
            </select>
          </div>

          {/* Subject Selector */}
          <div className="flex items-center gap-2 w-full sm:w-auto">
            <span className="text-xs font-bold text-slate-500 whitespace-nowrap">Subject:</span>
            <select
              value={selectedSubjectId}
              onChange={(e) => handleSubjectChange(e.target.value)}
              className="flex-1 sm:flex-none px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-800 max-w-full sm:max-w-xs"
            >
              <option value="">All Subjects</option>
              {subjects.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name}
                </option>
              ))}
            </select>
          </div>
        </div>

        <div className="relative w-full md:w-72">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search chapters..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-4 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
          />
        </div>
      </div>

      {/* Chapters Table */}
      <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs min-w-[620px]">
            <thead className="bg-slate-50/80 text-slate-500 uppercase text-[10px] font-bold border-b border-slate-100">
              <tr>
                <th className="px-5 py-3.5">Order</th>
                <th className="px-5 py-3.5">Chapter / Unit Title</th>
                <th className="px-5 py-3.5">Parent Subject</th>
                <th className="px-5 py-3.5">Status</th>
                <th className="px-5 py-3.5 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-medium text-slate-700">
              {loading ? (
                <tr>
                  <td colSpan={5} className="px-5 py-12 text-center text-slate-400">
                    <RefreshCw className="w-5 h-5 animate-spin mx-auto mb-2 text-blue-600" />
                    Loading chapters...
                  </td>
                </tr>
              ) : filteredChapters.length === 0 ? (
                <tr>
                  <td colSpan={5} className="px-5 py-12 text-center text-slate-400">
                    No chapters found. Click "Add Chapter" to create one.
                  </td>
                </tr>
              ) : (
                filteredChapters.map((chap) => (
                  <tr key={chap.id} className="hover:bg-slate-50/70 transition-colors">
                    <td className="px-5 py-4 font-bold text-slate-400 font-mono">
                      #{chap.order}
                    </td>
                    <td className="px-5 py-4">
                      <div>
                        <span className="font-extrabold text-slate-900 block text-sm">
                          {chap.name}
                        </span>
                        <span className="text-[11px] text-slate-400 line-clamp-1 max-w-sm">
                          {chap.description || 'No description provided.'}
                        </span>
                      </div>
                    </td>
                    <td className="px-5 py-4">
                      <Badge variant="emerald" size="sm">
                        {getSubjectName(chap.subjectId)}
                      </Badge>
                    </td>
                    <td className="px-5 py-4">
                      <PublishStatusBadge isPublished={chap.isPublished} />
                    </td>
                    <td className="px-5 py-4 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          type="button"
                          onClick={() => handleTogglePublish(chap)}
                          title={chap.isPublished ? 'Unpublish' : 'Publish'}
                          className={`p-1.5 rounded-lg border transition-colors ${
                            chap.isPublished
                              ? 'border-emerald-200 text-emerald-600 hover:bg-emerald-50'
                              : 'border-slate-200 text-slate-400 hover:bg-slate-100'
                          }`}
                        >
                          {chap.isPublished ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
                        </button>

                        <Link
                          to={`/admin/classes?chapterId=${chap.id}&subjectId=${chap.subjectId}&batchId=${chap.batchId}`}
                        >
                          <Button
                            variant="outline"
                            size="sm"
                            leftIcon={<BookOpen className="w-3 h-3 text-blue-600" />}
                          >
                            Classes
                          </Button>
                        </Link>

                        <Link
                          to={`/admin/video-classes?chapterId=${chap.id}&subjectId=${chap.subjectId}&batchId=${chap.batchId}`}
                        >
                          <Button
                            variant="outline"
                            size="sm"
                            leftIcon={<Video className="w-3 h-3 text-red-600" />}
                          >
                            Video Classes
                          </Button>
                        </Link>

                        <button
                          type="button"
                          onClick={() => handleOpenEdit(chap)}
                          title="Edit chapter"
                          className="p-1.5 rounded-lg border border-slate-200 text-slate-600 hover:bg-slate-100 transition-colors"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>

                        <button
                          type="button"
                          onClick={() => setDeleteTarget(chap)}
                          title="Delete chapter"
                          className="p-1.5 rounded-lg border border-rose-200 text-rose-600 hover:bg-rose-50 transition-colors"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Create / Edit Chapter Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div
            className="fixed inset-0 bg-slate-900/70"
            onClick={() => !submitting && setIsModalOpen(false)}
          />

          <div className="relative bg-white rounded-2xl border border-slate-200 shadow-2xl max-w-lg w-full p-6 space-y-5 animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h3 className="text-base font-extrabold text-slate-900">
                {editingChapter ? 'Edit Chapter' : 'Add New Chapter'}
              </h3>
              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                disabled={submitting}
                className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {formError && (
              <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs font-semibold">
                {formError}
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-4 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="font-bold text-slate-700">Course Batch *</label>
                  <select
                    required
                    value={formData.batchId}
                    onChange={(e) => setFormData({ ...formData, batchId: e.target.value })}
                    className="w-full px-3.5 py-2 rounded-xl border border-slate-200 font-medium"
                  >
                    <option value="">Select batch...</option>
                    {batches.map((b) => (
                      <option key={b.id} value={b.id}>
                        {b.title}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="font-bold text-slate-700">Subject Parent *</label>
                  <select
                    required
                    value={formData.subjectId}
                    onChange={(e) => setFormData({ ...formData, subjectId: e.target.value })}
                    className="w-full px-3.5 py-2 rounded-xl border border-slate-200 font-medium"
                  >
                    <option value="">Select subject...</option>
                    {subjects.map((s) => (
                      <option key={s.id} value={s.id}>
                        {s.name}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="space-y-1">
                <label className="font-bold text-slate-700">Chapter Title *</label>
                <input
                  type="text"
                  required
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder="e.g. Cardiovascular System & Myocardial Infarction"
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-200 font-medium"
                />
              </div>

              <div className="space-y-1">
                <label className="font-bold text-slate-700">Description</label>
                <textarea
                  rows={2}
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  placeholder="Summary of topics covered in this chapter"
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-200 font-medium"
                />
              </div>

              <div className="space-y-1">
                <label className="font-bold text-slate-700">Display Order</label>
                <input
                  type="number"
                  value={formData.order}
                  onChange={(e) => setFormData({ ...formData, order: Number(e.target.value) })}
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-200"
                />
              </div>

              <div className="pt-2">
                <label className="flex items-center gap-2 p-2.5 rounded-xl border border-slate-200 bg-slate-50 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={formData.isPublished}
                    onChange={(e) => setFormData({ ...formData, isPublished: e.target.checked })}
                    className="rounded text-blue-600"
                  />
                  <span className="font-bold text-slate-800 text-xs">Publish to Students</span>
                </label>
              </div>

              <div className="flex items-center justify-end gap-2.5 pt-4 border-t border-slate-100">
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => setIsModalOpen(false)}
                  disabled={submitting}
                >
                  Cancel
                </Button>
                <Button type="submit" variant="primary" size="sm" isLoading={submitting}>
                  {editingChapter ? 'Save Changes' : 'Create Chapter'}
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Confirmation */}
      <ConfirmationModal
        isOpen={Boolean(deleteTarget)}
        title={`Delete Chapter: ${deleteTarget?.name}`}
        message="Are you sure you want to delete this chapter? Ensure any nested video classes are moved or removed."
        confirmLabel="Delete Chapter"
        isDestructive
        isLoading={isDeleting}
        onConfirm={handleConfirmDelete}
        onCancel={() => setDeleteTarget(null)}
      />
    </div>
  );
}

export default AdminChaptersPage;
