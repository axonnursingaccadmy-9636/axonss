/**
 * Axon Nursing Academy - Admin PDF Notes & Clinical Documents CMS
 * Upload and manage PDF study materials, clinical handouts, and nursing notes via Firebase Storage & Firestore.
 */
import React, { useState, useEffect, useRef } from 'react';
import { useSearchParams, Link } from 'react-router-dom';
import {
  FileText,
  Plus,
  Search,
  Edit2,
  Trash2,
  Eye,
  EyeOff,
  Upload,
  RefreshCw,
  X,
  ExternalLink,
  Download,
  AlertCircle,
  FileCheck,
  HardDrive,
  Layers,
  FolderTree,
} from 'lucide-react';
import { ROUTES } from '@/src/config/routes.config';
import { Badge } from '@/src/components/ui/Badge';
import { Button } from '@/src/components/ui/Button';
import { AdminPageHeader } from '@/src/components/admin/AdminPageHeader';
import { PublishStatusBadge, FreeBadge } from '@/src/components/admin/StatusBadge';
import { ConfirmationModal } from '@/src/components/admin/ConfirmationModal';
import { getAllBatchesAdmin } from '@/src/services/firebase/adminBatchService';
import { getAllSubjectsAdmin, getSubjectsForBatchAdmin } from '@/src/services/firebase/adminSubjectService';
import { getAllChaptersAdmin, getChaptersForSubjectAdmin } from '@/src/services/firebase/adminChapterService';
import {
  getAllPdfNotesAdmin,
  getPdfNotesForChapterAdmin,
  createPdfNote,
  updatePdfNote,
  deletePdfNote,
  togglePdfNotePublish,
  PdfNoteFormData,
} from '@/src/services/firebase/adminPdfNotesService';
import {
  uploadPdfNote,
  validatePdfFile,
} from '@/src/services/firebase/storageService';
import { PdfNote, Chapter, Subject, Batch } from '@/src/types/lms.types';
import { useAuth } from '@/src/contexts/AuthContext';

function formatFileSize(bytes: number): string {
  if (!bytes || bytes === 0) return '0 KB';
  const k = 1024;
  const sizes = ['Bytes', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return `${parseFloat((bytes / Math.pow(k, i)).toFixed(1))} ${sizes[i]}`;
}

export function AdminPdfNotesPage() {
  const { currentUser } = useAuth();
  const [searchParams, setSearchParams] = useSearchParams();
  const selectedBatchId = searchParams.get('batchId') || '';
  const selectedSubjectId = searchParams.get('subjectId') || '';
  const selectedChapterId = searchParams.get('chapterId') || '';

  const [batches, setBatches] = useState<Batch[]>([]);
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [chapters, setChapters] = useState<Chapter[]>([]);
  const [pdfNotes, setPdfNotes] = useState<PdfNote[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  // PDF Preview State
  const [previewNote, setPreviewNote] = useState<PdfNote | null>(null);

  // Modal State
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingNote, setEditingNote] = useState<PdfNote | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  // Selected file for upload
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [uploadProgress, setUploadProgress] = useState<number | null>(null);
  const [isUploadingFile, setIsUploadingFile] = useState(false);

  const [formData, setFormData] = useState<PdfNoteFormData>({
    batchId: '',
    subjectId: '',
    chapterId: '',
    title: '',
    description: '',
    fileUrl: '',
    storagePath: '',
    fileName: '',
    fileSizeBytes: 0,
    pageCount: undefined,
    order: 1,
    isFree: false,
    isPublished: true,
  });
  const [submitting, setSubmitting] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);

  // Delete State
  const [deleteTarget, setDeleteTarget] = useState<PdfNote | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);

  const loadData = async () => {
    try {
      const bList = await getAllBatchesAdmin();
      setBatches(bList);

      const sList = selectedBatchId
        ? await getSubjectsForBatchAdmin(selectedBatchId)
        : await getAllSubjectsAdmin();
      setSubjects(sList);

      let cList = selectedSubjectId
        ? await getChaptersForSubjectAdmin(selectedSubjectId)
        : await getAllChaptersAdmin();
      if (selectedBatchId && !selectedSubjectId) {
        cList = cList.filter((c) => c.batchId === selectedBatchId);
      }
      setChapters(cList);

      let notesList: PdfNote[] = [];
      if (selectedChapterId) {
        notesList = await getPdfNotesForChapterAdmin(selectedChapterId);
      } else {
        notesList = await getAllPdfNotesAdmin();
        if (selectedBatchId) notesList = notesList.filter((n) => n.batchId === selectedBatchId);
        if (selectedSubjectId) notesList = notesList.filter((n) => n.subjectId === selectedSubjectId);
      }
      setPdfNotes(notesList);
    } catch (err) {
      console.error('[AdminPdfNotesPage] Error loading data:', err);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    loadData();
  }, [selectedBatchId, selectedSubjectId, selectedChapterId]);

  const handleBatchChange = (batchId: string) => {
    const params = new URLSearchParams(searchParams);
    if (batchId) {
      params.set('batchId', batchId);
    } else {
      params.delete('batchId');
    }
    params.delete('subjectId');
    params.delete('chapterId');
    setSearchParams(params);
  };

  const handleSubjectChange = (subjectId: string) => {
    const params = new URLSearchParams(searchParams);
    if (subjectId) {
      params.set('subjectId', subjectId);
    } else {
      params.delete('subjectId');
    }
    params.delete('chapterId');
    setSearchParams(params);
  };

  const handleChapterChange = (chapterId: string) => {
    const params = new URLSearchParams(searchParams);
    if (chapterId) {
      params.set('chapterId', chapterId);
    } else {
      params.delete('chapterId');
    }
    setSearchParams(params);
  };

  const handleOpenCreate = () => {
    setEditingNote(null);
    setSelectedFile(null);
    setUploadProgress(null);
    setFormData({
      batchId: selectedBatchId || batches[0]?.id || '',
      subjectId: selectedSubjectId || subjects[0]?.id || '',
      chapterId: selectedChapterId || chapters[0]?.id || '',
      title: '',
      description: '',
      fileUrl: '',
      storagePath: '',
      fileName: '',
      fileSizeBytes: 0,
      pageCount: undefined,
      order: pdfNotes.length + 1,
      isFree: false,
      isPublished: true,
    });
    setFormError(null);
    setIsModalOpen(true);
  };

  const handleOpenEdit = (note: PdfNote) => {
    setEditingNote(note);
    setSelectedFile(null);
    setUploadProgress(null);
    setFormData({
      batchId: note.batchId,
      subjectId: note.subjectId,
      chapterId: note.chapterId,
      title: note.title,
      description: note.description || '',
      fileUrl: note.fileUrl,
      storagePath: note.storagePath,
      fileName: note.fileName,
      fileSizeBytes: note.fileSizeBytes,
      pageCount: note.pageCount,
      order: note.order,
      isFree: note.isFree,
      isPublished: note.isPublished,
    });
    setFormError(null);
    setIsModalOpen(true);
  };

  const processSelectedPdfFile = async (file: File) => {
    const validation = validatePdfFile(file);
    if (!validation.valid) {
      setFormError(validation.error || 'Invalid file.');
      return;
    }

    setFormError(null);
    setSelectedFile(file);
    setIsUploadingFile(true);
    setUploadProgress(2);

    const cleanName = file.name.replace(/\.[^/.]+$/, '').replace(/[-_]/g, ' ');
    setFormData((prev) => ({
      ...prev,
      title: prev.title || cleanName,
      fileName: file.name,
      fileSizeBytes: file.size,
    }));

    try {
      const uploadResult = await uploadPdfNote(
        file,
        formData.batchId || selectedBatchId || 'general',
        formData.chapterId || selectedChapterId || 'general',
        {
          onProgress: (percent) => setUploadProgress(percent),
        }
      );

      setUploadProgress(100);
      setFormData((prev) => ({
        ...prev,
        fileUrl: uploadResult.downloadUrl,
        storagePath: uploadResult.storagePath,
        fileName: uploadResult.fileName,
        fileSizeBytes: uploadResult.fileSizeBytes,
      }));
    } catch (err: any) {
      console.error('[AdminPdfNotesPage] Instant PDF upload error:', err);
      setFormError(err.message || 'Failed to upload PDF file. Please try again.');
      setUploadProgress(null);
    } finally {
      setIsUploadingFile(false);
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    processSelectedPdfFile(file);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);

    if (!formData.batchId || !formData.subjectId || !formData.chapterId) {
      setFormError('Please select Batch, Subject, and Chapter.');
      return;
    }

    if (!formData.title.trim()) {
      setFormError('Please enter a note title.');
      return;
    }

    if (isUploadingFile) {
      setFormError('Please wait for the PDF file upload to reach 100%.');
      return;
    }

    if (!editingNote && !selectedFile && !formData.fileUrl) {
      setFormError('Please upload a PDF file or enter a valid PDF URL.');
      return;
    }

    setSubmitting(true);

    try {
      let finalFileUrl = formData.fileUrl;
      let finalStoragePath = formData.storagePath;
      let finalFileName = formData.fileName || 'document.pdf';
      let finalFileSize = formData.fileSizeBytes;

      // Upload file if selected but not yet uploaded
      if (selectedFile && !finalFileUrl) {
        setIsUploadingFile(true);
        setUploadProgress(2);
        const uploadResult = await uploadPdfNote(
          selectedFile,
          formData.batchId,
          formData.chapterId,
          {
            onProgress: (percent) => setUploadProgress(percent),
          }
        );
        finalFileUrl = uploadResult.downloadUrl;
        finalStoragePath = uploadResult.storagePath;
        finalFileName = uploadResult.fileName;
        finalFileSize = uploadResult.fileSizeBytes;
        setUploadProgress(100);
        setIsUploadingFile(false);
      }

      const notePayload: PdfNoteFormData = {
        ...formData,
        fileUrl: finalFileUrl,
        storagePath: finalStoragePath,
        fileName: finalFileName,
        fileSizeBytes: finalFileSize,
      };

      if (editingNote) {
        const noteId = editingNote.id;
        const updatedNote: PdfNote = {
          ...editingNote,
          ...notePayload,
          updatedAt: new Date().toISOString(),
        };

        // Instant UI update
        setPdfNotes((prev) =>
          prev.map((n) => (n.id === noteId ? updatedNote : n))
        );
        setIsModalOpen(false);

        await updatePdfNote(
          noteId,
          notePayload,
          currentUser?.uid || 'admin',
          currentUser?.email || undefined
        );
      } else {
        const newNote = await createPdfNote(
          notePayload,
          currentUser?.uid || 'admin',
          currentUser?.email || undefined
        );
        setPdfNotes((prev) => [...prev, newNote]);
        setIsModalOpen(false);
      }
    } catch (err: any) {
      console.error('[AdminPdfNotesPage] Submit error:', err);
      setFormError(err.message || 'Failed to save PDF note.');
      loadData();
    } finally {
      setSubmitting(false);
      setUploadProgress(null);
    }
  };

  const handleTogglePublish = async (note: PdfNote) => {
    const nextState = !note.isPublished;
    // Instant UI update
    setPdfNotes((prev) =>
      prev.map((n) => (n.id === note.id ? { ...n, isPublished: nextState } : n))
    );

    try {
      await togglePdfNotePublish(
        note.id,
        nextState,
        note.title,
        currentUser?.uid || 'admin',
        currentUser?.email || undefined
      );
    } catch (err) {
      console.error('Failed to toggle publish:', err);
      setPdfNotes((prev) =>
        prev.map((n) => (n.id === note.id ? { ...n, isPublished: note.isPublished } : n))
      );
    }
  };

  const handleConfirmDelete = async () => {
    if (!deleteTarget) return;
    setIsDeleting(true);
    try {
      await deletePdfNote(
        deleteTarget.id,
        deleteTarget.title,
        deleteTarget.storagePath,
        currentUser?.uid || 'admin',
        currentUser?.email || undefined
      );
      setPdfNotes((prev) => prev.filter((n) => n.id !== deleteTarget.id));
      setDeleteTarget(null);
    } catch (err) {
      console.error('Failed to delete PDF note:', err);
    } finally {
      setIsDeleting(false);
    }
  };

  const getChapterName = (chapId: string) => {
    return chapters.find((c) => c.id === chapId)?.name || chapId;
  };

  const filteredNotes = pdfNotes.filter((note) => {
    return (
      note.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      note.fileName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (note.description && note.description.toLowerCase().includes(searchQuery.toLowerCase()))
    );
  });

  return (
    <div className="space-y-6 font-['Plus_Jakarta_Sans',sans-serif]">
      <AdminPageHeader
        title="PDF Notes & Clinical Documents"
        description="Upload verified nursing lecture notes, clinical procedures, and high-yield question PDFs to Firebase Storage."
        breadcrumbs={[
          { label: 'Admin', path: ROUTES.ADMIN.DASHBOARD },
          { label: 'Chapters', path: ROUTES.ADMIN.CHAPTERS },
          { label: 'PDF Notes' },
        ]}
        actions={
          <>
            <Button
              variant="outline"
              size="sm"
              onClick={() => {
                setRefreshing(true);
                loadData();
              }}
              isLoading={refreshing}
              leftIcon={<RefreshCw className="w-3.5 h-3.5" />}
            >
              Refresh
            </Button>
            <Button
              variant="primary"
              size="sm"
              onClick={handleOpenCreate}
              leftIcon={<Upload className="w-4 h-4" />}
            >
              Upload PDF Note
            </Button>
          </>
        }
      />

      {/* Cascading Filter Bar */}
      <div className="bg-white rounded-2xl border border-slate-200/80 p-3.5 sm:p-4 shadow-xs flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
        <div className="flex items-center gap-2 w-full md:w-auto flex-wrap">
          <select
            value={selectedBatchId}
            onChange={(e) => handleBatchChange(e.target.value)}
            className="flex-1 sm:flex-none px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-800 max-w-full sm:max-w-xs"
          >
            <option value="">All Batches</option>
            {batches.map((b) => (
              <option key={b.id} value={b.id}>
                {b.title}
              </option>
            ))}
          </select>

          <select
            value={selectedSubjectId}
            onChange={(e) => handleSubjectChange(e.target.value)}
            className="flex-1 sm:flex-none px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-800 max-w-full sm:max-w-xs"
          >
            <option value="">All Subjects</option>
            {subjects.map((s) => (
              <option key={s.id} value={s.id}>
                {s.name}
              </option>
            ))}
          </select>

          <select
            value={selectedChapterId}
            onChange={(e) => handleChapterChange(e.target.value)}
            className="flex-1 sm:flex-none px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-800 max-w-full sm:max-w-xs"
          >
            <option value="">All Chapters</option>
            {chapters.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name}
              </option>
            ))}
          </select>
        </div>

        <div className="relative w-full md:w-64">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search PDF notes..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-4 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
          />
        </div>
      </div>

      {/* PDF Notes Table */}
      <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs min-w-[720px]">
            <thead className="bg-slate-50/80 text-slate-500 uppercase text-[10px] font-bold border-b border-slate-100">
              <tr>
                <th className="px-5 py-3.5">Order</th>
                <th className="px-5 py-3.5">Document Title & File</th>
                <th className="px-5 py-3.5">Chapter</th>
                <th className="px-5 py-3.5">File Size</th>
                <th className="px-5 py-3.5">Access</th>
                <th className="px-5 py-3.5">Status</th>
                <th className="px-5 py-3.5 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-medium text-slate-700">
              {loading ? (
                <tr>
                  <td colSpan={7} className="px-5 py-12 text-center text-slate-400">
                    <RefreshCw className="w-5 h-5 animate-spin mx-auto mb-2 text-blue-600" />
                    Loading PDF documents from Firestore...
                  </td>
                </tr>
              ) : filteredNotes.length === 0 ? (
                <tr>
                  <td colSpan={7} className="px-5 py-12 text-center text-slate-400">
                    <FileText className="w-8 h-8 text-slate-300 mx-auto mb-2" />
                    No PDF notes found. Click "Upload PDF Note" to add one.
                  </td>
                </tr>
              ) : (
                filteredNotes.map((note) => (
                  <tr key={note.id} className="hover:bg-slate-50/70 transition-colors">
                    <td className="px-5 py-4 font-bold text-slate-400 font-mono">
                      #{note.order}
                    </td>
                    <td className="px-5 py-4">
                      <div className="flex items-center gap-3">
                        <div className="w-9 h-9 rounded-xl bg-rose-50 border border-rose-100 flex items-center justify-center text-rose-600 shrink-0">
                          <FileText className="w-4 h-4" />
                        </div>
                        <div className="min-w-0">
                          <span className="font-extrabold text-slate-900 block text-sm">
                            {note.title}
                          </span>
                          <span className="text-[11px] text-slate-400 truncate block max-w-xs font-mono">
                            {note.fileName}
                          </span>
                        </div>
                      </div>
                    </td>
                    <td className="px-5 py-4">
                      <Badge variant="purple" size="sm">
                        {getChapterName(note.chapterId)}
                      </Badge>
                    </td>
                    <td className="px-5 py-4 text-slate-600 font-semibold font-mono text-[11px]">
                      {formatFileSize(note.fileSizeBytes)}
                    </td>
                    <td className="px-5 py-4">
                      {note.isFree ? (
                        <FreeBadge isFree={true} />
                      ) : (
                        <span className="text-slate-400 text-[11px]">Enrolled Only</span>
                      )}
                    </td>
                    <td className="px-5 py-4">
                      <PublishStatusBadge isPublished={note.isPublished} />
                    </td>
                    <td className="px-5 py-4 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        {/* View In Browser */}
                        <button
                          type="button"
                          onClick={() => setPreviewNote(note)}
                          title="Preview PDF document"
                          className="p-1.5 rounded-lg border border-blue-200 text-blue-600 hover:bg-blue-50 transition-colors"
                        >
                          <Eye className="w-3.5 h-3.5" />
                        </button>

                        {/* Direct Download */}
                        <a
                          href={note.fileUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          download={note.fileName}
                          title="Download PDF"
                          className="p-1.5 rounded-lg border border-slate-200 text-slate-600 hover:bg-slate-100 transition-colors"
                        >
                          <Download className="w-3.5 h-3.5" />
                        </a>

                        {/* Toggle Publish */}
                        <button
                          type="button"
                          onClick={() => handleTogglePublish(note)}
                          title={note.isPublished ? 'Unpublish' : 'Publish'}
                          className={`p-1.5 rounded-lg border transition-colors ${
                            note.isPublished
                              ? 'border-emerald-200 text-emerald-600 hover:bg-emerald-50'
                              : 'border-slate-200 text-slate-400 hover:bg-slate-100'
                          }`}
                        >
                          {note.isPublished ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
                        </button>

                        <button
                          type="button"
                          onClick={() => handleOpenEdit(note)}
                          title="Edit PDF metadata"
                          className="p-1.5 rounded-lg border border-slate-200 text-slate-600 hover:bg-slate-100 transition-colors"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>

                        <button
                          type="button"
                          onClick={() => setDeleteTarget(note)}
                          title="Delete PDF note"
                          className="p-1.5 rounded-lg border border-rose-200 text-rose-600 hover:bg-rose-50 transition-colors"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* PDF In-Browser Preview Modal */}
      {previewNote && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div
            className="fixed inset-0 bg-slate-950/85"
            onClick={() => setPreviewNote(null)}
          />

          <div className="relative bg-white rounded-2xl border border-slate-800 shadow-2xl max-w-4xl w-full h-[85vh] flex flex-col z-10 overflow-hidden">
            <div className="flex items-center justify-between px-5 py-3.5 border-b border-slate-100 bg-slate-50 shrink-0">
              <div className="flex items-center gap-2.5 min-w-0">
                <FileText className="w-5 h-5 text-rose-600 shrink-0" />
                <div className="min-w-0">
                  <h4 className="text-sm font-extrabold text-slate-900 truncate">
                    {previewNote.title}
                  </h4>
                  <span className="text-[11px] text-slate-400 font-mono">
                    {previewNote.fileName} ({formatFileSize(previewNote.fileSizeBytes)})
                  </span>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <a
                  href={previewNote.fileUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-3 py-1.5 rounded-lg bg-blue-50 text-blue-600 hover:bg-blue-100 text-xs font-semibold flex items-center gap-1.5 transition-colors"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Download</span>
                </a>
                <button
                  type="button"
                  onClick={() => setPreviewNote(null)}
                  className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            <div className="flex-1 w-full h-full bg-slate-100">
              <iframe
                src={previewNote.fileUrl}
                title={previewNote.title}
                className="w-full h-full border-0"
              />
            </div>
          </div>
        </div>
      )}

      {/* Upload / Edit PDF Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 overflow-y-auto">
          <div
            className="fixed inset-0 bg-slate-900/70"
            onClick={() => !submitting && setIsModalOpen(false)}
          />

          <div className="relative bg-white rounded-2xl border border-slate-200 shadow-2xl max-w-xl w-full p-6 space-y-5 my-8 max-h-[90vh] overflow-y-auto animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-xl bg-rose-50 text-rose-600 flex items-center justify-center">
                  <FileText className="w-4 h-4" />
                </div>
                <h3 className="text-base font-extrabold text-slate-900">
                  {editingNote ? 'Edit PDF Note' : 'Upload Clinical Study PDF'}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                disabled={submitting}
                className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {formError && (
              <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs font-semibold flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{formError}</span>
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-4 text-xs">
              <div className="grid grid-cols-3 gap-3">
                <div className="space-y-1">
                  <label className="font-bold text-slate-700">Course Batch *</label>
                  <select
                    required
                    value={formData.batchId}
                    onChange={(e) => setFormData({ ...formData, batchId: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 font-medium"
                  >
                    <option value="">Select batch...</option>
                    {batches.map((b) => (
                      <option key={b.id} value={b.id}>
                        {b.title}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="font-bold text-slate-700">Subject *</label>
                  <select
                    required
                    value={formData.subjectId}
                    onChange={(e) => setFormData({ ...formData, subjectId: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 font-medium"
                  >
                    <option value="">Select subject...</option>
                    {subjects.map((s) => (
                      <option key={s.id} value={s.id}>
                        {s.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="font-bold text-slate-700">Chapter *</label>
                  <select
                    required
                    value={formData.chapterId}
                    onChange={(e) => setFormData({ ...formData, chapterId: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 font-medium"
                  >
                    <option value="">Select chapter...</option>
                    {chapters.map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.name}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* File Upload Box */}
              <div className="space-y-2">
                <label className="font-bold text-slate-700">PDF Document File *</label>
                <div
                  onClick={() => !isUploadingFile && fileInputRef.current?.click()}
                  onDragOver={(e) => e.preventDefault()}
                  onDrop={(e) => {
                    e.preventDefault();
                    if (isUploadingFile) return;
                    const dropped = e.dataTransfer.files?.[0];
                    if (dropped) processSelectedPdfFile(dropped);
                  }}
                  className={`border-2 border-dashed rounded-2xl p-5 text-center transition-colors ${
                    isUploadingFile
                      ? 'border-blue-400 bg-blue-50/40 cursor-wait'
                      : uploadProgress === 100
                      ? 'border-emerald-400 bg-emerald-50/30 cursor-pointer hover:border-emerald-500'
                      : 'border-slate-200 hover:border-blue-500 bg-slate-50/50 hover:bg-blue-50/20 cursor-pointer'
                  }`}
                >
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="application/pdf,.pdf"
                    onChange={handleFileSelect}
                    className="hidden"
                  />
                  {selectedFile ? (
                    <div className="flex items-center justify-center gap-3 text-left">
                      <div
                        className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${
                          isUploadingFile
                            ? 'bg-blue-100 text-blue-700'
                            : 'bg-emerald-100 text-emerald-700'
                        }`}
                      >
                        {isUploadingFile ? (
                          <RefreshCw className="w-5 h-5 animate-spin" />
                        ) : (
                          <FileCheck className="w-5 h-5" />
                        )}
                      </div>
                      <div className="min-w-0 flex-1">
                        <p className="font-bold text-slate-900 truncate">{selectedFile.name}</p>
                        <p className="text-[11px] text-slate-600 font-mono">
                          {isUploadingFile
                            ? `Uploading: ${formatFileSize(
                                Math.round((selectedFile.size * (uploadProgress || 0)) / 100)
                              )} / ${formatFileSize(selectedFile.size)} (${uploadProgress ?? 0}%)`
                            : `${formatFileSize(selectedFile.size)} • 100% Uploaded & Ready to Save`}
                        </p>
                      </div>
                    </div>
                  ) : formData.fileUrl ? (
                    <div className="flex items-center justify-center gap-3 text-left">
                      <div className="w-10 h-10 rounded-xl bg-blue-100 text-blue-700 flex items-center justify-center shrink-0">
                        <FileText className="w-5 h-5" />
                      </div>
                      <div className="min-w-0">
                        <p className="font-bold text-slate-900 truncate">{formData.fileName || 'Attached PDF Document'}</p>
                        <p className="text-[11px] text-slate-500">Click to replace PDF file</p>
                      </div>
                    </div>
                  ) : (
                    <div className="space-y-1">
                      <Upload className="w-8 h-8 text-slate-400 mx-auto mb-1" />
                      <p className="font-bold text-slate-800">Click to select PDF or drag and drop</p>
                      <p className="text-[11px] text-slate-400">PDF documents up to 50MB</p>
                    </div>
                  )}
                </div>

                {uploadProgress !== null && (
                  <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 space-y-1.5">
                    <div className="flex items-center justify-between text-xs font-extrabold">
                      <span
                        className={
                          uploadProgress === 100
                            ? 'text-emerald-700 flex items-center gap-1.5'
                            : 'text-blue-700 flex items-center gap-1.5'
                        }
                      >
                        {uploadProgress === 100 ? (
                          <>
                            <FileCheck className="w-4 h-4 text-emerald-600" />
                            <span>PDF File Uploaded Successfully!</span>
                          </>
                        ) : (
                          <>
                            <RefreshCw className="w-3.5 h-3.5 animate-spin text-blue-600" />
                            <span>Uploading PDF Document...</span>
                          </>
                        )}
                      </span>
                      <span
                        className={`font-mono text-sm ${
                          uploadProgress === 100 ? 'text-emerald-700' : 'text-blue-700'
                        }`}
                      >
                        {uploadProgress}%
                      </span>
                    </div>
                    <div className="w-full bg-slate-200 h-2.5 rounded-full overflow-hidden">
                      <div
                        className={`h-full transition-all duration-200 rounded-full ${
                          uploadProgress === 100 ? 'bg-emerald-600' : 'bg-blue-600'
                        }`}
                        style={{ width: `${uploadProgress}%` }}
                      />
                    </div>
                  </div>
                )}
              </div>

              <div className="space-y-1">
                <label className="font-bold text-slate-700">Document Title *</label>
                <input
                  type="text"
                  required
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  placeholder="e.g. Critical Care Nursing Formula Sheet & Normal Lab Values"
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-200 font-medium"
                />
              </div>

              <div className="space-y-1">
                <label className="font-bold text-slate-700">Description / Topic Notes</label>
                <textarea
                  rows={2}
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  placeholder="Clinical summary, important formulas, and NORCET high-yield focus areas"
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-200 font-medium"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="font-bold text-slate-700">Display Order</label>
                  <input
                    type="number"
                    value={formData.order}
                    onChange={(e) => setFormData({ ...formData, order: Number(e.target.value) })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200"
                  />
                </div>

                <div className="space-y-1">
                  <label className="font-bold text-slate-700">Estimated Pages (Optional)</label>
                  <input
                    type="number"
                    value={formData.pageCount || ''}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        pageCount: e.target.value ? Number(e.target.value) : undefined,
                      })
                    }
                    placeholder="e.g. 14"
                    className="w-full px-3 py-2 rounded-xl border border-slate-200"
                  />
                </div>
              </div>

              {/* Toggles */}
              <div className="pt-2 grid grid-cols-2 gap-3">
                <label className="flex items-center gap-2 p-2.5 rounded-xl border border-slate-200 bg-slate-50 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={formData.isPublished}
                    onChange={(e) => setFormData({ ...formData, isPublished: e.target.checked })}
                    className="rounded text-blue-600"
                  />
                  <span className="font-bold text-slate-800 text-xs">Publish to Students</span>
                </label>

                <label className="flex items-center gap-2 p-2.5 rounded-xl border border-slate-200 bg-slate-50 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={formData.isFree}
                    onChange={(e) => setFormData({ ...formData, isFree: e.target.checked })}
                    className="rounded text-blue-600"
                  />
                  <span className="font-bold text-slate-800 text-xs">Free Sample Access</span>
                </label>
              </div>

              <div className="flex items-center justify-end gap-2.5 pt-4 border-t border-slate-100">
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => setIsModalOpen(false)}
                  disabled={submitting}
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  variant="primary"
                  size="sm"
                  isLoading={submitting || isUploadingFile}
                  disabled={submitting || isUploadingFile}
                >
                  {isUploadingFile
                    ? `Uploading (${uploadProgress ?? 0}%)...`
                    : editingNote
                    ? 'Save Changes'
                    : 'Save PDF Note'}
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      <ConfirmationModal
        isOpen={Boolean(deleteTarget)}
        title={`Delete PDF Note: ${deleteTarget?.title}`}
        message="Are you sure you want to permanently delete this PDF document? It will be removed from Firestore and Firebase Storage."
        confirmLabel="Delete Note"
        isDestructive
        isLoading={isDeleting}
        onConfirm={handleConfirmDelete}
        onCancel={() => setDeleteTarget(null)}
      />
    </div>
  );
}
export default AdminPdfNotesPage;
