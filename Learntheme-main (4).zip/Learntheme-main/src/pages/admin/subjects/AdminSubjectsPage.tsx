/**
 * Axon Nursing Academy - Admin Subjects CMS
 * Manage nursing syllabus subjects categorized under course batches.
 */
import React, { useState, useEffect } from 'react';
import { useSearchParams, Link } from 'react-router-dom';
import {
  Layers,
  Plus,
  Search,
  Edit2,
  Trash2,
  Eye,
  EyeOff,
  FolderTree,
  BookMarked,
  RefreshCw,
  X,
  ArrowRight,
} from 'lucide-react';
import { ROUTES } from '@/src/config/routes.config';
import { Badge } from '@/src/components/ui/Badge';
import { Button } from '@/src/components/ui/Button';
import { AdminPageHeader } from '@/src/components/admin/AdminPageHeader';
import { PublishStatusBadge } from '@/src/components/admin/StatusBadge';
import { ConfirmationModal } from '@/src/components/admin/ConfirmationModal';
import { ImageUploadField } from '@/src/components/common/ImageUploadField';
import { getAllBatchesAdmin, subscribeToBatchesAdmin } from '@/src/services/firebase/adminBatchService';
import {
  getAllSubjectsAdmin,
  getSubjectsForBatchAdmin,
  subscribeToSubjectsAdmin,
  createSubject,
  updateSubject,
  deleteSubject,
  toggleSubjectPublish,
  SubjectFormData,
} from '@/src/services/firebase/adminSubjectService';
import { Subject, Batch } from '@/src/types/lms.types';
import { useAuth } from '@/src/contexts/AuthContext';

export function AdminSubjectsPage() {
  const { currentUser } = useAuth();
  const [searchParams, setSearchParams] = useSearchParams();
  const selectedBatchId = searchParams.get('batchId') || '';

  const [batches, setBatches] = useState<Batch[]>([]);
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  // Modal State
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingSubject, setEditingSubject] = useState<Subject | null>(null);
  const [formData, setFormData] = useState<SubjectFormData>({
    batchId: '',
    name: '',
    description: '',
    thumbnailUrl: 'https://images.unsplash.com/photo-1579684385127-1ef15d508118?w=800&auto=format&fit=crop&q=80',
    order: 1,
    isPublished: true,
  });
  const [submitting, setSubmitting] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);

  // Delete State
  const [deleteTarget, setDeleteTarget] = useState<Subject | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);

  useEffect(() => {
    // 1. Subscribe to batches
    const unsubBatches = subscribeToBatchesAdmin(
      (bList) => setBatches(bList),
      (err) => console.warn('[AdminSubjectsPage] Batches subscription notice:', err)
    );

    // 2. Subscribe to subjects (filtered by selectedBatchId if present)
    const unsubSubjects = subscribeToSubjectsAdmin(
      (sList) => {
        setSubjects(sList);
        setLoading(false);
        setRefreshing(false);
      },
      selectedBatchId || undefined,
      (err) => {
        console.warn('[AdminSubjectsPage] Subjects subscription notice:', err);
        setLoading(false);
        setRefreshing(false);
      }
    );

    return () => {
      unsubBatches();
      unsubSubjects();
    };
  }, [selectedBatchId]);

  const handleRefresh = async () => {
    setRefreshing(true);
    try {
      const bList = await getAllBatchesAdmin();
      setBatches(bList);
      const sList = selectedBatchId
        ? await getSubjectsForBatchAdmin(selectedBatchId)
        : await getAllSubjectsAdmin();
      setSubjects(sList);
    } catch (err) {
      console.warn('[AdminSubjectsPage] Refresh notice:', err);
    } finally {
      setRefreshing(false);
    }
  };

  const handleBatchFilterChange = (batchId: string) => {
    if (batchId) {
      setSearchParams({ batchId });
    } else {
      setSearchParams({});
    }
  };

  const handleOpenCreate = () => {
    setEditingSubject(null);
    setFormData({
      batchId: selectedBatchId || (batches[0]?.id || ''),
      name: '',
      description: '',
      thumbnailUrl: 'https://images.unsplash.com/photo-1579684385127-1ef15d508118?w=800&auto=format&fit=crop&q=80',
      order: subjects.length + 1,
      isPublished: true,
    });
    setFormError(null);
    setIsModalOpen(true);
  };

  const handleOpenEdit = (subject: Subject) => {
    setEditingSubject(subject);
    setFormData({
      batchId: subject.batchId,
      name: subject.name,
      description: subject.description,
      thumbnailUrl: subject.thumbnailUrl,
      order: subject.order,
      isPublished: subject.isPublished,
    });
    setFormError(null);
    setIsModalOpen(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) return;
    if (!formData.name.trim()) {
      setFormError('Subject name is required.');
      return;
    }
    if (!formData.batchId) {
      setFormError('Please select a parent course batch.');
      return;
    }

    setSubmitting(true);
    setFormError(null);

    try {
      if (editingSubject) {
        const subjectId = editingSubject.id;
        const updatedSubject: Subject = {
          ...editingSubject,
          ...formData,
          updatedAt: new Date().toISOString(),
        };

        await updateSubject(
          subjectId,
          formData,
          currentUser.uid,
          currentUser.email || undefined
        );

        setSubjects((prev) =>
          prev.map((s) => (s.id === subjectId ? updatedSubject : s))
        );
        setIsModalOpen(false);
      } else {
        const newSub = await createSubject(formData, currentUser.uid, currentUser.email || undefined);
        setSubjects((prev) => [...prev, newSub]);
        setIsModalOpen(false);
      }
    } catch (err: any) {
      console.error('Error saving subject:', err);
      setFormError(err?.message || 'Failed to save subject.');
      handleRefresh();
    } finally {
      setSubmitting(false);
    }
  };

  const handleTogglePublish = async (subject: Subject) => {
    if (!currentUser) return;
    const newStatus = !subject.isPublished;
    // Instant UI update
    setSubjects((prev) =>
      prev.map((s) => (s.id === subject.id ? { ...s, isPublished: newStatus } : s))
    );

    try {
      await toggleSubjectPublish(
        subject.id,
        newStatus,
        subject.name,
        currentUser.uid,
        currentUser.email || undefined
      );
    } catch (err) {
      console.error('Failed to toggle subject:', err);
      setSubjects((prev) =>
        prev.map((s) => (s.id === subject.id ? { ...s, isPublished: subject.isPublished } : s))
      );
    }
  };

  const handleConfirmDelete = async () => {
    if (!deleteTarget || !currentUser) return;
    const targetId = deleteTarget.id;
    const targetName = deleteTarget.name;

    // Instant UI removal
    setSubjects((prev) => prev.filter((s) => s.id !== targetId));
    setDeleteTarget(null);

    setIsDeleting(true);
    try {
      await deleteSubject(
        targetId,
        targetName,
        currentUser.uid,
        currentUser.email || undefined
      );
    } catch (err) {
      console.error('Failed to delete subject:', err);
      handleRefresh();
    } finally {
      setIsDeleting(false);
    }
  };

  const getBatchTitle = (batchId: string) => {
    return batches.find((b) => b.id === batchId)?.title || batchId;
  };

  const filteredSubjects = subjects.filter((s) => {
    const matchesQuery =
      s.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      s.description.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesQuery;
  });

  return (
    <div className="space-y-6 font-['Plus_Jakarta_Sans',sans-serif]">
      <AdminPageHeader
        title="Subjects & Modules"
        description="Organize the academic syllabus into clinical and foundational nursing subjects."
        breadcrumbs={[
          { label: 'Admin', path: ROUTES.ADMIN.DASHBOARD },
          { label: 'Batches', path: ROUTES.ADMIN.BATCHES },
          { label: 'Subjects' },
        ]}
        actions={
          <>
            <Button
              variant="outline"
              size="sm"
              onClick={handleRefresh}
              isLoading={refreshing}
              leftIcon={<RefreshCw className="w-3.5 h-3.5" />}
            >
              Refresh
            </Button>
            <Button
              variant="primary"
              size="sm"
              onClick={handleOpenCreate}
              leftIcon={<Plus className="w-4 h-4" />}
            >
              Add Subject
            </Button>
          </>
        }
      />

      {/* Filter and Search Bar */}
      <div className="bg-white rounded-2xl border border-slate-200/80 p-3.5 sm:p-4 shadow-xs flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
        <div className="flex items-center gap-2.5 w-full md:w-auto flex-wrap">
          {/* Batch Selector Dropdown */}
          <div className="flex items-center gap-2 w-full sm:w-auto">
            <span className="text-xs font-bold text-slate-500 whitespace-nowrap">
              Parent Batch:
            </span>
            <select
              value={selectedBatchId}
              onChange={(e) => handleBatchFilterChange(e.target.value)}
              className="flex-1 sm:flex-none px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 max-w-full sm:max-w-xs"
            >
              <option value="">All Batches ({batches.length})</option>
              {batches.map((b) => (
                <option key={b.id} value={b.id}>
                  {b.title}
                </option>
              ))}
            </select>
          </div>
        </div>

        <div className="relative w-full md:w-72">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search subjects..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-4 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
          />
        </div>
      </div>

      {/* Subjects Table */}
      <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs min-w-[620px]">
            <thead className="bg-slate-50/80 text-slate-500 uppercase text-[10px] font-bold border-b border-slate-100">
              <tr>
                <th className="px-5 py-3.5">Order</th>
                <th className="px-5 py-3.5">Subject Name</th>
                <th className="px-5 py-3.5">Parent Course / Batch</th>
                <th className="px-5 py-3.5">Status</th>
                <th className="px-5 py-3.5 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-medium text-slate-700">
              {loading ? (
                <tr>
                  <td colSpan={5} className="px-5 py-12 text-center text-slate-400">
                    <RefreshCw className="w-5 h-5 animate-spin mx-auto mb-2 text-blue-600" />
                    Loading subjects...
                  </td>
                </tr>
              ) : filteredSubjects.length === 0 ? (
                <tr>
                  <td colSpan={5} className="px-5 py-12 text-center text-slate-400">
                    No subjects found. Click "Add Subject" to create one.
                  </td>
                </tr>
              ) : (
                filteredSubjects.map((sub) => (
                  <tr key={sub.id} className="hover:bg-slate-50/70 transition-colors">
                    <td className="px-5 py-4 font-bold text-slate-400 font-mono">
                      #{sub.order}
                    </td>
                    <td className="px-5 py-4">
                      <div className="flex items-center gap-3">
                        <img
                          src={sub.thumbnailUrl}
                          alt=""
                          className="w-10 h-8 rounded-lg object-cover bg-slate-100 border border-slate-200 shrink-0"
                        />
                        <div>
                          <span className="font-extrabold text-slate-900 block text-sm">
                            {sub.name}
                          </span>
                          <span className="text-[11px] text-slate-400 line-clamp-1 max-w-sm">
                            {sub.description || 'No description provided.'}
                          </span>
                        </div>
                      </div>
                    </td>
                    <td className="px-5 py-4">
                      <Badge variant="blue" size="sm">
                        {getBatchTitle(sub.batchId)}
                      </Badge>
                    </td>
                    <td className="px-5 py-4">
                      <PublishStatusBadge isPublished={sub.isPublished} />
                    </td>
                    <td className="px-5 py-4 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          type="button"
                          onClick={() => handleTogglePublish(sub)}
                          title={sub.isPublished ? 'Unpublish' : 'Publish'}
                          className={`p-1.5 rounded-lg border transition-colors ${
                            sub.isPublished
                              ? 'border-emerald-200 text-emerald-600 hover:bg-emerald-50'
                              : 'border-slate-200 text-slate-400 hover:bg-slate-100'
                          }`}
                        >
                          {sub.isPublished ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
                        </button>

                        <Link
                          to={`/admin/chapters?batchId=${sub.batchId}&subjectId=${sub.id}`}
                        >
                          <Button
                            variant="outline"
                            size="sm"
                            leftIcon={<FolderTree className="w-3 h-3 text-amber-600" />}
                          >
                            Chapters
                          </Button>
                        </Link>

                        <button
                          type="button"
                          onClick={() => handleOpenEdit(sub)}
                          title="Edit subject"
                          className="p-1.5 rounded-lg border border-slate-200 text-slate-600 hover:bg-slate-100 transition-colors"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>

                        <button
                          type="button"
                          onClick={() => setDeleteTarget(sub)}
                          title="Delete subject"
                          className="p-1.5 rounded-lg border border-rose-200 text-rose-600 hover:bg-rose-50 transition-colors"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Create / Edit Subject Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div
            className="fixed inset-0 bg-slate-900/70"
            onClick={() => !submitting && setIsModalOpen(false)}
          />

          <div className="relative bg-white rounded-2xl border border-slate-200 shadow-2xl max-w-lg w-full p-6 space-y-5 animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h3 className="text-base font-extrabold text-slate-900">
                {editingSubject ? 'Edit Subject' : 'Add New Subject'}
              </h3>
              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                disabled={submitting}
                className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {formError && (
              <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs font-semibold">
                {formError}
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-4 text-xs">
              <div className="space-y-1">
                <label className="font-bold text-slate-700">Course / Batch Parent *</label>
                <select
                  required
                  value={formData.batchId}
                  onChange={(e) => setFormData({ ...formData, batchId: e.target.value })}
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-200 font-medium"
                >
                  <option value="">Select a batch...</option>
                  {batches.map((b) => (
                    <option key={b.id} value={b.id}>
                      {b.title}
                    </option>
                  ))}
                </select>
              </div>

              <div className="space-y-1">
                <label className="font-bold text-slate-700">Subject Name *</label>
                <input
                  type="text"
                  required
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder="e.g. Medical Surgical Nursing (MSN)"
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-200 font-medium focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
                />
              </div>

              <div className="space-y-1">
                <label className="font-bold text-slate-700">Description</label>
                <textarea
                  rows={2}
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  placeholder="Brief overview of the subject curriculum"
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-200 font-medium"
                />
              </div>

              {/* Subject Photo Upload */}
              <ImageUploadField
                label="Subject Cover / Icon Photo"
                value={formData.thumbnailUrl}
                onChange={(url) => setFormData({ ...formData, thumbnailUrl: url })}
                aspectRatio="square"
                folder="thumbnails"
                placeholder="Upload subject cover photo"
                helperText="Square icon or photo (e.g., 400x400px). Displays in course syllabus list."
                required
              />

              <div className="space-y-1">
                <label className="font-bold text-slate-700">Display Order</label>
                <input
                  type="number"
                  value={formData.order}
                  onChange={(e) => setFormData({ ...formData, order: Number(e.target.value) })}
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-200"
                />
              </div>

              <div className="pt-2">
                <label className="flex items-center gap-2 p-2.5 rounded-xl border border-slate-200 bg-slate-50 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={formData.isPublished}
                    onChange={(e) => setFormData({ ...formData, isPublished: e.target.checked })}
                    className="rounded text-blue-600"
                  />
                  <span className="font-bold text-slate-800 text-xs">Publish to Students</span>
                </label>
              </div>

              <div className="flex items-center justify-end gap-2.5 pt-4 border-t border-slate-100">
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => setIsModalOpen(false)}
                  disabled={submitting}
                >
                  Cancel
                </Button>
                <Button type="submit" variant="primary" size="sm" isLoading={submitting}>
                  {editingSubject ? 'Save Changes' : 'Create Subject'}
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Confirmation */}
      <ConfirmationModal
        isOpen={Boolean(deleteTarget)}
        title={`Delete Subject: ${deleteTarget?.name}`}
        message="Are you sure you want to delete this subject? Ensure any nested chapters and classes are also handled."
        confirmLabel="Delete Subject"
        isDestructive
        isLoading={isDeleting}
        onConfirm={handleConfirmDelete}
        onCancel={() => setDeleteTarget(null)}
      />
    </div>
  );
}

export default AdminSubjectsPage;
