/**
 * Axon Nursing Academy - Admin Payments & Transactions CMS (Phase 7)
 * Authoritative financial audit trail, Razorpay transaction management,
 * and gateway configuration diagnostic interface.
 */
import React, { useEffect, useState, useMemo } from 'react';
import {
  CreditCard,
  CheckCircle2,
  AlertCircle,
  Search,
  RefreshCw,
  ShieldCheck,
  Tag,
  Copy,
  Check,
  TrendingUp,
  Receipt,
  Clock,
  ArrowUpRight,
} from 'lucide-react';
import { PaymentRecord, PaymentConfigStatus } from '@/src/types/payment.types';
import {
  checkPaymentConfig,
  getAdminPayments,
  testRazorpayConnection,
} from '@/src/services/payment/razorpayService';
import { formatCurrency } from '@/src/lib/utils/formatters';
import { Badge } from '@/src/components/ui/Badge';
import { useAuth } from '@/src/contexts/AuthContext';
import { collection, getDocs } from 'firebase/firestore';
import { getFirestoreDb } from '@/src/lib/firebase/firestore';

export function AdminPaymentsPage() {
  const { currentUser } = useAuth();
  const [payments, setPayments] = useState<PaymentRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'paid' | 'created' | 'failed'>('all');
  const [configStatus, setConfigStatus] = useState<PaymentConfigStatus>({
    configured: false,
    keyId: null,
  });
  const [testingConnection, setTestingConnection] = useState(false);
  const [testResult, setTestResult] = useState<{
    success: boolean;
    message?: string;
    error?: string;
    statusCode?: number;
    keyId?: string;
    isLiveMode?: boolean;
  } | null>(null);

  const handleTestConnection = async () => {
    setTestingConnection(true);
    setTestResult(null);
    try {
      const res = await testRazorpayConnection();
      setTestResult(res);
    } catch (err: any) {
      setTestResult({
        success: false,
        error: err?.message || 'Failed to communicate with diagnostic API.',
      });
    } finally {
      setTestingConnection(false);
    }
  };

  const loadData = async () => {
    try {
      let idToken: string | null = null;
      if (currentUser && typeof (currentUser as any).getIdToken === 'function') {
        idToken = await (currentUser as any).getIdToken().catch(() => null);
      }

      const [cfg, list] = await Promise.all([
        checkPaymentConfig(),
        getAdminPayments(idToken, currentUser?.email),
      ]);
      setConfigStatus(cfg);

      // Hydrate student names and emails from Firestore users collection if missing
      const db = getFirestoreDb();
      if (db && list.length > 0) {
        try {
          const usersSnap = await getDocs(collection(db, 'users'));
          const userMap = new Map<string, { fullName?: string; email?: string }>();
          usersSnap.docs.forEach((d) => {
            const u = d.data();
            userMap.set(d.id, { fullName: u.fullName, email: u.email });
          });

          const enriched = list.map((p) => {
            const user = p.userId ? userMap.get(p.userId) : null;
            return {
              ...p,
              studentName: p.studentName || user?.fullName || 'Student',
              studentEmail: p.studentEmail || user?.email || p.userId,
            };
          });
          setPayments(enriched);
        } catch {
          setPayments(list);
        }
      } else {
        setPayments(list);
      }
    } catch (err) {
      console.error('[AdminPaymentsPage] Error fetching payments:', err);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    loadData();
  }, [currentUser]);

  const handleRefresh = () => {
    setRefreshing(true);
    loadData();
  };

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  // Filtered Payments
  const filteredPayments = useMemo(() => {
    return payments.filter((p) => {
      const matchesStatus = statusFilter === 'all' || p.status === statusFilter;
      const term = searchTerm.toLowerCase().trim();
      const matchesSearch =
        !term ||
        (p.studentName && p.studentName.toLowerCase().includes(term)) ||
        (p.studentEmail && p.studentEmail.toLowerCase().includes(term)) ||
        (p.courseTitle && p.courseTitle.toLowerCase().includes(term)) ||
        (p.orderId && p.orderId.toLowerCase().includes(term)) ||
        (p.paymentId && p.paymentId.toLowerCase().includes(term)) ||
        (p.couponCode && p.couponCode.toLowerCase().includes(term));

      return matchesStatus && matchesSearch;
    });
  }, [payments, statusFilter, searchTerm]);

  // Financial Metrics
  const metrics = useMemo(() => {
    const paidList = payments.filter((p) => p.status === 'paid');
    const totalRevenue = paidList.reduce((sum, p) => sum + (p.amount || 0), 0);
    const avgTicket = paidList.length > 0 ? Math.round(totalRevenue / paidList.length) : 0;
    const withCouponCount = paidList.filter((p) => p.couponCode).length;

    return {
      totalRevenue,
      paidCount: paidList.length,
      avgTicket,
      withCouponCount,
    };
  }, [payments]);

  return (
    <div id="admin-payments-page" className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-extrabold text-slate-900 tracking-tight flex items-center gap-2">
            <CreditCard className="w-6 h-6 text-blue-600" />
            <span>Payments & Transactions</span>
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Real-time Razorpay financial reconciliation, orders, and student access unlocks.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            id="refresh-payments-btn"
            type="button"
            onClick={handleRefresh}
            disabled={refreshing || loading}
            className="inline-flex items-center gap-2 px-3.5 py-2 text-xs font-semibold rounded-xl bg-white border border-slate-200 text-slate-700 hover:bg-slate-50 transition-colors shadow-xs disabled:opacity-50"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${refreshing ? 'animate-spin' : ''}`} />
            Refresh
          </button>
        </div>
      </div>

      {/* Gateway Configuration Diagnostic Banner */}
      <div
        id="gateway-status-card"
        className={`p-4 rounded-2xl border ${
          configStatus.configured
            ? 'bg-emerald-50/70 border-emerald-200 text-emerald-900'
            : 'bg-amber-50/80 border-amber-200 text-amber-900'
        } flex flex-col gap-3`}
      >
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-start gap-3">
            <div
              className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${
                configStatus.configured ? 'bg-emerald-600 text-white' : 'bg-amber-600 text-white'
              }`}
            >
              {configStatus.configured ? (
                <ShieldCheck className="w-5 h-5" />
              ) : (
                <AlertCircle className="w-5 h-5" />
              )}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-sm font-bold">
                  {configStatus.configured
                    ? 'Razorpay Gateway Live & Operational'
                    : 'Razorpay Gateway Not Configured'}
                </h2>
                <span
                  className={`text-[10px] font-bold px-2 py-0.5 rounded-md ${
                    configStatus.configured
                      ? 'bg-emerald-100 text-emerald-800'
                      : 'bg-amber-100 text-amber-800'
                  }`}
                >
                  {configStatus.configured ? 'PRODUCTION READY' : 'ACTION REQUIRED'}
                </span>
              </div>
              <p className="text-xs opacity-90 mt-0.5">
                {configStatus.configured
                  ? `Key ID: ${configStatus.keyId} • Secret securely isolated on backend.`
                  : 'RAZORPAY_KEY_ID or RAZORPAY_KEY_SECRET missing in environment settings.'}
              </p>
            </div>
          </div>

          {configStatus.configured && (
            <button
              type="button"
              onClick={handleTestConnection}
              disabled={testingConnection}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white border border-emerald-300 text-emerald-800 hover:bg-emerald-100/70 text-xs font-bold transition-colors shadow-2xs self-start sm:self-auto disabled:opacity-60"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${testingConnection ? 'animate-spin' : ''}`} />
              {testingConnection ? 'Testing Connection...' : 'Test Gateway Connection'}
            </button>
          )}
        </div>

        {/* Live Test Diagnostic Output */}
        {testResult && (
          <div
            className={`p-3 rounded-xl border text-xs animate-in fade-in duration-150 ${
              testResult.success
                ? 'bg-emerald-100/80 border-emerald-300 text-emerald-950'
                : 'bg-rose-50 border-rose-300 text-rose-950'
            }`}
          >
            <div className="flex items-start gap-2">
              {testResult.success ? (
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              ) : (
                <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
              )}
              <div className="space-y-1">
                <p className="font-bold">
                  {testResult.success ? 'Gateway Verified' : 'Gateway Connection Failed'}
                </p>
                <p className="text-[11px] leading-relaxed">
                  {testResult.message || testResult.error}
                </p>
                {!testResult.success && testResult.statusCode === 401 && (
                  <div className="mt-2 p-2 bg-white/80 rounded-lg border border-rose-200 text-[11px] space-y-1">
                    <p className="font-bold text-rose-900">How to fix this:</p>
                    <ol className="list-decimal pl-4 space-y-0.5 text-slate-700">
                      <li>Go to your <strong>Razorpay Dashboard</strong> (<a href="https://dashboard.razorpay.com" target="_blank" rel="noreferrer" className="text-blue-600 underline">dashboard.razorpay.com</a>).</li>
                      <li>Navigate to <strong>Account &amp; Settings &gt; API Keys</strong>.</li>
                      <li>Generate a new Key or copy your current matching <strong>Key Secret</strong>.</li>
                      <li>Update <code>RAZORPAY_KEY_SECRET</code> in the project <code>.env</code> file.</li>
                    </ol>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-4 rounded-2xl bg-white border border-slate-200/80 shadow-xs space-y-2">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-xs font-semibold uppercase tracking-wider">Total Net Revenue</span>
            <TrendingUp className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-2xl font-extrabold text-slate-900">
            {formatCurrency(metrics.totalRevenue)}
          </div>
          <p className="text-[11px] text-slate-400">Verified successful settlements</p>
        </div>

        <div className="p-4 rounded-2xl bg-white border border-slate-200/80 shadow-xs space-y-2">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-xs font-semibold uppercase tracking-wider">Completed Orders</span>
            <Receipt className="w-4 h-4 text-blue-600" />
          </div>
          <div className="text-2xl font-extrabold text-slate-900">{metrics.paidCount}</div>
          <p className="text-[11px] text-slate-400">Verified access grants</p>
        </div>

        <div className="p-4 rounded-2xl bg-white border border-slate-200/80 shadow-xs space-y-2">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-xs font-semibold uppercase tracking-wider">Avg Order Value</span>
            <CreditCard className="w-4 h-4 text-indigo-600" />
          </div>
          <div className="text-2xl font-extrabold text-slate-900">
            {formatCurrency(metrics.avgTicket)}
          </div>
          <p className="text-[11px] text-slate-400">Per verified enrollment</p>
        </div>

        <div className="p-4 rounded-2xl bg-white border border-slate-200/80 shadow-xs space-y-2">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-xs font-semibold uppercase tracking-wider">Coupons Redeemed</span>
            <Tag className="w-4 h-4 text-purple-600" />
          </div>
          <div className="text-2xl font-extrabold text-slate-900">{metrics.withCouponCount}</div>
          <p className="text-[11px] text-slate-400">Discounts utilized by students</p>
        </div>
      </div>

      {/* Filter & Search Bar */}
      <div className="p-3 bg-white rounded-2xl border border-slate-200/80 shadow-xs flex flex-col sm:flex-row items-center gap-3">
        <div className="relative flex-1 w-full">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            id="search-payments-input"
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search by student name, email, course, order or payment ID..."
            className="w-full pl-9 pr-4 py-2 text-xs rounded-xl border border-slate-200 focus:outline-hidden focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
          />
        </div>

        <div className="flex items-center gap-1 w-full sm:w-auto overflow-x-auto">
          {(['all', 'paid', 'created', 'failed'] as const).map((status) => (
            <button
              key={status}
              type="button"
              onClick={() => setStatusFilter(status)}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold capitalize whitespace-nowrap transition-colors ${
                statusFilter === status
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              {status === 'all' ? 'All Transactions' : status}
            </button>
          ))}
        </div>
      </div>

      {/* Payments List Table */}
      <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden">
        {loading ? (
          <div className="p-12 text-center text-slate-400 text-xs animate-pulse">
            Loading authoritative payment records...
          </div>
        ) : filteredPayments.length === 0 ? (
          <div className="p-12 text-center text-slate-500 space-y-3">
            <Receipt className="w-10 h-10 text-slate-300 mx-auto" />
            <p className="text-sm font-semibold text-slate-700">No payment transactions found</p>
            <p className="text-xs text-slate-400 max-w-sm mx-auto">
              When students purchase paid batches through the Razorpay gateway, verified transactions and
              audit logs will appear here.
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-slate-600">
              <thead className="bg-slate-50 border-b border-slate-200 text-[11px] font-bold text-slate-500 uppercase tracking-wider">
                <tr>
                  <th className="py-3 px-4">Date & Time</th>
                  <th className="py-3 px-4">Student</th>
                  <th className="py-3 px-4">Course Batch</th>
                  <th className="py-3 px-4">Amount</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4">Gateway IDs</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 font-normal">
                {filteredPayments.map((payment) => (
                  <tr key={payment.id} className="hover:bg-slate-50/80 transition-colors">
                    <td className="py-3.5 px-4 whitespace-nowrap">
                      <div className="font-medium text-slate-900">
                        {new Date(payment.createdAt).toLocaleDateString('en-IN', {
                          day: 'numeric',
                          month: 'short',
                          year: 'numeric',
                        })}
                      </div>
                      <div className="text-[11px] text-slate-400">
                        {new Date(payment.createdAt).toLocaleTimeString('en-IN', {
                          hour: '2-digit',
                          minute: '2-digit',
                        })}
                      </div>
                    </td>

                    <td className="py-3.5 px-4 min-w-[180px]">
                      <div className="font-semibold text-slate-900 truncate">
                        {payment.studentName || 'Student'}
                      </div>
                      <div className="text-[11px] text-slate-400 truncate">
                        {payment.studentEmail || payment.userId}
                      </div>
                    </td>

                    <td className="py-3.5 px-4 min-w-[200px]">
                      <div className="font-medium text-slate-900 truncate">
                        {payment.courseTitle || payment.courseId}
                      </div>
                      {payment.couponCode && (
                        <div className="mt-0.5">
                          <span className="inline-flex items-center gap-1 text-[10px] font-mono font-bold text-emerald-700 bg-emerald-50 px-1.5 py-0.5 rounded border border-emerald-200">
                            <Tag className="w-2.5 h-2.5" />
                            {payment.couponCode}
                          </span>
                        </div>
                      )}
                    </td>

                    <td className="py-3.5 px-4 whitespace-nowrap font-bold text-slate-900">
                      {formatCurrency(payment.amount)}
                    </td>

                    <td className="py-3.5 px-4 whitespace-nowrap">
                      {payment.status === 'paid' ? (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800">
                          <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                          PAID
                        </span>
                      ) : payment.status === 'created' ? (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-800">
                          <Clock className="w-3 h-3 text-amber-600" />
                          PENDING
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-rose-100 text-rose-800">
                          <AlertCircle className="w-3 h-3 text-rose-600" />
                          FAILED
                        </span>
                      )}
                    </td>

                    <td className="py-3.5 px-4 min-w-[220px]">
                      <div className="space-y-1 font-mono text-[11px]">
                        <div className="flex items-center justify-between gap-2 group">
                          <span className="text-slate-400 text-[10px]">Order:</span>
                          <span className="text-slate-700 truncate max-w-[140px]">
                            {payment.orderId}
                          </span>
                          <button
                            type="button"
                            onClick={() => handleCopy(payment.orderId, `ord_${payment.id}`)}
                            className="text-slate-400 hover:text-slate-600 p-0.5 rounded"
                            title="Copy Order ID"
                          >
                            {copiedId === `ord_${payment.id}` ? (
                              <Check className="w-3 h-3 text-emerald-600" />
                            ) : (
                              <Copy className="w-3 h-3" />
                            )}
                          </button>
                        </div>

                        {payment.paymentId && (
                          <div className="flex items-center justify-between gap-2 group">
                            <span className="text-slate-400 text-[10px]">Pay ID:</span>
                            <span className="text-emerald-700 font-bold truncate max-w-[140px]">
                              {payment.paymentId}
                            </span>
                            <button
                              type="button"
                              onClick={() => handleCopy(payment.paymentId!, `pay_${payment.id}`)}
                              className="text-slate-400 hover:text-slate-600 p-0.5 rounded"
                              title="Copy Payment ID"
                            >
                              {copiedId === `pay_${payment.id}` ? (
                                <Check className="w-3 h-3 text-emerald-600" />
                              ) : (
                                <Copy className="w-3 h-3" />
                              )}
                            </button>
                          </div>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}

export default AdminPaymentsPage;
