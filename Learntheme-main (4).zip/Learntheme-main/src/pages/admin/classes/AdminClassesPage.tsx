/**
 * Axon Nursing Academy - Admin Classes CMS
 * Manage Class Names nested under Batch -> Subject -> Chapter.
 * Video lectures are managed in the dedicated Video Classes interface (/admin/video-classes).
 */
import React, { useState, useEffect, useMemo } from 'react';
import { useSearchParams, Link } from 'react-router-dom';
import {
  BookOpen,
  Plus,
  Search,
  Edit2,
  Trash2,
  Eye,
  EyeOff,
  Video,
  RefreshCw,
  X,
  CheckCircle2,
  AlertCircle,
} from 'lucide-react';
import { ROUTES } from '@/src/config/routes.config';
import { Badge } from '@/src/components/ui/Badge';
import { Button } from '@/src/components/ui/Button';
import { AdminPageHeader } from '@/src/components/admin/AdminPageHeader';
import { PublishStatusBadge } from '@/src/components/admin/StatusBadge';
import { ConfirmationModal } from '@/src/components/admin/ConfirmationModal';
import { getAllBatchesAdmin } from '@/src/services/firebase/adminBatchService';
import { getAllSubjectsAdmin } from '@/src/services/firebase/adminSubjectService';
import { getAllChaptersAdmin } from '@/src/services/firebase/adminChapterService';
import {
  getAllClassesAdmin,
  getClassesForChapterAdmin,
  subscribeToClassesAdmin,
  createClass,
  updateClass,
  deleteClass,
  toggleClassPublish,
  ClassFormData,
} from '@/src/services/firebase/adminClassService';
import { LmsClass, Chapter, Subject, Batch } from '@/src/types/lms.types';
import { useAuth } from '@/src/contexts/AuthContext';

export function AdminClassesPage() {
  const { currentUser } = useAuth();
  const [searchParams, setSearchParams] = useSearchParams();
  const selectedBatchId = searchParams.get('batchId') || '';
  const selectedSubjectId = searchParams.get('subjectId') || '';
  const selectedChapterId = searchParams.get('chapterId') || '';

  const [batches, setBatches] = useState<Batch[]>([]);
  const [allSubjects, setAllSubjects] = useState<Subject[]>([]);
  const [allChapters, setAllChapters] = useState<Chapter[]>([]);
  const [classes, setClasses] = useState<LmsClass[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  // Form Modal State (Class Name only)
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingClass, setEditingClass] = useState<LmsClass | null>(null);
  const [formData, setFormData] = useState<ClassFormData>({
    batchId: '',
    subjectId: '',
    chapterId: '',
    title: '',
    description: '',
    videoUrl: '',
    youtubeUrl: '',
    youtubeVideoId: '',
    videoProvider: 'youtube',
    durationMinutes: 0,
    thumbnailUrl: '',
    order: 1,
    isFree: false,
    isPublished: true,
  });

  const [submitting, setSubmitting] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);

  // Delete State
  const [deleteTarget, setDeleteTarget] = useState<LmsClass | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);

  const loadHierarchyData = async () => {
    try {
      const [bList, sList, cList] = await Promise.all([
        getAllBatchesAdmin(),
        getAllSubjectsAdmin(),
        getAllChaptersAdmin(),
      ]);
      setBatches(bList);
      setAllSubjects(sList);
      setAllChapters(cList);
    } catch (err) {
      console.warn('[AdminClassesPage] Error loading hierarchy data:', err);
    }
  };

  useEffect(() => {
    loadHierarchyData();

    const unsubscribe = subscribeToClassesAdmin(
      (clList) => {
        let filtered = clList;
        if (selectedChapterId) {
          filtered = filtered.filter((cl) => cl.chapterId === selectedChapterId);
        } else {
          if (selectedBatchId) filtered = filtered.filter((cl) => cl.batchId === selectedBatchId);
          if (selectedSubjectId) filtered = filtered.filter((cl) => cl.subjectId === selectedSubjectId);
        }
        setClasses(filtered);
        setLoading(false);
        setRefreshing(false);
      },
      selectedChapterId || undefined,
      (err) => {
        console.warn('[AdminClassesPage] Realtime subscription notice:', err);
        setLoading(false);
        setRefreshing(false);
      }
    );

    return () => unsubscribe();
  }, [selectedBatchId, selectedSubjectId, selectedChapterId]);

  // Filtered dropdown lists for page filter bar
  const filterSubjects = useMemo(() => {
    if (!selectedBatchId) return allSubjects;
    return allSubjects.filter((s) => s.batchId === selectedBatchId);
  }, [allSubjects, selectedBatchId]);

  const filterChapters = useMemo(() => {
    let list = allChapters;
    if (selectedBatchId) list = list.filter((c) => c.batchId === selectedBatchId);
    if (selectedSubjectId) list = list.filter((c) => c.subjectId === selectedSubjectId);
    return list;
  }, [allChapters, selectedBatchId, selectedSubjectId]);

  // Filtered dropdown lists inside the Modal Form
  const modalSubjects = useMemo(() => {
    if (!formData.batchId) return allSubjects;
    return allSubjects.filter((s) => s.batchId === formData.batchId);
  }, [allSubjects, formData.batchId]);

  const modalChapters = useMemo(() => {
    let list = allChapters;
    if (formData.batchId) list = list.filter((c) => c.batchId === formData.batchId);
    if (formData.subjectId) list = list.filter((c) => c.subjectId === formData.subjectId);
    return list;
  }, [allChapters, formData.batchId, formData.subjectId]);

  const handleRefresh = async () => {
    setRefreshing(true);
    try {
      await loadHierarchyData();
      let clList = selectedChapterId
        ? await getClassesForChapterAdmin(selectedChapterId)
        : await getAllClassesAdmin();
      if (selectedBatchId && !selectedChapterId) clList = clList.filter((cl) => cl.batchId === selectedBatchId);
      if (selectedSubjectId && !selectedChapterId) clList = clList.filter((cl) => cl.subjectId === selectedSubjectId);
      setClasses(clList);
    } catch (err) {
      console.warn('[AdminClassesPage] Refresh notice:', err);
    } finally {
      setRefreshing(false);
    }
  };

  const handleBatchChange = (bId: string) => {
    const params = new URLSearchParams(searchParams);
    if (bId) params.set('batchId', bId);
    else params.delete('batchId');
    params.delete('subjectId');
    params.delete('chapterId');
    setSearchParams(params);
  };

  const handleSubjectChange = (sId: string) => {
    const params = new URLSearchParams(searchParams);
    if (sId) params.set('subjectId', sId);
    else params.delete('subjectId');
    params.delete('chapterId');
    setSearchParams(params);
  };

  const handleChapterChange = (cId: string) => {
    const params = new URLSearchParams(searchParams);
    if (cId) params.set('chapterId', cId);
    else params.delete('chapterId');
    setSearchParams(params);
  };

  const handleOpenCreate = () => {
    setEditingClass(null);
    const defaultBatchId = selectedBatchId || batches[0]?.id || '';
    const subForBatch = allSubjects.filter((s) => !defaultBatchId || s.batchId === defaultBatchId);
    const defaultSubjectId = selectedSubjectId || subForBatch[0]?.id || '';
    const chapForSub = allChapters.filter(
      (c) => (!defaultBatchId || c.batchId === defaultBatchId) && (!defaultSubjectId || c.subjectId === defaultSubjectId)
    );
    const defaultChapterId = selectedChapterId || chapForSub[0]?.id || '';

    setFormData({
      batchId: defaultBatchId,
      subjectId: defaultSubjectId,
      chapterId: defaultChapterId,
      title: '',
      description: '',
      videoUrl: '',
      youtubeUrl: '',
      youtubeVideoId: '',
      videoProvider: 'youtube',
      durationMinutes: 0,
      thumbnailUrl: '',
      order: classes.length + 1,
      isFree: false,
      isPublished: true,
    });
    setFormError(null);
    setIsModalOpen(true);
  };

  const handleOpenEdit = (cls: LmsClass) => {
    setEditingClass(cls);
    setFormData({
      batchId: cls.batchId,
      subjectId: cls.subjectId,
      chapterId: cls.chapterId,
      title: cls.title,
      description: cls.description || '',
      videoUrl: cls.videoUrl || '',
      youtubeUrl: cls.youtubeUrl || '',
      youtubeVideoId: cls.youtubeVideoId || '',
      videoProvider: cls.videoProvider || 'youtube',
      durationMinutes: cls.durationMinutes || 0,
      thumbnailUrl: cls.thumbnailUrl || '',
      order: cls.order || 1,
      isFree: Boolean(cls.isFree),
      isPublished: Boolean(cls.isPublished),
    });
    setFormError(null);
    setIsModalOpen(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.title.trim()) {
      setFormError('Class name is required.');
      return;
    }
    if (!formData.batchId || !formData.subjectId || !formData.chapterId) {
      setFormError('Please select Batch, Subject, and Chapter.');
      return;
    }

    setSubmitting(true);
    setFormError(null);

    try {
      const actorUid = currentUser?.uid || 'admin';
      const actorEmail = currentUser?.email || 'pmgautamjaipur@gmail.com';

      if (editingClass) {
        const classId = editingClass.id;
        const updatedClass: LmsClass = {
          ...editingClass,
          batchId: formData.batchId,
          subjectId: formData.subjectId,
          chapterId: formData.chapterId,
          title: formData.title.trim(),
          description: formData.description.trim(),
          order: Number(formData.order) || 1,
          isPublished: Boolean(formData.isPublished),
          updatedAt: new Date().toISOString(),
        };

        setClasses((prev) => prev.map((c) => (c.id === classId ? updatedClass : c)));
        setIsModalOpen(false);

        await updateClass(
          classId,
          {
            batchId: formData.batchId,
            subjectId: formData.subjectId,
            chapterId: formData.chapterId,
            title: formData.title.trim(),
            description: formData.description.trim(),
            order: Number(formData.order) || 1,
            isPublished: Boolean(formData.isPublished),
          },
          actorUid,
          actorEmail
        );
      } else {
        const newCls = await createClass(
          {
            ...formData,
            title: formData.title.trim(),
            description: formData.description.trim(),
          },
          actorUid,
          actorEmail
        );
        setClasses((prev) => [...prev.filter((c) => c.id !== newCls.id), newCls]);
        setIsModalOpen(false);
      }
    } catch (err: any) {
      console.error('Error saving class:', err);
      setFormError(err?.message || 'Failed to save class.');
      handleRefresh();
    } finally {
      setSubmitting(false);
    }
  };

  const handleTogglePublish = async (cls: LmsClass) => {
    const nextState = !cls.isPublished;
    setClasses((prev) =>
      prev.map((c) => (c.id === cls.id ? { ...c, isPublished: nextState } : c))
    );

    try {
      await toggleClassPublish(
        cls.id,
        nextState,
        cls.title,
        currentUser?.uid || 'admin',
        currentUser?.email || 'pmgautamjaipur@gmail.com'
      );
    } catch (err) {
      console.error('Failed to toggle class status:', err);
      setClasses((prev) =>
        prev.map((c) => (c.id === cls.id ? { ...c, isPublished: cls.isPublished } : c))
      );
    }
  };

  const handleConfirmDelete = async () => {
    if (!deleteTarget) return;
    const targetId = deleteTarget.id;
    const targetTitle = deleteTarget.title;

    setClasses((prev) => prev.filter((c) => c.id !== targetId));
    setDeleteTarget(null);

    setIsDeleting(true);
    try {
      await deleteClass(
        targetId,
        targetTitle,
        currentUser?.uid || 'admin',
        currentUser?.email || 'pmgautamjaipur@gmail.com'
      );
    } catch (err) {
      console.error('Failed to delete class:', err);
      handleRefresh();
    } finally {
      setIsDeleting(false);
    }
  };

  const getChapterName = (chapId: string) => {
    return allChapters.find((c) => c.id === chapId)?.name || chapId;
  };

  const getSubjectName = (subId: string) => {
    return allSubjects.find((s) => s.id === subId)?.name || subId;
  };

  const filteredClasses = classes.filter((cls) => {
    return (
      cls.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (cls.description && cls.description.toLowerCase().includes(searchQuery.toLowerCase()))
    );
  });

  return (
    <div className="space-y-6 font-['Plus_Jakarta_Sans',sans-serif]">
      <AdminPageHeader
        title="Classes Management"
        description="Add and organize Class Names under your course chapters. Manage video lectures separately in Video Classes."
        breadcrumbs={[
          { label: 'Admin', path: ROUTES.ADMIN.DASHBOARD },
          { label: 'Chapters', path: ROUTES.ADMIN.CHAPTERS },
          { label: 'Classes' },
        ]}
        actions={
          <>
            <Link to={ROUTES.ADMIN.VIDEO_CLASSES}>
              <Button
                variant="outline"
                size="sm"
                leftIcon={<Video className="w-3.5 h-3.5 text-red-600" />}
              >
                Video Classes
              </Button>
            </Link>
            <Button
              variant="outline"
              size="sm"
              onClick={handleRefresh}
              isLoading={refreshing}
              leftIcon={<RefreshCw className="w-3.5 h-3.5" />}
            >
              Refresh
            </Button>
            <Button
              variant="primary"
              size="sm"
              onClick={handleOpenCreate}
              leftIcon={<Plus className="w-4 h-4" />}
            >
              Add Class Name
            </Button>
          </>
        }
      />

      {/* Cascading Filter Bar */}
      <div className="bg-white rounded-2xl border border-slate-200/80 p-3.5 sm:p-4 shadow-xs flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
        <div className="flex items-center gap-2 w-full md:w-auto flex-wrap">
          <select
            value={selectedBatchId}
            onChange={(e) => handleBatchChange(e.target.value)}
            className="flex-1 sm:flex-none px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-800 max-w-full sm:max-w-xs"
          >
            <option value="">All Batches</option>
            {batches.map((b) => (
              <option key={b.id} value={b.id}>
                {b.title}
              </option>
            ))}
          </select>

          <select
            value={selectedSubjectId}
            onChange={(e) => handleSubjectChange(e.target.value)}
            className="flex-1 sm:flex-none px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-800 max-w-full sm:max-w-xs"
          >
            <option value="">All Subjects</option>
            {filterSubjects.map((s) => (
              <option key={s.id} value={s.id}>
                {s.name}
              </option>
            ))}
          </select>

          <select
            value={selectedChapterId}
            onChange={(e) => handleChapterChange(e.target.value)}
            className="flex-1 sm:flex-none px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-800 max-w-full sm:max-w-xs"
          >
            <option value="">All Chapters</option>
            {filterChapters.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name}
              </option>
            ))}
          </select>
        </div>

        <div className="relative w-full md:w-64">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search class name..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-4 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
          />
        </div>
      </div>

      {/* Classes Table */}
      <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs min-w-[700px]">
            <thead className="bg-slate-50/80 text-slate-500 uppercase text-[10px] font-bold border-b border-slate-100">
              <tr>
                <th className="px-5 py-3.5">Order</th>
                <th className="px-5 py-3.5">Class Name</th>
                <th className="px-5 py-3.5">Parent Chapter</th>
                <th className="px-5 py-3.5">Subject</th>
                <th className="px-5 py-3.5">Video Lecture</th>
                <th className="px-5 py-3.5">Status</th>
                <th className="px-5 py-3.5 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-medium text-slate-700">
              {loading ? (
                <tr>
                  <td colSpan={7} className="px-5 py-12 text-center text-slate-400">
                    <RefreshCw className="w-5 h-5 animate-spin mx-auto mb-2 text-blue-600" />
                    Loading classes from Firestore...
                  </td>
                </tr>
              ) : filteredClasses.length === 0 ? (
                <tr>
                  <td colSpan={7} className="px-5 py-12 text-center text-slate-400">
                    No classes found. Click "Add Class Name" to create one.
                  </td>
                </tr>
              ) : (
                filteredClasses.map((cls) => {
                  const hasVideo = Boolean(cls.videoUrl || cls.youtubeVideoId);
                  return (
                    <tr key={cls.id} className="hover:bg-slate-50/70 transition-colors">
                      <td className="px-5 py-4 font-bold text-slate-400 font-mono">
                        #{cls.order}
                      </td>
                      <td className="px-5 py-4">
                        <div className="flex items-center gap-3">
                          <div className="w-9 h-9 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center shrink-0">
                            <BookOpen className="w-4 h-4" />
                          </div>
                          <div className="min-w-0">
                            <span className="font-extrabold text-slate-900 block text-sm">
                              {cls.title}
                            </span>
                            {cls.description && (
                              <span className="text-[11px] text-slate-400 truncate block max-w-xs">
                                {cls.description}
                              </span>
                            )}
                          </div>
                        </div>
                      </td>
                      <td className="px-5 py-4">
                        <Badge variant="purple" size="sm">
                          {getChapterName(cls.chapterId)}
                        </Badge>
                      </td>
                      <td className="px-5 py-4">
                        <Badge variant="blue" size="sm">
                          {getSubjectName(cls.subjectId)}
                        </Badge>
                      </td>
                      <td className="px-5 py-4">
                        <div className="flex items-center gap-2">
                          {hasVideo ? (
                            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-emerald-50 text-emerald-700 text-[11px] font-bold border border-emerald-200">
                              <CheckCircle2 className="w-3 h-3" />
                              Video Linked
                            </span>
                          ) : (
                            <span className="text-[11px] text-slate-400">No Video</span>
                          )}
                          <Link
                            to={`${ROUTES.ADMIN.VIDEO_CLASSES}?batchId=${cls.batchId}&subjectId=${cls.subjectId}&chapterId=${cls.chapterId}&classId=${cls.id}`}
                            className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-blue-50 hover:bg-blue-100 text-blue-700 font-bold text-[11px] transition-colors"
                          >
                            <Video className="w-3 h-3" />
                            <span>{hasVideo ? 'Manage Video' : '+ Add Video'}</span>
                          </Link>
                        </div>
                      </td>
                      <td className="px-5 py-4">
                        <PublishStatusBadge isPublished={cls.isPublished} />
                      </td>
                      <td className="px-5 py-4 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            type="button"
                            onClick={() => handleTogglePublish(cls)}
                            title={cls.isPublished ? 'Unpublish' : 'Publish'}
                            className={`p-1.5 rounded-lg border transition-colors ${
                              cls.isPublished
                                ? 'border-emerald-200 text-emerald-600 hover:bg-emerald-50'
                                : 'border-slate-200 text-slate-400 hover:bg-slate-100'
                            }`}
                          >
                            {cls.isPublished ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
                          </button>

                          <button
                            type="button"
                            onClick={() => handleOpenEdit(cls)}
                            title="Edit class name"
                            className="p-1.5 rounded-lg border border-slate-200 text-slate-600 hover:bg-slate-100 transition-colors"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>

                          <button
                            type="button"
                            onClick={() => setDeleteTarget(cls)}
                            title="Delete class"
                            className="p-1.5 rounded-lg border border-rose-200 text-rose-600 hover:bg-rose-50 transition-colors"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Create / Edit Class Name Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 overflow-y-auto">
          <div
            className="fixed inset-0 bg-slate-900/70"
            onClick={() => !submitting && setIsModalOpen(false)}
          />

          <div className="relative bg-white rounded-2xl border border-slate-200 shadow-2xl max-w-lg w-full p-6 space-y-5 my-8">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center">
                  <BookOpen className="w-4 h-4" />
                </div>
                <h3 className="text-base font-extrabold text-slate-900">
                  {editingClass ? 'Edit Class Name' : 'Add New Class Name'}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                disabled={submitting}
                className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {formError && (
              <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs font-semibold flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{formError}</span>
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-4 text-xs">
              <div className="space-y-1">
                <label className="font-bold text-slate-700">Course Batch *</label>
                <select
                  required
                  value={formData.batchId}
                  onChange={(e) => {
                    const nextBatchId = e.target.value;
                    const subsForBatch = allSubjects.filter((s) => s.batchId === nextBatchId);
                    const nextSubId = subsForBatch[0]?.id || '';
                    const chapsForSub = allChapters.filter(
                      (c) => c.batchId === nextBatchId && (!nextSubId || c.subjectId === nextSubId)
                    );
                    setFormData({
                      ...formData,
                      batchId: nextBatchId,
                      subjectId: nextSubId,
                      chapterId: chapsForSub[0]?.id || '',
                    });
                  }}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 font-medium bg-white"
                >
                  <option value="">Select batch...</option>
                  {batches.map((b) => (
                    <option key={b.id} value={b.id}>
                      {b.title}
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="font-bold text-slate-700">Subject *</label>
                  <select
                    required
                    value={formData.subjectId}
                    onChange={(e) => {
                      const nextSubId = e.target.value;
                      const chapsForSub = allChapters.filter((c) => c.subjectId === nextSubId);
                      setFormData({
                        ...formData,
                        subjectId: nextSubId,
                        chapterId: chapsForSub[0]?.id || '',
                      });
                    }}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 font-medium bg-white"
                  >
                    <option value="">Select subject...</option>
                    {modalSubjects.map((s) => (
                      <option key={s.id} value={s.id}>
                        {s.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="font-bold text-slate-700">Chapter *</label>
                  <select
                    required
                    value={formData.chapterId}
                    onChange={(e) => setFormData({ ...formData, chapterId: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 font-medium bg-white"
                  >
                    <option value="">Select chapter...</option>
                    {modalChapters.map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.name}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="space-y-1">
                <label className="font-bold text-slate-700">Class Name *</label>
                <input
                  type="text"
                  required
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  placeholder="e.g. Class 01 - Introduction & Clinical Concepts"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 font-semibold text-slate-900"
                />
              </div>

              <div className="space-y-1">
                <label className="font-bold text-slate-700">Description (Optional)</label>
                <textarea
                  rows={2}
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  placeholder="Optional summary or topic notes for this class"
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-200 font-medium"
                />
              </div>

              <div className="grid grid-cols-2 gap-3 items-end">
                <div className="space-y-1">
                  <label className="font-bold text-slate-700">Display Order</label>
                  <input
                    type="number"
                    min={1}
                    value={formData.order}
                    onChange={(e) => setFormData({ ...formData, order: Number(e.target.value) })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200"
                  />
                </div>

                <label className="flex items-center gap-2 p-2.5 rounded-xl border border-slate-200 bg-slate-50 cursor-pointer h-[38px]">
                  <input
                    type="checkbox"
                    checked={formData.isPublished}
                    onChange={(e) => setFormData({ ...formData, isPublished: e.target.checked })}
                    className="rounded text-blue-600"
                  />
                  <span className="font-bold text-slate-800 text-xs">Publish Class</span>
                </label>
              </div>

              <div className="flex items-center justify-end gap-2.5 pt-4 border-t border-slate-100">
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => setIsModalOpen(false)}
                  disabled={submitting}
                >
                  Cancel
                </Button>
                <Button type="submit" variant="primary" size="sm" isLoading={submitting}>
                  {editingClass ? 'Save Class Name' : 'Create Class'}
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Confirmation */}
      <ConfirmationModal
        isOpen={Boolean(deleteTarget)}
        title={`Delete Class: ${deleteTarget?.title}`}
        message="Are you sure you want to delete this class from Firestore?"
        confirmLabel="Delete Class"
        isDestructive
        isLoading={isDeleting}
        onConfirm={handleConfirmDelete}
        onCancel={() => setDeleteTarget(null)}
      />
    </div>
  );
}

export default AdminClassesPage;
