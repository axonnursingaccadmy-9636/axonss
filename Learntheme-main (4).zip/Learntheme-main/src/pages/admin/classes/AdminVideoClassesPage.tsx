/**
 * Axon Nursing Academy - Admin Video Classes CMS (/admin/video-classes)
 * Dedicated interface to add & manage YouTube Video Lectures, Video IDs,
 * thumbnails, durations, and demo access for Classes.
 */
import React, { useState, useEffect, useRef, useMemo } from 'react';
import { useSearchParams, Link } from 'react-router-dom';
import {
  Video,
  Plus,
  Search,
  Edit2,
  Trash2,
  Eye,
  EyeOff,
  Play,
  RefreshCw,
  X,
  Clock,
  CheckCircle2,
  Upload,
  AlertCircle,
  BookOpen,
} from 'lucide-react';
import { ROUTES } from '@/src/config/routes.config';
import { Badge } from '@/src/components/ui/Badge';
import { Button } from '@/src/components/ui/Button';
import { AdminPageHeader } from '@/src/components/admin/AdminPageHeader';
import { PublishStatusBadge, FreeBadge } from '@/src/components/admin/StatusBadge';
import { ConfirmationModal } from '@/src/components/admin/ConfirmationModal';
import { VideoPlayer } from '@/src/components/lms/VideoPlayer';
import { getAllBatchesAdmin } from '@/src/services/firebase/adminBatchService';
import { getAllSubjectsAdmin } from '@/src/services/firebase/adminSubjectService';
import { getAllChaptersAdmin } from '@/src/services/firebase/adminChapterService';
import {
  getAllClassesAdmin,
  getClassesForChapterAdmin,
  subscribeToClassesAdmin,
  createClass,
  updateClass,
  deleteClass,
  toggleClassPublish,
  ClassFormData,
} from '@/src/services/firebase/adminClassService';
import {
  extractYouTubeVideoId,
  buildYouTubeWatchUrl,
  buildYouTubeThumbnailUrl,
} from '@/src/lib/utils/youtubeUtils';
import { uploadThumbnailImage } from '@/src/services/firebase/storageService';
import { LmsClass, Chapter, Subject, Batch } from '@/src/types/lms.types';
import { useAuth } from '@/src/contexts/AuthContext';

export function AdminVideoClassesPage() {
  const { currentUser } = useAuth();
  const [searchParams, setSearchParams] = useSearchParams();
  const selectedBatchId = searchParams.get('batchId') || '';
  const selectedSubjectId = searchParams.get('subjectId') || '';
  const selectedChapterId = searchParams.get('chapterId') || '';
  const preselectedClassId = searchParams.get('classId') || '';

  const [batches, setBatches] = useState<Batch[]>([]);
  const [allSubjects, setAllSubjects] = useState<Subject[]>([]);
  const [allChapters, setAllChapters] = useState<Chapter[]>([]);
  const [allClasses, setAllClasses] = useState<LmsClass[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  // Video Preview Modal
  const [previewVideo, setPreviewVideo] = useState<LmsClass | null>(null);

  // Form Modal State
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingClass, setEditingClass] = useState<LmsClass | null>(null);
  const [targetClassId, setTargetClassId] = useState<string>('__new__');
  const [formData, setFormData] = useState<ClassFormData>({
    batchId: '',
    subjectId: '',
    chapterId: '',
    title: '',
    description: '',
    videoUrl: '',
    youtubeUrl: '',
    youtubeVideoId: '',
    videoProvider: 'youtube',
    durationMinutes: 45,
    thumbnailUrl: '',
    order: 1,
    isFree: false,
    isPublished: true,
  });

  // Live YouTube input state
  const [videoInputText, setVideoInputText] = useState('');
  const [detectedYouTubeId, setDetectedYouTubeId] = useState<string | null>(null);

  // Custom thumbnail upload state
  const [uploadingThumbnail, setUploadingThumbnail] = useState(false);
  const [thumbnailUploadProgress, setThumbnailUploadProgress] = useState<number | null>(null);
  const imageInputRef = useRef<HTMLInputElement | null>(null);

  const [submitting, setSubmitting] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);

  // Delete State
  const [deleteTarget, setDeleteTarget] = useState<LmsClass | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);

  const loadHierarchyData = async () => {
    try {
      const [bList, sList, cList] = await Promise.all([
        getAllBatchesAdmin(),
        getAllSubjectsAdmin(),
        getAllChaptersAdmin(),
      ]);
      setBatches(bList);
      setAllSubjects(sList);
      setAllChapters(cList);
    } catch (err) {
      console.warn('[AdminVideoClassesPage] Error loading hierarchy data:', err);
    }
  };

  useEffect(() => {
    loadHierarchyData();

    const unsubscribe = subscribeToClassesAdmin(
      (clList) => {
        setAllClasses(clList);
        setLoading(false);
        setRefreshing(false);
      },
      undefined,
      (err) => {
        console.warn('[AdminVideoClassesPage] Realtime subscription notice:', err);
        setLoading(false);
        setRefreshing(false);
      }
    );

    return () => unsubscribe();
  }, []);

  // Auto-open modal when navigated from Classes page with ?classId=...
  useEffect(() => {
    if (!loading && preselectedClassId && allClasses.length > 0) {
      const found = allClasses.find((c) => c.id === preselectedClassId);
      if (found) {
        handleOpenEdit(found);
        const nextParams = new URLSearchParams(searchParams);
        nextParams.delete('classId');
        setSearchParams(nextParams, { replace: true });
      }
    }
  }, [loading, preselectedClassId, allClasses]);

  // Filter dropdown lists for filter bar
  const filterSubjects = useMemo(() => {
    if (!selectedBatchId) return allSubjects;
    return allSubjects.filter((s) => s.batchId === selectedBatchId);
  }, [allSubjects, selectedBatchId]);

  const filterChapters = useMemo(() => {
    let list = allChapters;
    if (selectedBatchId) list = list.filter((c) => c.batchId === selectedBatchId);
    if (selectedSubjectId) list = list.filter((c) => c.subjectId === selectedSubjectId);
    return list;
  }, [allChapters, selectedBatchId, selectedSubjectId]);

  // Modal cascading lists
  const modalSubjects = useMemo(() => {
    if (!formData.batchId) return allSubjects;
    return allSubjects.filter((s) => s.batchId === formData.batchId);
  }, [allSubjects, formData.batchId]);

  const modalChapters = useMemo(() => {
    let list = allChapters;
    if (formData.batchId) list = list.filter((c) => c.batchId === formData.batchId);
    if (formData.subjectId) list = list.filter((c) => c.subjectId === formData.subjectId);
    return list;
  }, [allChapters, formData.batchId, formData.subjectId]);

  const modalChapterClasses = useMemo(() => {
    if (!formData.chapterId) return [];
    return allClasses.filter((c) => c.chapterId === formData.chapterId);
  }, [allClasses, formData.chapterId]);

  const handleRefresh = async () => {
    setRefreshing(true);
    try {
      await loadHierarchyData();
      const clList = await getAllClassesAdmin();
      setAllClasses(clList);
    } catch (err) {
      console.warn('[AdminVideoClassesPage] Refresh notice:', err);
    } finally {
      setRefreshing(false);
    }
  };

  const handleBatchChange = (bId: string) => {
    const params = new URLSearchParams(searchParams);
    if (bId) params.set('batchId', bId);
    else params.delete('batchId');
    params.delete('subjectId');
    params.delete('chapterId');
    setSearchParams(params);
  };

  const handleSubjectChange = (sId: string) => {
    const params = new URLSearchParams(searchParams);
    if (sId) params.set('subjectId', sId);
    else params.delete('subjectId');
    params.delete('chapterId');
    setSearchParams(params);
  };

  const handleChapterChange = (cId: string) => {
    const params = new URLSearchParams(searchParams);
    if (cId) params.set('chapterId', cId);
    else params.delete('chapterId');
    setSearchParams(params);
  };

  const handleVideoInputChange = (text: string) => {
    setVideoInputText(text);
    const ytId = extractYouTubeVideoId(text);
    setDetectedYouTubeId(ytId);

    if (ytId) {
      const autoThumb = buildYouTubeThumbnailUrl(ytId, 'hq');
      setFormData((prev) => ({
        ...prev,
        videoProvider: 'youtube',
        youtubeVideoId: ytId,
        youtubeUrl: text.startsWith('http') ? text : buildYouTubeWatchUrl(ytId),
        videoUrl: text.startsWith('http') ? text : buildYouTubeWatchUrl(ytId),
        thumbnailUrl: prev.thumbnailUrl || autoThumb,
      }));
    } else {
      setFormData((prev) => ({
        ...prev,
        videoUrl: text,
        youtubeVideoId: undefined,
        youtubeUrl: undefined,
        videoProvider: 'direct',
      }));
    }
  };

  const handleSelectExistingClassInModal = (classId: string) => {
    setTargetClassId(classId);
    if (classId === '__new__') {
      setEditingClass(null);
      setFormData((prev) => ({
        ...prev,
        title: '',
        description: '',
        order: modalChapterClasses.length + 1,
      }));
      return;
    }

    const found = allClasses.find((c) => c.id === classId);
    if (found) {
      setEditingClass(found);
      const initialInput = found.youtubeUrl || found.youtubeVideoId || found.videoUrl || '';
      setVideoInputText(initialInput);
      const ytId = found.youtubeVideoId || extractYouTubeVideoId(initialInput);
      setDetectedYouTubeId(ytId);

      setFormData({
        batchId: found.batchId,
        subjectId: found.subjectId,
        chapterId: found.chapterId,
        title: found.title,
        description: found.description || '',
        videoUrl: found.videoUrl || '',
        youtubeUrl: found.youtubeUrl || '',
        youtubeVideoId: found.youtubeVideoId || '',
        videoProvider: found.videoProvider || (ytId ? 'youtube' : 'direct'),
        durationMinutes: found.durationMinutes || 45,
        thumbnailUrl: found.thumbnailUrl || '',
        order: found.order || 1,
        isFree: Boolean(found.isFree),
        isPublished: Boolean(found.isPublished),
      });
    }
  };

  const handleOpenCreate = () => {
    const defaultBatchId = selectedBatchId || batches[0]?.id || '';
    const subForBatch = allSubjects.filter((s) => !defaultBatchId || s.batchId === defaultBatchId);
    const defaultSubjectId = selectedSubjectId || subForBatch[0]?.id || '';
    const chapForSub = allChapters.filter(
      (c) => (!defaultBatchId || c.batchId === defaultBatchId) && (!defaultSubjectId || c.subjectId === defaultSubjectId)
    );
    const defaultChapterId = selectedChapterId || chapForSub[0]?.id || '';
    const classesInChapter = allClasses.filter((c) => c.chapterId === defaultChapterId);
    const firstUnlinkedClass = classesInChapter.find((c) => !c.videoUrl && !c.youtubeVideoId) || classesInChapter[0];

    setThumbnailUploadProgress(null);
    setFormError(null);

    if (firstUnlinkedClass) {
      setTargetClassId(firstUnlinkedClass.id);
      setEditingClass(firstUnlinkedClass);
      const initialInput = firstUnlinkedClass.youtubeUrl || firstUnlinkedClass.youtubeVideoId || firstUnlinkedClass.videoUrl || '';
      setVideoInputText(initialInput);
      setDetectedYouTubeId(firstUnlinkedClass.youtubeVideoId || extractYouTubeVideoId(initialInput));
      setFormData({
        batchId: firstUnlinkedClass.batchId,
        subjectId: firstUnlinkedClass.subjectId,
        chapterId: firstUnlinkedClass.chapterId,
        title: firstUnlinkedClass.title,
        description: firstUnlinkedClass.description || '',
        videoUrl: firstUnlinkedClass.videoUrl || '',
        youtubeUrl: firstUnlinkedClass.youtubeUrl || '',
        youtubeVideoId: firstUnlinkedClass.youtubeVideoId || '',
        videoProvider: firstUnlinkedClass.videoProvider || 'youtube',
        durationMinutes: firstUnlinkedClass.durationMinutes || 45,
        thumbnailUrl: firstUnlinkedClass.thumbnailUrl || '',
        order: firstUnlinkedClass.order || 1,
        isFree: Boolean(firstUnlinkedClass.isFree),
        isPublished: Boolean(firstUnlinkedClass.isPublished),
      });
    } else {
      setTargetClassId('__new__');
      setEditingClass(null);
      setVideoInputText('');
      setDetectedYouTubeId(null);
      setFormData({
        batchId: defaultBatchId,
        subjectId: defaultSubjectId,
        chapterId: defaultChapterId,
        title: '',
        description: '',
        videoUrl: '',
        youtubeUrl: '',
        youtubeVideoId: '',
        videoProvider: 'youtube',
        durationMinutes: 45,
        thumbnailUrl: '',
        order: classesInChapter.length + 1,
        isFree: false,
        isPublished: true,
      });
    }

    setIsModalOpen(true);
  };

  const handleOpenEdit = (cls: LmsClass) => {
    setTargetClassId(cls.id);
    setEditingClass(cls);
    const initialInput = cls.youtubeUrl || cls.youtubeVideoId || cls.videoUrl || '';
    setVideoInputText(initialInput);
    const ytId = cls.youtubeVideoId || extractYouTubeVideoId(initialInput);
    setDetectedYouTubeId(ytId);
    setThumbnailUploadProgress(null);

    setFormData({
      batchId: cls.batchId,
      subjectId: cls.subjectId,
      chapterId: cls.chapterId,
      title: cls.title,
      description: cls.description || '',
      videoUrl: cls.videoUrl || '',
      youtubeUrl: cls.youtubeUrl || '',
      youtubeVideoId: cls.youtubeVideoId || '',
      videoProvider: cls.videoProvider || (ytId ? 'youtube' : 'direct'),
      durationMinutes: cls.durationMinutes || 45,
      thumbnailUrl: cls.thumbnailUrl || '',
      order: cls.order || 1,
      isFree: Boolean(cls.isFree),
      isPublished: Boolean(cls.isPublished),
    });
    setFormError(null);
    setIsModalOpen(true);
  };

  const handleThumbnailFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploadingThumbnail(true);
    setThumbnailUploadProgress(5);
    setFormError(null);
    try {
      const url = await uploadThumbnailImage(file, 'classes', {
        onProgress: (p) => setThumbnailUploadProgress(p),
      });
      setThumbnailUploadProgress(100);
      setFormData((prev) => ({ ...prev, thumbnailUrl: url }));
    } catch (err: any) {
      setFormError(err.message || 'Failed to upload thumbnail image.');
      setThumbnailUploadProgress(null);
    } finally {
      setUploadingThumbnail(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.title.trim()) {
      setFormError('Please select a Class or enter a Class Name.');
      return;
    }
    if (!formData.batchId || !formData.subjectId || !formData.chapterId) {
      setFormError('Please select Batch, Subject, and Chapter.');
      return;
    }
    if (!videoInputText.trim() && !formData.videoUrl && !formData.youtubeVideoId) {
      setFormError('Please enter a YouTube video URL or Video ID.');
      return;
    }

    setSubmitting(true);
    setFormError(null);

    try {
      const actorUid = currentUser?.uid || 'admin';
      const actorEmail = currentUser?.email || 'pmgautamjaipur@gmail.com';
      const ytId = detectedYouTubeId || extractYouTubeVideoId(videoInputText);
      const payload: ClassFormData = {
        ...formData,
        videoProvider: ytId ? 'youtube' : 'direct',
        youtubeVideoId: ytId || undefined,
        youtubeUrl: ytId ? (videoInputText.startsWith('http') ? videoInputText : buildYouTubeWatchUrl(ytId)) : undefined,
        videoUrl: videoInputText || (ytId ? buildYouTubeWatchUrl(ytId) : formData.videoUrl),
        thumbnailUrl:
          formData.thumbnailUrl ||
          (ytId ? buildYouTubeThumbnailUrl(ytId, 'hq') : ''),
      };

      if (editingClass) {
        const classId = editingClass.id;
        const updatedClass: LmsClass = {
          ...editingClass,
          ...payload,
          updatedAt: new Date().toISOString(),
        };

        setAllClasses((prev) => prev.map((c) => (c.id === classId ? updatedClass : c)));
        setIsModalOpen(false);

        await updateClass(classId, payload, actorUid, actorEmail);
      } else {
        const newCls = await createClass(payload, actorUid, actorEmail);
        setAllClasses((prev) => [...prev.filter((c) => c.id !== newCls.id), newCls]);
        setIsModalOpen(false);
      }
    } catch (err: any) {
      console.error('Error saving video class:', err);
      setFormError(err?.message || 'Failed to save video lecture.');
      handleRefresh();
    } finally {
      setSubmitting(false);
    }
  };

  const handleTogglePublish = async (cls: LmsClass) => {
    const nextState = !cls.isPublished;
    setAllClasses((prev) =>
      prev.map((c) => (c.id === cls.id ? { ...c, isPublished: nextState } : c))
    );

    try {
      await toggleClassPublish(
        cls.id,
        nextState,
        cls.title,
        currentUser?.uid || 'admin',
        currentUser?.email || 'pmgautamjaipur@gmail.com'
      );
    } catch (err) {
      console.error('Failed to toggle video class status:', err);
      setAllClasses((prev) =>
        prev.map((c) => (c.id === cls.id ? { ...c, isPublished: cls.isPublished } : c))
      );
    }
  };

  const handleConfirmDelete = async () => {
    if (!deleteTarget) return;
    const targetId = deleteTarget.id;
    const targetTitle = deleteTarget.title;

    setAllClasses((prev) => prev.filter((c) => c.id !== targetId));
    setDeleteTarget(null);

    setIsDeleting(true);
    try {
      await deleteClass(
        targetId,
        targetTitle,
        currentUser?.uid || 'admin',
        currentUser?.email || 'pmgautamjaipur@gmail.com'
      );
    } catch (err) {
      console.error('Failed to delete video class:', err);
      handleRefresh();
    } finally {
      setIsDeleting(false);
    }
  };

  const getChapterName = (chapId: string) => {
    return allChapters.find((c) => c.id === chapId)?.name || chapId;
  };

  const filteredVideoClasses = useMemo(() => {
    return allClasses.filter((cls) => {
      if (selectedBatchId && cls.batchId !== selectedBatchId) return false;
      if (selectedSubjectId && cls.subjectId !== selectedSubjectId) return false;
      if (selectedChapterId && cls.chapterId !== selectedChapterId) return false;

      const matchesSearch =
        cls.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        (cls.description && cls.description.toLowerCase().includes(searchQuery.toLowerCase())) ||
        (cls.youtubeVideoId && cls.youtubeVideoId.toLowerCase().includes(searchQuery.toLowerCase()));

      return matchesSearch;
    });
  }, [allClasses, selectedBatchId, selectedSubjectId, selectedChapterId, searchQuery]);

  return (
    <div className="space-y-6 font-['Plus_Jakarta_Sans',sans-serif]">
      <AdminPageHeader
        title="Video Classes"
        description="Attach and manage YouTube Video Lectures, Video IDs, thumbnails, and durations for your classes."
        breadcrumbs={[
          { label: 'Admin', path: ROUTES.ADMIN.DASHBOARD },
          { label: 'Classes', path: ROUTES.ADMIN.CLASSES },
          { label: 'Video Classes' },
        ]}
        actions={
          <>
            <Link to={ROUTES.ADMIN.CLASSES}>
              <Button
                variant="outline"
                size="sm"
                leftIcon={<BookOpen className="w-3.5 h-3.5 text-blue-600" />}
              >
                Manage Class Names
              </Button>
            </Link>
            <Button
              variant="outline"
              size="sm"
              onClick={handleRefresh}
              isLoading={refreshing}
              leftIcon={<RefreshCw className="w-3.5 h-3.5" />}
            >
              Refresh
            </Button>
            <Button
              variant="primary"
              size="sm"
              onClick={handleOpenCreate}
              leftIcon={<Plus className="w-4 h-4" />}
            >
              Add Video Class
            </Button>
          </>
        }
      />

      {/* Cascading Filter Bar */}
      <div className="bg-white rounded-2xl border border-slate-200/80 p-3.5 sm:p-4 shadow-xs flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
        <div className="flex items-center gap-2 w-full md:w-auto flex-wrap">
          <select
            value={selectedBatchId}
            onChange={(e) => handleBatchChange(e.target.value)}
            className="flex-1 sm:flex-none px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-800 max-w-full sm:max-w-xs"
          >
            <option value="">All Batches</option>
            {batches.map((b) => (
              <option key={b.id} value={b.id}>
                {b.title}
              </option>
            ))}
          </select>

          <select
            value={selectedSubjectId}
            onChange={(e) => handleSubjectChange(e.target.value)}
            className="flex-1 sm:flex-none px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-800 max-w-full sm:max-w-xs"
          >
            <option value="">All Subjects</option>
            {filterSubjects.map((s) => (
              <option key={s.id} value={s.id}>
                {s.name}
              </option>
            ))}
          </select>

          <select
            value={selectedChapterId}
            onChange={(e) => handleChapterChange(e.target.value)}
            className="flex-1 sm:flex-none px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-800 max-w-full sm:max-w-xs"
          >
            <option value="">All Chapters</option>
            {filterChapters.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name}
              </option>
            ))}
          </select>
        </div>

        <div className="relative w-full md:w-64">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search video classes or YouTube IDs..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-4 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
          />
        </div>
      </div>

      {/* Video Classes Table */}
      <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs min-w-[760px]">
            <thead className="bg-slate-50/80 text-slate-500 uppercase text-[10px] font-bold border-b border-slate-100">
              <tr>
                <th className="px-5 py-3.5">Order</th>
                <th className="px-5 py-3.5">Video Class / Lecture</th>
                <th className="px-5 py-3.5">Parent Chapter</th>
                <th className="px-5 py-3.5">Video Source</th>
                <th className="px-5 py-3.5">Duration</th>
                <th className="px-5 py-3.5">Access</th>
                <th className="px-5 py-3.5">Status</th>
                <th className="px-5 py-3.5 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-medium text-slate-700">
              {loading ? (
                <tr>
                  <td colSpan={8} className="px-5 py-12 text-center text-slate-400">
                    <RefreshCw className="w-5 h-5 animate-spin mx-auto mb-2 text-blue-600" />
                    Loading video classes from Firestore...
                  </td>
                </tr>
              ) : filteredVideoClasses.length === 0 ? (
                <tr>
                  <td colSpan={8} className="px-5 py-12 text-center text-slate-400">
                    No video classes found. Click "Add Video Class" to attach a video lecture.
                  </td>
                </tr>
              ) : (
                filteredVideoClasses.map((cls) => {
                  const hasVideo = Boolean(cls.videoUrl || cls.youtubeVideoId);
                  return (
                    <tr key={cls.id} className="hover:bg-slate-50/70 transition-colors">
                      <td className="px-5 py-4 font-bold text-slate-400 font-mono">
                        #{cls.order}
                      </td>
                      <td className="px-5 py-4">
                        <div className="flex items-center gap-3">
                          {hasVideo ? (
                            <button
                              type="button"
                              onClick={() => setPreviewVideo(cls)}
                              className="relative w-14 h-9 rounded-lg overflow-hidden bg-slate-900 shrink-0 group border border-slate-200"
                            >
                              {cls.thumbnailUrl || cls.youtubeVideoId ? (
                                <img
                                  src={
                                    cls.thumbnailUrl ||
                                    buildYouTubeThumbnailUrl(cls.youtubeVideoId || '', 'hq')
                                  }
                                  alt=""
                                  className="w-full h-full object-cover group-hover:opacity-75 transition-opacity"
                                />
                              ) : null}
                              <div className="absolute inset-0 flex items-center justify-center text-white">
                                <Play className="w-3.5 h-3.5 fill-white" />
                              </div>
                            </button>
                          ) : (
                            <button
                              type="button"
                              onClick={() => handleOpenEdit(cls)}
                              className="w-14 h-9 rounded-lg bg-amber-50 border border-amber-200 text-amber-700 flex items-center justify-center shrink-0 text-[10px] font-bold"
                              title="Click to attach video"
                            >
                              + Video
                            </button>
                          )}
                          <div className="min-w-0">
                            <span className="font-extrabold text-slate-900 block text-sm">
                              {cls.title}
                            </span>
                            <span className="text-[11px] text-slate-400 truncate block max-w-xs font-mono">
                              {cls.youtubeVideoId
                                ? `YouTube ID: ${cls.youtubeVideoId}`
                                : cls.videoUrl
                                ? cls.videoUrl
                                : 'No video URL attached yet'}
                            </span>
                          </div>
                        </div>
                      </td>
                      <td className="px-5 py-4">
                        <Badge variant="purple" size="sm">
                          {getChapterName(cls.chapterId)}
                        </Badge>
                      </td>
                      <td className="px-5 py-4">
                        {cls.youtubeVideoId ? (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-red-50 text-red-700 text-[10px] font-bold border border-red-200">
                            <span className="w-1.5 h-1.5 rounded-full bg-red-600"></span>
                            YouTube
                          </span>
                        ) : cls.videoUrl ? (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-blue-50 text-blue-700 text-[10px] font-bold border border-blue-200">
                            Direct Stream
                          </span>
                        ) : (
                          <button
                            type="button"
                            onClick={() => handleOpenEdit(cls)}
                            className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-amber-50 text-amber-700 text-[10px] font-bold border border-amber-200 hover:bg-amber-100"
                          >
                            + Add Video Link
                          </button>
                        )}
                      </td>
                      <td className="px-5 py-4 text-slate-600 font-semibold">
                        <div className="flex items-center gap-1">
                          <Clock className="w-3.5 h-3.5 text-slate-400" />
                          <span>{cls.durationMinutes || 0} mins</span>
                        </div>
                      </td>
                      <td className="px-5 py-4">
                        {cls.isFree ? (
                          <FreeBadge isFree={true} />
                        ) : (
                          <span className="text-slate-400 text-[11px]">Enrolled Only</span>
                        )}
                      </td>
                      <td className="px-5 py-4">
                        <PublishStatusBadge isPublished={cls.isPublished} />
                      </td>
                      <td className="px-5 py-4 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          {hasVideo && (
                            <button
                              type="button"
                              onClick={() => setPreviewVideo(cls)}
                              title="Preview video lecture"
                              className="p-1.5 rounded-lg border border-purple-200 text-purple-600 hover:bg-purple-50 transition-colors"
                            >
                              <Play className="w-3.5 h-3.5 fill-purple-600" />
                            </button>
                          )}

                          <button
                            type="button"
                            onClick={() => handleTogglePublish(cls)}
                            title={cls.isPublished ? 'Unpublish' : 'Publish'}
                            className={`p-1.5 rounded-lg border transition-colors ${
                              cls.isPublished
                                ? 'border-emerald-200 text-emerald-600 hover:bg-emerald-50'
                                : 'border-slate-200 text-slate-400 hover:bg-slate-100'
                            }`}
                          >
                            {cls.isPublished ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
                          </button>

                          <button
                            type="button"
                            onClick={() => handleOpenEdit(cls)}
                            title="Add or edit video lecture"
                            className="p-1.5 rounded-lg border border-slate-200 text-slate-600 hover:bg-slate-100 transition-colors"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>

                          <button
                            type="button"
                            onClick={() => setDeleteTarget(cls)}
                            title="Delete class"
                            className="p-1.5 rounded-lg border border-rose-200 text-rose-600 hover:bg-rose-50 transition-colors"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Video Preview Modal */}
      {previewVideo && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div
            className="fixed inset-0 bg-slate-950/85"
            onClick={() => setPreviewVideo(null)}
          />
          <div className="relative bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl max-w-3xl w-full overflow-hidden z-10">
            <div className="p-4 border-b border-slate-800 flex items-center justify-between">
              <div>
                <h3 className="text-sm font-bold text-white truncate max-w-md">
                  {previewVideo.title}
                </h3>
                <span className="text-[11px] text-slate-400">
                  {previewVideo.durationMinutes} mins • {previewVideo.isFree ? 'Free Preview' : 'Enrolled'} • {previewVideo.youtubeVideoId ? `YouTube (${previewVideo.youtubeVideoId})` : 'Direct Stream'}
                </span>
              </div>
              <button
                type="button"
                onClick={() => setPreviewVideo(null)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="bg-black aspect-video flex items-center justify-center">
              <VideoPlayer
                videoUrl={previewVideo.videoUrl}
                youtubeVideoId={previewVideo.youtubeVideoId}
                title={previewVideo.title}
                autoPlay
              />
            </div>
          </div>
        </div>
      )}

      {/* Create / Edit Video Class Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 overflow-y-auto">
          <div
            className="fixed inset-0 bg-slate-900/70"
            onClick={() => !submitting && setIsModalOpen(false)}
          />

          <div className="relative bg-white rounded-2xl border border-slate-200 shadow-2xl max-w-xl w-full p-6 space-y-5 my-8 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-red-50 text-red-600 flex items-center justify-center">
                  <Video className="w-4 h-4" />
                </div>
                <h3 className="text-base font-extrabold text-slate-900">
                  {editingClass ? `Video Lecture: ${editingClass.title}` : 'Add Video Class'}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                disabled={submitting}
                className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {formError && (
              <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs font-semibold flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{formError}</span>
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-4 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="space-y-1">
                  <label className="font-bold text-slate-700">Course Batch *</label>
                  <select
                    required
                    value={formData.batchId}
                    onChange={(e) => {
                      const nextBatchId = e.target.value;
                      const subs = allSubjects.filter((s) => s.batchId === nextBatchId);
                      const nextSubId = subs[0]?.id || '';
                      const chaps = allChapters.filter(
                        (c) => c.batchId === nextBatchId && (!nextSubId || c.subjectId === nextSubId)
                      );
                      const nextChapId = chaps[0]?.id || '';
                      setFormData({
                        ...formData,
                        batchId: nextBatchId,
                        subjectId: nextSubId,
                        chapterId: nextChapId,
                      });
                      setTargetClassId('__new__');
                      setEditingClass(null);
                    }}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 font-medium bg-white"
                  >
                    <option value="">Select batch...</option>
                    {batches.map((b) => (
                      <option key={b.id} value={b.id}>
                        {b.title}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="font-bold text-slate-700">Subject *</label>
                  <select
                    required
                    value={formData.subjectId}
                    onChange={(e) => {
                      const nextSubId = e.target.value;
                      const chaps = allChapters.filter((c) => c.subjectId === nextSubId);
                      setFormData({
                        ...formData,
                        subjectId: nextSubId,
                        chapterId: chaps[0]?.id || '',
                      });
                      setTargetClassId('__new__');
                      setEditingClass(null);
                    }}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 font-medium bg-white"
                  >
                    <option value="">Select subject...</option>
                    {modalSubjects.map((s) => (
                      <option key={s.id} value={s.id}>
                        {s.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="font-bold text-slate-700">Chapter *</label>
                  <select
                    required
                    value={formData.chapterId}
                    onChange={(e) => {
                      const nextChapId = e.target.value;
                      setFormData({ ...formData, chapterId: nextChapId });
                      const chapClasses = allClasses.filter((c) => c.chapterId === nextChapId);
                      if (chapClasses[0]) {
                        handleSelectExistingClassInModal(chapClasses[0].id);
                      } else {
                        setTargetClassId('__new__');
                        setEditingClass(null);
                      }
                    }}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 font-medium bg-white"
                  >
                    <option value="">Select chapter...</option>
                    {modalChapters.map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.name}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Select Class from Classes Page or Create New */}
              <div className="space-y-1.5 p-3 rounded-xl bg-blue-50/50 border border-blue-200/70">
                <label className="font-bold text-slate-800 block">
                  Select Class Name (from Classes) *
                </label>
                <select
                  value={targetClassId}
                  onChange={(e) => handleSelectExistingClassInModal(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 font-semibold text-slate-900 bg-white"
                >
                  {modalChapterClasses.map((c) => (
                    <option key={c.id} value={c.id}>
                      #{c.order} — {c.title} {c.videoUrl || c.youtubeVideoId ? '(Video Attached)' : '(No Video Yet)'}
                    </option>
                  ))}
                  <option value="__new__">+ Enter New Class Name Directly</option>
                </select>
              </div>

              <div className="space-y-1">
                <label className="font-bold text-slate-700">Class / Video Title *</label>
                <input
                  type="text"
                  required
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  placeholder="e.g. Class 01 - ECG Waveforms & Cardiac Arrhythmias"
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-200 font-medium"
                />
              </div>

              {/* YouTube Video URL / Video ID input */}
              <div className="space-y-1.5 p-3.5 rounded-2xl bg-slate-50 border border-slate-200/80">
                <div className="flex items-center justify-between">
                  <label className="font-bold text-slate-800 flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-red-600"></span>
                    YouTube Video URL or Video ID *
                  </label>
                  {detectedYouTubeId && (
                    <span className="text-[11px] font-bold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200 flex items-center gap-1">
                      <CheckCircle2 className="w-3 h-3" />
                      ID: {detectedYouTubeId}
                    </span>
                  )}
                </div>

                <input
                  type="text"
                  required
                  value={videoInputText}
                  onChange={(e) => handleVideoInputChange(e.target.value)}
                  placeholder="e.g. https://www.youtube.com/watch?v=dQw4w9WgXcQ or dQw4w9WgXcQ"
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-200 font-mono text-slate-800 bg-white"
                />
                <p className="text-[11px] text-slate-400">
                  Paste any YouTube watch link, youtu.be shortlink, YouTube Live link, or raw 11-char Video ID.
                </p>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="font-bold text-slate-700">Duration (Minutes)</label>
                  <input
                    type="number"
                    value={formData.durationMinutes}
                    onChange={(e) =>
                      setFormData({ ...formData, durationMinutes: Number(e.target.value) })
                    }
                    className="w-full px-3 py-2 rounded-xl border border-slate-200"
                  />
                </div>

                <div className="space-y-1">
                  <label className="font-bold text-slate-700">Display Order</label>
                  <input
                    type="number"
                    value={formData.order}
                    onChange={(e) => setFormData({ ...formData, order: Number(e.target.value) })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200"
                  />
                </div>
              </div>

              {/* Thumbnail URL with auto-preview & upload button */}
              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <label className="font-bold text-slate-700">Thumbnail Image URL</label>
                  <button
                    type="button"
                    onClick={() => imageInputRef.current?.click()}
                    disabled={uploadingThumbnail}
                    className="text-[11px] font-bold text-blue-600 hover:text-blue-700 flex items-center gap-1"
                  >
                    <Upload className="w-3 h-3" />
                    <span>
                      {uploadingThumbnail
                        ? `Uploading (${thumbnailUploadProgress ?? 0}%)...`
                        : 'Upload Custom Image'}
                    </span>
                  </button>
                  <input
                    ref={imageInputRef}
                    type="file"
                    accept="image/*"
                    onChange={handleThumbnailFileUpload}
                    className="hidden"
                  />
                </div>
                {thumbnailUploadProgress !== null && (
                  <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-200 space-y-1">
                    <div className="flex items-center justify-between text-[11px] font-extrabold">
                      <span className={thumbnailUploadProgress === 100 ? 'text-emerald-700' : 'text-blue-700'}>
                        {thumbnailUploadProgress === 100 ? 'Thumbnail Uploaded!' : 'Uploading Thumbnail...'}
                      </span>
                      <span className="font-mono">{thumbnailUploadProgress}%</span>
                    </div>
                    <div className="w-full h-2 bg-slate-200 rounded-full overflow-hidden">
                      <div
                        className={`h-full transition-all duration-150 ${
                          thumbnailUploadProgress === 100 ? 'bg-emerald-600' : 'bg-blue-600'
                        }`}
                        style={{ width: `${thumbnailUploadProgress}%` }}
                      />
                    </div>
                  </div>
                )}
                <input
                  type="url"
                  value={formData.thumbnailUrl}
                  onChange={(e) => setFormData({ ...formData, thumbnailUrl: e.target.value })}
                  placeholder="Auto-generated from YouTube or enter custom image URL"
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 text-[11px] font-mono"
                />
              </div>

              <div className="space-y-1">
                <label className="font-bold text-slate-700">Description & Key Takeaways</label>
                <textarea
                  rows={2}
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  placeholder="Summary of topics discussed in this video lecture"
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-200 font-medium"
                />
              </div>

              {/* Toggles */}
              <div className="pt-2 grid grid-cols-2 gap-3">
                <label className="flex items-center gap-2 p-2.5 rounded-xl border border-slate-200 bg-slate-50 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={formData.isPublished}
                    onChange={(e) => setFormData({ ...formData, isPublished: e.target.checked })}
                    className="rounded text-blue-600"
                  />
                  <span className="font-bold text-slate-800 text-xs">Publish to Students</span>
                </label>

                <label className="flex items-center gap-2 p-2.5 rounded-xl border border-slate-200 bg-slate-50 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={formData.isFree}
                    onChange={(e) => setFormData({ ...formData, isFree: e.target.checked })}
                    className="rounded text-blue-600"
                  />
                  <span className="font-bold text-slate-800 text-xs">Free Demo Preview</span>
                </label>
              </div>

              <div className="flex items-center justify-end gap-2.5 pt-4 border-t border-slate-100">
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => setIsModalOpen(false)}
                  disabled={submitting}
                >
                  Cancel
                </Button>
                <Button type="submit" variant="primary" size="sm" isLoading={submitting}>
                  {editingClass ? 'Save Video Lecture' : 'Publish Video Lecture'}
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Confirmation */}
      <ConfirmationModal
        isOpen={Boolean(deleteTarget)}
        title={`Delete Class: ${deleteTarget?.title}`}
        message="Are you sure you want to delete this video class from Firestore?"
        confirmLabel="Delete"
        isDestructive
        isLoading={isDeleting}
        onConfirm={handleConfirmDelete}
        onCancel={() => setDeleteTarget(null)}
      />
    </div>
  );
}

export default AdminVideoClassesPage;
