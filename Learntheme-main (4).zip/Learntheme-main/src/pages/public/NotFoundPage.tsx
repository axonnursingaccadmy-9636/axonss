/**
 * Axon Nursing Academy - 404 Not Found Page
 */
import React from 'react';
import { Link } from 'react-router-dom';
import { HelpCircle, Home, ArrowLeft } from 'lucide-react';
import { ROUTES } from '@/src/config/routes.config';
import { Button } from '@/src/components/ui/Button';

export function NotFoundPage() {
  return (
    <div className="min-h-[70vh] flex items-center justify-center p-4 text-center">
      <div className="max-w-md w-full bg-white rounded-3xl border border-slate-100 p-8 shadow-md">
        <div className="w-16 h-16 rounded-full bg-blue-50 text-blue-600 flex items-center justify-center mx-auto mb-4 border border-blue-100">
          <HelpCircle className="w-8 h-8" />
        </div>
        <h1 className="text-3xl font-extrabold text-slate-900 mb-1">404</h1>
        <h2 className="text-base font-bold text-slate-800 mb-2">Page Not Found</h2>
        <p className="text-xs text-slate-500 mb-6 leading-relaxed">
          The nursing resource or page you are looking for might have been moved or does not exist.
        </p>

        <div className="flex flex-col sm:flex-row gap-2.5 justify-center">
          <Link to={ROUTES.STUDENT.ROOT}>
            <Button variant="primary" size="sm" leftIcon={<Home className="w-4 h-4" />}>
              Student Portal
            </Button>
          </Link>
          <Link to={ROUTES.HOME}>
            <Button variant="outline" size="sm" leftIcon={<ArrowLeft className="w-4 h-4" />}>
              Public Home
            </Button>
          </Link>
        </div>
      </div>
    </div>
  );
}
export default NotFoundPage;
