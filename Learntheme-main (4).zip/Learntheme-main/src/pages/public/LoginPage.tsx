/**
 * Axon Nursing Academy - Login Page
 * Real Firebase Authentication Sign-In Screen utilizing reusable AuthLayout and useFormValidation.
 */
import React, { useEffect } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { Lock, Mail, ArrowRight, Loader2 } from 'lucide-react';
import { ROUTES } from '@/src/config/routes.config';
import { SITE_CONFIG } from '@/src/config/site.config';
import { Input } from '@/src/components/ui/Input';
import { Button } from '@/src/components/ui/Button';
import { AuthLayout } from '@/src/components/layout/AuthLayout';
import { useAuth } from '@/src/contexts/AuthContext';
import { useToast } from '@/src/hooks/useToast';
import { useFormValidation, validators } from '@/src/hooks/useFormValidation';

export function LoginPage() {
  const navigate = useNavigate();
  const location = useLocation();
  const { login, isAuthenticated, clearError } = useAuth();
  const { toast } = useToast();

  // If already logged in, redirect directly to student portal or targeted course
  const getDestination = () => {
    const searchParams = new URLSearchParams(location.search);
    const redirectParam = searchParams.get('redirect');
    if (redirectParam && redirectParam.startsWith('/')) {
      return redirectParam;
    }
    return (location.state as any)?.from?.pathname || ROUTES.STUDENT.ROOT;
  };

  useEffect(() => {
    if (isAuthenticated) {
      navigate(getDestination(), { replace: true });
    }
  }, [isAuthenticated, navigate, location]);

  const {
    values,
    errors,
    touched,
    isSubmitting,
    submitError,
    setSubmitError,
    handleChange,
    handleBlur,
    handleSubmit,
  } = useFormValidation({
    initialValues: {
      email: '',
      password: '',
    },
    validationSchema: {
      email: [
        validators.required('Please enter a valid email address.'),
        validators.email('Please enter a valid email address.'),
      ],
      password: [
        validators.required('Password is required.'),
      ],
    },
    onSubmit: async (formValues) => {
      clearError();
      try {
        await login(formValues.email.trim(), formValues.password);
        toast.success('Welcome back! You have signed in successfully.', {
          title: 'Sign In Successful',
        });
        navigate(getDestination(), { replace: true });
      } catch (err: any) {
        const message = err?.message || 'Incorrect email or password.';
        setSubmitError(message);
        toast.error(message, {
          title: 'Authentication Error',
        });
      }
    },
  });

  return (
    <AuthLayout
      title={`Sign In to ${SITE_CONFIG.shortName}`}
      subtitle="Access your courses, mock test scores, and live sessions"
      errorMessage={submitError}
      footerAction={{
        prompt: "Don't have an account yet?",
        actionText: 'Create Student Account',
        href: ROUTES.SIGNUP,
      }}
    >
      <form onSubmit={handleSubmit} className="space-y-4" noValidate>
        <Input
          id="login-email"
          label="Email Address"
          type="email"
          placeholder="student@example.com"
          value={values.email}
          onChange={(e) => handleChange('email', e.target.value)}
          onBlur={() => handleBlur('email')}
          error={touched.email ? errors.email : undefined}
          leftIcon={<Mail className="w-4 h-4" />}
          autoComplete="email"
          disabled={isSubmitting}
        />

        <Input
          id="login-password"
          label="Password"
          type="password"
          placeholder="••••••••"
          value={values.password}
          onChange={(e) => handleChange('password', e.target.value)}
          onBlur={() => handleBlur('password')}
          error={touched.password ? errors.password : undefined}
          leftIcon={<Lock className="w-4 h-4" />}
          autoComplete="current-password"
          disabled={isSubmitting}
        />

        <div className="flex items-center justify-between text-xs pt-1">
          <label className="flex items-center gap-2 cursor-pointer text-slate-600 font-medium select-none">
            <input
              type="checkbox"
              id="remember-me"
              className="rounded text-blue-600 focus:ring-blue-500"
              defaultChecked
            />
            <span>Remember me</span>
          </label>
          <Link
            to={ROUTES.FORGOT_PASSWORD}
            className="text-blue-600 hover:text-blue-700 font-semibold"
          >
            Forgot Password?
          </Link>
        </div>

        <Button
          id="login-submit-btn"
          type="submit"
          variant="primary"
          size="lg"
          fullWidth
          disabled={isSubmitting}
          rightIcon={
            isSubmitting ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : (
              <ArrowRight className="w-4 h-4" />
            )
          }
        >
          {isSubmitting ? 'Authenticating...' : 'Sign In'}
        </Button>
      </form>
    </AuthLayout>
  );
}

export default LoginPage;
