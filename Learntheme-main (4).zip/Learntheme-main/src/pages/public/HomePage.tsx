/**
 * Axon Nursing Academy - Public Landing Page
 */
import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import {
  Stethoscope,
  Sparkles,
  ShieldCheck,
  Award,
  Video,
  FileCheck,
  BookOpen,
  ArrowRight,
  CheckCircle2,
  Users,
  Layers,
  GraduationCap,
} from 'lucide-react';
import { SITE_CONFIG } from '@/src/config/site.config';
import { ROUTES } from '@/src/config/routes.config';
import { DEMO_CATEGORIES } from '@/src/data/demoData';
import { BatchCard } from '@/src/components/course/BatchCard';
import { CategoryCard } from '@/src/components/ui/CategoryCard';
import { Button } from '@/src/components/ui/Button';
import { Badge } from '@/src/components/ui/Badge';
import { SEO } from '@/src/components/common/SEO';
import { getPublishedBatches, subscribeToPublishedBatches } from '@/src/services/firebase/batchService';
import { fallbackStore } from '@/src/services/fallback/fallbackStore';
import { Batch } from '@/src/types/lms.types';

export function HomePage() {
  const [batches, setBatches] = useState<Batch[]>(() =>
    fallbackStore.getBatches().filter((b) => b.isPublished)
  );
  const [isLoadingBatches, setIsLoadingBatches] = useState<boolean>(true);

  useEffect(() => {
    let isMounted = true;
    getPublishedBatches()
      .then((data) => {
        if (isMounted) {
          setBatches(data || []);
          setIsLoadingBatches(false);
        }
      })
      .catch((err) => {
        console.warn('[HomePage] Could not fetch published batches:', err);
        if (isMounted) setIsLoadingBatches(false);
      });

    const unsubscribe = subscribeToPublishedBatches((liveBatches) => {
      if (isMounted) {
        setBatches(liveBatches || []);
        setIsLoadingBatches(false);
      }
    });

    return () => {
      isMounted = false;
      unsubscribe();
    };
  }, []);

  return (
    <div className="space-y-12 sm:space-y-16 pb-12">
      <SEO
        title="Premier Online Nursing Education"
        description="Ace NORCET, NCLEX-RN, CHO, and State Nursing exams with Axon Nursing Academy. Live interactive classes, clinical question banks, color-coded notes, and AI mentorship."
      />
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-b from-blue-50/70 via-white to-slate-50 pt-8 sm:pt-14 pb-12 border-b border-slate-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            {/* Left Hero Text */}
            <div className="lg:col-span-7 space-y-5 text-center lg:text-left">
              <div className="inline-flex items-center gap-2 bg-blue-100/80 text-blue-800 text-xs font-bold px-3 py-1 rounded-full border border-blue-200">
                <Sparkles className="w-3.5 h-3.5 text-blue-600" />
                <span>Premier Nursing LMS Platform</span>
              </div>

              <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-slate-900 tracking-tight leading-[1.15]">
                Ace <span className="text-blue-600">NORCET & NCLEX</span> With India's Top Nursing Educators
              </h1>

              <p className="text-sm sm:text-base text-slate-600 max-w-xl mx-auto lg:mx-0 leading-relaxed">
                Structured clinical video modules, system-wise color notes, exam-oriented MCQs with rationales, and live doubt solving designed for ambitious nurses.
              </p>

              {/* CTAs */}
              <div className="flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-3 pt-2">
                <Link to={ROUTES.STUDENT.ROOT} className="w-full sm:w-auto">
                  <Button size="lg" variant="primary" fullWidth rightIcon={<ArrowRight className="w-4 h-4" />}>
                    Open Student Portal
                  </Button>
                </Link>
                <Link to={ROUTES.STUDENT.ALL_COURSES} className="w-full sm:w-auto">
                  <Button size="lg" variant="outline" fullWidth>
                    Browse All Batches
                  </Button>
                </Link>
              </div>

              {/* Realistic Core Academic Pillars */}
              <div className="grid grid-cols-3 gap-3 pt-4 border-t border-slate-200/80 max-w-md mx-auto lg:mx-0 text-center lg:text-left">
                <div>
                  <div className="text-base sm:text-lg font-bold text-slate-900 flex items-center justify-center lg:justify-start gap-1">
                    <GraduationCap className="w-4 h-4 text-blue-600" />
                    <span>Clinical</span>
                  </div>
                  <div className="text-[11px] text-slate-500 font-medium">Concept Focused</div>
                </div>
                <div>
                  <div className="text-base sm:text-lg font-bold text-slate-900 flex items-center justify-center lg:justify-start gap-1">
                    <FileCheck className="w-4 h-4 text-emerald-600" />
                    <span>Updated</span>
                  </div>
                  <div className="text-[11px] text-slate-500 font-medium">AIIMS & NCLEX Pattern</div>
                </div>
                <div>
                  <div className="text-base sm:text-lg font-bold text-slate-900 flex items-center justify-center lg:justify-start gap-1">
                    <ShieldCheck className="w-4 h-4 text-indigo-600" />
                    <span>Verified</span>
                  </div>
                  <div className="text-[11px] text-slate-500 font-medium">Faculty Mentorship</div>
                </div>
              </div>
            </div>

            {/* Right Hero Image Card */}
            <div className="lg:col-span-5 relative">
              <div className="bg-white rounded-3xl p-4 shadow-xl border border-slate-200/90 relative z-10">
                <img
                  src="https://images.unsplash.com/photo-1576091160550-2173dba999ef?auto=format&fit=crop&w=800&q=80"
                  alt="Nursing education clinical lecture"
                  className="rounded-2xl w-full h-64 sm:h-72 object-cover"
                />

                <div className="mt-4 p-3 bg-blue-50 rounded-xl flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <div className="w-9 h-9 rounded-lg bg-blue-600 text-white flex items-center justify-center">
                      <Video className="w-5 h-5" />
                    </div>
                    <div>
                      <h4 className="text-xs font-bold text-slate-900">Next Live Class at 7:00 PM</h4>
                      <p className="text-[11px] text-slate-500">Cardiovascular Critical Care Series</p>
                    </div>
                  </div>
                  <Link to={ROUTES.STUDENT.ROOT}>
                    <Button size="sm" variant="primary">Join</Button>
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Target Exams & Category Cards */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="text-center max-w-2xl mx-auto mb-8">
          <Badge variant="blue" size="sm" className="mb-2">Target Programs</Badge>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900">
            Specialized Nursing Disciplines
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Choose your target competitive exam to view dedicated batches and study curriculum
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {DEMO_CATEGORIES.map((cat) => (
            <CategoryCard key={cat.id} category={cat} />
          ))}
        </div>
      </section>

      {/* Real Available Batches Showcase */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between mb-6">
          <div>
            <Badge variant="amber" size="sm" className="mb-2">Available Batches</Badge>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900">
              Coaching Batches & Courses
            </h2>
            <p className="text-xs sm:text-sm text-slate-500 mt-1">
              Active courses with complete theoretical mastery and clinical rationales
            </p>
          </div>
          <Link to={ROUTES.STUDENT.ALL_COURSES} className="mt-3 sm:mt-0">
            <Button variant="outline" size="sm" rightIcon={<ArrowRight className="w-3.5 h-3.5" />}>
              View All Batches
            </Button>
          </Link>
        </div>

        {isLoadingBatches && batches.length === 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {[1, 2, 3].map((i) => (
              <div key={i} className="bg-white rounded-2xl border border-slate-200 p-4 space-y-3 animate-pulse card-isolate">
                <div className="aspect-[16/10] bg-slate-200 rounded-xl w-full" style={{ aspectRatio: '16 / 10' }} />
                <div className="h-5 bg-slate-200 rounded w-3/4" />
                <div className="h-3 bg-slate-200 rounded w-full" />
              </div>
            ))}
          </div>
        ) : batches.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {batches.slice(0, 3).map((batch) => (
              <BatchCard key={batch.id} batch={batch} />
            ))}
          </div>
        ) : (
          <div className="bg-white rounded-2xl border border-slate-200 p-8 text-center">
            <BookOpen className="w-10 h-10 text-slate-300 mx-auto mb-2" />
            <h3 className="text-sm font-bold text-slate-800">No Batches Published Yet</h3>
            <p className="text-xs text-slate-500 mt-1">
              Batches created by the administration will appear here automatically.
            </p>
          </div>
        )}
      </section>

      {/* Realistic Academic Highlights */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="text-center max-w-2xl mx-auto mb-8">
          <Badge variant="emerald" size="sm" className="mb-2">Learning Methodology</Badge>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900">
            Why Prepare With Axon
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Built from ground up specifically for Indian and international nursing competitive exams
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
          <div className="bg-white p-5 sm:p-6 rounded-2xl border border-slate-200/80 shadow-xs">
            <div className="w-10 h-10 rounded-xl bg-blue-100 text-blue-700 flex items-center justify-center mb-4 font-bold">
              <Layers className="w-5 h-5" />
            </div>
            <h3 className="text-base font-bold text-slate-900 mb-1.5">
              Structured System-Wise Syllabus
            </h3>
            <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
              Every subject is systematically divided into chapters, high-definition video lectures, and color summary PDF notes.
            </p>
          </div>

          <div className="bg-white p-5 sm:p-6 rounded-2xl border border-slate-200/80 shadow-xs">
            <div className="w-10 h-10 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center mb-4 font-bold">
              <FileCheck className="w-5 h-5" />
            </div>
            <h3 className="text-base font-bold text-slate-900 mb-1.5">
              Chapter & Weekly Mock Tests
            </h3>
            <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
              Practice chapter-level unit tests and competitive Weekly Warrior tests with negative marking and detailed clinical rationales.
            </p>
          </div>

          <div className="bg-white p-5 sm:p-6 rounded-2xl border border-slate-200/80 shadow-xs">
            <div className="w-10 h-10 rounded-xl bg-purple-100 text-purple-700 flex items-center justify-center mb-4 font-bold">
              <Sparkles className="w-5 h-5" />
            </div>
            <h3 className="text-base font-bold text-slate-900 mb-1.5">
              Instant Clinical Doubt Solving
            </h3>
            <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
              Get immediate conceptual clarification and nursing protocol rationales through integrated AI Mentor and live faculty sessions.
            </p>
          </div>
        </div>
      </section>
    </div>
  );
}
export default HomePage;
