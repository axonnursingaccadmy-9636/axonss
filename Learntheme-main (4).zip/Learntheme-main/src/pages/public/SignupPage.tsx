/**
 * Axon Nursing Academy - Signup Page
 * Real Firebase Authentication Sign-Up Screen utilizing reusable AuthLayout and useFormValidation.
 */
import React, { useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { User, Mail, Lock, ArrowRight, Loader2 } from 'lucide-react';
import { ROUTES } from '@/src/config/routes.config';
import { Input } from '@/src/components/ui/Input';
import { Button } from '@/src/components/ui/Button';
import { AuthLayout } from '@/src/components/layout/AuthLayout';
import { useAuth } from '@/src/contexts/AuthContext';
import { useToast } from '@/src/hooks/useToast';
import { useFormValidation, validators } from '@/src/hooks/useFormValidation';

export function SignupPage() {
  const navigate = useNavigate();
  const location = useLocation();
  const { signUp, isAuthenticated, clearError } = useAuth();
  const { toast } = useToast();

  const getDestination = () => {
    const searchParams = new URLSearchParams(location.search);
    const redirectParam = searchParams.get('redirect');
    if (redirectParam && redirectParam.startsWith('/')) {
      return redirectParam;
    }
    return (location.state as any)?.from?.pathname || ROUTES.STUDENT.ROOT;
  };

  // If already logged in, redirect directly to student portal or course
  useEffect(() => {
    if (isAuthenticated) {
      navigate(getDestination(), { replace: true });
    }
  }, [isAuthenticated, navigate, location]);

  const {
    values,
    errors,
    touched,
    isSubmitting,
    submitError,
    setSubmitError,
    handleChange,
    handleBlur,
    handleSubmit,
  } = useFormValidation({
    initialValues: {
      fullName: '',
      email: '',
      password: '',
      confirmPassword: '',
    },
    validationSchema: {
      fullName: [
        validators.required('Full name is required.'),
        validators.minLength(2, 'Name must be at least 2 characters.'),
      ],
      email: [
        validators.required('Please enter a valid email address.'),
        validators.email('Please enter a valid email address.'),
      ],
      password: [
        validators.required('Password is required.'),
        validators.minLength(6, 'Password is too weak. Please use a stronger password.'),
      ],
      confirmPassword: [
        validators.required('Please confirm your password.'),
        validators.matches('password', 'Passwords do not match. Please verify.'),
      ],
    },
    onSubmit: async (formValues) => {
      clearError();
      try {
        await signUp(formValues.email.trim(), formValues.password, formValues.fullName.trim());
        toast.success(`Welcome to Axon Nursing Academy, ${formValues.fullName.trim()}! Your account has been created.`, {
          title: 'Account Created',
        });
        navigate(getDestination(), { replace: true });
      } catch (err: any) {
        const message = err?.message || 'Signup failed. Please try again.';
        setSubmitError(message);
        toast.error(message, {
          title: 'Registration Error',
        });
      }
    },
  });

  return (
    <AuthLayout
      title="Create Student Account"
      subtitle="Join thousands of nursing aspirants preparing for NORCET, NCLEX & State CHO"
      errorMessage={submitError}
      footerAction={{
        prompt: 'Already have an account?',
        actionText: 'Sign In',
        href: ROUTES.LOGIN,
      }}
    >
      <form onSubmit={handleSubmit} className="space-y-3.5" noValidate>
        <Input
          id="signup-fullname"
          label="Full Name"
          placeholder="e.g. Priya Sharma"
          value={values.fullName}
          onChange={(e) => handleChange('fullName', e.target.value)}
          onBlur={() => handleBlur('fullName')}
          error={touched.fullName ? errors.fullName : undefined}
          leftIcon={<User className="w-4 h-4" />}
          autoComplete="name"
          disabled={isSubmitting}
        />

        <Input
          id="signup-email"
          label="Email Address"
          type="email"
          placeholder="student@example.com"
          value={values.email}
          onChange={(e) => handleChange('email', e.target.value)}
          onBlur={() => handleBlur('email')}
          error={touched.email ? errors.email : undefined}
          leftIcon={<Mail className="w-4 h-4" />}
          autoComplete="email"
          disabled={isSubmitting}
        />

        <Input
          id="signup-password"
          label="Password"
          type="password"
          placeholder="At least 6 characters"
          value={values.password}
          onChange={(e) => handleChange('password', e.target.value)}
          onBlur={() => handleBlur('password')}
          error={touched.password ? errors.password : undefined}
          leftIcon={<Lock className="w-4 h-4" />}
          autoComplete="new-password"
          disabled={isSubmitting}
        />

        <Input
          id="signup-confirm-password"
          label="Confirm Password"
          type="password"
          placeholder="Re-enter password"
          value={values.confirmPassword}
          onChange={(e) => handleChange('confirmPassword', e.target.value)}
          onBlur={() => handleBlur('confirmPassword')}
          error={touched.confirmPassword ? errors.confirmPassword : undefined}
          leftIcon={<Lock className="w-4 h-4" />}
          autoComplete="new-password"
          disabled={isSubmitting}
        />

        <Button
          id="signup-submit-btn"
          type="submit"
          variant="primary"
          size="lg"
          fullWidth
          disabled={isSubmitting}
          rightIcon={
            isSubmitting ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : (
              <ArrowRight className="w-4 h-4" />
            )
          }
          className="mt-2"
        >
          {isSubmitting ? 'Creating Account...' : 'Create Account & Start Learning'}
        </Button>
      </form>
    </AuthLayout>
  );
}

export default SignupPage;
