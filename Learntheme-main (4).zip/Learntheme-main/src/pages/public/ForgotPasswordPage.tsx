/**
 * Axon Nursing Academy - Forgot Password Page
 * Real Firebase Authentication Password Reset Screen utilizing reusable AuthLayout and useFormValidation.
 */
import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Mail, ArrowRight, Loader2, CheckCircle2 } from 'lucide-react';
import { ROUTES } from '@/src/config/routes.config';
import { Input } from '@/src/components/ui/Input';
import { Button } from '@/src/components/ui/Button';
import { AuthLayout } from '@/src/components/layout/AuthLayout';
import { useAuth } from '@/src/contexts/AuthContext';
import { useToast } from '@/src/hooks/useToast';
import { useFormValidation, validators } from '@/src/hooks/useFormValidation';

export function ForgotPasswordPage() {
  const { resetPassword, clearError } = useAuth();
  const { toast } = useToast();
  const [isSubmitted, setIsSubmitted] = useState(false);

  const {
    values,
    errors,
    touched,
    isSubmitting,
    submitError,
    setSubmitError,
    handleChange,
    handleBlur,
    handleSubmit,
  } = useFormValidation({
    initialValues: {
      email: '',
    },
    validationSchema: {
      email: [
        validators.required('Please enter your registered email address.'),
        validators.email('Please enter a valid email address format.'),
      ],
    },
    onSubmit: async (formValues) => {
      clearError();
      try {
        await resetPassword(formValues.email.trim());
        setIsSubmitted(true);
        toast.success(`Password reset email sent to ${formValues.email.trim()}. Please check your inbox.`, {
          title: 'Reset Link Dispatched',
        });
      } catch (err: any) {
        const message =
          err?.message || 'Failed to dispatch password reset email. Please verify your email address.';
        setSubmitError(message);
        toast.error(message, {
          title: 'Reset Error',
        });
      }
    },
  });

  return (
    <AuthLayout
      title="Reset Your Password"
      subtitle="Enter your registered email and we will send password reset instructions"
      errorMessage={submitError}
      footerAction={{
        prompt: 'Remember your credentials?',
        actionText: 'Return to Sign In',
        href: ROUTES.LOGIN,
      }}
    >
      {isSubmitted ? (
        <div
          id="password-reset-success"
          className="bg-emerald-50 border border-emerald-200 rounded-2xl p-5 text-center text-xs space-y-3 animate-in fade-in duration-200"
        >
          <CheckCircle2 className="w-10 h-10 text-emerald-600 mx-auto" />
          <h3 className="font-bold text-slate-900 text-sm">Reset Link Dispatched</h3>
          <p className="text-slate-600 leading-relaxed">
            We have sent a secure password reset link to{' '}
            <strong className="text-slate-800">{values.email}</strong>. Please check your inbox and
            spam folder.
          </p>
          <Link to={ROUTES.LOGIN} className="inline-block pt-2">
            <Button size="sm" variant="primary">
              Return to Sign In
            </Button>
          </Link>
        </div>
      ) : (
        <form onSubmit={handleSubmit} className="space-y-4" noValidate>
          <Input
            id="forgot-password-email"
            label="Registered Email"
            type="email"
            placeholder="student@example.com"
            value={values.email}
            onChange={(e) => handleChange('email', e.target.value)}
            onBlur={() => handleBlur('email')}
            error={touched.email ? errors.email : undefined}
            leftIcon={<Mail className="w-4 h-4" />}
            autoComplete="email"
            disabled={isSubmitting}
          />

          <Button
            id="forgot-password-submit-btn"
            type="submit"
            variant="primary"
            size="lg"
            fullWidth
            disabled={isSubmitting}
            rightIcon={
              isSubmitting ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <ArrowRight className="w-4 h-4" />
              )
            }
          >
            {isSubmitting ? 'Sending Instructions...' : 'Send Password Reset Link'}
          </Button>
        </form>
      )}
    </AuthLayout>
  );
}

export default ForgotPasswordPage;
