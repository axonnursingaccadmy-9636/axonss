/**
 * Axon Nursing Academy - Student Enrolled Courses Page (Phase 6.1)
 * Displays active enrolled/purchased courses with direct access to curriculum
 * and Weekly Warrior competitive mock tests.
 */
import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import {
  BookOpen,
  Sparkles,
  ArrowRight,
  ShieldCheck,
  Clock,
  PlayCircle,
  Award,
  RefreshCw,
} from 'lucide-react';
import { useAuth } from '@/src/contexts/AuthContext';
import { getStudentActiveEnrollments } from '@/src/services/firebase/enrollmentService';
import { getBatchById } from '@/src/services/firebase/batchService';
import { ROUTES } from '@/src/config/routes.config';
import { Button } from '@/src/components/ui/Button';
import { Badge } from '@/src/components/ui/Badge';
import { Enrollment } from '@/src/types/enrollment.types';
import { Batch } from '@/src/types/lms.types';

interface EnrolledBatchItem {
  enrollment: Enrollment;
  batch: Batch | null;
}

export function StudentCoursesPage() {
  const { currentUser } = useAuth();
  const [enrolledBatches, setEnrolledBatches] = useState<EnrolledBatchItem[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let isMounted = true;

    async function loadEnrollments() {
      if (!currentUser) {
        setLoading(false);
        return;
      }

      try {
        const enrollments = await getStudentActiveEnrollments(currentUser.uid);
        const batchPromises = enrollments.map(async (enr) => {
          const b = await getBatchById(enr.batchId);
          return { enrollment: enr, batch: b };
        });

        const items = await Promise.all(batchPromises);
        if (isMounted) {
          setEnrolledBatches(items);
        }
      } catch (err) {
        console.error('[StudentCoursesPage] Failed to load enrollments:', err);
      } finally {
        if (isMounted) setLoading(false);
      }
    }

    loadEnrollments();
    return () => {
      isMounted = false;
    };
  }, [currentUser?.uid]);

  return (
    <div id="student-courses-page" className="space-y-6 animate-in fade-in duration-150 pb-12">
      {/* Page Title Header */}
      <div className="bg-white rounded-2xl border border-slate-100 p-4 sm:p-5 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-lg sm:text-xl font-extrabold text-slate-900">
            My Enrolled Batches
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
            Access your registered nursing courses, recorded classes, and Weekly Warrior tests
          </p>
        </div>

        <Link to={ROUTES.STUDENT.ALL_COURSES}>
          <Button variant="primary" size="sm" rightIcon={<ArrowRight className="w-3.5 h-3.5" />}>
            Explore All Courses
          </Button>
        </Link>
      </div>

      {loading ? (
        <div className="p-12 text-center bg-white rounded-2xl border border-slate-200">
          <RefreshCw className="w-6 h-6 text-blue-600 animate-spin mx-auto mb-2" />
          <p className="text-xs text-slate-500">Checking course enrollments...</p>
        </div>
      ) : enrolledBatches.length > 0 ? (
        /* Enrolled Courses Grid */
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {enrolledBatches.map(({ enrollment, batch }) => {
            const courseTitle = batch?.title || enrollment.courseTitle || 'Nursing Coaching Batch';
            const courseThumb =
              batch?.thumbnailUrl ||
              enrollment.courseThumbnail ||
              'https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?w=800&auto=format&fit=crop&q=80';
            const duration = batch?.duration || (batch?.durationDays ? `${batch.durationDays} Days` : 'Full Access');

            return (
              <div
                key={enrollment.id}
                className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-xs hover:shadow-md hover:border-blue-300 transition-all flex flex-col justify-between"
              >
                <div>
                  <div className="relative h-44 w-full bg-slate-900 overflow-hidden">
                    <img
                      src={courseThumb}
                      alt={courseTitle}
                      className="w-full h-full object-cover opacity-90"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-transparent" />
                    <div className="absolute top-3 left-3">
                      <Badge variant="emerald" size="sm">
                        ACTIVE ENROLLMENT
                      </Badge>
                    </div>
                  </div>

                  <div className="p-4 space-y-2">
                    <h3 className="font-bold text-slate-900 text-sm line-clamp-1">
                      {courseTitle}
                    </h3>
                    <p className="text-xs text-slate-500 line-clamp-2">
                      {batch?.shortDescription ||
                        'Full curriculum access including recorded lectures and Weekly Warrior tests.'}
                    </p>

                    <div className="pt-2 flex items-center gap-3 text-xs text-slate-500">
                      <span className="flex items-center gap-1">
                        <Clock className="w-3.5 h-3.5 text-blue-600" /> {duration}
                      </span>
                      {enrollment.expiresAt && (
                        <span>• Valid till {new Date(enrollment.expiresAt).toLocaleDateString()}</span>
                      )}
                    </div>
                  </div>
                </div>

                <div className="p-4 pt-0">
                  <Link
                    to={`/course/${enrollment.batchId}`}
                    className="w-full flex items-center justify-center gap-2 py-2 px-3 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-semibold shadow-xs transition-colors"
                  >
                    <PlayCircle className="w-4 h-4" />
                    Open Course Overview
                  </Link>
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        /* Empty State */
        <div className="bg-white rounded-3xl border border-slate-200 p-8 sm:p-12 text-center max-w-2xl mx-auto shadow-xs">
          <div className="w-16 h-16 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center mx-auto mb-4 border border-blue-100">
            <BookOpen className="w-8 h-8" />
          </div>
          <h2 className="text-base sm:text-lg font-bold text-slate-900">
            No enrolled courses yet.
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 mt-1.5 max-w-md mx-auto leading-relaxed">
            You haven't enrolled in any coaching batch yet. Explore our AIIMS NORCET, NCLEX-RN, and
            State CHO foundation batches in the course catalog.
          </p>

          <div className="mt-6 flex flex-wrap items-center justify-center gap-3">
            <Link to={ROUTES.STUDENT.ALL_COURSES}>
              <Button variant="primary" size="md" leftIcon={<Sparkles className="w-4 h-4" />}>
                Browse Course Catalog
              </Button>
            </Link>
          </div>

          <div className="mt-8 pt-6 border-t border-slate-100 grid grid-cols-1 sm:grid-cols-3 gap-3 text-left">
            <div className="p-3 bg-slate-50 rounded-xl">
              <h4 className="text-xs font-bold text-slate-800">Free Starter Lessons</h4>
              <p className="text-[11px] text-slate-500 mt-0.5">
                Access open demo classes without any payment.
              </p>
            </div>
            <div className="p-3 bg-slate-50 rounded-xl">
              <h4 className="text-xs font-bold text-slate-800">AIIMS NORCET Batches</h4>
              <p className="text-[11px] text-slate-500 mt-0.5">
                Full syllabus & test series curriculum.
              </p>
            </div>
            <div className="p-3 bg-slate-50 rounded-xl">
              <h4 className="text-xs font-bold text-slate-800">NCLEX-RN NextGen</h4>
              <p className="text-[11px] text-slate-500 mt-0.5">
                International case studies and drills.
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default StudentCoursesPage;
