/**
 * Axon Nursing Academy - Chapter Details Page (/course/:batchId/subject/:subjectId/chapter/:chapterId)
 * Displays Chapter info, published YouTube Video Lectures, and Firebase Storage Clinical PDF Study Notes.
 * Strictly hardened for Phase 8 Course Access & Resource Hierarchy Security.
 */
import React, { useEffect, useState, useCallback } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import {
  PlayCircle,
  Clock,
  Lock,
  ChevronRight,
  ArrowLeft,
  Video,
  FileText,
  RefreshCw,
  Download,
  Eye,
  X,
  AlertCircle,
  FileCheck,
  ShieldAlert,
  BookOpen,
} from 'lucide-react';
import { getBatchById } from '@/src/services/firebase/batchService';
import { getSubjectById } from '@/src/services/firebase/subjectService';
import { getChapterById } from '@/src/services/firebase/chapterService';
import { getPublishedClasses } from '@/src/services/firebase/classService';
import { getPublishedPdfNotes } from '@/src/services/firebase/pdfNotesService';
import { getPublishedUnitTests } from '@/src/services/firebase/unitTestService';
import { checkStudentCourseAccess } from '@/src/services/firebase/enrollmentService';
import { useAuth } from '@/src/contexts/AuthContext';
import { fallbackStore } from '@/src/services/fallback/fallbackStore';
import { Batch, Subject, Chapter, LmsClass, PdfNote } from '@/src/types/lms.types';
import { UnitTest } from '@/src/types/assessment.types';
import { CourseAccessCheck } from '@/src/types/enrollment.types';
import { Badge } from '@/src/components/ui/Badge';
import { Button } from '@/src/components/ui/Button';

function formatFileSize(bytes: number): string {
  if (!bytes || bytes === 0) return '0 KB';
  const k = 1024;
  const sizes = ['Bytes', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return `${parseFloat((bytes / Math.pow(k, i)).toFixed(1))} ${sizes[i]}`;
}

export function ChapterDetailsPage() {
  const { batchId, subjectId, chapterId } = useParams<{
    batchId: string;
    subjectId: string;
    chapterId: string;
  }>();
  const navigate = useNavigate();
  const { currentUser, isAdmin } = useAuth();

  const cachedBatch = batchId ? fallbackStore.getBatchById(batchId) : null;
  const cachedSubject = subjectId ? fallbackStore.getSubjectById(subjectId) : null;
  const cachedChapter = chapterId ? fallbackStore.getChapterById(chapterId) : null;
  const cachedClasses = chapterId ? fallbackStore.getClasses(chapterId).filter((c) => c.isPublished) : [];
  const cachedPdfNotes = chapterId ? fallbackStore.getPdfNotes(chapterId).filter((p) => p.isPublished) : [];
  const cachedUnitTests = chapterId ? fallbackStore.getUnitTests(chapterId).filter((u) => u.isPublished) : [];

  const [batch, setBatch] = useState<Batch | null>(() => cachedBatch);
  const [subject, setSubject] = useState<Subject | null>(() => cachedSubject);
  const [chapter, setChapter] = useState<Chapter | null>(() => cachedChapter);
  const [classes, setClasses] = useState<LmsClass[]>(() => cachedClasses);
  const [pdfNotes, setPdfNotes] = useState<PdfNote[]>(() => cachedPdfNotes);
  const [unitTests, setUnitTests] = useState<UnitTest[]>(() => cachedUnitTests);
  const [isLoading, setIsLoading] = useState<boolean>(() => !(cachedBatch && cachedSubject && cachedChapter));
  const [error, setError] = useState<string | null>(null);
  const [accessState, setAccessState] = useState<CourseAccessCheck | null>(() =>
    isAdmin ? { hasAccess: true, status: 'enrolled' } : null
  );

  // Active Tab: 'all' | 'videos' | 'notes' | 'tests'
  const [activeTab, setActiveTab] = useState<'all' | 'videos' | 'notes' | 'tests'>('all');

  // PDF Preview Modal
  const [activePdfModal, setActivePdfModal] = useState<PdfNote | null>(null);

  const loadChapterData = useCallback(async () => {
    if (!batchId || !subjectId || !chapterId) {
      setError('Invalid course hierarchy identifiers.');
      setIsLoading(false);
      return;
    }

    if (!(cachedBatch && cachedSubject && cachedChapter)) {
      setIsLoading(true);
    }
    setError(null);

    try {
      // 1. Fetch batch
      const batchData = await getBatchById(batchId);
      if (!batchData) {
        setError('The parent course batch could not be found.');
        setIsLoading(false);
        return;
      }
      setBatch(batchData);

      // 2. Strict Hierarchy Verification: Subject must belong to Batch
      const subjectData = await getSubjectById(subjectId);
      if (!subjectData || subjectData.batchId !== batchId) {
        setError('Resource hierarchy violation: Subject does not belong to this course batch.');
        setAccessState({
          hasAccess: false,
          status: 'not_enrolled',
          reason: 'This subject does not belong to the specified course batch.',
        });
        setIsLoading(false);
        return;
      }
      setSubject(subjectData);

      // 3. Strict Hierarchy Verification: Chapter must belong to Subject
      const chapterData = await getChapterById(chapterId);
      if (!chapterData || chapterData.subjectId !== subjectId) {
        setError('Resource hierarchy violation: Chapter does not belong to this subject.');
        setAccessState({
          hasAccess: false,
          status: 'not_enrolled',
          reason: 'This chapter does not belong to the specified subject.',
        });
        setIsLoading(false);
        return;
      }
      setChapter(chapterData);

      // 4. Phase 8 Course Access Security: Authoritative enrollment check
      const access = await checkStudentCourseAccess(
        currentUser?.uid,
        batchId,
        batchData.isFree,
        currentUser?.email
      );
      setAccessState(access);

      if (!access.hasAccess) {
        setIsLoading(false);
        return;
      }

      // 5. Fetch published classes, pdfs, and unit tests ONLY for authorized students
      const [classesData, pdfData, testsData] = await Promise.all([
        getPublishedClasses(chapterId),
        getPublishedPdfNotes(chapterId),
        getPublishedUnitTests(chapterId),
      ]);

      setClasses(classesData);
      setPdfNotes(pdfData);
      setUnitTests(testsData);
    } catch (err: any) {
      console.error('[ChapterDetailsPage] Error loading chapter:', err);
      setError(err.message || 'Failed to load chapter content.');
    } finally {
      setIsLoading(false);
    }
  }, [batchId, subjectId, chapterId, currentUser?.uid]);

  useEffect(() => {
    loadChapterData();
  }, [loadChapterData]);

  // Loading skeleton
  if (isLoading) {
    return (
      <div className="max-w-4xl mx-auto space-y-6 animate-pulse p-4">
        <div className="h-6 w-56 bg-slate-200 rounded-lg" />
        <div className="h-44 bg-slate-200 rounded-3xl" />
        <div className="h-10 w-80 bg-slate-200 rounded-xl" />
        <div className="space-y-3">
          <div className="h-20 bg-slate-200 rounded-2xl" />
          <div className="h-20 bg-slate-200 rounded-2xl" />
          <div className="h-20 bg-slate-200 rounded-2xl" />
        </div>
      </div>
    );
  }

  // Access Denied / Locked State (Phase 8 Production Guard)
  if (accessState && !accessState.hasAccess) {
    const isExpired = accessState.status === 'expired';
    return (
      <div className="max-w-xl mx-auto my-12 bg-white rounded-3xl border border-slate-200 p-8 text-center shadow-xs">
        <div className={`w-14 h-14 rounded-2xl ${isExpired ? 'bg-amber-50 text-amber-600' : 'bg-rose-50 text-rose-600'} flex items-center justify-center mx-auto mb-4`}>
          {isExpired ? <Clock className="w-7 h-7" /> : <Lock className="w-7 h-7" />}
        </div>
        <Badge variant={isExpired ? 'amber' : 'rose'} size="md" className="mb-3">
          {isExpired ? 'Access Expired' : 'Protected Chapter Resources'}
        </Badge>
        <h2 className="text-xl font-extrabold text-slate-900 mb-2">
          {isExpired ? 'Course Access Expired' : 'Course Enrollment Required'}
        </h2>
        <p className="text-xs sm:text-sm text-slate-600 mb-6 leading-relaxed">
          {accessState.reason || 'This chapter contains paid video lectures, study PDFs, and Unit MCQ assessments requiring active course enrollment.'}
        </p>
        <div className="flex justify-center gap-3">
          <Button
            variant="outline"
            size="sm"
            onClick={() => navigate('/student/all-courses')}
            leftIcon={<BookOpen className="w-3.5 h-3.5" />}
          >
            All Courses
          </Button>
          <Button
            variant="primary"
            size="sm"
            onClick={() => navigate(batchId ? `/course/${batchId}` : '/student/all-courses')}
            leftIcon={<ArrowLeft className="w-3.5 h-3.5" />}
          >
            {isExpired ? 'Renew Course Access' : 'View Course & Enroll'}
          </Button>
        </div>
      </div>
    );
  }

  // Error / Not Found State
  if (error || !chapter || !subject || !batch) {
    return (
      <div className="max-w-xl mx-auto my-12 bg-white rounded-3xl border border-slate-200 p-8 text-center shadow-xs">
        <div className="w-14 h-14 rounded-2xl bg-rose-50 text-rose-600 flex items-center justify-center mx-auto mb-4">
          <AlertCircle className="w-7 h-7" />
        </div>
        <h2 className="text-lg font-bold text-slate-900 mb-2">Chapter Content Unavailable</h2>
        <p className="text-xs text-slate-500 mb-6 leading-relaxed">
          {error || 'The requested chapter does not exist, has been unpublished, or violates resource hierarchy.'}
        </p>
        <div className="flex justify-center gap-3">
          <Button
            variant="outline"
            size="sm"
            onClick={() => loadChapterData()}
            leftIcon={<RefreshCw className="w-3.5 h-3.5" />}
          >
            Retry
          </Button>
          <Button
            variant="primary"
            size="sm"
            onClick={() =>
              navigate(
                batchId && subjectId
                  ? `/course/${batchId}/subject/${subjectId}`
                  : batchId
                  ? `/course/${batchId}`
                  : '/student/all-courses'
              )
            }
            leftIcon={<ArrowLeft className="w-3.5 h-3.5" />}
          >
            Back to Subject
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* Breadcrumbs */}
      <div className="flex items-center gap-2 text-xs font-medium text-slate-500 overflow-x-auto pb-1 scrollbar-none">
        <Link to="/student" className="hover:text-blue-600 shrink-0">Home</Link>
        <ChevronRight className="w-3.5 h-3.5 text-slate-400 shrink-0" />
        <Link to={`/course/${batch.id}`} className="hover:text-blue-600 truncate max-w-[120px] shrink-0">
          {batch.title}
        </Link>
        <ChevronRight className="w-3.5 h-3.5 text-slate-400 shrink-0" />
        <Link to={`/course/${batch.id}/subject/${subject.id}`} className="hover:text-blue-600 truncate max-w-[120px] shrink-0">
          {subject.name}
        </Link>
        <ChevronRight className="w-3.5 h-3.5 text-slate-400 shrink-0" />
        <span className="text-slate-900 font-bold truncate max-w-[180px] shrink-0">
          {chapter.name}
        </span>
      </div>

      {/* Chapter Header Card */}
      <div className="bg-white rounded-3xl border border-slate-200/80 p-5 sm:p-7 shadow-xs">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="space-y-1.5 flex-1">
            <div className="flex items-center gap-2">
              <Badge variant="blue" size="sm">
                Chapter
              </Badge>
              <span className="text-xs font-medium text-slate-500">
                {classes.length} Video Lectures • {pdfNotes.length} PDF Notes • {unitTests.length} MCQ Tests
              </span>
            </div>
            <h1 className="text-xl sm:text-2xl font-extrabold text-slate-900">
              {chapter.name}
            </h1>
            <p className="text-xs sm:text-sm text-slate-600 max-w-2xl leading-relaxed">
              {chapter.description || 'Lectures and clinical examination modules.'}
            </p>
          </div>

          <Link to={`/course/${batch.id}/subject/${subject.id}`}>
            <Button variant="outline" size="sm" leftIcon={<ArrowLeft className="w-3.5 h-3.5" />}>
              Back to Subject
            </Button>
          </Link>
        </div>

        {/* Content Navigation Filter Tabs */}
        <div className="mt-6 pt-5 border-t border-slate-100 flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
          <button
            onClick={() => setActiveTab('all')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-colors shrink-0 ${
              activeTab === 'all'
                ? 'bg-blue-600 text-white shadow-xs'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            All Resources ({classes.length + pdfNotes.length + unitTests.length})
          </button>
          <button
            onClick={() => setActiveTab('videos')}
            className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl text-xs font-bold transition-colors shrink-0 ${
              activeTab === 'videos'
                ? 'bg-blue-600 text-white shadow-xs'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            <Video className="w-3.5 h-3.5" />
            Video Lectures ({classes.length})
          </button>
          <button
            onClick={() => setActiveTab('notes')}
            className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl text-xs font-bold transition-colors shrink-0 ${
              activeTab === 'notes'
                ? 'bg-blue-600 text-white shadow-xs'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            <FileText className="w-3.5 h-3.5" />
            Study Notes ({pdfNotes.length})
          </button>
          <button
            onClick={() => setActiveTab('tests')}
            className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl text-xs font-bold transition-colors shrink-0 ${
              activeTab === 'tests'
                ? 'bg-blue-600 text-white shadow-xs'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            <FileCheck className="w-3.5 h-3.5" />
            Unit MCQ Tests ({unitTests.length})
          </button>
        </div>
      </div>

      {/* 1. Video Lectures Section */}
      {(activeTab === 'all' || activeTab === 'videos') && (
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <h2 className="text-base font-extrabold text-slate-900 flex items-center gap-2">
              <Video className="w-4 h-4 text-blue-600" />
              <span>Video Lectures ({classes.length})</span>
            </h2>
          </div>

          {classes.length > 0 ? (
            <div className="space-y-3">
              {classes.map((cls, idx) => (
                <Link
                  key={cls.id}
                  to={`/course/${batch.id}/class/${cls.id}`}
                  className="group bg-white rounded-2xl border border-slate-200/80 p-4 shadow-xs hover:shadow-md hover:border-blue-300 transition-colors flex items-center justify-between gap-4"
                >
                  <div className="flex items-center gap-3.5 min-w-0">
                    <div className="w-10 h-10 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center shrink-0 group-hover:bg-blue-600 group-hover:text-white transition-colors">
                      <PlayCircle className="w-5 h-5" />
                    </div>
                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold text-slate-400">
                          Lecture {(idx + 1).toString().padStart(2, '0')}
                        </span>
                        {cls.durationMinutes > 0 && (
                          <span className="text-[11px] text-slate-400 flex items-center gap-1">
                            • <Clock className="w-3 h-3 inline" /> {cls.durationMinutes} mins
                          </span>
                        )}
                      </div>
                      <h3 className="text-sm font-bold text-slate-900 group-hover:text-blue-600 transition-colors truncate mt-0.5">
                        {cls.title}
                      </h3>
                      {cls.description && (
                        <p className="text-xs text-slate-500 line-clamp-1 mt-0.5">
                          {cls.description}
                        </p>
                      )}
                    </div>
                  </div>

                  <div className="flex items-center gap-3 shrink-0">
                    <span className="hidden sm:inline text-xs font-semibold text-blue-600 group-hover:underline">
                      Watch Lecture
                    </span>
                    <ChevronRight className="w-4 h-4 text-slate-400 group-hover:text-blue-600 transition-colors" />
                  </div>
                </Link>
              ))}
            </div>
          ) : (
            <div className="bg-white rounded-2xl border border-slate-200 p-6 text-center">
              <Video className="w-6 h-6 text-slate-300 mx-auto mb-1.5" />
              <p className="text-xs font-semibold text-slate-600">No video lectures uploaded yet.</p>
            </div>
          )}
        </div>
      )}

      {/* 2. Clinical Study PDF Notes Section */}
      {(activeTab === 'all' || activeTab === 'notes') && (
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <h2 className="text-base font-extrabold text-slate-900 flex items-center gap-2">
              <FileText className="w-4 h-4 text-emerald-600" />
              <span>Clinical Study Notes & Handouts ({pdfNotes.length})</span>
            </h2>
          </div>

          {pdfNotes.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {pdfNotes.map((pdf) => (
                <div
                  key={pdf.id}
                  className="bg-white rounded-2xl border border-slate-200/80 p-4 shadow-xs hover:border-emerald-300 transition-all flex flex-col justify-between gap-3"
                >
                  <div className="flex items-start gap-3">
                    <div className="w-9 h-9 rounded-xl bg-emerald-50 text-emerald-700 flex items-center justify-center shrink-0">
                      <FileText className="w-5 h-5" />
                    </div>
                    <div className="min-w-0 flex-1">
                      <h3 className="text-sm font-bold text-slate-900 truncate">
                        {pdf.title}
                      </h3>
                      <div className="flex items-center gap-2 text-[11px] text-slate-400 mt-0.5">
                        <span>{formatFileSize(pdf.fileSizeBytes)}</span>
                        {pdf.pageCount && <span>• {pdf.pageCount} Pages</span>}
                      </div>
                      {pdf.description && (
                        <p className="text-xs text-slate-500 line-clamp-1 mt-1">
                          {pdf.description}
                        </p>
                      )}
                    </div>
                  </div>

                  <div className="flex items-center gap-2 pt-2 border-t border-slate-100">
                    <button
                      onClick={() => setActivePdfModal(pdf)}
                      className="flex-1 flex items-center justify-center gap-1.5 py-1.5 px-3 rounded-lg bg-emerald-50 hover:bg-emerald-100 text-emerald-800 text-xs font-semibold transition-colors"
                    >
                      <Eye className="w-3.5 h-3.5" />
                      Preview PDF
                    </button>
                    <a
                      href={pdf.fileUrl}
                      download={pdf.fileName || `${pdf.title}.pdf`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center justify-center gap-1 py-1.5 px-3 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold transition-colors"
                    >
                      <Download className="w-3.5 h-3.5" />
                    </a>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="bg-white rounded-2xl border border-slate-200 p-6 text-center">
              <FileText className="w-6 h-6 text-slate-300 mx-auto mb-1.5" />
              <p className="text-xs font-semibold text-slate-600">No clinical PDF notes uploaded for this chapter yet.</p>
            </div>
          )}
        </div>
      )}

      {/* 3. Unit MCQ Tests Section */}
      {(activeTab === 'all' || activeTab === 'tests') && (
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <h2 className="text-base font-extrabold text-slate-900 flex items-center gap-2">
              <FileCheck className="w-4 h-4 text-purple-600" />
              <span>Unit MCQ Practice Tests ({unitTests.length})</span>
            </h2>
          </div>

          {unitTests.length > 0 ? (
            <div className="space-y-3">
              {unitTests.map((test) => (
                <div
                  key={test.id}
                  className="bg-white rounded-2xl border border-slate-200/80 p-4 sm:p-5 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4"
                >
                  <div className="flex items-center gap-3.5 min-w-0">
                    <div className="w-10 h-10 rounded-xl bg-purple-50 text-purple-600 flex items-center justify-center shrink-0">
                      <FileCheck className="w-5 h-5" />
                    </div>
                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <Badge variant="purple" size="sm">Unit MCQ</Badge>
                        <span className="text-xs text-slate-400">
                          {test.durationMinutes} Mins • {test.totalMarks} Marks
                        </span>
                      </div>
                      <h3 className="text-sm sm:text-base font-bold text-slate-900 truncate mt-1">
                        {test.title}
                      </h3>
                      {test.description && (
                        <p className="text-xs text-slate-500 line-clamp-1 mt-0.5">
                          {test.description}
                        </p>
                      )}
                    </div>
                  </div>

                  <Link
                    to={`/test/unit-test/${test.id}`}
                    className="shrink-0"
                  >
                    <Button
                      variant="primary"
                      size="sm"
                      leftIcon={<PlayCircle className="w-4 h-4" />}
                    >
                      Start Unit Test
                    </Button>
                  </Link>
                </div>
              ))}
            </div>
          ) : (
            <div className="bg-white rounded-2xl border border-slate-200 p-6 text-center">
              <FileCheck className="w-6 h-6 text-slate-300 mx-auto mb-1.5" />
              <p className="text-xs font-semibold text-slate-600">No unit MCQ tests configured for this chapter yet.</p>
            </div>
          )}
        </div>
      )}

      {/* PDF Modal Viewer */}
      {activePdfModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/75 p-3 sm:p-4">
          <div className="bg-white rounded-2xl sm:rounded-3xl max-w-4xl w-full h-[85dvh] max-h-[85vh] flex flex-col overflow-hidden shadow-2xl border border-slate-200">
            <div className="p-4 bg-slate-900 text-white flex items-center justify-between shrink-0">
              <div className="flex items-center gap-2 truncate">
                <FileText className="w-4 h-4 text-emerald-400 shrink-0" />
                <span className="text-sm font-bold truncate">{activePdfModal.title}</span>
              </div>
              <div className="flex items-center gap-2">
                <a
                  href={activePdfModal.fileUrl}
                  download={activePdfModal.fileName || 'notes.pdf'}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs flex items-center gap-1 transition-colors"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">Download</span>
                </a>
                <button
                  onClick={() => setActivePdfModal(null)}
                  className="p-1.5 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-white transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            <div className="flex-1 bg-slate-100 flex items-center justify-center p-4">
              <iframe
                src={activePdfModal.fileUrl}
                title={activePdfModal.title}
                className="w-full h-full rounded-2xl border border-slate-200 bg-white"
              />
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default ChapterDetailsPage;
