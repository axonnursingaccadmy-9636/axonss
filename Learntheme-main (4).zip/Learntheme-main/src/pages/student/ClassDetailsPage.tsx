/**
 * Axon Nursing Academy - Class / Lecture Learning Page (/course/:batchId/class/:classId)
 * Features YouTube educational player, clinical study PDF notes viewer/downloads, and sibling lecture navigation.
 * Strictly hardened for Phase 8 Course Access & Resource Hierarchy Security.
 */
import React, { useEffect, useState, useCallback } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import {
  Play,
  Clock,
  Lock,
  ChevronRight,
  ArrowLeft,
  Video,
  FileText,
  ShieldCheck,
  AlertCircle,
  Sparkles,
  BookOpen,
  RefreshCw,
  Download,
  Eye,
  X,
  FileCheck,
  ShieldAlert,
} from 'lucide-react';
import { getBatchById } from '@/src/services/firebase/batchService';
import { getSubjectById } from '@/src/services/firebase/subjectService';
import { getChapterById } from '@/src/services/firebase/chapterService';
import { getClassById, getPublishedClasses } from '@/src/services/firebase/classService';
import { getPublishedPdfNotes } from '@/src/services/firebase/pdfNotesService';
import { checkStudentCourseAccess } from '@/src/services/firebase/enrollmentService';
import { useAuth } from '@/src/contexts/AuthContext';
import { fallbackStore } from '@/src/services/fallback/fallbackStore';
import { Batch, Subject, Chapter, LmsClass, PdfNote } from '@/src/types/lms.types';
import { CourseAccessCheck } from '@/src/types/enrollment.types';
import { Badge } from '@/src/components/ui/Badge';
import { Button } from '@/src/components/ui/Button';
import { VideoPlayer } from '@/src/components/lms/VideoPlayer';

function formatFileSize(bytes: number): string {
  if (!bytes || bytes === 0) return '0 KB';
  const k = 1024;
  const sizes = ['Bytes', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return `${parseFloat((bytes / Math.pow(k, i)).toFixed(1))} ${sizes[i]}`;
}

export function ClassDetailsPage() {
  const { batchId, classId } = useParams<{ batchId: string; classId: string }>();
  const navigate = useNavigate();
  const { currentUser, isAdmin } = useAuth();

  const cachedBatch = batchId ? fallbackStore.getBatchById(batchId) : null;
  const cachedClass = classId ? fallbackStore.getClassById(classId) : null;
  const cachedSub = cachedClass?.subjectId ? fallbackStore.getSubjectById(cachedClass.subjectId) : null;
  const cachedChap = cachedClass?.chapterId ? fallbackStore.getChapterById(cachedClass.chapterId) : null;
  const cachedSiblings = cachedClass?.chapterId ? fallbackStore.getClasses(cachedClass.chapterId).filter((c) => c.isPublished) : [];
  const cachedPdfs = cachedClass?.chapterId ? fallbackStore.getPdfNotes(cachedClass.chapterId).filter((p) => p.isPublished) : [];

  const [batch, setBatch] = useState<Batch | null>(() => cachedBatch);
  const [subject, setSubject] = useState<Subject | null>(() => cachedSub);
  const [chapter, setChapter] = useState<Chapter | null>(() => cachedChap);
  const [classItem, setClassItem] = useState<LmsClass | null>(() => cachedClass);
  const [chapterClasses, setChapterClasses] = useState<LmsClass[]>(() => cachedSiblings);
  const [chapterPdfs, setChapterPdfs] = useState<PdfNote[]>(() => cachedPdfs);
  const [isLoading, setIsLoading] = useState<boolean>(() => !(cachedBatch && cachedClass));
  const [error, setError] = useState<string | null>(null);
  const [accessState, setAccessState] = useState<CourseAccessCheck | null>(() =>
    isAdmin ? { hasAccess: true, status: 'enrolled' } : null
  );

  // In-app PDF Viewer Modal
  const [activePdfModal, setActivePdfModal] = useState<PdfNote | null>(null);

  const loadClassData = useCallback(async () => {
    if (!batchId || !classId) {
      setError('Invalid course or class identifier.');
      setIsLoading(false);
      return;
    }

    if (!(cachedBatch && cachedClass)) {
      setIsLoading(true);
    }
    setError(null);

    try {
      // 1. Fetch batch
      const batchData = await getBatchById(batchId);
      if (!batchData) {
        setError('The parent course batch was not found.');
        setIsLoading(false);
        return;
      }
      setBatch(batchData);

      // 2. Strict Hierarchy Verification: Class must belong to this course batch
      const classData = await getClassById(classId);
      if (!classData || classData.batchId !== batchId) {
        setError('Resource hierarchy violation: Class lecture does not belong to this course batch.');
        setAccessState({
          hasAccess: false,
          status: 'not_enrolled',
          reason: 'This video lecture does not belong to the requested course.',
        });
        setIsLoading(false);
        return;
      }
      setClassItem(classData);

      // 3. Phase 8 Course Access Security: Authoritative check
      const access = await checkStudentCourseAccess(
        currentUser?.uid,
        batchId,
        batchData.isFree || Boolean(classData.isFree),
        currentUser?.email
      );
      setAccessState(access);

      if (!access.hasAccess) {
        setIsLoading(false);
        return;
      }

      // 4. Fetch subject and chapter context ONLY for authorized students
      if (classData.subjectId) {
        const sub = await getSubjectById(classData.subjectId);
        setSubject(sub);
      }
      if (classData.chapterId) {
        const chap = await getChapterById(classData.chapterId);
        setChapter(chap);

        // Fetch sibling classes
        const siblings = await getPublishedClasses(classData.chapterId);
        setChapterClasses(siblings);

        // Fetch PDF Notes for this chapter
        const pdfNotes = await getPublishedPdfNotes(classData.chapterId);
        setChapterPdfs(pdfNotes);
      }
    } catch (err: any) {
      console.error('[ClassDetailsPage] Error loading class:', err);
      setError(err.message || 'Unable to load class lecture details.');
    } finally {
      setIsLoading(false);
    }
  }, [batchId, classId, currentUser?.uid]);

  useEffect(() => {
    loadClassData();
  }, [loadClassData]);

  // Loading skeleton
  if (isLoading) {
    return (
      <div className="max-w-5xl mx-auto space-y-6 animate-pulse p-4">
        <div className="h-6 w-64 bg-slate-200 rounded-lg" />
        <div className="aspect-video w-full bg-slate-300 rounded-3xl" />
        <div className="h-28 bg-slate-200 rounded-2xl" />
      </div>
    );
  }

  // Access Denied / Locked State (Phase 8 Production Guard)
  if (accessState && !accessState.hasAccess) {
    const isExpired = accessState.status === 'expired';
    return (
      <div className="max-w-xl mx-auto my-12 bg-white rounded-3xl border border-slate-200 p-8 text-center shadow-xs">
        <div className={`w-14 h-14 rounded-2xl ${isExpired ? 'bg-amber-50 text-amber-600' : 'bg-rose-50 text-rose-600'} flex items-center justify-center mx-auto mb-4`}>
          {isExpired ? <Clock className="w-7 h-7" /> : <Lock className="w-7 h-7" />}
        </div>
        <Badge variant={isExpired ? 'amber' : 'rose'} size="md" className="mb-3">
          {isExpired ? 'Access Expired' : 'Protected Video Lecture'}
        </Badge>
        <h2 className="text-xl font-extrabold text-slate-900 mb-2">
          {isExpired ? 'Course Access Expired' : 'Course Enrollment Required'}
        </h2>
        <p className="text-xs sm:text-sm text-slate-600 mb-6 leading-relaxed">
          {accessState.reason || 'This video lecture is a protected course resource. Direct URL access is blocked without an active course enrollment.'}
        </p>
        <div className="flex justify-center gap-3">
          <Button
            variant="outline"
            size="sm"
            onClick={() => navigate('/student/all-courses')}
            leftIcon={<BookOpen className="w-3.5 h-3.5" />}
          >
            Browse Courses
          </Button>
          <Button
            variant="primary"
            size="sm"
            onClick={() => navigate(batchId ? `/course/${batchId}` : '/student/all-courses')}
            leftIcon={<ArrowLeft className="w-3.5 h-3.5" />}
          >
            {isExpired ? 'Renew Course Access' : 'View Course & Enroll'}
          </Button>
        </div>
      </div>
    );
  }

  // Error / Not Found State
  if (error || !classItem || !batch) {
    return (
      <div className="max-w-xl mx-auto my-12 bg-white rounded-3xl border border-slate-200 p-8 text-center shadow-xs">
        <div className="w-14 h-14 rounded-2xl bg-rose-50 text-rose-600 flex items-center justify-center mx-auto mb-4">
          <AlertCircle className="w-7 h-7" />
        </div>
        <h2 className="text-lg font-bold text-slate-900 mb-2">Lecture Unavailable</h2>
        <p className="text-xs text-slate-500 mb-6 leading-relaxed">
          {error || 'This lecture does not exist, has been unpublished, or violates resource hierarchy.'}
        </p>
        <div className="flex justify-center gap-3">
          <Button
            variant="outline"
            size="sm"
            onClick={() => loadClassData()}
            leftIcon={<RefreshCw className="w-3.5 h-3.5" />}
          >
            Retry
          </Button>
          <Button
            variant="primary"
            size="sm"
            onClick={() => navigate(batchId ? `/course/${batchId}` : '/student/all-courses')}
            leftIcon={<ArrowLeft className="w-3.5 h-3.5" />}
          >
            Back to Course
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-5xl mx-auto space-y-6 pb-12">
      {/* Breadcrumb Path */}
      <div className="flex items-center gap-2 text-xs font-medium text-slate-500 overflow-x-auto pb-1 scrollbar-none">
        <Link to="/student" className="hover:text-blue-600 shrink-0">Home</Link>
        <ChevronRight className="w-3.5 h-3.5 text-slate-400 shrink-0" />
        <Link to={`/course/${batch.id}`} className="hover:text-blue-600 truncate max-w-[120px] shrink-0">
          {batch.title}
        </Link>
        {subject && (
          <>
            <ChevronRight className="w-3.5 h-3.5 text-slate-400 shrink-0" />
            <Link
              to={`/course/${batch.id}/subject/${subject.id}`}
              className="hover:text-blue-600 truncate max-w-[120px] shrink-0"
            >
              {subject.name}
            </Link>
          </>
        )}
        {chapter && subject && (
          <>
            <ChevronRight className="w-3.5 h-3.5 text-slate-400 shrink-0" />
            <Link
              to={`/course/${batch.id}/subject/${subject.id}/chapter/${chapter.id}`}
              className="hover:text-blue-600 truncate max-w-[150px] shrink-0"
            >
              {chapter.name}
            </Link>
          </>
        )}
        <ChevronRight className="w-3.5 h-3.5 text-slate-400 shrink-0" />
        <span className="text-slate-900 font-bold truncate max-w-[160px] shrink-0">
          {classItem.title}
        </span>
      </div>

      {/* Main Grid: Video Player + Sibling Sidebar */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 items-start">
        {/* Left 2 Cols: Player & Clinical Details */}
        <div className="lg:col-span-2 space-y-5">
          {/* Protected Video Player */}
          <div className="overflow-hidden rounded-3xl bg-slate-900 shadow-xl border border-slate-800">
            <VideoPlayer
              videoUrl={classItem.videoUrl}
              youtubeVideoId={classItem.youtubeVideoId}
              title={classItem.title}
              poster={classItem.thumbnailUrl}
            />
          </div>

          {/* Lecture Metadata */}
          <div className="bg-white rounded-3xl border border-slate-200/80 p-5 sm:p-6 shadow-xs space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center gap-2">
                <Badge variant="blue" size="sm">
                  Clinical Lecture
                </Badge>
                {classItem.durationMinutes > 0 && (
                  <span className="text-xs font-semibold text-slate-500 flex items-center gap-1">
                    <Clock className="w-3.5 h-3.5" />
                    {classItem.durationMinutes} mins
                  </span>
                )}
              </div>

              {chapter && subject && (
                <Link to={`/course/${batch.id}/subject/${subject.id}/chapter/${chapter.id}`}>
                  <Button variant="outline" size="sm" leftIcon={<ArrowLeft className="w-3.5 h-3.5" />}>
                    Chapter Index
                  </Button>
                </Link>
              )}
            </div>

            <div>
              <h1 className="text-lg sm:text-xl font-extrabold text-slate-900 leading-snug">
                {classItem.title}
              </h1>
              {classItem.description ? (
                <p className="mt-2 text-xs sm:text-sm text-slate-600 leading-relaxed whitespace-pre-line">
                  {classItem.description}
                </p>
              ) : (
                <p className="mt-2 text-xs text-slate-400 italic">
                  No additional lecture notes or clinical description provided.
                </p>
              )}
            </div>

            {/* Teaching Faculty Info */}
            <div className="pt-4 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
              <div className="flex items-center gap-2">
                <div className="w-7 h-7 rounded-full bg-blue-100 text-blue-700 font-bold flex items-center justify-center text-[11px]">
                  AN
                </div>
                <span>Axon Nursing Academy Faculty</span>
              </div>
              <span className="flex items-center gap-1 text-emerald-600 font-medium">
                <ShieldCheck className="w-3.5 h-3.5" /> Enrolled Verified Access
              </span>
            </div>
          </div>
        </div>

        {/* Right 1 Col: Chapter Classes & Handouts */}
        <div className="space-y-5">
          {/* Sibling Lectures Navigation */}
          <div className="bg-white rounded-3xl border border-slate-200/80 p-5 shadow-xs space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-extrabold text-slate-900 flex items-center gap-2">
                <Video className="w-4 h-4 text-blue-600" />
                <span>Chapter Lectures ({chapterClasses.length})</span>
              </h3>
            </div>

            <div className="space-y-2 max-h-[360px] overflow-y-auto pr-1">
              {chapterClasses.map((sibling, idx) => {
                const isCurrent = sibling.id === classItem.id;
                return (
                  <Link
                    key={sibling.id}
                    to={`/course/${batch.id}/class/${sibling.id}`}
                    className={`block p-3 rounded-2xl border transition-all ${
                      isCurrent
                        ? 'bg-blue-50/80 border-blue-200 shadow-xs'
                        : 'bg-white border-slate-100 hover:border-slate-200 hover:bg-slate-50'
                    }`}
                  >
                    <div className="flex items-start gap-2.5">
                      <div
                        className={`w-7 h-7 rounded-lg flex items-center justify-center shrink-0 mt-0.5 text-xs font-bold ${
                          isCurrent
                            ? 'bg-blue-600 text-white'
                            : 'bg-slate-100 text-slate-600'
                        }`}
                      >
                        {isCurrent ? <Play className="w-3 h-3 fill-current" /> : idx + 1}
                      </div>
                      <div className="min-w-0 flex-1">
                        <h4
                          className={`text-xs font-bold leading-tight truncate ${
                            isCurrent ? 'text-blue-900' : 'text-slate-800'
                          }`}
                        >
                          {sibling.title}
                        </h4>
                        <div className="flex items-center gap-2 text-[10px] text-slate-400 mt-1">
                          {sibling.durationMinutes > 0 && <span>{sibling.durationMinutes} mins</span>}
                          {isCurrent && <span className="text-blue-600 font-semibold">• Now Playing</span>}
                        </div>
                      </div>
                    </div>
                  </Link>
                );
              })}
            </div>
          </div>

          {/* Chapter PDF Study Notes */}
          {chapterPdfs.length > 0 && (
            <div className="bg-white rounded-3xl border border-slate-200/80 p-5 shadow-xs space-y-3">
              <h3 className="text-sm font-extrabold text-slate-900 flex items-center gap-2">
                <FileText className="w-4 h-4 text-emerald-600" />
                <span>Chapter PDF Notes ({chapterPdfs.length})</span>
              </h3>

              <div className="space-y-2">
                {chapterPdfs.map((pdf) => (
                  <div
                    key={pdf.id}
                    className="p-3 rounded-2xl bg-slate-50 border border-slate-100 flex items-center justify-between gap-2"
                  >
                    <div className="min-w-0 flex-1">
                      <h4 className="text-xs font-bold text-slate-800 truncate">
                        {pdf.title}
                      </h4>
                      <p className="text-[10px] text-slate-400">
                        {formatFileSize(pdf.fileSizeBytes)}
                      </p>
                    </div>

                    <div className="flex items-center gap-1.5 shrink-0">
                      <button
                        onClick={() => setActivePdfModal(pdf)}
                        className="p-1.5 rounded-lg bg-white border border-slate-200 hover:bg-slate-100 text-slate-700 transition-colors"
                        title="Preview PDF"
                      >
                        <Eye className="w-3.5 h-3.5" />
                      </button>
                      <a
                        href={pdf.fileUrl}
                        download={pdf.fileName || `${pdf.title}.pdf`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="p-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white transition-colors"
                        title="Download PDF"
                      >
                        <Download className="w-3.5 h-3.5" />
                      </a>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* PDF Viewer Modal */}
      {activePdfModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/75 p-3 sm:p-4">
          <div className="bg-white rounded-2xl sm:rounded-3xl max-w-4xl w-full h-[85dvh] max-h-[85vh] flex flex-col overflow-hidden shadow-2xl border border-slate-200">
            <div className="p-4 bg-slate-900 text-white flex items-center justify-between shrink-0">
              <div className="flex items-center gap-2 truncate">
                <FileText className="w-4 h-4 text-emerald-400 shrink-0" />
                <span className="text-sm font-bold truncate">{activePdfModal.title}</span>
              </div>
              <div className="flex items-center gap-2">
                <a
                  href={activePdfModal.fileUrl}
                  download={activePdfModal.fileName || 'notes.pdf'}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs flex items-center gap-1 transition-colors"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">Download</span>
                </a>
                <button
                  onClick={() => setActivePdfModal(null)}
                  className="p-1.5 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-white transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            <div className="flex-1 bg-slate-100 flex items-center justify-center p-4">
              <iframe
                src={activePdfModal.fileUrl}
                title={activePdfModal.title}
                className="w-full h-full rounded-2xl border border-slate-200 bg-white"
              />
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default ClassDetailsPage;
