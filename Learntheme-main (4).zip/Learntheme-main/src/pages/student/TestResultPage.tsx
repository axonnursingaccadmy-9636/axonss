/**
 * Axon Nursing Academy - Test Scorecard & Clinical Solution Review (Phase 6 & 8)
 * Real-time score computation, accuracy breakdown, and interactive clinical rationales.
 * Strictly hardened for Phase 8 Attempt Isolation & Student Cross-Access Prevention.
 */
import React, { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import {
  Award,
  FileCheck,
  CheckCircle2,
  XCircle,
  Clock,
  RotateCcw,
  BookOpen,
  ArrowLeft,
  ChevronRight,
  TrendingUp,
  Percent,
  Check,
  X,
  HelpCircle,
  Sparkles,
  Layers,
  ChevronDown,
  ShieldAlert,
  Lock,
  LogIn,
} from 'lucide-react';
import { ROUTES } from '@/src/config/routes.config';
import { Button } from '@/src/components/ui/Button';
import { LoadingState } from '@/src/components/common/LoadingState';
import {
  getWeeklyWarriorTestById,
  getWeeklyWarriorResult,
  getWeeklyWarriorQuestionReviewList,
} from '@/src/services/firebase/weeklyWarriorTestService';
import {
  getUnitTestById,
  getUnitTestResult,
  getUnitTestQuestionReviewList,
} from '@/src/services/firebase/unitTestService';
import { checkStudentCourseAccess } from '@/src/services/firebase/enrollmentService';
import {
  WeeklyWarriorTest,
  UnitTest,
  WeeklyWarriorResult,
  UnitTestResult,
  QuestionReviewItem,
} from '@/src/types/assessment.types';
import { fallbackStore } from '@/src/services/fallback/fallbackStore';
import { useAuth } from '@/src/contexts/AuthContext';

type FilterType = 'all' | 'correct' | 'incorrect' | 'skipped';

export function TestResultPage() {
  const { testType, testId, attemptId } = useParams<{
    testType: 'weekly-warrior' | 'unit-test';
    testId: string;
    attemptId: string;
  }>();
  const navigate = useNavigate();
  const { currentUser, isAdmin, loading: authLoading } = useAuth();

  const cachedTest = testId
    ? testType === 'weekly-warrior'
      ? fallbackStore.getWeeklyWarriorTestById(testId)
      : fallbackStore.getUnitTestById(testId)
    : null;

  const cachedResult = attemptId
    ? testType === 'weekly-warrior'
      ? fallbackStore.getWeeklyWarriorResult(attemptId)
      : fallbackStore.getUnitTestResult(attemptId)
    : null;

  const [test, setTest] = useState<WeeklyWarriorTest | UnitTest | null>(() => cachedTest);
  const [result, setResult] = useState<WeeklyWarriorResult | UnitTestResult | null>(() => cachedResult);
  const [reviewItems, setReviewItems] = useState<QuestionReviewItem[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [accessDeniedError, setAccessDeniedError] = useState<string | null>(null);
  const [filter, setFilter] = useState<FilterType>('all');

  useEffect(() => {
    if (!authLoading) {
      loadScorecard();
    }
  }, [testType, testId, attemptId, currentUser?.uid, authLoading, isAdmin]);

  const loadScorecard = async () => {
    if (!testType || !testId || !attemptId) {
      setLoading(false);
      return;
    }

    // Rule 8.2: Block unauthenticated users immediately
    if (!currentUser) {
      setLoading(false);
      return;
    }

    setLoading(true);
    setAccessDeniedError(null);

    try {
      let testData: WeeklyWarriorTest | UnitTest | null = null;
      let resultData: WeeklyWarriorResult | UnitTestResult | null = null;

      if (testType === 'weekly-warrior') {
        testData = await getWeeklyWarriorTestById(testId);
        resultData = await getWeeklyWarriorResult(attemptId);
      } else {
        testData = await getUnitTestById(testId);
        resultData = await getUnitTestResult(attemptId);
      }

      if (!testData || !resultData) {
        setTest(testData);
        setResult(resultData);
        setLoading(false);
        return;
      }

      // Rule 8.6: Cross-student data isolation
      // A student can ONLY view their own attempt results. Only Admins can view any attempt.
      if (resultData.studentId && resultData.studentId !== currentUser.uid && !isAdmin) {
        setAccessDeniedError('Access Denied: You are not authorized to view another student’s examination results.');
        setLoading(false);
        return;
      }

      // Rule 8.1 & 8.5: Course Access Verification
      const access = await checkStudentCourseAccess(
        currentUser.uid,
        testData.batchId,
        undefined,
        currentUser.email
      );
      if (!access.hasAccess && !isAdmin) {
        setAccessDeniedError(access.reason || 'Course enrollment required to view assessment solutions and scorecards.');
        setLoading(false);
        return;
      }

      setTest(testData);
      setResult(resultData);

      // Load solution review list
      const userAnswersMap: Record<string, string> = resultData.answers || {};
      const reviews =
        testType === 'weekly-warrior'
          ? await getWeeklyWarriorQuestionReviewList(testId, userAnswersMap, attemptId)
          : await getUnitTestQuestionReviewList(testId, userAnswersMap, attemptId);
      setReviewItems(reviews);
    } catch (err: any) {
      console.error('[TestResultPage] Failed to load test result:', err);
      setAccessDeniedError(err.message || 'Error loading examination results.');
    } finally {
      setLoading(false);
    }
  };

  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    if (mins === 0) return `${secs} seconds`;
    return `${mins} min ${secs} sec`;
  };

  if (loading || authLoading) {
    return <LoadingState message="Verifying Student Authorization & Generating Scorecard..." fullScreen />;
  }

  // 1. Unauthenticated Student Guard
  if (!currentUser) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4">
        <div className="bg-white rounded-3xl border border-slate-200 p-8 max-w-md w-full text-center shadow-lg">
          <div className="w-14 h-14 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center mx-auto mb-4">
            <LogIn className="w-7 h-7" />
          </div>
          <h2 className="text-xl font-bold text-slate-900 mb-2">Authentication Required</h2>
          <p className="text-xs sm:text-sm text-slate-500 mb-6 leading-relaxed">
            Please sign in to view your examination scorecard and solution rationales.
          </p>
          <Button
            variant="primary"
            size="sm"
            onClick={() => navigate(`/login?redirect=/test/${testType}/${testId}/result/${attemptId}`)}
            className="w-full"
            leftIcon={<LogIn className="w-4 h-4" />}
          >
            Sign In to Account
          </Button>
        </div>
      </div>
    );
  }

  // 2. Cross-Student Access Denied Guard (Phase 8 Isolation)
  if (accessDeniedError) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4">
        <div className="bg-white rounded-3xl border border-slate-200 p-8 max-w-md w-full text-center shadow-lg">
          <div className="w-14 h-14 rounded-2xl bg-rose-50 text-rose-600 flex items-center justify-center mx-auto mb-4">
            <ShieldAlert className="w-7 h-7" />
          </div>
          <h2 className="text-xl font-bold text-slate-900 mb-2">Access Denied</h2>
          <p className="text-xs sm:text-sm text-slate-600 mb-6 leading-relaxed">
            {accessDeniedError}
          </p>
          <div className="flex gap-3 justify-center">
            <Button
              variant="outline"
              size="sm"
              onClick={() => navigate('/student')}
            >
              Dashboard
            </Button>
            <Button
              variant="primary"
              size="sm"
              onClick={() => navigate('/student/all-courses')}
              leftIcon={<BookOpen className="w-3.5 h-3.5" />}
            >
              All Courses
            </Button>
          </div>
        </div>
      </div>
    );
  }

  // 3. Not Found State
  if (!result || !test) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4">
        <div className="bg-white rounded-3xl border border-slate-200 p-8 max-w-md w-full text-center shadow-lg">
          <div className="w-14 h-14 rounded-2xl bg-amber-50 text-amber-600 flex items-center justify-center mx-auto mb-4">
            <HelpCircle className="w-7 h-7" />
          </div>
          <h2 className="text-lg font-bold text-slate-900 mb-2">Scorecard Not Found</h2>
          <p className="text-xs text-slate-500 mb-6">
            Unable to locate the evaluation record for this attempt.
          </p>
          <Button onClick={() => navigate('/student')} className="w-full bg-blue-600 hover:bg-blue-700 text-white">
            Return to Learning Portal
          </Button>
        </div>
      </div>
    );
  }

  const isPassed = result.isPassed;
  const filteredReview = reviewItems.filter((item) => {
    if (filter === 'correct') return item.isCorrect;
    if (filter === 'incorrect') return !item.isCorrect && !item.isSkipped;
    if (filter === 'skipped') return item.isSkipped;
    return true;
  });

  const backUrl =
    testType === 'weekly-warrior'
      ? ROUTES.COURSE.DETAILS(test.batchId)
      : (test as UnitTest).chapterId
      ? ROUTES.COURSE.CHAPTER(
          test.batchId,
          (test as UnitTest).subjectId,
          (test as UnitTest).chapterId
        )
      : ROUTES.STUDENT.COURSES;

  return (
    <div className="min-h-screen bg-slate-50 py-8 px-4 md:px-8">
      <div className="max-w-4xl mx-auto space-y-6">
        {/* Navigation Bar */}
        <div className="flex items-center justify-between">
          <Link
            to={backUrl}
            className="inline-flex items-center gap-2 text-xs font-bold text-slate-600 hover:text-slate-900 bg-white px-3.5 py-2 rounded-xl border border-slate-200 transition-colors shadow-2xs"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Return to Course</span>
          </Link>

          <Link to={ROUTES.TEST.PLAYER(testType || 'weekly-warrior', test.id)}>
            <Button size="sm" variant="outline" className="gap-1.5 text-xs font-bold bg-white">
              <RotateCcw className="w-3.5 h-3.5" />
              Retake Test
            </Button>
          </Link>
        </div>

        {/* 1. SCORECARD HERO CARD */}
        <div className="bg-white rounded-3xl border border-slate-200/80 p-6 md:p-8 shadow-xs overflow-hidden relative">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 pb-6 border-b border-slate-100">
            <div className="space-y-1.5">
              <div className="flex items-center gap-2">
                <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-lg text-[10px] font-extrabold bg-blue-50 text-blue-700 uppercase tracking-wider">
                  {testType === 'weekly-warrior' ? 'Weekly Warrior' : 'Chapter Unit Test'}
                </span>
                <span
                  className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-lg text-[10px] font-extrabold uppercase tracking-wider ${
                    isPassed
                      ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                      : 'bg-red-50 text-red-700 border border-red-200'
                  }`}
                >
                  {isPassed ? '✓ Passed Qualifying Benchmark' : '✕ Needs Revision'}
                </span>
              </div>
              <h1 className="text-xl md:text-2xl font-black text-slate-900 tracking-tight">
                {test.title}
              </h1>
              <p className="text-xs text-slate-500">
                Completed on {new Date(result.submittedAt).toLocaleDateString()} at{' '}
                {new Date(result.submittedAt).toLocaleTimeString([], {
                  hour: '2-digit',
                  minute: '2-digit',
                })}
              </p>
            </div>

            {/* Score Big Badge */}
            <div className="p-4 rounded-2xl bg-gradient-to-br from-slate-900 to-slate-800 text-white text-center shrink-0 min-w-44 shadow-md">
              <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
                Total Score
              </span>
              <div className="text-3xl font-black mt-1">
                <span className="text-emerald-400">{result.score}</span>
                <span className="text-slate-500 text-lg"> / {result.totalMarks}</span>
              </div>
              <span className="text-[11px] text-slate-300 font-semibold mt-0.5 block">
                {((result.score / (result.totalMarks || 1)) * 100).toFixed(1)}% Marks
              </span>
            </div>
          </div>

          {/* 4 Pillars Metric Row */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 pt-6">
            <div className="bg-slate-50 rounded-2xl p-4 border border-slate-100">
              <div className="flex items-center gap-2 text-emerald-600 font-bold text-xs mb-1">
                <CheckCircle2 className="w-4 h-4" />
                <span>Correct Answers</span>
              </div>
              <div className="text-xl font-black text-slate-900">{result.correctCount}</div>
              <span className="text-[10px] text-slate-400 font-medium">Questions solved accurately</span>
            </div>

            <div className="bg-slate-50 rounded-2xl p-4 border border-slate-100">
              <div className="flex items-center gap-2 text-red-600 font-bold text-xs mb-1">
                <XCircle className="w-4 h-4" />
                <span>Incorrect Answers</span>
              </div>
              <div className="text-xl font-black text-slate-900">{result.incorrectCount}</div>
              <span className="text-[10px] text-slate-400 font-medium">Attracted negative deduction</span>
            </div>

            <div className="bg-slate-50 rounded-2xl p-4 border border-slate-100">
              <div className="flex items-center gap-2 text-purple-600 font-bold text-xs mb-1">
                <Percent className="w-4 h-4" />
                <span>Overall Accuracy</span>
              </div>
              <div className="text-xl font-black text-slate-900">
                {(result.accuracyPercentage ?? result.accuracy ?? 0).toFixed(1)}%
              </div>
              <span className="text-[10px] text-slate-400 font-medium">Of attempted questions</span>
            </div>

            <div className="bg-slate-50 rounded-2xl p-4 border border-slate-100">
              <div className="flex items-center gap-2 text-blue-600 font-bold text-xs mb-1">
                <Clock className="w-4 h-4" />
                <span>Time Utilized</span>
              </div>
              <div className="text-xl font-black text-slate-900">
                {formatDuration(result.timeTakenSeconds ?? result.timeSpentSeconds ?? 0)}
              </div>
              <span className="text-[10px] text-slate-400 font-medium">
                Allocated: {test.durationMinutes} mins
              </span>
            </div>
          </div>
        </div>

        {/* 2. CLINICAL SOLUTION REVIEW & RATIONALES SECTION */}
        <div className="space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h2 className="text-base font-extrabold text-slate-900 flex items-center gap-2">
                <BookOpen className="w-4 h-4 text-blue-600" />
                <span>Question Review & Clinical Rationales</span>
              </h2>
              <p className="text-xs text-slate-500">
                Verified high-yield clinical justifications for competitive nursing examinations
              </p>
            </div>

            {/* Filter Tabs */}
            <div className="flex items-center gap-1 bg-white p-1 rounded-xl border border-slate-200">
              <button
                onClick={() => setFilter('all')}
                className={`px-3 py-1 rounded-lg text-xs font-bold transition-colors ${
                  filter === 'all' ? 'bg-slate-900 text-white' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                All ({reviewItems.length})
              </button>
              <button
                onClick={() => setFilter('correct')}
                className={`px-3 py-1 rounded-lg text-xs font-bold transition-colors ${
                  filter === 'correct' ? 'bg-emerald-600 text-white' : 'text-emerald-700 hover:bg-emerald-50'
                }`}
              >
                Correct ({result.correctCount})
              </button>
              <button
                onClick={() => setFilter('incorrect')}
                className={`px-3 py-1 rounded-lg text-xs font-bold transition-colors ${
                  filter === 'incorrect' ? 'bg-red-600 text-white' : 'text-red-700 hover:bg-red-50'
                }`}
              >
                Incorrect ({result.incorrectCount})
              </button>
              <button
                onClick={() => setFilter('skipped')}
                className={`px-3 py-1 rounded-lg text-xs font-bold transition-colors ${
                  filter === 'skipped' ? 'bg-slate-700 text-white' : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                Skipped ({result.unattemptedCount})
              </button>
            </div>
          </div>

          {/* Questions Review List */}
          <div className="space-y-4">
            {filteredReview.map((item, idx) => {
              const statusBadge = item.isCorrect ? (
                <span className="px-2.5 py-0.5 rounded-md bg-emerald-50 text-emerald-700 border border-emerald-200 text-xs font-bold flex items-center gap-1">
                  <Check className="w-3.5 h-3.5" /> Correct
                </span>
              ) : item.isSkipped ? (
                <span className="px-2.5 py-0.5 rounded-md bg-slate-100 text-slate-600 border border-slate-200 text-xs font-bold flex items-center gap-1">
                  Skipped
                </span>
              ) : (
                <span className="px-2.5 py-0.5 rounded-md bg-red-50 text-red-700 border border-red-200 text-xs font-bold flex items-center gap-1">
                  <X className="w-3.5 h-3.5" /> Incorrect
                </span>
              );

              return (
                <div
                  key={item.id}
                  className="bg-white rounded-2xl border border-slate-200 p-5 space-y-4 shadow-2xs"
                >
                  {/* Question header */}
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="w-6 h-6 rounded-lg bg-slate-900 text-white text-xs font-bold flex items-center justify-center">
                        {idx + 1}
                      </span>
                      {item.subjectTag && (
                        <span className="text-[10px] font-bold text-slate-500 uppercase bg-slate-100 px-2 py-0.5 rounded-md">
                          {item.subjectTag}
                        </span>
                      )}
                    </div>
                    {statusBadge}
                  </div>

                  {/* Question Text */}
                  <p className="text-sm sm:text-base font-bold text-slate-900 leading-snug">
                    {item.questionText}
                  </p>

                  {item.questionImageUrl && (
                    <div className="max-w-md rounded-xl overflow-hidden border border-slate-200 p-1">
                      <img
                        src={item.questionImageUrl}
                        alt="Clinical Question diagram"
                        className="w-full h-auto object-contain max-h-56 rounded-lg"
                      />
                    </div>
                  )}

                  {/* Options Comparison */}
                  <div className="space-y-2 pt-1">
                    {item.options.map((opt, oIdx) => {
                      const prefix = ['A', 'B', 'C', 'D'][oIdx] || String(oIdx + 1);
                      const isUserChoice = item.selectedOptionId === opt.id;
                      const isCorrectChoice = item.correctOptionId === opt.id;

                      let rowClass = 'bg-white border-slate-200 text-slate-700';
                      let badgeClass = 'bg-slate-100 text-slate-600';

                      if (isCorrectChoice) {
                        rowClass = 'bg-emerald-50 border-emerald-500 text-emerald-950 font-semibold ring-1 ring-emerald-500';
                        badgeClass = 'bg-emerald-600 text-white';
                      } else if (isUserChoice && !isCorrectChoice) {
                        rowClass = 'bg-red-50 border-red-400 text-red-950 font-medium';
                        badgeClass = 'bg-red-600 text-white';
                      }

                      return (
                        <div
                          key={opt.id}
                          className={`p-3 rounded-xl border flex items-center justify-between gap-3 text-xs sm:text-sm ${rowClass}`}
                        >
                          <div className="flex items-center gap-3">
                            <span
                              className={`w-6 h-6 rounded-lg font-bold flex items-center justify-center text-xs shrink-0 ${badgeClass}`}
                            >
                              {prefix}
                            </span>
                            <span>{opt.text}</span>
                          </div>

                          <div className="flex items-center gap-1 text-[11px] font-bold shrink-0">
                            {isCorrectChoice && (
                              <span className="text-emerald-700 flex items-center gap-1">
                                <Check className="w-3.5 h-3.5" /> Correct Answer
                              </span>
                            )}
                            {isUserChoice && !isCorrectChoice && (
                              <span className="text-red-700 flex items-center gap-1">
                                <X className="w-3.5 h-3.5" /> Your Answer
                              </span>
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>

                  {/* Clinical Explanation / Rationale */}
                  {item.explanation && (
                    <div className="p-4 rounded-xl bg-blue-50/70 border border-blue-200/80 text-xs sm:text-sm space-y-1.5 mt-3">
                      <div className="flex items-center gap-1.5 font-bold text-blue-900">
                        <Sparkles className="w-4 h-4 text-blue-600 shrink-0" />
                        <span>Clinical Rationale & High-Yield Analysis</span>
                      </div>
                      <p className="text-slate-700 leading-relaxed pl-5 whitespace-pre-line">
                        {item.explanation}
                      </p>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}

export default TestResultPage;
