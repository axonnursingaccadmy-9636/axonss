/**
 * Axon Nursing Academy - Student Profile Page
 * Displays authenticated Firestore user profile details and profile name editing.
 */
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  User,
  Mail,
  Shield,
  Bell,
  HelpCircle,
  LogOut,
  Edit3,
  Check,
  X,
  Loader2,
  AlertCircle,
  CheckCircle2,
  ShieldCheck,
  Calendar,
} from 'lucide-react';
import { SITE_CONFIG } from '@/src/config/site.config';
import { ROUTES } from '@/src/config/routes.config';
import { Avatar } from '@/src/components/ui/Avatar';
import { Badge } from '@/src/components/ui/Badge';
import { Button } from '@/src/components/ui/Button';
import { Input } from '@/src/components/ui/Input';
import { useAuth } from '@/src/contexts/AuthContext';
import { useToast } from '@/src/hooks/useToast';
import { validateFullName } from '@/src/services/firebase/userService';

export function StudentProfilePage() {
  const navigate = useNavigate();
  const { currentUser, profile, profileLoading, updateProfileName, logout } = useAuth();
  const { toast } = useToast();

  const [isEditingName, setIsEditingName] = useState(false);
  const [editedName, setEditedName] = useState('');
  const [isSavingName, setIsSavingName] = useState(false);
  const [isLoggingOut, setIsLoggingOut] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  // Firestore profile data with fallbacks
  const fullName = profile?.fullName || currentUser?.displayName || 'Nursing Aspirant';
  const email = profile?.email || currentUser?.email || '';
  const role = profile?.role || 'student';
  const isActive = profile?.isActive !== undefined ? profile.isActive : true;

  const creationDateDisplay = currentUser?.metadata?.creationTime
    ? new Date(currentUser.metadata.creationTime).toLocaleDateString('en-US', {
        month: 'short',
        day: 'numeric',
        year: 'numeric',
      })
    : 'Active Student';

  const startEditing = () => {
    setEditedName(fullName);
    setErrorMessage(null);
    setSuccessMessage(null);
    setIsEditingName(true);
  };

  const cancelEditing = () => {
    setIsEditingName(false);
    setErrorMessage(null);
  };

  const handleSaveName = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);
    setSuccessMessage(null);

    const { isValid, error, sanitized } = validateFullName(editedName);
    if (!isValid) {
      setErrorMessage(error || 'Invalid name.');
      return;
    }

    if (sanitized === fullName) {
      setIsEditingName(false);
      return;
    }

    setIsSavingName(true);
    try {
      await updateProfileName(sanitized);
      setSuccessMessage('Full name updated successfully in your student record.');
      toast.success('Your profile name has been updated successfully.', {
        title: 'Profile Updated',
      });
      setIsEditingName(false);
    } catch (err: any) {
      const message = err.message || 'Failed to update profile name.';
      setErrorMessage(message);
      toast.error(message, {
        title: 'Update Error',
      });
    } finally {
      setIsSavingName(false);
    }
  };

  const handleSignOut = async () => {
    setIsLoggingOut(true);
    try {
      await logout();
      toast.info('You have been signed out successfully.', {
        title: 'Signed Out',
      });
      navigate(ROUTES.LOGIN, { replace: true });
    } catch (error: any) {
      console.error('Logout error:', error);
      toast.error(error?.message || 'Failed to sign out. Please try again.');
      setIsLoggingOut(false);
    }
  };

  return (
    <div className="max-w-3xl mx-auto space-y-5 animate-in fade-in duration-150">
      {/* Success Notification */}
      {successMessage && (
        <div className="bg-emerald-50 border border-emerald-200 rounded-2xl p-3.5 flex items-center gap-2.5 text-xs text-emerald-800 animate-in fade-in">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span className="font-medium">{successMessage}</span>
        </div>
      )}

      {/* Error Notification */}
      {errorMessage && (
        <div className="bg-rose-50 border border-rose-200 rounded-2xl p-3.5 flex items-center gap-2.5 text-xs text-rose-800 animate-in fade-in">
          <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
          <span className="font-medium">{errorMessage}</span>
        </div>
      )}

      {/* Profile Header Card */}
      <div className="bg-white rounded-2xl border border-slate-100 p-5 sm:p-6 shadow-xs">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <Avatar name={fullName} size="xl" />
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h1 className="text-base sm:text-lg font-extrabold text-slate-900">
                  {fullName}
                </h1>
                <Badge variant={role === 'admin' ? 'purple' : 'blue'} size="sm">
                  {role === 'admin' ? 'Administrator' : 'Student'}
                </Badge>
                <Badge variant={isActive ? 'emerald' : 'rose'} size="sm">
                  {isActive ? 'Account Active' : 'Account Inactive'}
                </Badge>
              </div>
              <p className="text-xs text-slate-500 mt-1">{email}</p>
              <p className="text-[11px] text-slate-400 mt-0.5">
                Target: AIIMS NORCET 2026 & NCLEX
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 w-full sm:w-auto">
            {!isEditingName && (
              <Button
                variant="outline"
                size="sm"
                onClick={startEditing}
                leftIcon={<Edit3 className="w-3.5 h-3.5" />}
              >
                Edit Name
              </Button>
            )}

            <Button
              variant="outline"
              size="sm"
              onClick={handleSignOut}
              disabled={isLoggingOut}
              leftIcon={
                isLoggingOut ? (
                  <Loader2 className="w-3.5 h-3.5 animate-spin" />
                ) : (
                  <LogOut className="w-3.5 h-3.5 text-rose-600" />
                )
              }
              className="text-rose-600 border-rose-200 hover:bg-rose-50 ml-auto sm:ml-0"
            >
              {isLoggingOut ? 'Signing out...' : 'Sign Out'}
            </Button>
          </div>
        </div>

        {/* Name Editing Form (Section 10) */}
        {isEditingName && (
          <form
            onSubmit={handleSaveName}
            className="mt-4 pt-4 border-t border-slate-100 bg-slate-50/70 p-4 rounded-xl space-y-3"
          >
            <div className="text-xs font-bold text-slate-800 flex items-center justify-between">
              <span>Update Full Name</span>
              <span className="text-[11px] text-slate-400 font-normal">
                Email and role are managed securely
              </span>
            </div>

            <div className="flex flex-col sm:flex-row gap-2">
              <div className="flex-1">
                <Input
                  value={editedName}
                  onChange={(e) => setEditedName(e.target.value)}
                  placeholder="Enter your real full name"
                  disabled={isSavingName}
                  required
                  autoFocus
                />
              </div>
              <div className="flex items-center gap-2">
                <Button
                  type="submit"
                  variant="primary"
                  size="md"
                  disabled={isSavingName}
                  leftIcon={
                    isSavingName ? (
                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                    ) : (
                      <Check className="w-3.5 h-3.5" />
                    )
                  }
                >
                  {isSavingName ? 'Saving...' : 'Save'}
                </Button>
                <Button
                  type="button"
                  variant="outline"
                  size="md"
                  onClick={cancelEditing}
                  disabled={isSavingName}
                  leftIcon={<X className="w-3.5 h-3.5" />}
                >
                  Cancel
                </Button>
              </div>
            </div>
          </form>
        )}

        {/* Quick Academic Indicators */}
        <div className="grid grid-cols-3 gap-2 mt-5 pt-4 border-t border-slate-100 text-center">
          <div className="bg-slate-50 p-2.5 rounded-xl">
            <span className="text-base sm:text-lg font-extrabold text-blue-700">1</span>
            <p className="text-[11px] text-slate-500 font-medium">Active Batch</p>
          </div>
          <div className="bg-slate-50 p-2.5 rounded-xl">
            <span className="text-base sm:text-lg font-extrabold text-emerald-700">24</span>
            <p className="text-[11px] text-slate-500 font-medium">Lectures</p>
          </div>
          <div className="bg-slate-50 p-2.5 rounded-xl">
            <span className="text-base sm:text-lg font-extrabold text-amber-700">12</span>
            <p className="text-[11px] text-slate-500 font-medium">Tests Done</p>
          </div>
        </div>
      </div>

      {/* Account Settings & Firestore Record Details */}
      <div className="bg-white rounded-2xl border border-slate-100 p-4 shadow-xs divide-y divide-slate-100 text-sm">
        <div className="py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <User className="w-4 h-4 text-slate-400" />
            <div>
              <p className="text-xs font-bold text-slate-800">Student Full Name</p>
              <p className="text-xs text-slate-600">{fullName}</p>
            </div>
          </div>
          <Badge variant="slate" size="sm">Firestore Verified</Badge>
        </div>

        <div className="py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Mail className="w-4 h-4 text-slate-400" />
            <div>
              <p className="text-xs font-bold text-slate-800">Email Address</p>
              <p className="text-xs text-slate-600 font-mono">{email}</p>
            </div>
          </div>
          <Badge variant="emerald" size="sm">
            {currentUser?.emailVerified ? 'Verified' : 'Auth Registered'}
          </Badge>
        </div>

        <div className="py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <ShieldCheck className="w-4 h-4 text-slate-400" />
            <div>
              <p className="text-xs font-bold text-slate-800">Assigned Role</p>
              <p className="text-xs text-slate-500 capitalize">{role}</p>
            </div>
          </div>
          <Badge variant={role === 'admin' ? 'purple' : 'blue'} size="sm">
            {role === 'admin' ? 'Admin Access' : 'Student Access'}
          </Badge>
        </div>

        <div className="py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Calendar className="w-4 h-4 text-slate-400" />
            <div>
              <p className="text-xs font-bold text-slate-800">Registration Date</p>
              <p className="text-xs text-slate-500">{creationDateDisplay}</p>
            </div>
          </div>
          <Badge variant="slate" size="sm">Enrolled</Badge>
        </div>

        <div className="py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Bell className="w-4 h-4 text-slate-400" />
            <div>
              <p className="text-xs font-bold text-slate-800">Exam Alert Notifications</p>
              <p className="text-xs text-slate-500">Live class and mock test alerts</p>
            </div>
          </div>
          <Badge variant="emerald" size="sm">Enabled</Badge>
        </div>

        <div className="py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Shield className="w-4 h-4 text-slate-400" />
            <div>
              <p className="text-xs font-bold text-slate-800">Database & Security</p>
              <p className="text-xs text-slate-500">
                Firestore User Collection (users/{currentUser?.uid ? `${currentUser.uid.slice(0, 8)}...` : 'uid'})
              </p>
            </div>
          </div>
          <Badge variant="blue" size="sm">Protected</Badge>
        </div>
      </div>

      {/* Support Helpline */}
      <div className="bg-white rounded-2xl border border-slate-100 p-4 shadow-xs">
        <a
          href={`tel:${SITE_CONFIG.supportPhone}`}
          className="flex items-center justify-between p-2.5 rounded-xl hover:bg-slate-50 text-slate-700 transition-colors"
        >
          <div className="flex items-center gap-3">
            <HelpCircle className="w-4 h-4 text-blue-600" />
            <span className="text-xs font-bold">24/7 Nursing Student Support</span>
          </div>
          <span className="text-xs text-slate-500">{SITE_CONFIG.supportPhone}</span>
        </a>
      </div>
    </div>
  );
}

export default StudentProfilePage;
