/**
 * Axon Nursing Academy - Full-Page Google Gemini Style Axon AI (Academic Doubt Room)
 * 
 * Features:
 * - Full-page immersive layout matching Google Gemini's clean, elegant interface
 * - Multi-turn conversational flow where previous Q&As scroll smoothly upward
 * - Server-side Gemini API integration (/api/axon-ai/chat) with fallback to clinical knowledge engine
 * - Strict non-medical domain guardrail policy enforcement
 * - Rich markdown rendering with bold clinical rationales, tables, and NORCET pearls
 * - Audio narration (TTS), copy, feedback, and speech-to-text dictation
 * - Minimalist top bar and collapsible sidebar for past session management
 */
import React, { useState, useEffect, useRef } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import {
  Sparkles,
  ArrowUp,
  Menu,
  Plus,
  Trash2,
  ArrowLeft,
  Loader2,
} from 'lucide-react';
import { useAuth } from '@/src/contexts/AuthContext';
import { ChatMessageItem, ChatMessageData } from '@/src/components/chat/ChatMessageItem';
import { getApiUrl } from '@/src/services/api';
import { PromptSuggestions } from '@/src/components/chat/PromptSuggestions';
import { ChatSidebar, ChatSession } from '@/src/components/chat/ChatSidebar';
import { ConfirmationModal } from '@/src/components/admin/ConfirmationModal';
import { NON_MEDICAL_REFUSAL, isClearlyNonMedical } from '@/src/services/ai/geminiMentorService';

const SESSIONS_STORAGE_KEY = 'axon_ai_chat_sessions_v1';
const CURRENT_SESSION_ID_KEY = 'axon_ai_current_session_id_v1';

export function StudentChatsPage() {
  const { currentUser, profile } = useAuth();
  const navigate = useNavigate();

  const studentName = profile?.fullName || currentUser?.displayName || 'Aspirant';
  const studentUid = currentUser?.uid || '';
  const studentEmail = currentUser?.email || '';

  // Sessions state
  const [sessions, setSessions] = useState<ChatSession[]>(() => {
    try {
      const saved = localStorage.getItem(SESSIONS_STORAGE_KEY);
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [currentSessionId, setCurrentSessionId] = useState<string | null>(() => {
    try {
      return localStorage.getItem(CURRENT_SESSION_ID_KEY) || null;
    } catch {
      return null;
    }
  });

  // Current session messages
  const [messages, setMessages] = useState<ChatMessageData[]>(() => {
    try {
      const activeId = localStorage.getItem(CURRENT_SESSION_ID_KEY);
      if (activeId) {
        const savedMessages = localStorage.getItem(`axon_ai_msgs_${activeId}`);
        return savedMessages ? JSON.parse(savedMessages) : [];
      }
      return [];
    } catch {
      return [];
    }
  });

  // Input & generation state
  const [inputPrompt, setInputPrompt] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [showClearModal, setShowClearModal] = useState(false);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  // Auto-save sessions to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(SESSIONS_STORAGE_KEY, JSON.stringify(sessions));
    } catch (e) {
      console.warn('Could not save sessions to localStorage', e);
    }
  }, [sessions]);

  // Auto-save messages for current active session
  useEffect(() => {
    if (currentSessionId) {
      try {
        localStorage.setItem(`axon_ai_msgs_${currentSessionId}`, JSON.stringify(messages));
      } catch (e) {
        console.warn('Could not save messages to localStorage', e);
      }
    }
  }, [messages, currentSessionId]);

  // Scroll to bottom on new messages
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isLoading]);

  // Auto-resize textarea
  const adjustTextareaHeight = () => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = `${Math.min(textareaRef.current.scrollHeight, 180)}px`;
    }
  };

  useEffect(() => {
    adjustTextareaHeight();
  }, [inputPrompt]);

  // Start new clean chat session
  const handleNewChat = () => {
    const newId = `session_${Date.now()}`;
    setCurrentSessionId(newId);
    setMessages([]);
    localStorage.setItem(CURRENT_SESSION_ID_KEY, newId);
    setInputPrompt('');
    setErrorMessage(null);
    if (textareaRef.current) {
      textareaRef.current.focus();
    }
  };

  // Switch to an existing session
  const handleSelectSession = (sessionId: string) => {
    setCurrentSessionId(sessionId);
    localStorage.setItem(CURRENT_SESSION_ID_KEY, sessionId);
    try {
      const saved = localStorage.getItem(`axon_ai_msgs_${sessionId}`);
      setMessages(saved ? JSON.parse(saved) : []);
    } catch {
      setMessages([]);
    }
    setErrorMessage(null);
  };

  // Delete a session
  const handleDeleteSession = (sessionId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const updated = sessions.filter((s) => s.id !== sessionId);
    setSessions(updated);
    localStorage.removeItem(`axon_ai_msgs_${sessionId}`);

    if (currentSessionId === sessionId) {
      if (updated.length > 0) {
        handleSelectSession(updated[0].id);
      } else {
        handleNewChat();
      }
    }
  };

  // Clear current conversation
  const handleClearCurrent = () => {
    setShowClearModal(true);
  };

  const confirmClearCurrent = () => {
    setMessages([]);
    if (currentSessionId) {
      localStorage.removeItem(`axon_ai_msgs_${currentSessionId}`);
    }
    setShowClearModal(false);
  };

  // Send message
  const handleSendMessage = async (promptOverride?: string) => {
    const promptToSend = (promptOverride || inputPrompt).trim();
    if (!promptToSend || isLoading) return;

    setErrorMessage(null);
    setInputPrompt('');
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
    }

    // Ensure session exists
    let activeSessionId = currentSessionId;
    if (!activeSessionId) {
      activeSessionId = `session_${Date.now()}`;
      setCurrentSessionId(activeSessionId);
      localStorage.setItem(CURRENT_SESSION_ID_KEY, activeSessionId);
    }

    // Create user message
    const userMsg: ChatMessageData = {
      id: `usr_${Date.now()}`,
      role: 'user',
      text: promptToSend,
      timestamp: new Date().toISOString(),
    };

    // Update sessions list preview/title if this is the first message
    const titleSnippet =
      promptToSend.length > 36 ? `${promptToSend.substring(0, 36)}...` : promptToSend;

    setSessions((prev) => {
      const existing = prev.find((s) => s.id === activeSessionId);
      if (existing) {
        return prev.map((s) =>
          s.id === activeSessionId
            ? { ...s, updatedAt: new Date().toISOString(), preview: titleSnippet }
            : s
        );
      } else {
        return [
          {
            id: activeSessionId!,
            title: titleSnippet,
            preview: titleSnippet,
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString(),
          },
          ...prev,
        ];
      }
    });

    const updatedMessages = [...messages, userMsg];
    setMessages(updatedMessages);
    setIsLoading(true);

    // 1. Client-Side Non-Medical Check for Instant Response
    if (isClearlyNonMedical(promptToSend)) {
      setTimeout(() => {
        const refusalMsg: ChatMessageData = {
          id: `ai_${Date.now()}`,
          role: 'model',
          text: NON_MEDICAL_REFUSAL,
          timestamp: new Date().toISOString(),
          source: 'clinical_engine',
        };
        setMessages((prev) => [...prev, refusalMsg]);
        setIsLoading(false);
      }, 350);
      return;
    }

    // 2. Call Server-Side Gemini API
    try {
      // Prepare history formatted for API
      const historyPayload = messages.slice(-10).map((m) => ({
        role: m.role,
        text: m.text,
      }));

      const token = currentUser ? await currentUser.getIdToken().catch(() => null) : null;
      const headers: Record<string, string> = {
        'Content-Type': 'application/json',
      };
      if (token) {
        headers['Authorization'] = `Bearer ${token}`;
      }

      const res = await fetch(getApiUrl('/api/axon-ai/chat'), {
        method: 'POST',
        headers,
        body: JSON.stringify({
          prompt: promptToSend,
          messages: historyPayload,
        }),
      });

      if (!res.ok) {
        throw new Error(`Server returned status ${res.status}`);
      }

      const data = await res.json();
      const aiText = data.text || NON_MEDICAL_REFUSAL;

      const aiMsg: ChatMessageData = {
        id: `ai_${Date.now()}`,
        role: 'model',
        text: aiText,
        timestamp: new Date().toISOString(),
        source: data.source || 'gemini',
      };

      setMessages((prev) => [...prev, aiMsg]);
    } catch (err: any) {
      console.warn('Axon AI response fetch fallback:', err?.message || err);
      // Helpful fallback message explaining momentary interruption with retry
      const fallbackMsg: ChatMessageData = {
        id: `ai_${Date.now()}`,
        role: 'model',
        text: `### Clinical Mentor Connection Notice\n\nI experienced a momentary connection interruption while synthesizing the clinical rationale for **"${promptToSend}"**.\n\nPlease click the **Retry** button below or submit your question again.`,
        timestamp: new Date().toISOString(),
        source: 'clinical_engine',
      };
      setMessages((prev) => [...prev, fallbackMsg]);
    } finally {
      setIsLoading(false);
    }
  };

  // Keyboard shortcut: Enter to send, Shift+Enter for newline
  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  return (
    <div className="fixed inset-0 h-[100dvh] z-50 bg-[#f8fafc] text-slate-900 flex overflow-hidden font-['Plus_Jakarta_Sans',sans-serif]">
      {/* Google Gemini Collapsible Sidebar */}
      <ChatSidebar
        isOpen={isSidebarOpen}
        onClose={() => setIsSidebarOpen(false)}
        sessions={sessions}
        currentSessionId={currentSessionId}
        onSelectSession={handleSelectSession}
        onNewChat={handleNewChat}
        onDeleteSession={handleDeleteSession}
      />

      {/* Main Gemini Chat Stage */}
      <div className="flex-1 flex flex-col h-full min-w-0 relative bg-white sm:bg-[#f8fafc]">
        {/* Top Minimalist Header */}
        <header className="h-14 sm:h-16 px-3 sm:px-6 border-b border-slate-200/80 bg-white flex items-center justify-between shrink-0 z-10 shadow-2xs">
          {/* Left: Sidebar Toggle, Brand & Model Tag */}
          <div className="flex items-center gap-2 sm:gap-3">
            <button
              onClick={() => setIsSidebarOpen(!isSidebarOpen)}
              className="p-2 rounded-xl text-slate-600 hover:text-slate-900 hover:bg-slate-100 transition-colors"
              title="Toggle sidebar"
            >
              <Menu className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-blue-600 via-indigo-600 to-sky-400 text-white flex items-center justify-center shadow-xs">
                <Sparkles className="w-4 h-4" />
              </div>
              <div>
                <div className="flex items-center gap-1.5">
                  <h1 className="text-sm sm:text-base font-extrabold text-slate-900 tracking-tight">
                    Axon AI
                  </h1>
                  <span className="hidden sm:inline-flex text-[10px] font-bold px-2 py-0.5 rounded-full bg-blue-50 text-blue-700 border border-blue-200/60">
                    Clinical Mentor
                  </span>
                </div>
                <p className="text-[10px] text-slate-400 font-medium leading-none hidden xs:block">
                  Google Gemini 3.8 • AIIMS NORCET & Nursing Sciences
                </p>
              </div>
            </div>
          </div>

          {/* Right: Actions (New Chat, Clear, Back to Portal) */}
          <div className="flex items-center gap-1.5 sm:gap-2">
            <button
              onClick={handleNewChat}
              className="py-1.5 px-3 rounded-full border border-slate-200 bg-white hover:bg-slate-50 text-slate-700 text-xs font-semibold flex items-center gap-1.5 shadow-2xs transition-colors"
              title="Start a fresh chat"
            >
              <Plus className="w-3.5 h-3.5 text-blue-600 stroke-[2.5]" />
              <span className="hidden xs:inline">New Chat</span>
            </button>

            {messages.length > 0 && (
              <button
                onClick={handleClearCurrent}
                className="p-2 rounded-xl text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition-colors"
                title="Clear current conversation"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            )}

            <Link
              to="/student"
              className="py-1.5 px-3 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold flex items-center gap-1.5 transition-colors ml-1"
              title="Return to Student Portal"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Portal</span>
            </Link>
          </div>
        </header>

        {/* Scrollable Conversation Stream Area */}
        <div className="flex-1 overflow-y-auto px-3 sm:px-8 py-4 sm:py-6">
          <div className="max-w-4xl mx-auto w-full min-h-full flex flex-col justify-between">
            {/* If no messages: Gemini Welcome & Prompt Starter Cards */}
            {messages.length === 0 ? (
              <PromptSuggestions
                studentName={studentName}
                onSelectPrompt={(text) => handleSendMessage(text)}
              />
            ) : (
              /* Message Stream: Upward-scrolling multi-turn thread */
              <div className="space-y-4 pb-4">
                {messages.map((msg, idx) => (
                  <ChatMessageItem
                    key={msg.id}
                    message={msg}
                    studentName={studentName}
                    isLast={idx === messages.length - 1}
                    onRetry={(retryText) => {
                      const lastUserMsg = [...messages].reverse().find((m) => m.role === 'user');
                      if (lastUserMsg) {
                        handleSendMessage(lastUserMsg.text);
                      }
                    }}
                  />
                ))}

                {/* Gemini Thinking / Formulating Indicator */}
                {isLoading && (
                  <div className="flex items-start gap-3 sm:gap-4 my-6 animate-in fade-in duration-200 max-w-4xl">
                    <div className="w-8 h-8 sm:w-9 sm:h-9 rounded-full bg-gradient-to-tr from-blue-600 via-indigo-600 to-sky-400 text-white flex items-center justify-center shrink-0 shadow-xs animate-pulse ring-2 ring-blue-100 mt-1">
                      <Sparkles className="w-4 h-4 sm:w-4.5 sm:h-4.5 animate-spin" />
                    </div>
                    <div className="space-y-2 pt-1 flex-1">
                      <div className="flex items-center gap-2">
                        <span className="text-xs sm:text-sm font-bold text-slate-800">
                          Axon AI
                        </span>
                        <span className="text-[10px] font-semibold text-blue-600 animate-pulse">
                          Formulating clinical rationale...
                        </span>
                      </div>
                      <div className="space-y-2 max-w-lg">
                        <div className="h-3.5 bg-slate-200/70 rounded-md w-full animate-pulse" />
                        <div className="h-3.5 bg-slate-200/70 rounded-md w-4/5 animate-pulse" />
                        <div className="h-3.5 bg-slate-200/70 rounded-md w-2/3 animate-pulse" />
                      </div>
                    </div>
                  </div>
                )}

                <div ref={messagesEndRef} />
              </div>
            )}
          </div>
        </div>

        {/* Gemini Bottom Input Area (Centered Pill Container) */}
        <div className="p-3 sm:p-5 pb-[max(0.75rem,env(safe-area-inset-bottom))] bg-gradient-to-t from-white via-white to-transparent sm:from-[#f8fafc] sm:via-[#f8fafc] shrink-0">
          <div className="max-w-3xl sm:max-w-4xl mx-auto w-full">
            {/* Input Capsule */}
            <div className="relative flex items-end gap-2 bg-white rounded-3xl border border-slate-200/90 shadow-md focus-within:border-blue-500 focus-within:ring-2 focus-within:ring-blue-100 p-2 sm:p-2.5 px-3 sm:px-4 transition-all">
              {/* Expanding Textarea */}
              <textarea
                ref={textareaRef}
                value={inputPrompt}
                onChange={(e) => setInputPrompt(e.target.value)}
                onKeyDown={handleKeyDown}
                rows={1}
                placeholder="Ask Axon AI about nursing subjects, NORCET clinical doubts, drug dosages, protocols..."
                className="flex-1 max-h-40 bg-transparent text-slate-900 placeholder:text-slate-400 text-xs sm:text-sm resize-none focus:outline-none py-2 px-1 leading-relaxed"
              />

              {/* Send Button */}
              <button
                type="button"
                onClick={() => handleSendMessage()}
                disabled={!inputPrompt.trim() || isLoading}
                className={`w-9 h-9 rounded-full flex items-center justify-center shrink-0 transition-all ${
                  inputPrompt.trim() && !isLoading
                    ? 'bg-blue-600 hover:bg-blue-700 text-white shadow-xs'
                    : 'bg-slate-100 text-slate-300 cursor-not-allowed'
                }`}
                title="Send message"
              >
                {isLoading ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  <ArrowUp className="w-4 h-4 stroke-[2.5]" />
                )}
              </button>
            </div>

            {/* Bottom Disclaimer */}
            <p className="text-[11px] text-center text-slate-400 mt-2">
              Axon AI specializes in Nursing & Healthcare Sciences. Always verify critical clinical protocols with authorized hospital guidelines.
            </p>
          </div>
        </div>
      </div>

      <ConfirmationModal
        isOpen={showClearModal}
        title="Clear Conversation"
        message="Are you sure you want to clear all messages in this conversation? This action cannot be undone."
        confirmLabel="Clear All"
        cancelLabel="Cancel"
        isDestructive={true}
        onConfirm={confirmClearCurrent}
        onCancel={() => setShowClearModal(false)}
      />
    </div>
  );
}
export default StudentChatsPage;
