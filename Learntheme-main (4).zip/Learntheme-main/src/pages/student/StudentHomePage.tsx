/**
 * Axon Nursing Academy - Student Home Portal (Phase 3 Firestore LMS Integration)
 * Reads real published & featured batches directly from Firestore `batches` collection.
 */
import React, { useState, useEffect, useCallback } from 'react';
import { Link } from 'react-router-dom';
import {
  Search,
  Sparkles,
  Video,
  FileCheck,
  FileText,
  BookOpen,
  MessageSquare,
  Bell,
  PhoneCall,
  GraduationCap,
  AlertCircle,
  RefreshCw,
  Layers,
} from 'lucide-react';
import {
  DEMO_BANNERS,
  DEMO_QUICK_ACTIONS,
  DEMO_CATEGORIES,
  DEMO_NOTICES,
} from '@/src/data/demoData';
import { SITE_CONFIG } from '@/src/config/site.config';
import { ROUTES } from '@/src/config/routes.config';
import { BannerCard } from '@/src/components/ui/BannerCard';
import { BatchCard } from '@/src/components/course/BatchCard';
import { CategoryCard } from '@/src/components/ui/CategoryCard';
import { SectionHeader } from '@/src/components/ui/SectionHeader';
import { Button } from '@/src/components/ui/Button';
import { Badge } from '@/src/components/ui/Badge';
import { useAuth } from '@/src/contexts/AuthContext';
import { getFeaturedBatches, getPublishedBatches, subscribeToPublishedBatches } from '@/src/services/firebase/batchService';
import { fallbackStore } from '@/src/services/fallback/fallbackStore';
import { Batch } from '@/src/types/lms.types';

export function StudentHomePage() {
  const { currentUser, profile } = useAuth();
  const [activeBannerIndex, setActiveBannerIndex] = useState(0);
  const [searchQuery, setSearchQuery] = useState('');

  const cachedFeatured = fallbackStore.getBatches().filter((b) => b.isFeatured && b.isPublished);
  const cachedAll = fallbackStore.getBatches().filter((b) => b.isPublished);

  const [featuredBatches, setFeaturedBatches] = useState<Batch[]>(() => cachedFeatured);
  const [availableBatches, setAvailableBatches] = useState<Batch[]>(() => cachedAll);
  const [isLoadingBatches, setIsLoadingBatches] = useState<boolean>(() => cachedAll.length === 0);
  const [batchesError, setBatchesError] = useState<string | null>(null);

  const displayName =
    profile?.fullName ||
    currentUser?.displayName ||
    currentUser?.email?.split('@')[0] ||
    'Nursing Aspirant';

  const quickActionIcons: Record<string, React.ReactNode> = {
    Video: <Video className="w-5 h-5 sm:w-6 sm:h-6" />,
    FileCheck: <FileCheck className="w-5 h-5 sm:w-6 sm:h-6" />,
    FileText: <FileText className="w-5 h-5 sm:w-6 sm:h-6" />,
    BookOpen: <BookOpen className="w-5 h-5 sm:w-6 sm:h-6" />,
    MessageSquare: <MessageSquare className="w-5 h-5 sm:w-6 sm:h-6" />,
    Bell: <Bell className="w-5 h-5 sm:w-6 sm:h-6" />,
  };

  const loadBatchesFromFirestore = useCallback(async () => {
    if (availableBatches.length === 0) {
      setIsLoadingBatches(true);
    }
    setBatchesError(null);
    try {
      // 1. Fetch featured published batches
      const featured = await getFeaturedBatches();
      setFeaturedBatches(featured);

      // 2. Fetch all published batches
      const allPublished = await getPublishedBatches();
      setAvailableBatches(allPublished);
    } catch (err: any) {
      console.warn('[StudentHomePage] Notice fetching Firestore batches:', err);
      setBatchesError(err?.message || 'Unable to connect to course database.');
    } finally {
      setIsLoadingBatches(false);
    }
  }, [availableBatches.length]);

  useEffect(() => {
    loadBatchesFromFirestore();
    const unsubscribe = subscribeToPublishedBatches((liveBatches) => {
      const list = liveBatches || [];
      setAvailableBatches(list);
      const featured = list.filter((b) => b.isFeatured);
      setFeaturedBatches(featured.length > 0 ? featured : list);
      setIsLoadingBatches(false);
    });
    return () => unsubscribe();
  }, [loadBatchesFromFirestore]);

  // Auto-rotate promotional banners smoothly every 5 seconds
  useEffect(() => {
    if (DEMO_BANNERS.length <= 1) return;
    const interval = setInterval(() => {
      setActiveBannerIndex((prev) => (prev + 1) % DEMO_BANNERS.length);
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  const displayedBatches =
    featuredBatches.length > 0 ? featuredBatches : availableBatches.slice(0, 3);

  return (
    <div className="space-y-6 sm:space-y-8">
      {/* 1. Welcome Sub-Header & Live Notice Ticker */}
      <div className="bg-white rounded-2xl border border-slate-100 p-3.5 sm:p-4 shadow-xs">
        <div className="flex items-center justify-between gap-3">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="w-8 h-8 rounded-full bg-blue-50 text-blue-600 flex items-center justify-center shrink-0">
              <GraduationCap className="w-4 h-4" />
            </div>
            <div className="truncate">
              <p className="text-xs font-semibold text-slate-500">Welcome Back,</p>
              <h1 className="text-sm sm:text-base font-extrabold text-slate-900 truncate">
                {displayName}
              </h1>
            </div>
          </div>
          <div className="hidden xs:flex flex-col items-end">
            <Badge variant="blue" size="sm">
              AIIMS NORCET 2026
            </Badge>
            {currentUser?.email && (
              <span className="text-[10px] text-slate-400 font-mono mt-0.5 max-w-[180px] truncate">
                {currentUser.email}
              </span>
            )}
          </div>
        </div>

        {/* Live Exam Notice Strip */}
        {DEMO_NOTICES.length > 0 && (
          <div className="mt-3 pt-2.5 border-t border-slate-100 flex items-center gap-2 text-xs">
            <span className="shrink-0 flex items-center gap-1 font-bold text-rose-600 bg-rose-50 px-2 py-0.5 rounded-md text-[10px] uppercase tracking-wider">
              <span className="w-1.5 h-1.5 rounded-full bg-rose-600 animate-ping" />
              Notice
            </span>
            <p className="text-slate-700 truncate font-medium flex-1">
              {DEMO_NOTICES[0].title}
            </p>
            <Link
              to={ROUTES.STUDENT.ALL_COURSES}
              className="text-blue-600 hover:text-blue-700 text-[11px] font-bold shrink-0"
            >
              View
            </Link>
          </div>
        )}
      </div>

      {/* 2. Promotional Banner Carousel / Hero Showcase */}
      <section aria-label="Promotional Banners">
        <div className="relative">
          <BannerCard banner={DEMO_BANNERS[activeBannerIndex]} />

          {/* Banner Dot Indicators */}
          <div className="flex justify-center items-center gap-1.5 mt-2.5">
            {DEMO_BANNERS.map((_, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => setActiveBannerIndex(idx)}
                className={`h-1.5 rounded-full transition-all duration-200 cursor-pointer ${
                  activeBannerIndex === idx ? 'w-6 bg-blue-600' : 'w-2 bg-slate-300'
                }`}
                aria-label={`Slide ${idx + 1}`}
              />
            ))}
          </div>
        </div>
      </section>

      {/* 3. Quick Actions Section */}
      <section aria-label="Quick Actions">
        <div className="grid grid-cols-3 sm:grid-cols-6 gap-2.5 sm:gap-3">
          {DEMO_QUICK_ACTIONS.map((action) => (
            <Link
              key={action.id}
              to={action.route}
              className="group bg-white rounded-2xl border border-slate-100 p-3 sm:p-3.5 flex flex-col items-center text-center shadow-xs hover:shadow-md hover:border-slate-200 transition-all duration-200 active:scale-95"
            >
              <div
                className={`w-11 h-11 sm:w-12 sm:h-12 rounded-xl flex items-center justify-center mb-2 shadow-xs group-hover:scale-105 transition-transform ${action.bgClass} ${action.colorClass}`}
              >
                {quickActionIcons[action.iconName]}
              </div>
              <span className="text-[11px] sm:text-xs font-bold text-slate-800 leading-tight">
                {action.title}
              </span>
              {action.badge && (
                <span className="mt-1 text-[9px] font-extrabold text-blue-600 bg-blue-50 px-1.5 py-0.2 rounded">
                  {action.badge}
                </span>
              )}
            </Link>
          ))}
        </div>
      </section>

      {/* 4. REAL FIRESTORE FEATURED BATCHES (Section 9) */}
      <section aria-label="Featured Batches">
        <SectionHeader
          title="Featured Intensive Batches"
          subtitle="Top-rated comprehensive coaching programs for AIIMS NORCET & Nursing Officer Exams"
          badgeText="High Yield"
          viewAllLink={ROUTES.STUDENT.ALL_COURSES}
        />

        {isLoadingBatches ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {[1, 2, 3].map((i) => (
              <div key={i} className="bg-white rounded-2xl border border-slate-100 p-4 space-y-3 animate-pulse card-isolate">
                <div className="aspect-[16/10] bg-slate-200 rounded-xl w-full" style={{ aspectRatio: '16 / 10' }} />
                <div className="h-5 bg-slate-200 rounded w-3/4" />
                <div className="h-3 bg-slate-200 rounded w-full" />
                <div className="h-8 bg-slate-200 rounded-xl mt-2" />
              </div>
            ))}
          </div>
        ) : batchesError ? (
          <div className="bg-white rounded-2xl border border-slate-200 p-6 text-center shadow-xs">
            <AlertCircle className="w-8 h-8 text-amber-500 mx-auto mb-2" />
            <h3 className="text-sm font-bold text-slate-800">Connection Notice</h3>
            <p className="text-xs text-slate-500 mt-1 mb-4">Please check your connection and try again.</p>
            <Button
              size="sm"
              variant="outline"
              onClick={() => loadBatchesFromFirestore()}
              leftIcon={<RefreshCw className="w-3.5 h-3.5" />}
            >
              Retry
            </Button>
          </div>
        ) : displayedBatches.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {displayedBatches.map((batch) => (
              <BatchCard key={batch.id} batch={batch} />
            ))}
          </div>
        ) : (
          <div className="bg-white rounded-2xl border border-slate-200 p-6 sm:p-8 text-center">
            <Layers className="w-10 h-10 text-slate-300 mx-auto mb-2" />
            <h3 className="text-sm font-bold text-slate-800">No Batches Available</h3>
            <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
              New coaching batches and test series will appear here as soon as announced.
            </p>
          </div>
        )}
      </section>

      {/* 5. "What are you looking for?" / Search & Quick Target Selector */}
      <section aria-label="What are you looking for">
        <div className="bg-gradient-to-br from-blue-700 to-indigo-900 rounded-2xl sm:rounded-3xl p-5 sm:p-7 text-white shadow-md">
          <div className="max-w-xl">
            <span className="text-[11px] font-bold tracking-wider uppercase text-blue-200 bg-white/10 px-2 py-0.5 rounded-md">
              Customized Study Planner
            </span>
            <h2 className="text-lg sm:text-2xl font-extrabold mt-1.5 tracking-tight">
              What exam are you preparing for?
            </h2>
            <p className="text-xs sm:text-sm text-blue-100/90 mt-1 mb-4">
              Search real coaching batches, test series, and live modules.
            </p>

            {/* Quick search input (Section 24) */}
            <div className="relative flex items-center">
              <Search className="w-4 h-4 absolute left-3.5 text-slate-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search Shikhar, NORCET, NCLEX, Anatomy..."
                className="w-full bg-white text-slate-900 placeholder:text-slate-400 text-xs sm:text-sm rounded-xl pl-10 pr-24 py-3 font-medium focus:outline-none focus:ring-2 focus:ring-blue-300 shadow-sm"
              />
              <Link
                to={searchQuery ? `/student/all-courses?q=${encodeURIComponent(searchQuery)}` : ROUTES.STUDENT.ALL_COURSES}
                className="absolute right-1.5"
              >
                <Button size="sm" variant="primary" className="h-8 text-xs">
                  Search
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* 6. AVAILABLE BATCHES (REAL FIRESTORE) */}
      <section aria-label="Available Batches">
        <SectionHeader
          title="All Available Batches"
          subtitle="Explore all officially published nursing courses"
          viewAllLink={ROUTES.STUDENT.ALL_COURSES}
        />

        {isLoadingBatches ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {[1, 2, 3].map((i) => (
              <div key={i} className="bg-white rounded-2xl border border-slate-100 p-4 space-y-3 animate-pulse card-isolate">
                <div className="aspect-[16/10] bg-slate-200 rounded-xl w-full" style={{ aspectRatio: '16 / 10' }} />
                <div className="h-5 bg-slate-200 rounded w-3/4" />
                <div className="h-3 bg-slate-200 rounded w-full" />
                <div className="h-8 bg-slate-200 rounded-xl mt-2" />
              </div>
            ))}
          </div>
        ) : availableBatches.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {availableBatches.map((batch) => (
              <BatchCard key={batch.id} batch={batch} />
            ))}
          </div>
        ) : (
          <div className="bg-white rounded-2xl border border-slate-200 p-8 text-center">
            <BookOpen className="w-10 h-10 text-slate-300 mx-auto mb-2" />
            <h3 className="text-sm font-bold text-slate-800">No Published Batches Found</h3>
            <p className="text-xs text-slate-500 mt-1">
              New batches are being prepared by the administration.
            </p>
          </div>
        )}
      </section>

      {/* 7. Learning Category Cards */}
      <section aria-label="Learning Categories">
        <SectionHeader
          title="Explore Nursing Specializations"
          subtitle="Curriculum and study tracks organized by exam and clinical scope"
          viewAllLink={ROUTES.STUDENT.ALL_COURSES}
        />
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {DEMO_CATEGORIES.map((cat) => (
            <CategoryCard key={cat.id} category={cat} />
          ))}
        </div>
      </section>


      {/* 9. Social / Connect Section */}
      <section aria-label="Social and Community Support">
        <div className="bg-white rounded-2xl border border-slate-200/80 p-5 sm:p-6 shadow-xs">
          <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-1.5 text-blue-600 font-bold text-xs uppercase tracking-wider mb-1">
                <Sparkles className="w-3.5 h-3.5" />
                <span>Join Axon Student Community</span>
              </div>
              <h3 className="text-base sm:text-lg font-bold text-slate-900">
                Connect with Faculty & Peer Aspirants
              </h3>
              <p className="text-xs sm:text-sm text-slate-500 mt-1 max-w-md">
                Get daily free MCQs, image-based clinical flashcards, and official recruitment updates directly on our community channels.
              </p>
            </div>

            <div className="flex flex-wrap gap-2.5 w-full md:w-auto">
              <a
                href={SITE_CONFIG.socialLinks.telegram}
                target="_blank"
                rel="noreferrer"
                className="flex-1 sm:flex-none"
              >
                <Button variant="outline" size="sm" fullWidth>
                  Telegram Channel
                </Button>
              </a>
              <a
                href={SITE_CONFIG.socialLinks.youtube}
                target="_blank"
                rel="noreferrer"
                className="flex-1 sm:flex-none"
              >
                <Button variant="outline" size="sm" fullWidth>
                  YouTube Live
                </Button>
              </a>
              <a
                href={`tel:${SITE_CONFIG.supportPhone}`}
                className="flex-1 sm:flex-none"
              >
                <Button variant="primary" size="sm" fullWidth leftIcon={<PhoneCall className="w-3.5 h-3.5" />}>
                  Counselor Helpline
                </Button>
              </a>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}

export default StudentHomePage;
