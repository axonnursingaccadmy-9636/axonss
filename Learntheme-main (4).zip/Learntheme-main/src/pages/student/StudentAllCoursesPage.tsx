/**
 * Axon Nursing Academy - All Courses & Batches Catalog Page (Phase 3 Firestore LMS)
 * Fetches all published batches from Firestore and provides real-time search & filters.
 */
import React, { useState, useEffect, useCallback } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Search, Sparkles, BookOpen, AlertCircle, RefreshCw } from 'lucide-react';
import { BatchCard } from '@/src/components/course/BatchCard';
import { getPublishedBatches, subscribeToPublishedBatches } from '@/src/services/firebase/batchService';
import { fallbackStore } from '@/src/services/fallback/fallbackStore';
import { Batch } from '@/src/types/lms.types';
import { Button } from '@/src/components/ui/Button';

export function StudentAllCoursesPage() {
  const [searchParams] = useSearchParams();
  const initialQuery = searchParams.get('q') || '';

  const initialBatches = fallbackStore.getBatches().filter((b) => b.isPublished);
  const [batches, setBatches] = useState<Batch[]>(() => initialBatches);
  const [isLoading, setIsLoading] = useState<boolean>(() => initialBatches.length === 0);
  const [error, setError] = useState<string | null>(null);
  const [selectedFilter, setSelectedFilter] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState<string>(initialQuery);

  const filters = [
    { id: 'ALL', label: 'All Batches' },
    { id: 'FREE', label: 'Free Demo Batches' },
    { id: 'FEATURED', label: 'Featured Batches' },
    { id: 'PREMIUM', label: 'Full Preparation Batches' },
  ];

  const fetchBatches = useCallback(async () => {
    if (batches.length === 0) {
      setIsLoading(true);
    }
    setError(null);
    try {
      const data = await getPublishedBatches();
      setBatches(data);
    } catch (err: any) {
      console.error('[StudentAllCoursesPage] Error loading published batches:', err);
      setError(err?.message || 'Unable to load course batches.');
    } finally {
      setIsLoading(false);
    }
  }, [batches.length]);

  useEffect(() => {
    fetchBatches();
    const unsubscribe = subscribeToPublishedBatches((liveBatches) => {
      setBatches(liveBatches || []);
      setIsLoading(false);
    });
    return () => unsubscribe();
  }, [fetchBatches]);

  // Section 24: Search filter by title and shortDescription
  const filteredBatches = batches.filter((batch) => {
    // Filter tag
    if (selectedFilter === 'FREE' && !batch.isFree) return false;
    if (selectedFilter === 'FEATURED' && !batch.isFeatured) return false;
    if (selectedFilter === 'PREMIUM' && batch.isFree) return false;

    // Search query
    if (!searchQuery.trim()) return true;
    const query = searchQuery.toLowerCase();
    const titleMatch = batch.title.toLowerCase().includes(query);
    const descMatch = (batch.shortDescription || '').toLowerCase().includes(query);
    const fullDescMatch = (batch.description || '').toLowerCase().includes(query);
    return titleMatch || descMatch || fullDescMatch;
  });

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-white rounded-2xl border border-slate-100 p-4 sm:p-6 shadow-xs">
        <div className="flex items-center gap-2 text-blue-600 font-bold text-xs uppercase tracking-wider mb-1">
          <Sparkles className="w-3.5 h-3.5" />
          <span>Course Catalog</span>
        </div>
        <h1 className="text-lg sm:text-2xl font-extrabold text-slate-900">
          All Nursing Batches & Test Series
        </h1>
        <p className="text-xs sm:text-sm text-slate-500 mt-1 max-w-xl">
          Explore specialized coaching batches taught by top AIIMS nursing faculty and clinical educators.
        </p>

        {/* Search Bar (Section 24) */}
        <div className="mt-4 relative flex items-center">
          <Search className="w-4 h-4 absolute left-3.5 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search by batch name, subject, or exam code..."
            className="w-full bg-slate-50 text-slate-900 placeholder:text-slate-400 text-xs sm:text-sm rounded-xl pl-10 pr-4 py-2.5 font-medium border border-slate-200 focus:outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-100"
          />
        </div>

        {/* Filter Chips */}
        <div className="flex gap-2 overflow-x-auto pb-1 mt-4 scrollbar-none">
          {filters.map((filter) => (
            <button
              key={filter.id}
              type="button"
              onClick={() => setSelectedFilter(filter.id)}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-colors cursor-pointer ${
                selectedFilter === filter.id
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200 hover:text-slate-900'
              }`}
            >
              {filter.label}
            </button>
          ))}
        </div>
      </div>

      {/* Courses Grid */}
      {isLoading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {[1, 2, 3, 4, 5, 6].map((i) => (
            <div key={i} className="bg-white rounded-2xl border border-slate-100 p-4 space-y-3 animate-pulse">
              <div className="aspect-[16/10] bg-slate-200 rounded-xl w-full" style={{ aspectRatio: '16 / 10' }} />
              <div className="h-5 bg-slate-200 rounded w-3/4" />
              <div className="h-3 bg-slate-200 rounded w-full" />
              <div className="h-8 bg-slate-200 rounded-xl mt-2" />
            </div>
          ))}
        </div>
      ) : error ? (
        <div className="bg-white rounded-2xl border border-slate-200 p-8 text-center shadow-xs">
          <AlertCircle className="w-10 h-10 text-amber-500 mx-auto mb-2" />
          <h3 className="text-sm font-bold text-slate-800">Database Connection Notice</h3>
          <p className="text-xs text-slate-500 mt-1 mb-4">{error}</p>
          <Button
            size="sm"
            variant="outline"
            onClick={() => fetchBatches()}
            leftIcon={<RefreshCw className="w-3.5 h-3.5" />}
          >
            Retry Fetching Courses
          </Button>
        </div>
      ) : filteredBatches.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredBatches.map((batch) => (
            <BatchCard key={batch.id} batch={batch} />
          ))}
        </div>
      ) : (
        <div className="bg-white rounded-2xl border border-slate-200 p-8 text-center">
          <BookOpen className="w-10 h-10 text-slate-300 mx-auto mb-2" />
          <h3 className="text-sm font-bold text-slate-800">
            {batches.length === 0 ? 'No Batches Available' : 'No courses match your filter'}
          </h3>
          <p className="text-xs text-slate-500 mt-1 max-w-md mx-auto">
            {batches.length === 0
              ? 'New batches are being scheduled. Please check back soon or contact academy support.'
              : 'Try clearing your search query or switching the category tab.'}
          </p>
        </div>
      )}
    </div>
  );
}

export default StudentAllCoursesPage;
