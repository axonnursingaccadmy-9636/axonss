/**
 * Axon Nursing Academy - Production MCQ Test Runner Player (Phase 6 & 8)
 * Zero-Trust Secure Test-Taking Engine with real-time countdown, question palette, status tracking, and automated submission.
 * Strictly hardened for Phase 8 Course Access, Attempt Isolation & Assessment Security.
 */
import React, { useState, useEffect, useRef, useMemo } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import {
  Clock,
  CheckCircle2,
  AlertTriangle,
  ChevronLeft,
  ChevronRight,
  Bookmark,
  RotateCcw,
  Send,
  HelpCircle,
  Award,
  FileCheck,
  Grid,
  X,
  ShieldAlert,
  ArrowLeft,
  Lock,
  LogIn,
} from 'lucide-react';
import { ROUTES } from '@/src/config/routes.config';
import { Button } from '@/src/components/ui/Button';
import { LoadingState } from '@/src/components/common/LoadingState';
import { ConfirmationModal } from '@/src/components/admin/ConfirmationModal';
import {
  getWeeklyWarriorTestById,
  getWeeklyWarriorQuestionsForStudent,
  startWeeklyWarriorAttempt,
  submitWeeklyWarriorAttempt,
} from '@/src/services/firebase/weeklyWarriorTestService';
import {
  getUnitTestById,
  getUnitTestQuestionsForStudent,
  startUnitTestAttempt,
  submitUnitTestAttempt,
} from '@/src/services/firebase/unitTestService';
import { checkStudentCourseAccess } from '@/src/services/firebase/enrollmentService';
import {
  WeeklyWarriorTest,
  UnitTest,
  StudentMcqQuestion,
  UserAnswerSubmission,
} from '@/src/types/assessment.types';
import { CourseAccessCheck } from '@/src/types/enrollment.types';
import { fallbackStore } from '@/src/services/fallback/fallbackStore';
import { useAuth } from '@/src/contexts/AuthContext';

type QuestionStatus = 'not_visited' | 'not_answered' | 'answered' | 'marked_review' | 'answered_marked_review';

export function TestPlayerPage() {
  const { testType, testId } = useParams<{ testType: 'weekly-warrior' | 'unit-test'; testId: string }>();
  const navigate = useNavigate();
  const { currentUser, loading: authLoading } = useAuth();

  const cachedTest = useMemo(() => {
    if (!testId || !testType) return null;
    return testType === 'weekly-warrior'
      ? fallbackStore.getWeeklyWarriorTestById(testId)
      : fallbackStore.getUnitTestById(testId);
  }, [testId, testType]);

  const [test, setTest] = useState<WeeklyWarriorTest | UnitTest | null>(() => cachedTest);
  const [questions, setQuestions] = useState<StudentMcqQuestion[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [accessState, setAccessState] = useState<CourseAccessCheck | null>(null);

  // Attempt State
  const [attemptId, setAttemptId] = useState<string>('');
  const [currentIndex, setCurrentIndex] = useState<number>(0);
  const [userSelections, setUserSelections] = useState<Record<string, string>>({}); // questionId -> selectedOptionId
  const [reviewFlags, setReviewFlags] = useState<Record<string, boolean>>({}); // questionId -> isMarked
  const [visitedQuestions, setVisitedQuestions] = useState<Record<string, boolean>>({});

  // Timer State (Seconds remaining)
  const [secondsRemaining, setSecondsRemaining] = useState<number>(() => (cachedTest?.durationMinutes || 30) * 60);
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [showSubmitModal, setShowSubmitModal] = useState<boolean>(false);
  const [isPaletteOpen, setIsPaletteOpen] = useState<boolean>(false);

  // Time tracking
  const startTimeRef = useRef<number>(Date.now());
  const timerIntervalRef = useRef<any>(null);

  useEffect(() => {
    if (!authLoading) {
      initTest();
    }
    return () => {
      if (timerIntervalRef.current) clearInterval(timerIntervalRef.current);
    };
  }, [testId, testType, currentUser?.uid, authLoading]);

  const initTest = async () => {
    if (!testId || !testType) {
      setError('Test identifier and type are required.');
      setLoading(false);
      return;
    }

    // Rule 8.2: Block unauthenticated users immediately - No guest students
    if (!currentUser) {
      setLoading(false);
      return;
    }

    setLoading(true);
    setError(null);

    try {
      let testMeta: WeeklyWarriorTest | UnitTest | null = null;
      let qList: StudentMcqQuestion[] = [];
      let parentBatchId = '';

      // 1. Fetch test metadata
      if (testType === 'weekly-warrior') {
        testMeta = await getWeeklyWarriorTestById(testId);
        if (!testMeta || !testMeta.isPublished) {
          throw new Error('This Weekly Warrior test is not currently available or has been unpublished.');
        }
        parentBatchId = testMeta.batchId;
      } else {
        testMeta = await getUnitTestById(testId);
        if (!testMeta || !testMeta.isPublished) {
          throw new Error('This Unit MCQ test is not currently available or has been unpublished.');
        }
        parentBatchId = testMeta.batchId;
      }

      if (!parentBatchId) {
        throw new Error('Test does not have an associated course batch.');
      }

      // 2. Authoritative Course Access Check (Phase 8 Production Guard)
      const access = await checkStudentCourseAccess(
        currentUser.uid,
        parentBatchId,
        undefined,
        currentUser.email
      );
      setAccessState(access);

      if (!access.hasAccess) {
        setLoading(false);
        return;
      }

      // 3. Hierarchy verification for Unit Tests
      if (testType === 'unit-test') {
        const uTest = testMeta as UnitTest;
        if (!uTest.chapterId || !uTest.subjectId) {
          throw new Error('Unit test does not have complete curriculum hierarchy.');
        }
      }

      // 4. Fetch questions ONLY after access is verified
      let activeAttempt: any = null;
      if (testType === 'weekly-warrior') {
        qList = await getWeeklyWarriorQuestionsForStudent(testId);
        if (qList.length === 0) {
          throw new Error('This test does not have any published questions yet.');
        }

        // Create or resume secure attempt with verified currentUser.uid
        activeAttempt = await startWeeklyWarriorAttempt(
          testId,
          testMeta.batchId,
          currentUser.uid,
          currentUser.displayName || undefined,
          currentUser.email || undefined
        );
        setAttemptId(activeAttempt.id);
      } else {
        qList = await getUnitTestQuestionsForStudent(testId);
        if (qList.length === 0) {
          throw new Error('This unit test does not have any questions yet.');
        }

        const uTest = testMeta as UnitTest;
        // Create or resume secure attempt with verified currentUser.uid
        activeAttempt = await startUnitTestAttempt(
          testId,
          uTest.batchId,
          uTest.subjectId,
          uTest.chapterId,
          currentUser.uid,
          currentUser.displayName || undefined,
          currentUser.email || undefined
        );
        setAttemptId(activeAttempt.id);
      }

      setTest(testMeta);
      setQuestions(qList);

      // Restore previously saved answers and flagged questions if resuming attempt
      if (activeAttempt?.answers && typeof activeAttempt.answers === 'object') {
        setUserSelections(activeAttempt.answers);
      }
      if (Array.isArray(activeAttempt?.markedForReview)) {
        const flaggedMap: Record<string, boolean> = {};
        activeAttempt.markedForReview.forEach((qId: string) => {
          flaggedMap[qId] = true;
        });
        setReviewFlags(flaggedMap);
      }

      // Authoritative duration and timer computation (Section 9.12)
      // Compare current time with attempt.startedAt so refresh does not reset timer
      const totalSecs = (testMeta.durationMinutes || 30) * 60;
      const startedAtMs = activeAttempt?.startedAt ? new Date(activeAttempt.startedAt).getTime() : Date.now();
      startTimeRef.current = startedAtMs;

      const elapsedSecs = Math.max(0, Math.floor((Date.now() - startedAtMs) / 1000));
      const remainingSecs = Math.max(0, totalSecs - elapsedSecs);
      setSecondsRemaining(remainingSecs);

      // Mark first question visited
      if (qList[0]) {
        setVisitedQuestions({ [qList[0].id]: true });
      }

      // If test already expired while student was away, auto-submit immediately
      if (remainingSecs <= 0) {
        handleAutoSubmit();
        return;
      }

      if (timerIntervalRef.current) clearInterval(timerIntervalRef.current);
      // Authoritative Countdown Timer using true elapsed timestamp
      timerIntervalRef.current = setInterval(() => {
        const currentElapsed = Math.floor((Date.now() - startTimeRef.current) / 1000);
        const currentRemaining = Math.max(0, totalSecs - currentElapsed);
        setSecondsRemaining(currentRemaining);

        if (currentRemaining <= 0) {
          if (timerIntervalRef.current) clearInterval(timerIntervalRef.current);
          handleAutoSubmit();
        }
      }, 1000);
    } catch (err: any) {
      console.error('[TestPlayerPage] Failed to init test:', err);
      setError(err.message || 'Failed to start test session.');
    } finally {
      setLoading(false);
    }
  };

  const handleAutoSubmit = async () => {
    await executeSubmission(true);
  };

  const executeSubmission = async (isAuto = false) => {
    if (!testId || !testType || isSubmitting || !currentUser) return;
    if (timerIntervalRef.current) clearInterval(timerIntervalRef.current);

    setIsSubmitting(true);
    const timeSpentSeconds = Math.max(1, Math.round((Date.now() - startTimeRef.current) / 1000));

    try {
      let finalAttemptId = attemptId;
      if (testType === 'weekly-warrior') {
        const result = await submitWeeklyWarriorAttempt(
          attemptId,
          testId,
          userSelections,
          timeSpentSeconds,
          currentUser.uid,
          currentUser.displayName || undefined,
          currentUser.email || undefined
        );
        finalAttemptId = result.attemptId || attemptId;
      } else {
        const result = await submitUnitTestAttempt(
          attemptId,
          testId,
          userSelections,
          timeSpentSeconds,
          currentUser.uid,
          currentUser.displayName || undefined,
          currentUser.email || undefined
        );
        finalAttemptId = result.attemptId || attemptId;
      }

      // Navigate to detailed score & solution review
      navigate(ROUTES.TEST.RESULT(testType, testId, finalAttemptId));
    } catch (err: any) {
      console.error('[TestPlayerPage] Submission failed:', err);
      setError('Error recording test answers. Please retry submitting.');
      setIsSubmitting(false);
    }
  };

  const currentQ = questions[currentIndex];

  const handleSelectOption = (optId: string) => {
    if (!currentQ) return;
    setUserSelections((prev) => ({
      ...prev,
      [currentQ.id]: optId,
    }));
  };

  const handleClearResponse = () => {
    if (!currentQ) return;
    setUserSelections((prev) => {
      const next = { ...prev };
      delete next[currentQ.id];
      return next;
    });
  };

  const handleToggleReview = () => {
    if (!currentQ) return;
    setReviewFlags((prev) => ({
      ...prev,
      [currentQ.id]: !prev[currentQ.id],
    }));
  };

  const goToQuestion = (index: number) => {
    if (index < 0 || index >= questions.length) return;
    const targetQ = questions[index];
    if (targetQ) {
      setVisitedQuestions((prev) => ({ ...prev, [targetQ.id]: true }));
    }
    setCurrentIndex(index);
    setIsPaletteOpen(false);
  };

  const handleNext = () => {
    if (currentIndex < questions.length - 1) {
      goToQuestion(currentIndex + 1);
    }
  };

  const handlePrev = () => {
    if (currentIndex > 0) {
      goToQuestion(currentIndex - 1);
    }
  };

  // Helper for Status Badge of Question in Palette
  const getQuestionStatus = (qId: string): QuestionStatus => {
    const isAnswered = Boolean(userSelections[qId]);
    const isMarked = Boolean(reviewFlags[qId]);
    const isVisited = Boolean(visitedQuestions[qId]);

    if (isAnswered && isMarked) return 'answered_marked_review';
    if (isMarked) return 'marked_review';
    if (isAnswered) return 'answered';
    if (isVisited) return 'not_answered';
    return 'not_visited';
  };

  const getStatusColorClass = (status: QuestionStatus) => {
    switch (status) {
      case 'answered':
        return 'bg-emerald-600 text-white border-emerald-700';
      case 'marked_review':
        return 'bg-purple-600 text-white border-purple-700';
      case 'answered_marked_review':
        return 'bg-blue-600 text-white border-blue-700 ring-2 ring-purple-400';
      case 'not_answered':
        return 'bg-amber-100 text-amber-900 border-amber-300';
      case 'not_visited':
      default:
        return 'bg-slate-100 text-slate-700 border-slate-300';
    }
  };

  // Format Timer String (HH:MM:SS or MM:SS)
  const formatTime = (secs: number) => {
    const hrs = Math.floor(secs / 3600);
    const mins = Math.floor((secs % 3600) / 60);
    const s = secs % 60;
    if (hrs > 0) {
      return `${hrs.toString().padStart(2, '0')}:${mins.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
    }
    return `${mins.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  // Counts for summary
  const answeredCount = Object.keys(userSelections).length;
  const markedCount = Object.values(reviewFlags).filter(Boolean).length;
  const unansweredCount = questions.length - answeredCount;

  if (loading || authLoading) {
    return <LoadingState message="Verifying Course Security & Initializing Exam..." fullScreen />;
  }

  // 1. Unauthenticated Student Guard (Rule 8.2 & Test 1)
  if (!currentUser) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4">
        <div className="bg-white rounded-3xl border border-slate-200 p-8 max-w-md w-full text-center shadow-lg">
          <div className="w-14 h-14 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center mx-auto mb-4">
            <LogIn className="w-7 h-7" />
          </div>
          <h2 className="text-xl font-bold text-slate-900 mb-2">Authentication Required</h2>
          <p className="text-xs sm:text-sm text-slate-500 mb-6 leading-relaxed">
            Please sign in to your student account to access this assessment. Guest examination access is not permitted.
          </p>
          <div className="flex gap-3 justify-center">
            <Button
              variant="outline"
              size="sm"
              onClick={() => navigate('/student/all-courses')}
            >
              Back to Courses
            </Button>
            <Button
              variant="primary"
              size="sm"
              onClick={() => navigate(`/login?redirect=/test/${testType}/${testId}`)}
              leftIcon={<LogIn className="w-4 h-4" />}
            >
              Sign In to Continue
            </Button>
          </div>
        </div>
      </div>
    );
  }

  // 2. Access Denied / Course Locked Guard (Rule 8.1, 8.4, 8.5 & Tests 2, 9, 18)
  if (accessState && !accessState.hasAccess) {
    const isExpired = accessState.status === 'expired';
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4">
        <div className="bg-white rounded-3xl border border-slate-200 p-8 max-w-md w-full text-center shadow-lg">
          <div className={`w-14 h-14 rounded-2xl ${isExpired ? 'bg-amber-50 text-amber-600' : 'bg-rose-50 text-rose-600'} flex items-center justify-center mx-auto mb-4`}>
            {isExpired ? <Clock className="w-7 h-7" /> : <Lock className="w-7 h-7" />}
          </div>
          <h2 className="text-xl font-bold text-slate-900 mb-2">
            {isExpired ? 'Course Access Expired' : 'Assessment Access Denied'}
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 mb-6 leading-relaxed">
            {accessState.reason || 'You do not have an active enrollment in the course batch that owns this assessment.'}
          </p>
          <div className="flex gap-3 justify-center">
            <Button
              variant="outline"
              size="sm"
              onClick={() => navigate('/student/all-courses')}
            >
              Browse Courses
            </Button>
            <Button
              variant="primary"
              size="sm"
              onClick={() => navigate(test?.batchId ? `/course/${test.batchId}` : '/student/all-courses')}
              leftIcon={<ArrowLeft className="w-4 h-4" />}
            >
              {isExpired ? 'Renew Course Access' : 'View Course'}
            </Button>
          </div>
        </div>
      </div>
    );
  }

  // 3. Error State (Resource Not Found / Hierarchy Violation)
  if (error || !test) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4">
        <div className="bg-white rounded-3xl border border-slate-200 p-8 max-w-md w-full text-center shadow-lg">
          <div className="w-14 h-14 rounded-2xl bg-rose-50 text-rose-600 flex items-center justify-center mx-auto mb-4">
            <ShieldAlert className="w-7 h-7" />
          </div>
          <h2 className="text-xl font-bold text-slate-900 mb-2">Unable to Start Exam</h2>
          <p className="text-xs text-slate-500 mb-6 leading-relaxed">
            {error || 'The requested assessment test does not exist, has been unpublished, or violates resource hierarchy.'}
          </p>
          <Button onClick={() => navigate('/student')} className="w-full bg-blue-600 hover:bg-blue-700 text-white">
            Return to Learning Portal
          </Button>
        </div>
      </div>
    );
  }

  const isTimerLow = secondsRemaining <= 300; // < 5 mins

  return (
    <div className="min-h-screen bg-slate-100 flex flex-col select-none">
      {/* 1. SECURE EXAM HEADER */}
      <header className="min-h-16 py-2 bg-slate-900 text-white border-b border-slate-800 px-3 sm:px-4 md:px-6 flex items-center justify-between gap-2 shrink-0 sticky top-0 z-30">
        <div className="flex items-center gap-3 min-w-0">
          <div className="w-9 h-9 rounded-xl bg-blue-600 flex items-center justify-center text-white font-bold shrink-0">
            {testType === 'weekly-warrior' ? <Award className="w-5 h-5" /> : <FileCheck className="w-5 h-5" />}
          </div>
          <div className="min-w-0">
            <h1 className="text-sm font-extrabold tracking-tight truncate text-white">
              {test.title}
            </h1>
            <span className="text-[10px] font-bold text-blue-400 uppercase tracking-wider block">
              {testType === 'weekly-warrior' ? 'Course Weekly Warrior' : 'Chapter Unit Test'} | {questions.length} Questions
            </span>
          </div>
        </div>

        {/* Real-time Countdown Timer & Actions */}
        <div className="flex items-center gap-3">
          <div
            className={`flex items-center gap-2 px-3 py-1.5 rounded-xl font-mono text-sm font-bold border transition-colors ${
              isTimerLow
                ? 'bg-rose-950/80 border-rose-600 text-rose-400 animate-pulse'
                : 'bg-slate-800 border-slate-700 text-slate-200'
            }`}
          >
            <Clock className={`w-4 h-4 ${isTimerLow ? 'text-rose-400' : 'text-blue-400'}`} />
            <span>{formatTime(secondsRemaining)}</span>
          </div>

          <button
            onClick={() => setIsPaletteOpen(true)}
            className="md:hidden p-2 rounded-xl bg-slate-800 text-slate-300 hover:text-white"
            title="Open Question Palette"
          >
            <Grid className="w-5 h-5" />
          </button>

          <Button
            size="sm"
            onClick={() => setShowSubmitModal(true)}
            disabled={isSubmitting}
            className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold shadow-xs"
          >
            {isSubmitting ? 'Submitting...' : 'Submit Test'}
          </Button>
        </div>
      </header>

      {/* 2. MAIN BODY (Split View: Question Engine + Palette) */}
      <div className="flex-1 flex overflow-hidden">
        {/* Left: Interactive Question Sheet */}
        <main className="flex-1 overflow-y-auto p-4 md:p-6 lg:p-8 flex flex-col justify-between">
          <div className="max-w-4xl w-full mx-auto space-y-6">
            {/* Question Header Bar */}
            <div className="flex items-center justify-between pb-3 border-b border-slate-200">
              <div className="flex items-center gap-2">
                <span className="px-3 py-1 rounded-lg bg-blue-600 text-white font-extrabold text-xs">
                  Question {currentIndex + 1} of {questions.length}
                </span>
                {currentQ?.subjectTag && (
                  <span className="px-2.5 py-0.5 rounded-md bg-slate-200 text-slate-700 text-[11px] font-bold">
                    {currentQ.subjectTag}
                  </span>
                )}
              </div>

              <div className="flex items-center gap-3 text-xs font-semibold text-slate-600">
                <span className="text-emerald-700 font-bold">+{currentQ?.marks || 1} Mark</span>
                <span className="text-rose-600 font-bold">-{currentQ?.negativeMarks || 0.33} Negative</span>
              </div>
            </div>

            {/* Question Text */}
            {currentQ ? (
              <div className="space-y-4">
                <p className="text-base sm:text-lg font-bold text-slate-900 leading-relaxed">
                  {currentQ.questionText}
                </p>

                {currentQ.questionImageUrl && (
                  <div className="my-4 max-w-lg rounded-2xl overflow-hidden border border-slate-200 bg-white p-2">
                    <img
                      src={currentQ.questionImageUrl}
                      alt="Clinical Question Reference"
                      className="w-full h-auto object-contain max-h-72 rounded-xl"
                    />
                  </div>
                )}

                {/* Option Selections (A, B, C, D) */}
                <div className="space-y-3 pt-2">
                  {currentQ.options.map((opt, oIdx) => {
                    const optionPrefix = ['A', 'B', 'C', 'D'][oIdx] || String(oIdx + 1);
                    const isSelected = userSelections[currentQ.id] === opt.id;

                    return (
                      <button
                        key={opt.id}
                        type="button"
                        onClick={() => handleSelectOption(opt.id)}
                        className={`w-full text-left p-4 rounded-2xl border transition-all flex items-center gap-3.5 ${
                          isSelected
                            ? 'bg-blue-50 border-blue-600 text-blue-900 shadow-xs ring-1 ring-blue-600 font-semibold'
                            : 'bg-white border-slate-200 text-slate-800 hover:border-slate-300 hover:bg-slate-50'
                        }`}
                      >
                        <div
                          className={`w-8 h-8 rounded-xl font-bold flex items-center justify-center shrink-0 text-xs ${
                            isSelected
                              ? 'bg-blue-600 text-white'
                              : 'bg-slate-100 text-slate-600 border border-slate-200'
                          }`}
                        >
                          {optionPrefix}
                        </div>
                        <span className="text-sm flex-1 leading-snug">{opt.text}</span>
                      </button>
                    );
                  })}
                </div>
              </div>
            ) : (
              <div className="text-center py-12 text-slate-400">Loading question content...</div>
            )}
          </div>

          {/* Action Toolbar (Bottom of question sheet) */}
          <div className="max-w-4xl w-full mx-auto pt-6 border-t border-slate-200 flex flex-wrap items-center justify-between gap-3 mt-8">
            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={handleToggleReview}
                leftIcon={<Bookmark className={`w-4 h-4 ${reviewFlags[currentQ?.id || ''] ? 'fill-purple-600 text-purple-600' : ''}`} />}
                className={reviewFlags[currentQ?.id || ''] ? 'border-purple-600 text-purple-700 bg-purple-50' : ''}
              >
                {reviewFlags[currentQ?.id || ''] ? 'Marked for Review' : 'Mark for Review'}
              </Button>

              {userSelections[currentQ?.id || ''] && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={handleClearResponse}
                  leftIcon={<RotateCcw className="w-3.5 h-3.5 text-slate-400" />}
                  className="text-slate-600"
                >
                  Clear Response
                </Button>
              )}
            </div>

            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={handlePrev}
                disabled={currentIndex === 0}
                leftIcon={<ChevronLeft className="w-4 h-4" />}
              >
                Previous
              </Button>

              <Button
                variant="primary"
                size="sm"
                onClick={handleNext}
                disabled={currentIndex === questions.length - 1}
                rightIcon={<ChevronRight className="w-4 h-4" />}
              >
                Save & Next
              </Button>
            </div>
          </div>
        </main>

        {/* Right: Question Palette & Status Legend (Desktop permanent / Mobile drawer) */}
        {isPaletteOpen && (
          <div
            className="fixed inset-0 bg-slate-950/60 z-30 md:hidden"
            onClick={() => setIsPaletteOpen(false)}
            aria-hidden="true"
          />
        )}
        <aside
          className={`fixed inset-y-0 right-0 z-40 w-80 max-w-[85vw] bg-white border-l border-slate-200 p-5 flex flex-col justify-between transform transition-transform md:relative md:translate-x-0 ${
            isPaletteOpen ? 'translate-x-0' : 'translate-x-full md:translate-x-0'
          }`}
        >
          <div className="space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200">
              <h3 className="font-extrabold text-sm text-slate-900 flex items-center gap-2">
                <Grid className="w-4 h-4 text-blue-600" />
                <span>Question Palette</span>
              </h3>
              <button
                onClick={() => setIsPaletteOpen(false)}
                className="md:hidden p-1 rounded-lg text-slate-400 hover:text-slate-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Quick Metrics Bar */}
            <div className="grid grid-cols-2 gap-2 text-xs">
              <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-2.5">
                <span className="text-emerald-700 font-bold block">{answeredCount}</span>
                <span className="text-[10px] text-emerald-800">Answered</span>
              </div>
              <div className="bg-purple-50 border border-purple-200 rounded-xl p-2.5">
                <span className="text-purple-700 font-bold block">{markedCount}</span>
                <span className="text-[10px] text-purple-800">Marked Review</span>
              </div>
            </div>

            {/* Palette Grid Buttons */}
            <div className="max-h-[380px] overflow-y-auto pr-1">
              <div className="grid grid-cols-5 gap-2">
                {questions.map((q, idx) => {
                  const status = getQuestionStatus(q.id);
                  const isCurrent = idx === currentIndex;

                  return (
                    <button
                      key={q.id}
                      onClick={() => goToQuestion(idx)}
                      className={`h-10 rounded-xl font-mono text-xs font-bold border transition-all flex items-center justify-center ${getStatusColorClass(
                        status
                      )} ${isCurrent ? 'ring-2 ring-blue-600 ring-offset-2' : ''}`}
                    >
                      {idx + 1}
                    </button>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Palette Legend */}
          <div className="pt-4 border-t border-slate-200 space-y-2 text-[11px] text-slate-600">
            <div className="grid grid-cols-2 gap-2">
              <div className="flex items-center gap-2">
                <span className="w-3 h-3 rounded-full bg-emerald-600" />
                <span>Answered</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="w-3 h-3 rounded-full bg-amber-200" />
                <span>Not Answered</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="w-3 h-3 rounded-full bg-purple-600" />
                <span>Marked Review</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="w-3 h-3 rounded-full bg-slate-200" />
                <span>Not Visited</span>
              </div>
            </div>
          </div>
        </aside>
      </div>

      {/* Confirmation Modal Before Submission */}
      {showSubmitModal && (
        <ConfirmationModal
          isOpen={showSubmitModal}
          onCancel={() => setShowSubmitModal(false)}
          onConfirm={() => {
            setShowSubmitModal(false);
            executeSubmission(false);
          }}
          title="Submit Examination"
          message={`Are you sure you want to finalize and submit your test? You have answered ${answeredCount} of ${questions.length} questions.`}
          confirmLabel={isSubmitting ? 'Submitting...' : 'Yes, Final Submit'}
          cancelLabel="Return to Questions"
        />
      )}
    </div>
  );
}

export default TestPlayerPage;
