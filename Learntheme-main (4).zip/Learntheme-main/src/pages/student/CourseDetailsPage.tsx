/**
 * Axon Nursing Academy - Course Details & Purchased Course Experience (Phase 6.1)
 * Authoritative course overview, access gatekeeper, subjects hierarchy,
 * course-level Weekly Warrior tests, and zero-trust coupon checkout.
 */
import React, { useEffect, useState, useCallback } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import {
  BookOpen,
  Clock,
  Video,
  FileText,
  ShieldCheck,
  Sparkles,
  ArrowLeft,
  ChevronRight,
  Lock,
  Unlock,
  PlayCircle,
  AlertCircle,
  RefreshCw,
  Award,
  CheckCircle2,
  Tag,
  ArrowRight,
  AlertTriangle,
  HelpCircle,
  Calendar,
  Copy,
  ShieldAlert,
  ChevronDown,
  ChevronUp,
  Zap,
  Check,
  Smartphone,
  Users,
} from 'lucide-react';
import { useAuth } from '@/src/contexts/AuthContext';
import { getBatchById } from '@/src/services/firebase/batchService';
import { getPublishedSubjects } from '@/src/services/firebase/subjectService';
import { getPublishedClassCountForBatch } from '@/src/services/firebase/classService';
import { getPublishedWeeklyWarriorTests } from '@/src/services/firebase/weeklyWarriorTestService';
import {
  checkStudentCourseAccess,
  enrollInFreeBatch,
  purchaseBatchWithCoupon,
} from '@/src/services/firebase/enrollmentService';
import { validateCouponForCourse } from '@/src/services/firebase/couponService';
import { fallbackStore } from '@/src/services/fallback/fallbackStore';
import { Batch, Subject } from '@/src/types/lms.types';
import { WeeklyWarriorTest } from '@/src/types/assessment.types';
import { CourseAccessCheck } from '@/src/types/enrollment.types';
import { CouponValidationResult } from '@/src/types/coupon.types';
import {
  checkPaymentConfig,
  createRazorpayOrder,
  launchRazorpayCheckout,
  verifyRazorpayPayment,
  PaymentCancelledError,
  RazorpayDomainBlockedError,
} from '@/src/services/payment/razorpayService';
import { PaymentConfigStatus } from '@/src/types/payment.types';
import { formatCurrency } from '@/src/lib/utils/formatters';
import { Badge } from '@/src/components/ui/Badge';
import { Button } from '@/src/components/ui/Button';
import { useToast } from '@/src/hooks/useToast';
import { SEO } from '@/src/components/common/SEO';

export function CourseDetailsPage() {
  const { batchId } = useParams<{ batchId: string }>();
  const { currentUser, isAdmin } = useAuth();
  const { toast } = useToast();
  const navigate = useNavigate();

  const cachedBatch = batchId ? fallbackStore.getBatchById(batchId) : null;
  const cachedSubjects = batchId
    ? fallbackStore.getSubjects(batchId).filter((s) => s.isPublished)
    : [];
  const cachedWW = batchId
    ? fallbackStore.getWeeklyWarriorTests(batchId).filter((t) => t.isPublished)
    : [];
  const cachedCount = batchId
    ? fallbackStore.getClasses().filter((c) => c.batchId === batchId && c.isPublished).length
    : 0;

  const [batch, setBatch] = useState<Batch | null>(() => cachedBatch);
  const [subjects, setSubjects] = useState<Subject[]>(() => cachedSubjects);
  const [weeklyWarriorTests, setWeeklyWarriorTests] = useState<WeeklyWarriorTest[]>(() => cachedWW);
  const [totalClassesCount, setTotalClassesCount] = useState<number>(() => cachedCount);
  const [isLoading, setIsLoading] = useState<boolean>(() => !cachedBatch);
  const [error, setError] = useState<string | null>(null);

  // Access & Enrollment State (Phase 6.1) — synchronously seeded with isAdmin to prevent mid-scroll layout shifts
  const [accessCheck, setAccessCheck] = useState<CourseAccessCheck | null>(() =>
    isAdmin
      ? {
          hasAccess: true,
          isAdmin: true,
          status: 'admin_bypass',
        }
      : null
  );
  const [isCheckingAccess, setIsCheckingAccess] = useState<boolean>(() => !isAdmin);
  const [enrolling, setEnrolling] = useState<boolean>(false);
  const [enrollmentError, setEnrollmentError] = useState<string | null>(null);
  const [enrollmentNotice, setEnrollmentNotice] = useState<string | null>(null);

  // Razorpay Domain Whitelist / Preview Sandbox Resolution
  const [domainBlockedInfo, setDomainBlockedInfo] = useState<{ domain: string; keyId?: string } | null>(null);
  const [copiedDomain, setCopiedDomain] = useState<boolean>(false);

  // Real Razorpay Payment State (Phase 7)
  const [paymentConfig, setPaymentConfig] = useState<PaymentConfigStatus>({
    configured: false,
    keyId: null,
  });
  const [checkoutStep, setCheckoutStep] = useState<
    'idle' | 'creating_order' | 'checkout_open' | 'verifying' | 'success'
  >('idle');
  const [verifiedPayment, setVerifiedPayment] = useState<{
    paymentId: string;
    orderId: string;
  } | null>(null);

  // Real Coupon System (Phase 6.1)
  const [couponCodeInput, setCouponCodeInput] = useState<string>('');
  const [couponLoading, setCouponLoading] = useState<boolean>(false);
  const [appliedCoupon, setAppliedCoupon] = useState<CouponValidationResult | null>(null);
  const [couponError, setCouponError] = useState<string | null>(null);

  // FAQ Accordion State
  const [openFaqIndex, setOpenFaqIndex] = useState<number | null>(null);

  // Check Razorpay Payment Service Status on Mount
  useEffect(() => {
    let isMounted = true;
    checkPaymentConfig().then((cfg) => {
      if (isMounted) {
        setPaymentConfig(cfg);
      }
    });
    return () => {
      isMounted = false;
    };
  }, []);

  // 1. Fetch Course Data & Authoritative Enrollment Access Together (prevents mid-scroll layout shifts)
  const loadCourseData = useCallback(async () => {
    if (!batchId) {
      setError('Invalid course batch identifier.');
      setIsLoading(false);
      return;
    }

    if (!cachedBatch) {
      setIsLoading(true);
    }
    setError(null);

    try {
      // Fetch batch and access check in parallel so layout renders once at final height
      const [batchData, check] = await Promise.all([
        getBatchById(batchId),
        checkStudentCourseAccess(
          currentUser?.uid,
          batchId,
          cachedBatch?.isFree,
          currentUser?.email
        ).catch(() => ({
          hasAccess: Boolean(isAdmin),
          isAdmin: Boolean(isAdmin),
          status: (isAdmin ? 'admin_bypass' : 'not_enrolled') as CourseAccessCheck['status'],
        })),
      ]);

      if (!batchData) {
        setBatch(null);
        setError('This course batch was not found or is currently not published.');
        setIsLoading(false);
        return;
      }

      // Fetch published subjects, class count, and Weekly Warrior tests in parallel
      const [subjectsData, classCount, testsData] = await Promise.all([
        getPublishedSubjects(batchId),
        getPublishedClassCountForBatch(batchId),
        getPublishedWeeklyWarriorTests(batchId),
      ]);

      setBatch(batchData);
      setAccessCheck(check);
      setIsCheckingAccess(false);
      setSubjects(subjectsData);
      setTotalClassesCount(classCount);
      setWeeklyWarriorTests(testsData);
    } catch (err: any) {
      console.error('[CourseDetailsPage] Failed to load course:', err);
      setError(err.message || 'Unable to load course details. Please try again.');
    } finally {
      setIsLoading(false);
      setIsCheckingAccess(false);
    }
  }, [batchId, cachedBatch, currentUser?.uid, currentUser?.email, isAdmin]);

  useEffect(() => {
    loadCourseData();
  }, [loadCourseData]);

  // Handle Coupon Apply
  const handleApplyCoupon = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!batch) return;
    const trimmed = couponCodeInput.trim().toUpperCase();
    if (!trimmed) {
      setCouponError('Please enter a coupon code.');
      return;
    }

    setCouponLoading(true);
    setCouponError(null);

    try {
      const result = await validateCouponForCourse(trimmed, batch.id, batch.price);
      if (result.isValid) {
        setAppliedCoupon(result);
        setCouponError(null);
        toast.success(
          `Coupon "${result.coupon?.code}" applied! You saved ${formatCurrency(result.discountAmount)}.`,
          { title: 'Coupon Applied' }
        );
      } else {
        setAppliedCoupon(null);
        const errMsg = result.error || 'Invalid or expired coupon code.';
        setCouponError(errMsg);
        toast.error(errMsg, { title: 'Invalid Coupon' });
      }
    } catch (err: any) {
      const errMsg = err?.message || 'Error checking coupon code.';
      setCouponError(errMsg);
      setAppliedCoupon(null);
      toast.error(errMsg);
    } finally {
      setCouponLoading(false);
    }
  };

  // Remove Applied Coupon
  const handleRemoveCoupon = () => {
    setAppliedCoupon(null);
    setCouponCodeInput('');
    setCouponError(null);
    toast.info('Coupon code removed.');
  };

  // Handle Free or Paid Enrollment via Razorpay (Phase 7)
  const handleEnrollment = async () => {
    if (!batch) return;
    if (!currentUser) {
      toast.info('Please sign in or create an account to enroll in this course.', {
        title: 'Sign In Required',
      });
      navigate(`/login?redirect=/course/${batch.id}`);
      return;
    }

    setEnrolling(true);
    setEnrollmentError(null);
    setEnrollmentNotice(null);

    try {
      if (batch.isFree) {
        const enrollment = await enrollInFreeBatch(currentUser.uid, batch);
        setAccessCheck({
          hasAccess: true,
          isAdmin: false,
          status: 'active',
          enrollment,
          expiresAt: enrollment.expiresAt || undefined,
        });
        toast.success(`You are now enrolled in "${batch.title}". Enjoy free learning!`, {
          title: 'Enrollment Confirmed',
        });
        return;
      }

      // Paid Course Flow
      // Case A: 100% discount coupon applied (final payable price is 0)
      if (currentPayablePrice === 0) {
        const result = await purchaseBatchWithCoupon(
          currentUser.uid,
          batch,
          appliedCoupon?.coupon?.code
        );
        setAccessCheck({
          hasAccess: true,
          isAdmin: false,
          status: 'active',
          enrollment: result.enrollment,
          expiresAt: result.enrollment.expiresAt || undefined,
        });
        toast.success(`Course access activated with coupon "${appliedCoupon?.coupon?.code}"!`, {
          title: 'Enrollment Confirmed',
        });
        return;
      }

      // Case B: Real Paid Razorpay Flow
      if (!paymentConfig.configured) {
        setEnrollmentError(
          'Payment service is not configured. Live transactions are currently unavailable.'
        );
        return;
      }

      setCheckoutStep('creating_order');

      let idToken: string | null = null;
      try {
        if (currentUser && typeof (currentUser as any).getIdToken === 'function') {
          idToken = await (currentUser as any).getIdToken();
        }
      } catch (tokErr) {
        console.warn('[CourseDetailsPage] Failed to obtain Firebase ID token:', tokErr);
      }

      // Step 1: Create Order on Authoritative Backend
      const orderResp = await createRazorpayOrder(
        batch.id,
        appliedCoupon?.coupon?.code,
        idToken,
        {
          name: currentUser.displayName || currentUser.email || 'Student',
          email: currentUser.email || '',
        }
      );

      setCheckoutStep('checkout_open');

      // Step 2: Open Razorpay Web Checkout Modal
      const checkoutResult = await launchRazorpayCheckout({
        orderResponse: orderResp,
        studentName: currentUser.displayName || currentUser.email || 'Student',
        studentEmail: currentUser.email || '',
      });

      // Step 3: Backend Cryptographic Signature Verification
      setCheckoutStep('verifying');
      const verificationResult = await verifyRazorpayPayment(
        {
          razorpay_order_id: checkoutResult.razorpay_order_id,
          razorpay_payment_id: checkoutResult.razorpay_payment_id,
          razorpay_signature: checkoutResult.razorpay_signature,
          courseId: batch.id,
        },
        idToken
      );

      // Step 4: Verification Success -> Unlock Course & Sync to Firestore
      setCheckoutStep('success');
      setVerifiedPayment({
        paymentId: checkoutResult.razorpay_payment_id,
        orderId: checkoutResult.razorpay_order_id,
      });

      setAccessCheck({
        hasAccess: true,
        isAdmin: false,
        status: 'active',
        enrollment: verificationResult.enrollment,
        expiresAt: verificationResult.enrollment.expiresAt || undefined,
      });

      toast.success('Payment verified! Your course is now unlocked.', {
        title: 'Payment Successful',
      });
    } catch (err: any) {
      const isCancelled =
        err instanceof PaymentCancelledError ||
        Boolean(err?.isCancelled) ||
        err?.name === 'PaymentCancelledError' ||
        (typeof err?.message === 'string' &&
          (err.message.includes('Payment was cancelled') ||
            err.message.toLowerCase().includes('payment was cancelled')));

      const isDomainBlocked =
        err instanceof RazorpayDomainBlockedError ||
        Boolean(err?.isDomainBlocked) ||
        err?.name === 'RazorpayDomainBlockedError' ||
        (typeof err?.message === 'string' &&
          (err.message.toLowerCase().includes('website does not match registered website') ||
            err.message.toLowerCase().includes('payment blocked as website')));

      setCheckoutStep('idle');
      if (isCancelled) {
        // User closed or dismissed the payment window - this is standard interaction, not an error
        console.info('[CourseDetailsPage] Payment checkout was cancelled by student.');
        setEnrollmentNotice('Payment checkout was cancelled. You can complete your enrollment at any time.');
        setEnrollmentError(null);
        toast.info('Payment checkout was cancelled. You can complete enrollment at any time.');
      } else if (isDomainBlocked) {
        const currentOrigin = typeof window !== 'undefined' ? window.location.origin : '';
        setDomainBlockedInfo({
          domain: err?.domain || currentOrigin,
          keyId: err?.keyId || paymentConfig.keyId || '',
        });
        setEnrollmentError(
          'Payment blocked by Razorpay: This web domain is not registered in your Razorpay Dashboard.'
        );
        setEnrollmentNotice(null);
      } else {
        console.error('[CourseDetailsPage] Enrollment/Payment error:', err);
        setEnrollmentError(err?.message || 'Payment or enrollment was not completed. Course remains locked.');
        setEnrollmentNotice(null);
      }
    } finally {
      setEnrolling(false);
    }
  };

  const handleCopyDomain = () => {
    const domainToCopy =
      domainBlockedInfo?.domain || (typeof window !== 'undefined' ? window.location.origin : '');
    if (navigator?.clipboard?.writeText) {
      navigator.clipboard.writeText(domainToCopy);
      setCopiedDomain(true);
      setTimeout(() => setCopiedDomain(false), 2200);
    }
  };

  // Loading skeleton
  if (isLoading) {
    return (
      <div id="course-details-loading" className="max-w-5xl mx-auto space-y-6 animate-pulse p-4">
        <div className="h-6 w-32 bg-slate-200 rounded-lg" />
        <div className="h-64 bg-slate-200 rounded-3xl" />
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="h-40 bg-slate-200 rounded-2xl md:col-span-2" />
          <div className="h-40 bg-slate-200 rounded-2xl" />
        </div>
        <div className="h-8 w-48 bg-slate-200 rounded-lg mt-6" />
        <div className="space-y-3">
          <div className="h-20 bg-slate-200 rounded-2xl" />
          <div className="h-20 bg-slate-200 rounded-2xl" />
          <div className="h-20 bg-slate-200 rounded-2xl" />
        </div>
      </div>
    );
  }

  // Error or Not Found State
  if (error || !batch) {
    return (
      <div id="course-details-error" className="max-w-md mx-auto py-16 px-4 text-center">
        <div className="w-16 h-16 rounded-2xl bg-rose-50 text-rose-600 flex items-center justify-center mx-auto mb-4 border border-rose-100">
          <AlertCircle className="w-8 h-8" />
        </div>
        <h2 className="text-lg font-bold text-slate-900">Batch Not Found</h2>
        <p className="text-xs text-slate-500 mt-2 leading-relaxed">
          {error || 'This batch is currently unavailable or may have been unlisted.'}
        </p>
        <div className="mt-6 flex justify-center gap-3">
          <Button
            id="browse-all-courses-btn"
            variant="primary"
            size="sm"
            onClick={() => navigate('/student/all-courses')}
            leftIcon={<ArrowLeft className="w-3.5 h-3.5" />}
          >
            Browse All Courses
          </Button>
        </div>
      </div>
    );
  }

  // Calculate pricing & discounts
  const hasOriginalDiscount = batch.originalPrice > batch.price && batch.originalPrice > 0;
  const originalDiscountPercentage = hasOriginalDiscount
    ? Math.round(((batch.originalPrice - batch.price) / batch.originalPrice) * 100)
    : 0;

  const currentPayablePrice = appliedCoupon
    ? (appliedCoupon.finalPrice ?? batch.price)
    : batch.price;

  // Strict enrollment check: A user is only enrolled if they have an active verified enrollment record
  const isEnrolled = Boolean(accessCheck?.enrollment && accessCheck.enrollment.status === 'active');
  const isAdminPreview = Boolean((isAdmin || accessCheck?.isAdmin) && !isEnrolled);
  const canAccessCurriculum = Boolean(isEnrolled || isAdminPreview || isAdmin || batch.isFree);
  const durationLabel = batch.duration || `${batch.durationDays || 180} Days`;

  return (
    <div id="course-details-page" className="max-w-5xl mx-auto space-y-6 pb-24 sm:pb-12 bg-slate-50">
      {/* Breadcrumb Header */}
      <div className="flex items-center gap-2 text-xs font-medium text-slate-500">
        <Link to="/student" className="hover:text-blue-600 transition-colors">
          Home
        </Link>
        <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
        <Link to="/student/all-courses" className="hover:text-blue-600 transition-colors">
          All Batches
        </Link>
        <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
        <span className="text-slate-900 font-bold truncate max-w-xs">{batch.title}</span>
      </div>

      {/* Celebration & Immediate Access Banner */}
      {(checkoutStep === 'success' || verifiedPayment) && (
        <div
          id="payment-success-celebration-banner"
          className="p-4 bg-gradient-to-r from-emerald-600 to-teal-700 text-white rounded-3xl shadow-sm flex flex-col sm:flex-row items-center justify-between gap-4 animate-in fade-in slide-in-from-top-3 duration-200"
        >
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-white/20 flex items-center justify-center shrink-0">
              <CheckCircle2 className="w-6 h-6 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-extrabold text-sm sm:text-base">Payment Verified • Course Unlocked!</h3>
                <Badge variant="emerald" size="sm" className="bg-emerald-800 text-emerald-100 border-none">
                  Instant Access
                </Badge>
              </div>
              <p className="text-xs text-emerald-100 mt-0.5 leading-relaxed">
                Transaction recorded in Firebase Firestore &amp; CMS. You now have complete access to all subjects, video classes, PDF notes &amp; tests.
              </p>
            </div>
          </div>
          {subjects.length > 0 && (
            <Link
              to={`/course/${batch.id}/subject/${subjects[0].id}`}
              className="px-4 py-2.5 bg-white text-emerald-900 hover:bg-emerald-50 rounded-xl font-bold text-xs shrink-0 transition-colors shadow-xs flex items-center gap-1.5"
            >
              <PlayCircle className="w-4 h-4 text-emerald-700" />
              Start Learning Now
            </Link>
          )}
        </div>
      )}

      {/* Hero Banner Card */}
      <div className="bg-white rounded-3xl border border-slate-200/80 overflow-hidden shadow-xs">
        {/* Banner Media */}
        <div className="relative h-52 sm:h-72 w-full bg-slate-900 overflow-hidden">
          <img
            id="course-hero-image"
            src={
              batch.bannerUrl ||
              batch.thumbnailUrl ||
              'https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?w=1200&auto=format&fit=crop&q=80'
            }
            alt={batch.title}
            className="w-full h-full object-cover opacity-85"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/40 to-transparent" />

          {/* Badges in Hero */}
          <div className="absolute top-4 left-4 flex flex-wrap gap-2">
            {isEnrolled ? (
              <Badge variant="emerald" size="md">
                <CheckCircle2 className="w-3.5 h-3.5 mr-1 inline" /> ENROLLED & ACTIVE
              </Badge>
            ) : batch.isFree ? (
              <Badge variant="emerald" size="md">
                FREE ACCESS
              </Badge>
            ) : (
              <Badge variant="blue" size="md">
                PREMIUM COURSE
              </Badge>
            )}

            {batch.isFeatured && (
              <Badge variant="amber" size="md">
                <Sparkles className="w-3 h-3 mr-1 inline" /> Featured
              </Badge>
            )}

            {isAdminPreview && (
              <Badge variant="purple" size="md">
                <ShieldCheck className="w-3 h-3 mr-1 inline" /> ADMIN PREVIEW MODE
              </Badge>
            )}
          </div>

          {/* Title and duration overlay */}
          <div className="absolute bottom-4 left-4 right-4">
            <h1 id="course-title-header" className="text-lg sm:text-2xl font-extrabold text-white leading-tight">
              {batch.title}
            </h1>
            <p className="text-xs sm:text-sm text-slate-200 mt-1 line-clamp-2 max-w-3xl">
              {batch.shortDescription}
            </p>

            {/* Purchased Quick Bar */}
            {isEnrolled && (
              <div className="mt-3 flex flex-wrap items-center gap-3 text-xs text-slate-300">
                <span className="flex items-center gap-1.5 text-emerald-400 font-semibold">
                  <ShieldCheck className="w-4 h-4" /> Unrestricted Access
                </span>
                <span>•</span>
                <span className="flex items-center gap-1.5">
                  <Clock className="w-3.5 h-3.5 text-blue-400" /> Duration: {durationLabel}
                </span>
                {accessCheck?.expiresAt && (
                  <>
                    <span>•</span>
                    <span className="flex items-center gap-1.5">
                      <Calendar className="w-3.5 h-3.5 text-amber-400" /> Valid Until:{' '}
                      {new Date(accessCheck.expiresAt).toLocaleDateString()}
                    </span>
                  </>
                )}
              </div>
            )}
            {isAdminPreview && (
              <div className="mt-3 flex flex-wrap items-center gap-3 text-xs text-purple-200">
                <span className="flex items-center gap-1.5 text-purple-300 font-semibold">
                  <ShieldCheck className="w-4 h-4" /> Staff Preview Mode
                </span>
                <span>•</span>
                <span className="text-slate-300">Course checkout and payment gateway are active below for testing</span>
              </div>
            )}
          </div>
        </div>

        {/* Key Info & Stats Bar */}
        <div className="p-4 sm:p-5 grid grid-cols-2 sm:grid-cols-4 gap-3 bg-slate-50/70 border-b border-slate-100 text-center">
          <div className="bg-white p-3 rounded-2xl border border-slate-100">
            <div className="flex items-center justify-center gap-1.5 text-blue-600 mb-1">
              <BookOpen className="w-4 h-4" />
              <span className="text-base font-extrabold text-slate-900">{subjects.length}</span>
            </div>
            <p className="text-[11px] text-slate-500 font-medium">Subjects Included</p>
          </div>

          <div className="bg-white p-3 rounded-2xl border border-slate-100">
            <div className="flex items-center justify-center gap-1.5 text-emerald-600 mb-1">
              <Video className="w-4 h-4" />
              <span className="text-base font-extrabold text-slate-900">{totalClassesCount}</span>
            </div>
            <p className="text-[11px] text-slate-500 font-medium">Recorded Lessons</p>
          </div>

          <div className="bg-white p-3 rounded-2xl border border-slate-100">
            <div className="flex items-center justify-center gap-1.5 text-amber-600 mb-1">
              <Clock className="w-4 h-4" />
              <span className="text-base font-extrabold text-slate-900">{durationLabel}</span>
            </div>
            <p className="text-[11px] text-slate-500 font-medium">Course Duration</p>
          </div>

          <div className="bg-white p-3 rounded-2xl border border-slate-100">
            <div className="flex items-center justify-center gap-1.5 text-purple-600 mb-1">
              <Award className="w-4 h-4" />
              <span className="text-base font-extrabold text-slate-900">
                {weeklyWarriorTests.length}
              </span>
            </div>
            <p className="text-[11px] text-slate-500 font-medium">Weekly Warrior Tests</p>
          </div>
        </div>

        {/* About this Course & Enrollment Action */}
        <div className="p-4 sm:p-6 grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="md:col-span-2 space-y-4">
            <div>
              <h2 className="text-base font-bold text-slate-900">About this Course</h2>
              <p className="mt-2 text-xs sm:text-sm text-slate-600 leading-relaxed whitespace-pre-line">
                {batch.description ||
                  batch.shortDescription ||
                  'Comprehensive curriculum prepared by Axon Nursing Academy faculty with clinical case studies, previous year exam patterns, and concept tests.'}
              </p>
            </div>

            {/* Validity & Access period breakdown */}
            <div className="pt-3 border-t border-slate-100 grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div className="flex items-start gap-2 text-slate-600">
                <Clock className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
                <div>
                  <p className="font-semibold text-slate-800">Course Duration</p>
                  <p className="text-slate-500">{durationLabel}</p>
                </div>
              </div>

              <div className="flex items-start gap-2 text-slate-600">
                <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                <div>
                  <p className="font-semibold text-slate-800">Validity & Access Period</p>
                  <p className="text-slate-500">
                    {batch.durationDays > 0
                      ? `${batch.durationDays} Days continuous access from registration date`
                      : 'Lifetime access for current batch cycle'}
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Pricing Box / Enrollment Status Card */}
          <div className="bg-slate-50 p-5 rounded-2xl border border-slate-200/80 flex flex-col justify-between space-y-4">
            {isEnrolled ? (
              /* Enrolled Student Overview Card */
              <div id="enrolled-status-card" className="space-y-4">
                <div className="p-3 bg-emerald-50 rounded-xl border border-emerald-200/80">
                  <div className="flex items-center gap-2 text-emerald-700 font-bold text-xs">
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Enrolled Course</span>
                  </div>
                  <p className="text-[11px] text-emerald-600 mt-1">
                    You have complete access to all subjects, recorded classes, notes, and Weekly
                    Warrior tests.
                  </p>
                </div>

                {/* Verified Payment Transaction Badge */}
                {(verifiedPayment || accessCheck?.enrollment?.paymentId) && (
                  <div className="p-2.5 rounded-xl bg-blue-50/70 border border-blue-200/80 text-[11px] text-blue-900 space-y-1">
                    <div className="flex items-center justify-between font-bold">
                      <span className="flex items-center gap-1 text-blue-700">
                        <ShieldCheck className="w-3.5 h-3.5 text-blue-600" />
                        Verified Payment
                      </span>
                      <span className="text-[10px] text-slate-500 font-mono">
                        Secured by Razorpay
                      </span>
                    </div>
                    <p className="text-slate-600 font-mono text-[10px] truncate">
                      ID: {verifiedPayment?.paymentId || accessCheck?.enrollment?.paymentId}
                    </p>
                  </div>
                )}

                {accessCheck?.enrollment?.enrolledAt && (
                  <div className="text-xs text-slate-600 space-y-1">
                    <p className="flex justify-between">
                      <span className="text-slate-400">Enrolled On:</span>
                      <span className="font-medium text-slate-800">
                        {new Date(accessCheck.enrollment.enrolledAt).toLocaleDateString()}
                      </span>
                    </p>
                    {accessCheck.expiresAt && (
                      <p className="flex justify-between">
                        <span className="text-slate-400">Valid Until:</span>
                        <span className="font-medium text-slate-800">
                          {new Date(accessCheck.expiresAt).toLocaleDateString()}
                        </span>
                      </p>
                    )}
                  </div>
                )}

                {subjects.length > 0 && (
                  <Link
                    to={`/course/${batch.id}/subject/${subjects[0].id}`}
                    className="w-full flex items-center justify-center gap-2 py-2.5 px-4 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-semibold shadow-xs transition-colors"
                  >
                    <PlayCircle className="w-4 h-4" />
                    Continue Learning
                  </Link>
                )}
              </div>
            ) : (
              /* Non-Enrolled Student Checkout & Coupon Box */
              <div id="enrollment-checkout-card" className="space-y-4">
                {isAdminPreview && (
                  <div className="p-3 bg-purple-50 rounded-xl border border-purple-200/80 text-xs text-purple-900 space-y-1">
                    <div className="flex items-center gap-1.5 font-bold text-purple-800">
                      <ShieldCheck className="w-4 h-4 text-purple-600" />
                      <span>Admin Mode: Student Checkout Preview</span>
                    </div>
                    <p className="text-[11px] text-purple-700 leading-relaxed">
                      You have administrator access to review curriculum content. The live student enrollment, coupon, and payment flow is active below for testing.
                    </p>
                  </div>
                )}
                <div>
                  <span className="text-xs font-semibold text-slate-500">Course Investment</span>
                  <div className="mt-1 flex items-baseline gap-2">
                    {batch.isFree ? (
                      <span className="text-2xl font-extrabold text-emerald-600">FREE</span>
                    ) : (
                      <>
                        <span className="text-2xl font-extrabold text-slate-900">
                          {formatCurrency(currentPayablePrice)}
                        </span>
                        {(hasOriginalDiscount || appliedCoupon) && (
                          <span className="text-sm text-slate-400 line-through">
                            {formatCurrency(batch.originalPrice || batch.price)}
                          </span>
                        )}
                      </>
                    )}
                  </div>

                  {/* Discount Badges */}
                  {appliedCoupon ? (
                    <div className="mt-1.5 flex items-center gap-1.5">
                      <Badge variant="emerald" size="sm">
                        <Tag className="w-3 h-3 mr-1 inline" />
                        Code {appliedCoupon.coupon?.code} Applied (Save {formatCurrency(appliedCoupon.discountAmount)})
                      </Badge>
                    </div>
                  ) : hasOriginalDiscount ? (
                    <div className="mt-1.5">
                      <Badge variant="emerald" size="sm">
                        {originalDiscountPercentage}% Early Bird Discount
                      </Badge>
                    </div>
                  ) : null}
                </div>

                {/* Coupon Code Input for Paid Courses */}
                {!batch.isFree && (
                  <div className="space-y-2 pt-3 border-t border-slate-200">
                    <label className="text-[11px] font-bold text-slate-700 flex items-center gap-1">
                      <Tag className="w-3 h-3 text-blue-600" />
                      Have a coupon code?
                    </label>

                    {appliedCoupon ? (
                      <div className="flex items-center justify-between p-2 rounded-xl bg-emerald-50 border border-emerald-200 text-xs">
                        <span className="font-mono font-bold text-emerald-700">
                          {appliedCoupon.coupon?.code}
                        </span>
                        <button
                          type="button"
                          onClick={handleRemoveCoupon}
                          className="text-emerald-700 hover:text-emerald-900 font-semibold text-[11px]"
                        >
                          Remove
                        </button>
                      </div>
                    ) : (
                      <form onSubmit={handleApplyCoupon} className="flex gap-1.5">
                        <input
                          id="coupon-input-field"
                          type="text"
                          value={couponCodeInput}
                          onChange={(e) => setCouponCodeInput(e.target.value.toUpperCase())}
                          placeholder="e.g. AXON50"
                          className="flex-1 px-3 py-1.5 text-xs uppercase font-mono font-bold tracking-wider rounded-xl border border-slate-200 focus:outline-hidden focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
                        />
                        <button
                          type="submit"
                          disabled={couponLoading || !couponCodeInput.trim()}
                          className="px-3 py-1.5 bg-slate-900 text-white rounded-xl text-xs font-semibold hover:bg-slate-800 disabled:opacity-50 transition-colors"
                        >
                          {couponLoading ? '...' : 'Apply'}
                        </button>
                      </form>
                    )}

                    {couponError && (
                      <p className="text-[11px] text-rose-600 flex items-center gap-1">
                        <AlertTriangle className="w-3 h-3 shrink-0" />
                        {couponError}
                      </p>
                    )}
                  </div>
                )}

                {/* Payment Configuration Notice for Paid Batches */}
                {!batch.isFree && currentPayablePrice > 0 && !paymentConfig.configured && (
                  <div className="p-3 bg-amber-50 rounded-xl border border-amber-200/80 text-xs text-amber-800 flex items-start gap-2">
                    <AlertCircle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                    <div>
                      <p className="font-bold text-amber-900">Payment service is not configured</p>
                      <p className="text-[11px] text-amber-700 mt-0.5">
                        Razorpay live gateway keys are not provided. Paid course checkout is temporarily unavailable.
                      </p>
                    </div>
                  </div>
                )}

                {enrollmentNotice && (
                  <div
                    id="enrollment-notice-banner"
                    className="text-[11px] text-slate-700 bg-slate-100 p-2.5 rounded-xl border border-slate-200 flex items-start justify-between gap-2 animate-in fade-in duration-150"
                  >
                    <div className="flex items-start gap-1.5">
                      <AlertCircle className="w-3.5 h-3.5 text-slate-500 shrink-0 mt-0.5" />
                      <span>{enrollmentNotice}</span>
                    </div>
                    <button
                      type="button"
                      onClick={() => setEnrollmentNotice(null)}
                      className="text-slate-400 hover:text-slate-700 font-bold text-sm leading-none px-1"
                      aria-label="Dismiss notice"
                    >
                      ×
                    </button>
                  </div>
                )}

                {enrollmentError && (
                  <div
                    id="enrollment-error-banner"
                    className="text-[11px] text-rose-600 bg-rose-50 p-2.5 rounded-xl border border-rose-200 flex items-start justify-between gap-2 animate-in fade-in duration-150"
                  >
                    <div className="flex items-start gap-1.5">
                      <AlertTriangle className="w-3.5 h-3.5 text-rose-600 shrink-0 mt-0.5" />
                      <span>{enrollmentError}</span>
                    </div>
                    <button
                      type="button"
                      onClick={() => setEnrollmentError(null)}
                      className="text-rose-400 hover:text-rose-700 font-bold text-sm leading-none px-1"
                      aria-label="Dismiss error"
                    >
                      ×
                    </button>
                  </div>
                )}

                {/* Razorpay Live Domain Whitelist Resolution Card */}
                {domainBlockedInfo && (
                  <div
                    id="razorpay-domain-blocked-card"
                    className="p-3.5 bg-amber-50/90 rounded-2xl border border-amber-300 text-xs space-y-3 animate-in fade-in duration-200"
                  >
                    <div className="flex items-start gap-2">
                      <ShieldAlert className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
                      <div className="space-y-1">
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <span className="font-bold text-amber-950">Domain Whitelist Required</span>
                          <span className="text-[10px] font-semibold bg-amber-200/80 text-amber-900 px-1.5 py-0.5 rounded-full">
                            Razorpay Live Mode
                          </span>
                        </div>
                        <p className="text-[11px] text-amber-800 leading-relaxed">
                          Razorpay Live security blocks transactions initiated from domains not registered in your merchant dashboard.
                        </p>
                      </div>
                    </div>

                    {/* Current Domain with Copy Button */}
                    <div className="bg-white p-2 rounded-xl border border-amber-200 flex items-center justify-between gap-2 text-[11px]">
                      <div className="min-w-0 flex-1 font-mono text-slate-700 truncate select-all">
                        {domainBlockedInfo.domain || (typeof window !== 'undefined' ? window.location.origin : '')}
                      </div>
                      <button
                        type="button"
                        onClick={handleCopyDomain}
                        className="shrink-0 flex items-center gap-1 px-2.5 py-1 bg-amber-100 hover:bg-amber-200 text-amber-900 rounded-lg text-[10px] font-semibold transition-colors"
                      >
                        {copiedDomain ? (
                          <>
                            <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                            <span>Copied</span>
                          </>
                        ) : (
                          <>
                            <Copy className="w-3 h-3" />
                            <span>Copy URL</span>
                          </>
                        )}
                      </button>
                    </div>

                    <div className="text-[10px] text-amber-800 space-y-1 bg-amber-100/50 p-2 rounded-lg border border-amber-200/60">
                      <p className="font-semibold text-amber-950">To accept real student payments:</p>
                      <ol className="list-decimal list-inside space-y-0.5 pl-0.5">
                        <li>Open Razorpay Dashboard &gt; Account &amp; Settings &gt; Business website detail</li>
                        <li>Add this URL or your custom production domain</li>
                      </ol>
                    </div>
                  </div>
                )}

                {/* Enrollment CTA Button */}
                <Button
                  id="enroll-course-cta-btn"
                  variant="primary"
                  size="md"
                  onClick={handleEnrollment}
                  disabled={
                    enrolling ||
                    (!batch.isFree && currentPayablePrice > 0 && !paymentConfig.configured)
                  }
                  className="w-full justify-center"
                >
                  {checkoutStep === 'creating_order'
                    ? 'Creating Razorpay Order...'
                    : checkoutStep === 'checkout_open'
                    ? 'Checkout in Progress...'
                    : checkoutStep === 'verifying'
                    ? 'Verifying Signature...'
                    : enrolling
                    ? 'Processing...'
                    : !currentUser
                    ? 'Sign In to Enroll'
                    : batch.isFree
                    ? 'Enroll for Free'
                    : !paymentConfig.configured && currentPayablePrice > 0
                    ? 'Payment Gateway Not Configured'
                    : `Pay Now • ${formatCurrency(currentPayablePrice)}`}
                </Button>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Course Inclusions & Study Highlights */}
      <div id="course-features-section" className="bg-white rounded-3xl border border-slate-200/80 p-5 sm:p-6 shadow-xs space-y-4">
        <div>
          <h2 className="text-base font-extrabold text-slate-900 flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-blue-600" />
            <span>What You Get in This Course</span>
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Everything structured by clinical nursing specialists to prepare you for AIIMS NORCET, ESIC, CHO, and State PSC exams.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5">
          <div className="p-4 rounded-2xl bg-blue-50/50 border border-blue-100 flex items-start gap-3">
            <div className="w-9 h-9 rounded-xl bg-blue-600 text-white flex items-center justify-center shrink-0 shadow-xs">
              <Video className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-xs font-bold text-slate-900">HD Video Lectures</h3>
              <p className="text-[11px] text-slate-500 mt-0.5 leading-relaxed">
                In-depth clinical theory classes, clinical rationale &amp; previous exam question discussions.
              </p>
            </div>
          </div>

          <div className="p-4 rounded-2xl bg-emerald-50/50 border border-emerald-100 flex items-start gap-3">
            <div className="w-9 h-9 rounded-xl bg-emerald-600 text-white flex items-center justify-center shrink-0 shadow-xs">
              <FileText className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-xs font-bold text-slate-900">Clinical PDF Notes</h3>
              <p className="text-[11px] text-slate-500 mt-0.5 leading-relaxed">
                Concise high-yield revision summaries, nursing formulas &amp; quick-reference cheat sheets.
              </p>
            </div>
          </div>

          <div className="p-4 rounded-2xl bg-purple-50/50 border border-purple-100 flex items-start gap-3">
            <div className="w-9 h-9 rounded-xl bg-purple-600 text-white flex items-center justify-center shrink-0 shadow-xs">
              <Award className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-xs font-bold text-slate-900">Weekly Warrior Tests</h3>
              <p className="text-[11px] text-slate-500 mt-0.5 leading-relaxed">
                Full-length mock tests with real exam timers, negative marking &amp; domain performance ranking.
              </p>
            </div>
          </div>

          <div className="p-4 rounded-2xl bg-amber-50/50 border border-amber-100 flex items-start gap-3">
            <div className="w-9 h-9 rounded-xl bg-amber-600 text-white flex items-center justify-center shrink-0 shadow-xs">
              <Smartphone className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-xs font-bold text-slate-900">Instant Unlock Access</h3>
              <p className="text-[11px] text-slate-500 mt-0.5 leading-relaxed">
                Unlocks immediately after payment. Access seamlessly from your mobile, tablet, or PC browser.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Curriculum / Subjects Hierarchy */}
      <div id="course-curriculum-section" className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-base sm:text-lg font-extrabold text-slate-900 flex items-center gap-2">
              <span>Subjects Included ({subjects.length})</span>
              {!canAccessCurriculum && (
                <span className="text-xs font-normal text-amber-600 bg-amber-50 px-2 py-0.5 rounded-md border border-amber-200 flex items-center gap-1">
                  <Lock className="w-3 h-3" /> Enroll to Access
                </span>
              )}
              {isAdminPreview && (
                <span className="text-xs font-normal text-purple-700 bg-purple-50 px-2 py-0.5 rounded-md border border-purple-200 flex items-center gap-1">
                  <ShieldCheck className="w-3 h-3" /> Staff Preview
                </span>
              )}
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Comprehensive subject curriculum with chapter-wise video classes and PDF notes
            </p>
          </div>
        </div>

        {subjects.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {subjects.map((subject, index) => (
              <div
                key={subject.id}
                role="button"
                tabIndex={0}
                onClick={() => {
                  if (canAccessCurriculum) {
                    navigate(`/course/${batch.id}/subject/${subject.id}`);
                  } else {
                    handleEnrollment();
                  }
                }}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' || e.key === ' ') {
                    e.preventDefault();
                    if (canAccessCurriculum) {
                      navigate(`/course/${batch.id}/subject/${subject.id}`);
                    } else {
                      handleEnrollment();
                    }
                  }
                }}
                className={`group bg-white rounded-2xl border border-slate-200/80 p-4 shadow-xs cursor-pointer transition-colors flex items-start gap-3.5 ${
                  canAccessCurriculum ? 'hover:border-blue-300' : 'hover:border-amber-300'
                }`}
                title={
                  canAccessCurriculum
                    ? `Open ${subject.name}`
                    : 'Enroll in course to unlock this subject'
                }
              >
                <div className="w-12 h-12 rounded-xl bg-blue-50 text-blue-700 font-bold flex items-center justify-center shrink-0 overflow-hidden">
                  {subject.thumbnailUrl ? (
                    <img
                      src={subject.thumbnailUrl}
                      alt={subject.name}
                      className="w-12 h-12 object-cover rounded-xl"
                    />
                  ) : (
                    <span className="text-sm">{(index + 1).toString().padStart(2, '0')}</span>
                  )}
                </div>

                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between">
                    <h3 className="text-sm font-bold text-slate-900 group-hover:text-blue-600 transition-colors truncate">
                      {subject.name}
                    </h3>
                    {canAccessCurriculum ? (
                      <ChevronRight className="w-4 h-4 text-slate-400 group-hover:text-blue-600 transition-colors shrink-0 ml-1" />
                    ) : (
                      <Lock className="w-4 h-4 text-slate-300 shrink-0 ml-1" />
                    )}
                  </div>
                  <p className="text-xs text-slate-500 line-clamp-2 mt-1">
                    {subject.description || 'Core subject curriculum and clinical modules.'}
                  </p>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="bg-white rounded-2xl border border-slate-200 p-8 text-center">
            <BookOpen className="w-8 h-8 text-slate-300 mx-auto mb-2" />
            <h4 className="text-sm font-bold text-slate-800">Curriculum in Preparation</h4>
            <p className="text-xs text-slate-500 mt-1">
              Nursing syllabus and subject modules are actively being structured.
            </p>
          </div>
        )}
      </div>

      {/* Weekly Warrior Tests Section (Course-Level Assessments) */}
      <div id="course-weekly-warrior-section" className="space-y-4 pt-4 border-t border-slate-200">
        <div className="flex items-center justify-between">
          <div>
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center">
                <Award className="w-4 h-4" />
              </div>
              <h2 className="text-base sm:text-lg font-extrabold text-slate-900">
                Weekly Warrior Competitive Tests ({weeklyWarriorTests.length})
              </h2>
            </div>
            <p className="text-xs text-slate-500 mt-0.5">
              Course-level mock examinations with real exam timer, negative marking, and domain ranking.
            </p>
          </div>
        </div>

        {weeklyWarriorTests.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {weeklyWarriorTests.map((t) => (
              <div
                key={t.id}
                className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs hover:shadow-md hover:border-blue-200 transition-all flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-start justify-between gap-2 mb-2">
                    <h3 className="font-bold text-slate-900 text-sm">{t.title}</h3>
                    <Badge variant="blue" size="sm">
                      {t.durationMinutes} Mins
                    </Badge>
                  </div>
                  <p className="text-xs text-slate-500 line-clamp-2 mb-4">
                    {Array.isArray(t.instructions)
                      ? t.instructions[0] || 'Comprehensive weekly test designed to test clinical readiness.'
                      : t.instructions || 'Comprehensive weekly test designed to test clinical readiness.'}
                  </p>
                  <div className="flex flex-wrap items-center gap-3 text-xs text-slate-600 mb-4">
                    <span className="flex items-center gap-1 font-semibold text-slate-700">
                      Total: {t.totalMarks} Marks
                    </span>
                    <span className="text-slate-300">•</span>
                    <span>+{t.marksPerQuestion} Correct</span>
                    <span className="text-slate-300">•</span>
                    <span className="text-rose-600 font-medium">-{t.negativeMarksPerQuestion} Wrong</span>
                  </div>
                </div>

                <div className="pt-3 border-t border-slate-100 flex items-center justify-between">
                  <span className="text-[11px] text-slate-400">Course Assessment</span>
                  {canAccessCurriculum ? (
                    <Button
                      size="sm"
                      variant="primary"
                      onClick={() => navigate(`/test/weekly-warrior/${t.id}`)}
                    >
                      Start Test
                    </Button>
                  ) : (
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={handleEnrollment}
                      leftIcon={<Lock className="w-3 h-3" />}
                    >
                      Unlock Test
                    </Button>
                  )}
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="bg-white rounded-2xl border border-slate-200 p-8 text-center">
            <Award className="w-8 h-8 text-slate-300 mx-auto mb-2" />
            <h4 className="text-sm font-bold text-slate-800">No Weekly Warrior Tests Scheduled</h4>
            <p className="text-xs text-slate-500 mt-1">
              Weekly mock tests for this course will appear here when scheduled by the faculty.
            </p>
          </div>
        )}
      </div>

      {/* Trust & Guarantee Banner */}
      <div id="course-guarantee-strip" className="p-4 sm:p-5 bg-gradient-to-r from-blue-900 to-indigo-950 text-white rounded-3xl shadow-xs">
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-white/10 flex items-center justify-center shrink-0">
              <ShieldCheck className="w-5 h-5 text-emerald-400" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white">Axon Academic Excellence Guarantee</h3>
              <p className="text-xs text-blue-200 mt-0.5">
                Curriculum curated strictly according to recent INC syllabus, NORCET 7.0 &amp; state nursing exam trends.
              </p>
            </div>
          </div>
          <div className="flex items-center gap-4 text-xs text-blue-200 shrink-0">
            <span className="flex items-center gap-1.5">
              <Check className="w-4 h-4 text-emerald-400" /> 100% Verified Content
            </span>
            <span className="flex items-center gap-1.5">
              <Zap className="w-4 h-4 text-amber-400" /> Instant Razorpay Unlock
            </span>
          </div>
        </div>
      </div>

      {/* Frequently Asked Questions (FAQs) Accordion */}
      <div id="course-faq-section" className="bg-white rounded-3xl border border-slate-200/80 p-5 sm:p-6 shadow-xs space-y-4">
        <div>
          <div className="flex items-center gap-2 text-blue-600 font-bold text-xs">
            <HelpCircle className="w-4 h-4" />
            <span>Got Questions?</span>
          </div>
          <h2 className="text-base sm:text-lg font-extrabold text-slate-900 mt-1">
            Frequently Asked Questions
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Everything you need to know about payment, instant course unlock, and studying with Axon Nursing Academy.
          </p>
        </div>

        <div className="divide-y divide-slate-100">
          {[
            {
              q: 'Payment hone ke baad course kab aur kaise unlock hoga?',
              a: 'Payment complete hote hi course turant unlock ho jata hai! Jaise hi aap Razorpay par payment confirm karte hain, Firebase Firestore me aapka payment aur enrollment record automatically register ho jata hai, aur CMS ko notify ho jata hai. Page refresh hone par aapko sabhi subjects, recorded classes, notes aur tests unlock milte hain.',
            },
            {
              q: 'Payment ke kaun-kaun se options available hain?',
              a: 'Aap Razorpay ke through UPI (Google Pay, PhonePe, Paytm, BHIM), Credit Card, Debit Card (Visa, MasterCard, RuPay), Net Banking aur popular Wallets se 100% securely pay kar sakte hain. Bank-grade 256-bit encryption ke sath transaction fully safe rehta hai.',
            },
            {
              q: 'Kya mai mobile phone aur laptop dono par classes dekh sakta hoon?',
              a: 'Ji haan! Aap apne kisi bhi smartphone, tablet ya computer browser me apne registered email address se login karke seamlessly padhai continue kar sakte hain. Aapka study progress har device par sync rehta hai.',
            },
            {
              q: 'Kya PDF notes aur tests is course me included hain?',
              a: 'Haan! Is batch me sabhi chapter-wise clinical PDF notes, revision summaries aur Weekly Warrior competitive mock tests (with negative marking & All-India rank) fully included hain.',
            },
            {
              q: 'Agar payment ke dauran network issue ho jaye to kya karein?',
              a: 'Hamara server aur Razorpay webhooks automatic verification karte hain. Jaise hi bank se confirm hota hai, aapka course unlock ho jata hai. Kisi bhi query ke liye aap Axon Nursing Academy support ya admin se sampark kar sakte hain.',
            },
          ].map((faq, idx) => {
            const isOpen = openFaqIndex === idx;
            return (
              <div key={idx} className="py-3.5 first:pt-0 last:pb-0">
                <button
                  type="button"
                  onClick={() => setOpenFaqIndex(isOpen ? null : idx)}
                  className="w-full flex items-center justify-between gap-3 text-left group"
                >
                  <span className="text-xs sm:text-sm font-bold text-slate-800 group-hover:text-blue-600 transition-colors">
                    {faq.q}
                  </span>
                  {isOpen ? (
                    <ChevronUp className="w-4 h-4 text-blue-600 shrink-0" />
                  ) : (
                    <ChevronDown className="w-4 h-4 text-slate-400 group-hover:text-slate-600 shrink-0" />
                  )}
                </button>
                {isOpen && (
                  <p className="text-xs text-slate-600 mt-2 pl-1 leading-relaxed animate-in fade-in duration-150">
                    {faq.a}
                  </p>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Mobile Sticky Bottom Bar (Quick Pay Now) */}
      {!isEnrolled && (
        <div
          id="course-mobile-sticky-bar"
          className="fixed bottom-16 left-0 right-0 z-30 bg-white border-t border-slate-200 p-3.5 sm:hidden shadow-lg flex items-center justify-between gap-3"
        >
          <div className="min-w-0 flex-1">
            <span className="text-[10px] text-slate-400 font-semibold uppercase tracking-wider block">
              {batch.isFree ? 'Fee' : 'Total Course Investment'}
            </span>
            <div className="flex items-baseline gap-1.5">
              <span className="text-base font-extrabold text-slate-900">
                {batch.isFree ? 'FREE' : formatCurrency(currentPayablePrice)}
              </span>
              {!batch.isFree && (hasOriginalDiscount || appliedCoupon) && (
                <span className="text-xs text-slate-400 line-through">
                  {formatCurrency(batch.originalPrice || batch.price)}
                </span>
              )}
            </div>
          </div>
          <Button
            size="sm"
            variant="primary"
            onClick={handleEnrollment}
            disabled={
              enrolling ||
              (!batch.isFree && currentPayablePrice > 0 && !paymentConfig.configured)
            }
            className="px-5 py-2 text-xs font-bold shadow-xs shrink-0"
          >
            {enrolling
              ? 'Processing...'
              : !currentUser
              ? 'Sign In to Enroll'
              : batch.isFree
              ? 'Enroll for Free'
              : 'Pay Now'}
          </Button>
        </div>
      )}
    </div>
  );
}

export default CourseDetailsPage;
