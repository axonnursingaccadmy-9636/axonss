/**
 * Axon Nursing Academy - Subject Details Page (/course/:batchId/subject/:subjectId)
 * Displays Subject information and published Chapters loaded from Firestore.
 * Strictly hardened for Phase 8 Course Access & Resource Hierarchy Security.
 */
import React, { useEffect, useState, useCallback } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import {
  BookOpen,
  ChevronRight,
  ArrowLeft,
  Layers,
  Sparkles,
  AlertCircle,
  RefreshCw,
  Lock,
  ShieldAlert,
  Clock,
} from 'lucide-react';
import { getBatchById } from '@/src/services/firebase/batchService';
import { getSubjectById } from '@/src/services/firebase/subjectService';
import { getPublishedChapters } from '@/src/services/firebase/chapterService';
import { checkStudentCourseAccess } from '@/src/services/firebase/enrollmentService';
import { useAuth } from '@/src/contexts/AuthContext';
import { fallbackStore } from '@/src/services/fallback/fallbackStore';
import { Batch, Subject, Chapter } from '@/src/types/lms.types';
import { CourseAccessCheck } from '@/src/types/enrollment.types';
import { Badge } from '@/src/components/ui/Badge';
import { Button } from '@/src/components/ui/Button';

export function SubjectDetailsPage() {
  const { batchId, subjectId } = useParams<{ batchId: string; subjectId: string }>();
  const navigate = useNavigate();
  const { currentUser, isAdmin } = useAuth();

  const cachedBatch = batchId ? fallbackStore.getBatchById(batchId) : null;
  const cachedSubject = subjectId ? fallbackStore.getSubjectById(subjectId) : null;
  const cachedChapters = subjectId ? fallbackStore.getChapters(subjectId).filter((c) => c.isPublished) : [];

  const [batch, setBatch] = useState<Batch | null>(() => cachedBatch);
  const [subject, setSubject] = useState<Subject | null>(() => cachedSubject);
  const [chapters, setChapters] = useState<Chapter[]>(() => cachedChapters);
  const [isLoading, setIsLoading] = useState<boolean>(() => !(cachedBatch && cachedSubject));
  const [error, setError] = useState<string | null>(null);
  const [accessState, setAccessState] = useState<CourseAccessCheck | null>(() =>
    isAdmin ? { hasAccess: true, status: 'enrolled' } : null
  );

  const loadSubjectData = useCallback(async () => {
    if (!batchId || !subjectId) {
      setError('Invalid course or subject identifier.');
      setIsLoading(false);
      return;
    }

    if (!(cachedBatch && cachedSubject)) {
      setIsLoading(true);
    }
    setError(null);

    try {
      // 1. Fetch batch info for context
      const batchData = await getBatchById(batchId);
      if (!batchData) {
        setError('The parent course batch could not be found.');
        setIsLoading(false);
        return;
      }
      setBatch(batchData);

      // 2. Strict Hierarchy Verification: verify that subject belongs to the requested course batch
      const subjectData = await getSubjectById(subjectId);
      if (!subjectData || subjectData.batchId !== batchId) {
        setError('Resource hierarchy violation: Subject does not belong to this course batch.');
        setAccessState({
          hasAccess: false,
          status: 'not_enrolled',
          reason: 'This subject does not belong to the specified course batch.',
        });
        setIsLoading(false);
        return;
      }
      setSubject(subjectData);

      // 3. Phase 8 Course Access Security: Authoritative check
      const access = await checkStudentCourseAccess(
        currentUser?.uid,
        batchId,
        batchData.isFree,
        currentUser?.email
      );
      setAccessState(access);

      if (!access.hasAccess) {
        setIsLoading(false);
        return;
      }

      // 4. Fetch published chapters ONLY IF user is authorized
      const chaptersData = await getPublishedChapters(subjectId);
      setChapters(chaptersData);
    } catch (err: any) {
      console.error('[SubjectDetailsPage] Error loading subject:', err);
      setError(err.message || 'Failed to load subject chapters.');
    } finally {
      setIsLoading(false);
    }
  }, [batchId, subjectId, currentUser?.uid]);

  useEffect(() => {
    loadSubjectData();
  }, [loadSubjectData]);

  // Loading Skeleton
  if (isLoading) {
    return (
      <div className="max-w-4xl mx-auto space-y-6 animate-pulse p-4">
        <div className="h-6 w-48 bg-slate-200 rounded-lg" />
        <div className="h-44 bg-slate-200 rounded-3xl" />
        <div className="space-y-3">
          <div className="h-20 bg-slate-200 rounded-2xl" />
          <div className="h-20 bg-slate-200 rounded-2xl" />
          <div className="h-20 bg-slate-200 rounded-2xl" />
        </div>
      </div>
    );
  }

  // Access Denied / Locked State (Phase 8 Production Guard)
  if (accessState && !accessState.hasAccess) {
    const isExpired = accessState.status === 'expired';
    return (
      <div className="max-w-xl mx-auto my-12 bg-white rounded-3xl border border-slate-200 p-8 text-center shadow-xs">
        <div className={`w-14 h-14 rounded-2xl ${isExpired ? 'bg-amber-50 text-amber-600' : 'bg-rose-50 text-rose-600'} flex items-center justify-center mx-auto mb-4`}>
          {isExpired ? <Clock className="w-7 h-7" /> : <Lock className="w-7 h-7" />}
        </div>
        <Badge variant={isExpired ? 'amber' : 'rose'} size="md" className="mb-3">
          {isExpired ? 'Access Expired' : 'Protected Course Resource'}
        </Badge>
        <h2 className="text-xl font-extrabold text-slate-900 mb-2">
          {isExpired ? 'Course Access Expired' : 'Course Enrollment Required'}
        </h2>
        <p className="text-xs sm:text-sm text-slate-600 mb-6 leading-relaxed">
          {accessState.reason || 'You need an active enrollment in this course to access subject chapters, video lectures, and study notes.'}
        </p>
        <div className="flex justify-center gap-3">
          <Button
            variant="outline"
            size="sm"
            onClick={() => navigate('/student/all-courses')}
            leftIcon={<BookOpen className="w-3.5 h-3.5" />}
          >
            Browse Courses
          </Button>
          <Button
            variant="primary"
            size="sm"
            onClick={() => navigate(batchId ? `/course/${batchId}` : '/student/all-courses')}
            leftIcon={<ArrowLeft className="w-3.5 h-3.5" />}
          >
            {isExpired ? 'Renew Course Access' : 'View Course & Enroll'}
          </Button>
        </div>
      </div>
    );
  }

  // Error / Not Found State
  if (error || !subject || !batch) {
    return (
      <div className="max-w-xl mx-auto my-12 bg-white rounded-3xl border border-slate-200 p-8 text-center shadow-xs">
        <div className="w-14 h-14 rounded-2xl bg-rose-50 text-rose-600 flex items-center justify-center mx-auto mb-4">
          <AlertCircle className="w-7 h-7" />
        </div>
        <h2 className="text-lg font-bold text-slate-900 mb-2">Subject Unavailable</h2>
        <p className="text-xs text-slate-500 mb-6 leading-relaxed">
          {error || 'This subject does not exist, has been unpublished, or is not part of this course.'}
        </p>
        <div className="flex justify-center gap-3">
          <Button
            variant="outline"
            size="sm"
            onClick={() => loadSubjectData()}
            leftIcon={<RefreshCw className="w-3.5 h-3.5" />}
          >
            Retry
          </Button>
          <Button
            variant="primary"
            size="sm"
            onClick={() => navigate(batchId ? `/course/${batchId}` : '/student/all-courses')}
            leftIcon={<ArrowLeft className="w-3.5 h-3.5" />}
          >
            Back to Course
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* Breadcrumbs */}
      <div className="flex items-center gap-2 text-xs font-medium text-slate-500 overflow-x-auto pb-1 scrollbar-none">
        <Link to="/student" className="hover:text-blue-600 shrink-0">Home</Link>
        <ChevronRight className="w-3.5 h-3.5 text-slate-400 shrink-0" />
        <Link to={`/course/${batch.id}`} className="hover:text-blue-600 truncate max-w-[150px] shrink-0">
          {batch.title}
        </Link>
        <ChevronRight className="w-3.5 h-3.5 text-slate-400 shrink-0" />
        <span className="text-slate-900 font-bold truncate max-w-[200px] shrink-0">
          {subject.name}
        </span>
      </div>

      {/* Subject Header Card */}
      <div className="bg-white rounded-3xl border border-slate-200/80 p-5 sm:p-7 shadow-xs">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="space-y-1.5 flex-1">
            <div className="flex items-center gap-2">
              <Badge variant="blue" size="sm">
                Subject Module
              </Badge>
              <span className="text-xs font-semibold text-slate-400">
                {chapters.length} Chapters Published
              </span>
            </div>
            <h1 className="text-xl sm:text-2xl font-extrabold text-slate-900">
              {subject.name}
            </h1>
            <p className="text-xs sm:text-sm text-slate-600 max-w-2xl leading-relaxed">
              {subject.description || 'Systematic chapters covering theoretical concepts and clinical applications.'}
            </p>
          </div>

          <Link to={`/course/${batch.id}`}>
            <Button variant="outline" size="sm" leftIcon={<ArrowLeft className="w-3.5 h-3.5" />}>
              Back to Batch
            </Button>
          </Link>
        </div>
      </div>

      {/* Chapters List */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-base font-extrabold text-slate-900 flex items-center gap-2">
            <Layers className="w-4 h-4 text-blue-600" />
            <span>Chapters & Topics</span>
          </h2>
          <span className="text-xs font-medium text-slate-500">
            Ordered by syllabus progression
          </span>
        </div>

        {chapters.length > 0 ? (
          <div className="space-y-3">
            {chapters.map((chapter, index) => (
              <Link
                key={chapter.id}
                to={`/course/${batch.id}/subject/${subject.id}/chapter/${chapter.id}`}
                className="group bg-white rounded-2xl border border-slate-200/80 p-4 sm:p-5 shadow-xs hover:shadow-md hover:border-blue-300 transition-colors flex items-center justify-between gap-4"
              >
                <div className="flex items-center gap-4 min-w-0">
                  <div className="w-10 h-10 rounded-xl bg-blue-50 text-blue-700 font-bold flex items-center justify-center shrink-0 group-hover:bg-blue-600 group-hover:text-white transition-colors text-sm">
                    {(index + 1).toString().padStart(2, '0')}
                  </div>
                  <div className="min-w-0">
                    <h3 className="text-sm sm:text-base font-bold text-slate-900 group-hover:text-blue-600 transition-colors truncate">
                      {chapter.name}
                    </h3>
                    <p className="text-xs text-slate-500 line-clamp-1 mt-0.5">
                      {chapter.description || 'Lectures, clinical points & MCQ practice.'}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-3 shrink-0">
                  <span className="hidden sm:inline text-xs font-semibold text-blue-600 group-hover:underline">
                    View Classes
                  </span>
                  <ChevronRight className="w-4 h-4 text-slate-400 group-hover:text-blue-600 transition-colors" />
                </div>
              </Link>
            ))}
          </div>
        ) : (
          <div className="bg-white rounded-2xl border border-slate-200 p-8 text-center">
            <BookOpen className="w-8 h-8 text-slate-300 mx-auto mb-2" />
            <h4 className="text-sm font-bold text-slate-800">No Chapters Published Yet</h4>
            <p className="text-xs text-slate-500 mt-1">
              Faculty is currently preparing the chapter sequence for this subject.
            </p>
          </div>
        )}
      </div>
    </div>
  );
}

export default SubjectDetailsPage;
