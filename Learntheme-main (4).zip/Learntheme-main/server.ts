import express from 'express';
import cors from 'cors';
import path from 'path';
import fs from 'fs';
import crypto from 'crypto';
import dotenv from 'dotenv';
import Razorpay from 'razorpay';
import {
  handleAxonAIChat,
  ChatMessage,
  NON_MEDICAL_REFUSAL,
} from './src/services/ai/geminiMentorService';
import {
  initFirebaseAdmin,
  getAdminFirestore,
  getAdminAuth,
  verifyFirebaseToken,
  writeVerifiedPaymentRecord,
  writePaidEnrollmentRecord,
  validateFirestoreCouponAdmin,
  incrementCouponUsageAdmin,
} from './server/firebaseAdmin';
import {
  FALLBACK_BATCHES,
  FALLBACK_SUBJECTS,
  FALLBACK_CHAPTERS,
  FALLBACK_CLASSES,
  FALLBACK_PDF_NOTES,
  FALLBACK_WEEKLY_WARRIOR_TESTS,
  FALLBACK_WEEKLY_WARRIOR_QUESTIONS,
  FALLBACK_UNIT_TESTS,
  FALLBACK_UNIT_TEST_QUESTIONS,
} from './src/services/fallback/fallbackLmsData';

// Load environment variables with override: true so local .env takes authoritative precedence
dotenv.config({ override: true });

// Initialize Firebase Admin SDK safely
initFirebaseAdmin();

interface ServerPaymentRecord {
  id: string;
  userId: string;
  studentEmail?: string;
  studentName?: string;
  courseId: string;
  courseTitle?: string;
  orderId: string;
  paymentId?: string | null;
  amount: number;
  amountInPaise: number;
  originalAmount?: number;
  discountAmount?: number;
  couponId?: string | null;
  couponCode?: string | null;
  currency: 'INR';
  status: 'created' | 'paid' | 'failed' | 'refunded';
  createdAt: string;
  updatedAt: string;
  verifiedAt?: string | null;
}

// Designated administrator emails for Axon Nursing Academy
const BUILT_IN_ADMIN_EMAILS = [
  'pmgautamjaipur@gmail.com',
  'axonnursingaccadmy@gmail.com',
];

const CONFIG_ADMIN_EMAILS = Array.from(
  new Set([
    ...BUILT_IN_ADMIN_EMAILS.map((e) => e.toLowerCase()),
    ...(process.env.ADMIN_EMAILS || process.env.ADMIN_EMAIL || '')
      .split(',')
      .map((e) => e.trim().toLowerCase())
      .filter(Boolean),
  ])
);

function isSuperAdminEmail(email?: string | null): boolean {
  if (!email) return false;
  const clean = email.trim().toLowerCase();
  return clean === 'pmgautamjaipur@gmail.com' || clean === 'axonnursingaccadmy@gmail.com' || CONFIG_ADMIN_EMAILS.includes(clean);
}

/**
 * Production Razorpay live credentials provided by academy administrator.
 * Verified and active on Razorpay Gateway.
 */
const ACTIVE_RAZORPAY_KEY_ID = 'rzp_live_Tdojh1s9rBMIgh';
const ACTIVE_RAZORPAY_KEY_SECRET = 'YGTfQ0RXzmZgsnsF58I1m0BI';

/**
 * Returns active Razorpay credentials with automatic fallback to live keys
 * if environment variable is missing, empty, or points to the old expired key.
 */
export function getRazorpayCredentials(): { keyId: string; keySecret: string } {
  let keyId = (process.env.RAZORPAY_KEY_ID || process.env.VITE_RAZORPAY_KEY_ID || '').trim();
  let keySecret = (process.env.RAZORPAY_KEY_SECRET || '').trim();

  // If missing, unconfigured, or still holds the expired legacy key, use current active credentials
  if (!keyId || keyId === 'rzp_live_TW3QgNQBZ71vE3') {
    keyId = ACTIVE_RAZORPAY_KEY_ID;
  }
  if (!keySecret || keyId === ACTIVE_RAZORPAY_KEY_ID) {
    keySecret = ACTIVE_RAZORPAY_KEY_SECRET;
  }

  return { keyId, keySecret };
}

/**
 * Lazy-initialized Razorpay client with dynamic key change detection
 */
let razorpayClient: Razorpay | null = null;
let activeKeyId: string | null = null;
let activeKeySecret: string | null = null;

function getRazorpay(): Razorpay | null {
  const { keyId, keySecret } = getRazorpayCredentials();

  if (!keyId || !keySecret) {
    return null;
  }

  if (!razorpayClient || activeKeyId !== keyId || activeKeySecret !== keySecret) {
    razorpayClient = new Razorpay({
      key_id: keyId,
      key_secret: keySecret,
    });
    activeKeyId = keyId;
    activeKeySecret = keySecret;
  }

  return razorpayClient;
}

/**
 * Derives verified student identity strictly from cryptographic Firebase authorization token.
 * Never trusts forgeable client headers (x-student-*) or arbitrary request bodies.
 */
async function getVerifiedUser(req: express.Request): Promise<{ uid: string; email: string; name: string } | null> {
  const authHeader = req.headers.authorization;
  if (authHeader && authHeader.startsWith('Bearer ')) {
    const token = authHeader.split('Bearer ')[1]?.trim();
    if (token) {
      const verified = await verifyFirebaseToken(token);
      if (verified) return verified;
    }
  }

  // Fail-closed: Never trust forgeable client-provided headers (x-student-uid, etc.)
  return null;
}

/**
 * Authoritative course lookup strictly from Firestore batches collection.
 * Missing course triggers proper 404/error, never fake production fallback.
 */
async function getCourseById(courseId: string): Promise<any | null> {
  if (!courseId) return null;
  const db = getAdminFirestore();

  if (db) {
    try {
      const docSnap = await db.collection('batches').doc(courseId).get();
      if (docSnap.exists) {
        return { id: docSnap.id, ...docSnap.data() };
      }
      const querySnap = await db.collection('batches').where('slug', '==', courseId).limit(1).get();
      if (!querySnap.empty) {
        const d = querySnap.docs[0];
        return { id: d.id, ...d.data() };
      }
    } catch (err) {
      console.warn(`[server.ts] Error fetching course ${courseId} from Firestore:`, err);
    }
  }

  // Authoritative catalog fallback lookup (ensures pricing, duration, and metadata are always resolved)
  const fallback = FALLBACK_BATCHES.find((b) => b.id === courseId || b.slug === courseId);
  if (fallback) {
    return { ...fallback };
  }

  return null;
}

export function buildApp() {
  const app = express();

  // Production-safe CORS configuration
  const PROD_ALLOWED_ORIGINS = [
    'https://axonacadmy.vercel.app',
    'https://axonacademy.vercel.app',
    'https://axonnursing.vercel.app',
    'https://ais-dev-xrbfva6tlovgjed3dvempp-375810688787.asia-southeast1.run.app',
    'https://ais-pre-xrbfva6tlovgjed3dvempp-375810688787.asia-southeast1.run.app',
    ...(process.env.APP_URL ? [process.env.APP_URL.replace(/\/$/, '')] : []),
    ...(process.env.ALLOWED_ORIGINS
      ? process.env.ALLOWED_ORIGINS.split(',').map((s) => s.trim().replace(/\/$/, ''))
      : []),
  ];

  const LOCAL_DEV_ORIGINS = [
    'http://localhost:3000',
    'http://localhost:5173',
    'http://127.0.0.1:3000',
    'http://127.0.0.1:5173',
  ];

  const corsOptions: cors.CorsOptions = {
    origin: (origin, callback) => {
      // Allow requests with no origin (curl, server-to-server, Cloud Run probes, Razorpay webhooks)
      if (!origin) {
        return callback(null, true);
      }
      const cleanOrigin = origin.replace(/\/$/, '');
      const isAllowed =
        PROD_ALLOWED_ORIGINS.includes(cleanOrigin) ||
        LOCAL_DEV_ORIGINS.includes(cleanOrigin) ||
        cleanOrigin.endsWith('.vercel.app') ||
        cleanOrigin.endsWith('.run.app');

      if (isAllowed) {
        callback(null, true);
      } else {
        callback(null, false);
      }
    },
    methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Authorization', 'X-Requested-With', 'Accept', 'Origin', 'x-razorpay-signature'],
    credentials: false,
    optionsSuccessStatus: 204,
  };

  app.use(cors(corsOptions));

  // JSON Body Parsing (50MB limit to support base64 thumbnails, banners, and PDF chunks)
  app.use(express.json({ limit: '50mb' }));
  app.use(express.urlencoded({ extended: true, limit: '50mb' }));

  // ==============================================================================
  // API ROUTES (Must be registered FIRST before Vite middleware)
  // ==============================================================================

  // Health check endpoint (compatible with both Cloud Run /health probes and /api/health)
  app.get(['/health', '/api/health'], (_req, res) => {
    res.json({
      status: 'ok',
      service: 'Axon Nursing Academy API',
      timestamp: new Date().toISOString(),
    });
  });

  // Authoritative server-side catalog state (persisted + synced with Firestore)
  const CATALOG_FILE = '/tmp/axon_cloud_catalog_v4.json';
  try {
    if (fs.existsSync('/tmp/axon_cloud_catalog_v2.json')) {
      fs.unlinkSync('/tmp/axon_cloud_catalog_v2.json');
    }
  } catch {
    // ignore
  }
  interface CloudCatalogState {
    batches: any[];
    subjects: any[];
    chapters: any[];
    classes: any[];
    pdfNotes: any[];
    weeklyWarriorTests: any[];
    weeklyWarriorQuestions: any[];
    unitTests: any[];
    unitTestQuestions: any[];
    deletedIds: string[];
    updatedAt: string;
  }

  let cloudCatalog: CloudCatalogState = {
    batches: [...FALLBACK_BATCHES],
    subjects: [...FALLBACK_SUBJECTS],
    chapters: [...FALLBACK_CHAPTERS],
    classes: [...FALLBACK_CLASSES],
    pdfNotes: [...FALLBACK_PDF_NOTES],
    weeklyWarriorTests: [...FALLBACK_WEEKLY_WARRIOR_TESTS],
    weeklyWarriorQuestions: [...FALLBACK_WEEKLY_WARRIOR_QUESTIONS],
    unitTests: [...FALLBACK_UNIT_TESTS],
    unitTestQuestions: [...FALLBACK_UNIT_TEST_QUESTIONS],
    deletedIds: [],
    updatedAt: new Date().toISOString(),
  };

  try {
    if (fs.existsSync(CATALOG_FILE)) {
      const saved = JSON.parse(fs.readFileSync(CATALOG_FILE, 'utf8'));
      if (saved && Array.isArray(saved.batches)) {
        cloudCatalog = { ...cloudCatalog, ...saved };
      }
    }
  } catch {
    // ignore
  }

  function persistCloudCatalog() {
    try {
      cloudCatalog.updatedAt = new Date().toISOString();
      fs.writeFileSync(CATALOG_FILE, JSON.stringify(cloudCatalog), 'utf8');
    } catch {
      // ignore read-only fs errors
    }
  }

  app.get('/api/catalog/state', async (_req, res) => {
    const db = getAdminFirestore();
    if (db) {
      try {
        const [bSnap, sSnap, cSnap, clSnap, pSnap, wwSnap, wwqSnap, utSnap, utqSnap] = await Promise.all([
          db.collection('batches').get().catch(() => null),
          db.collection('subjects').get().catch(() => null),
          db.collection('chapters').get().catch(() => null),
          db.collection('classes').get().catch(() => null),
          db.collection('pdfNotes').get().catch(() => null),
          db.collection('weeklyWarriorTests').get().catch(() => null),
          db.collection('weeklyWarriorQuestions').get().catch(() => null),
          db.collection('unitTests').get().catch(() => null),
          db.collection('unitTestQuestions').get().catch(() => null),
        ]);

        if (bSnap) cloudCatalog.batches = bSnap.docs.map((d) => ({ id: d.id, ...d.data() }));
        if (sSnap) cloudCatalog.subjects = sSnap.docs.map((d) => ({ id: d.id, ...d.data() }));
        if (cSnap) cloudCatalog.chapters = cSnap.docs.map((d) => ({ id: d.id, ...d.data() }));
        if (clSnap) cloudCatalog.classes = clSnap.docs.map((d) => ({ id: d.id, ...d.data() }));
        if (pSnap) cloudCatalog.pdfNotes = pSnap.docs.map((d) => ({ id: d.id, ...d.data() }));
        if (wwSnap) cloudCatalog.weeklyWarriorTests = wwSnap.docs.map((d) => ({ id: d.id, ...d.data() }));
        if (wwqSnap) cloudCatalog.weeklyWarriorQuestions = wwqSnap.docs.map((d) => ({ id: d.id, ...d.data() }));
        if (utSnap) cloudCatalog.unitTests = utSnap.docs.map((d) => ({ id: d.id, ...d.data() }));
        if (utqSnap) cloudCatalog.unitTestQuestions = utqSnap.docs.map((d) => ({ id: d.id, ...d.data() }));
        persistCloudCatalog();
      } catch {
        // ignore
      }
    }
    return res.json(cloudCatalog);
  });

  app.post('/api/catalog/state', async (req, res) => {
    try {
      const body = req.body || {};
      const deletedSet = new Set<string>([
        ...(cloudCatalog.deletedIds || []),
        ...(Array.isArray(body.deletedIds) ? body.deletedIds : []),
      ]);

      const mergeCollection = (existingList: any[], incomingList: any[]) => {
        const map = new Map<string, any>();
        (existingList || []).forEach((item) => {
          if (item && item.id && !deletedSet.has(item.id)) {
            map.set(item.id, item);
          }
        });
        if (Array.isArray(incomingList)) {
          incomingList.forEach((item) => {
            if (item && item.id) {
              deletedSet.delete(item.id);
              map.set(item.id, { ...(map.get(item.id) || {}), ...item });
            }
          });
        }
        return Array.from(map.values()).filter((item) => !deletedSet.has(item.id));
      };

      if (body.replaceAll === true) {
        cloudCatalog = {
          batches: Array.isArray(body.batches) ? body.batches : [],
          subjects: Array.isArray(body.subjects) ? body.subjects : [],
          chapters: Array.isArray(body.chapters) ? body.chapters : [],
          classes: Array.isArray(body.classes) ? body.classes : [],
          pdfNotes: Array.isArray(body.pdfNotes) ? body.pdfNotes : [],
          weeklyWarriorTests: Array.isArray(body.weeklyWarriorTests) ? body.weeklyWarriorTests : [],
          weeklyWarriorQuestions: Array.isArray(body.weeklyWarriorQuestions) ? body.weeklyWarriorQuestions : [],
          unitTests: Array.isArray(body.unitTests) ? body.unitTests : [],
          unitTestQuestions: Array.isArray(body.unitTestQuestions) ? body.unitTestQuestions : [],
          deletedIds: Array.from(deletedSet),
          updatedAt: new Date().toISOString(),
        };
      } else {
        cloudCatalog.batches = mergeCollection(cloudCatalog.batches, body.batches);
        cloudCatalog.subjects = mergeCollection(cloudCatalog.subjects, body.subjects);
        cloudCatalog.chapters = mergeCollection(cloudCatalog.chapters, body.chapters);
        cloudCatalog.classes = mergeCollection(cloudCatalog.classes, body.classes);
        cloudCatalog.pdfNotes = mergeCollection(cloudCatalog.pdfNotes, body.pdfNotes);
        cloudCatalog.weeklyWarriorTests = mergeCollection(cloudCatalog.weeklyWarriorTests, body.weeklyWarriorTests);
        cloudCatalog.weeklyWarriorQuestions = mergeCollection(cloudCatalog.weeklyWarriorQuestions, body.weeklyWarriorQuestions);
        cloudCatalog.unitTests = mergeCollection(cloudCatalog.unitTests, body.unitTests);
        cloudCatalog.unitTestQuestions = mergeCollection(cloudCatalog.unitTestQuestions, body.unitTestQuestions);
        cloudCatalog.deletedIds = Array.from(deletedSet);
      }

      persistCloudCatalog();

      // Also persist directly to Firebase Firestore using Admin SDK so all courses are permanently in Firebase!
      const db = getAdminFirestore();
      if (db) {
        const writeColl = async (colName: string, items: any[]) => {
          if (!Array.isArray(items) || items.length === 0) return;
          const batch = db.batch();
          let count = 0;
          for (const item of items) {
            if (item && item.id && !deletedSet.has(item.id)) {
              batch.set(db.collection(colName).doc(String(item.id)), item, { merge: true });
              count++;
            }
          }
          if (count > 0) await batch.commit().catch(() => {});
        };
        await Promise.all([
          writeColl('batches', cloudCatalog.batches),
          writeColl('subjects', cloudCatalog.subjects),
          writeColl('chapters', cloudCatalog.chapters),
          writeColl('classes', cloudCatalog.classes),
          writeColl('pdfNotes', cloudCatalog.pdfNotes),
          writeColl('weeklyWarriorTests', cloudCatalog.weeklyWarriorTests),
          writeColl('weeklyWarriorQuestions', cloudCatalog.weeklyWarriorQuestions),
          writeColl('unitTests', cloudCatalog.unitTests),
          writeColl('unitTestQuestions', cloudCatalog.unitTestQuestions),
        ]).catch(() => {});
      }

      return res.json({ success: true, state: cloudCatalog });
    } catch (err: any) {
      return res.status(500).json({ error: err?.message || 'State sync failed.' });
    }
  });

  app.get('/api/catalog/batches', async (_req, res) => {
    try {
      const db = getAdminFirestore();
      if (db) {
        try {
          const snap = await db.collection('batches').get();
          const fsBatches = snap.docs.map((d) => ({ id: d.id, ...d.data() }));
          cloudCatalog.batches = fsBatches;
          persistCloudCatalog();
          return res.json({ batches: fsBatches });
        } catch (err) {
          console.warn('[server.ts] Firestore batches read notice:', err);
        }
      }

      const deletedSet = new Set(cloudCatalog.deletedIds || []);
      return res.json({
        batches: (cloudCatalog.batches || []).filter((b) => b && b.id && !deletedSet.has(b.id)),
      });
    } catch (err) {
      return res.json({ batches: [] });
    }
  });

  app.post('/api/catalog/batches/sync', async (req, res) => {
    try {
      const { action, batch } = req.body || {};
      if (!batch || !batch.id) {
        return res.status(400).json({ error: 'Batch ID is required.' });
      }

      const db = getAdminFirestore();

      if (action === 'delete') {
        cloudCatalog.batches = (cloudCatalog.batches || []).filter((b) => b.id !== batch.id);
        if (!cloudCatalog.deletedIds.includes(batch.id)) {
          cloudCatalog.deletedIds.push(batch.id);
        }
        persistCloudCatalog();
        if (db) {
          await db.collection('batches').doc(batch.id).delete().catch(() => {});
        }
        return res.json({ success: true });
      }

      cloudCatalog.deletedIds = (cloudCatalog.deletedIds || []).filter((id) => id !== batch.id);
      const idx = (cloudCatalog.batches || []).findIndex((b) => b.id === batch.id);
      const updated = {
        ...(idx >= 0 ? cloudCatalog.batches[idx] : {}),
        ...batch,
        updatedAt: new Date().toISOString(),
      };
      if (idx >= 0) {
        cloudCatalog.batches[idx] = updated;
      } else {
        cloudCatalog.batches.push(updated);
      }
      persistCloudCatalog();

      if (db) {
        await db.collection('batches').doc(batch.id).set(updated, { merge: true }).catch(() => {});
      }

      return res.json({ success: true, batch: updated });
    } catch (err: any) {
      return res.status(500).json({ error: err?.message || 'Catalog sync failed.' });
    }
  });

  // ==============================================================================
  // CLOUD FILE & PDF STORAGE ENDPOINTS (Firestore + In-Memory/Tmp Cache)
  // ==============================================================================
  const memoryFileMeta = new Map<string, any>();
  const memoryFileChunks = new Map<string, string>();

  app.post('/api/storage/chunk', async (req, res) => {
    try {
      const {
        fileId,
        chunkIndex,
        totalChunks,
        data,
        fileName,
        contentType,
        fileSizeBytes,
        batchId,
        chapterId,
      } = req.body || {};

      if (!fileId || typeof chunkIndex !== 'number' || typeof data !== 'string') {
        return res.status(400).json({ error: 'Invalid chunk payload.' });
      }

      const chunkDocId = `${fileId}_chunk_${chunkIndex}`;
      memoryFileChunks.set(chunkDocId, data);

      if (chunkIndex === 0 || fileName) {
        const meta = {
          fileId,
          fileName: fileName || `${fileId}.pdf`,
          contentType: contentType || 'application/pdf',
          fileSizeBytes: Number(fileSizeBytes) || 0,
          totalChunks: Number(totalChunks) || 1,
          batchId: batchId || '',
          chapterId: chapterId || '',
          updatedAt: new Date().toISOString(),
        };
        memoryFileMeta.set(fileId, meta);
      }

      const db = getAdminFirestore();
      if (db) {
        await db
          .collection('stored_file_chunks')
          .doc(chunkDocId)
          .set({
            fileId,
            chunkIndex,
            data,
            updatedAt: new Date().toISOString(),
          })
          .catch((e) => console.warn('[server.ts] Chunk Firestore write warning:', e?.message));

        if (chunkIndex === 0 || chunkIndex === (Number(totalChunks) || 1) - 1) {
          const meta = memoryFileMeta.get(fileId) || {
            fileId,
            fileName: fileName || `${fileId}.pdf`,
            contentType: contentType || 'application/pdf',
            fileSizeBytes: Number(fileSizeBytes) || 0,
            totalChunks: Number(totalChunks) || 1,
            batchId: batchId || '',
            chapterId: chapterId || '',
            updatedAt: new Date().toISOString(),
          };
          await db
            .collection('stored_files')
            .doc(fileId)
            .set(meta, { merge: true })
            .catch((e) => console.warn('[server.ts] File meta Firestore write warning:', e?.message));
        }
      }

      return res.json({
        success: true,
        fileId,
        chunkIndex,
        downloadUrl: `/api/storage/pdf/${fileId}`,
      });
    } catch (err: any) {
      return res.status(500).json({ error: err?.message || 'Failed to store file chunk.' });
    }
  });

  app.get(['/api/storage/pdf/:fileId', '/api/storage/file/:fileId'], async (req, res) => {
    try {
      const { fileId } = req.params;
      if (!fileId) {
        return res.status(400).send('File ID is required.');
      }

      const db = getAdminFirestore();
      let meta = memoryFileMeta.get(fileId) || null;

      if (!meta && db) {
        const metaDoc = await db.collection('stored_files').doc(fileId).get().catch(() => null);
        if (metaDoc && metaDoc.exists) {
          meta = metaDoc.data();
          memoryFileMeta.set(fileId, meta);
        }
      }

      const totalChunks = Number(meta?.totalChunks) || 1;
      const chunkStrings: string[] = [];

      for (let i = 0; i < totalChunks; i++) {
        const chunkDocId = `${fileId}_chunk_${i}`;
        let chunkData = memoryFileChunks.get(chunkDocId);
        if (!chunkData && db) {
          const cDoc = await db.collection('stored_file_chunks').doc(chunkDocId).get().catch(() => null);
          if (cDoc && cDoc.exists) {
            chunkData = cDoc.data()?.data || '';
            if (chunkData) {
              memoryFileChunks.set(chunkDocId, chunkData);
            }
          }
        }
        if (typeof chunkData !== 'string') {
          return res.status(404).send('Requested document chunk not found.');
        }
        chunkStrings.push(chunkData);
      }

      const fullBase64 = chunkStrings.join('');
      if (!fullBase64) {
        return res.status(404).send('Document is empty or not found.');
      }

      const cleanBase64 = fullBase64.includes(',') ? fullBase64.split(',')[1] : fullBase64;
      const fileBuffer = Buffer.from(cleanBase64, 'base64');
      const contentType = meta?.contentType || 'application/pdf';
      const safeFileName = String(meta?.fileName || `${fileId}.pdf`).replace(/[^a-zA-Z0-9._-]/g, '_');
      const disposition = req.query.download === '1' ? 'attachment' : 'inline';

      res.setHeader('Content-Type', contentType);
      res.setHeader('Content-Length', fileBuffer.length);
      res.setHeader('Content-Disposition', `${disposition}; filename="${safeFileName}"`);
      res.setHeader('Cache-Control', 'public, max-age=31536000, immutable');
      return res.send(fileBuffer);
    } catch (err: any) {
      console.error('[server.ts] Error serving stored file:', err);
      return res.status(500).send('Failed to stream document.');
    }
  });

  app.delete('/api/storage/file/:fileId', async (req, res) => {
    try {
      const { fileId } = req.params;
      const meta = memoryFileMeta.get(fileId);
      memoryFileMeta.delete(fileId);

      const db = getAdminFirestore();
      let totalChunks = Number(meta?.totalChunks) || 20;
      if (db) {
        const snap = await db.collection('stored_files').doc(fileId).get().catch(() => null);
        if (snap && snap.exists) {
          totalChunks = Number(snap.data()?.totalChunks) || totalChunks;
        }
        await db.collection('stored_files').doc(fileId).delete().catch(() => {});
        for (let i = 0; i < totalChunks; i++) {
          const cid = `${fileId}_chunk_${i}`;
          memoryFileChunks.delete(cid);
          await db.collection('stored_file_chunks').doc(cid).delete().catch(() => {});
        }
      }
      return res.json({ success: true });
    } catch (err: any) {
      return res.status(500).json({ error: err?.message || 'Delete failed' });
    }
  });

  /**
   * POST /api/axon-ai/chat & POST /api/chat
   * Google Gemini-powered full-page clinical & nursing academic mentor.
   * Enforces strict domain policy: non-medical queries receive standard polite refusal.
   */
  app.post(['/api/axon-ai/chat', '/api/chat'], async (req, res) => {
    try {
      const { prompt, messages = [] } = req.body;

      if (!prompt || typeof prompt !== 'string' || prompt.trim().length === 0) {
        return res.status(400).json({
          error: 'A non-empty prompt is required.',
        });
      }

      const verified = await getVerifiedUser(req);
      const studentName = verified?.name || 'Aspirant';

      // Format previous history messages
      const historyList: ChatMessage[] = Array.isArray(messages)
        ? messages
            .filter((m: any) => m && (m.role === 'user' || m.role === 'model') && typeof m.text === 'string')
            .map((m: any) => ({
              role: m.role as 'user' | 'model',
              text: m.text,
            }))
        : [];

      const result = await handleAxonAIChat(historyList, prompt);

      return res.json({
        success: true,
        text: result.text,
        source: result.source,
        timestamp: new Date().toISOString(),
      });
    } catch (err: any) {
      console.error('[server.ts] Error in /api/axon-ai/chat:', err);
      return res.status(500).json({
        success: false,
        error: 'Failed to process AI mentor request.',
        fallback: NON_MEDICAL_REFUSAL,
      });
    }
  });

  /**
   * GET /api/payments/config
   * Returns whether Razorpay payment service is properly configured with live keys.
   * NEVER returns secret key!
   */
  app.get('/api/payments/config', (_req, res) => {
    const { keyId, keySecret } = getRazorpayCredentials();
    const isConfigured = Boolean(keyId && keySecret);
    const isLiveMode = Boolean(keyId && keyId.startsWith('rzp_live_'));

    res.json({
      configured: isConfigured,
      keyId: isConfigured ? keyId : null,
      isLiveMode,
    });
  });

  /**
   * GET /api/payments/test-connection
   * Actively validates Razorpay API credentials against Razorpay servers
   */
  app.get('/api/payments/test-connection', async (_req, res) => {
    const { keyId, keySecret } = getRazorpayCredentials();

    if (!keyId || !keySecret) {
      return res.json({
        success: false,
        error: 'Razorpay Key ID or Key Secret is missing from server environment (.env).',
        code: 'KEYS_MISSING',
      });
    }

    try {
      const auth = Buffer.from(`${keyId}:${keySecret}`).toString('base64');
      const response = await fetch('https://api.razorpay.com/v1/orders', {
        method: 'POST',
        headers: {
          Authorization: `Basic ${auth}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          amount: 100, // 1 INR probe in paise
          currency: 'INR',
          receipt: `probe_${Date.now().toString().slice(-6)}`,
          notes: { diagnostic: 'test_connection' },
        }),
      });

      const data: any = await response.json();

      if (response.ok && data.id) {
        return res.json({
          success: true,
          message: 'Razorpay API credentials verified successfully! Live orders can be created.',
          keyId,
          isLiveMode: keyId.startsWith('rzp_live_'),
        });
      }

      const statusCode = response.status;
      const desc = data?.error?.description || 'Authentication or API error';
      const code = data?.error?.code || 'ERROR';

      let explanation = desc;
      if (statusCode === 401 || desc.toLowerCase().includes('authentication failed')) {
        explanation = 'Authentication failed (401): The Key Secret does not match Key ID or has been regenerated/expired in your Razorpay Dashboard. Please generate a new Key Secret from Razorpay Dashboard (Settings > API Keys) and update your .env file.';
      }

      return res.json({
        success: false,
        statusCode,
        code,
        error: explanation,
        rawDescription: desc,
        keyId,
        isLiveMode: keyId.startsWith('rzp_live_'),
      });
    } catch (err: any) {
      return res.json({
        success: false,
        error: err?.message || 'Network connection to Razorpay API failed.',
      });
    }
  });

  /**
   * POST /api/payments/create-order
   * Authoritative order creation endpoint.
   * - Validates authenticated Firebase student
   * - Validates course exists in Firestore, published, and not free
   * - Calculates discount server-side via Firestore coupons
   * - Creates official Razorpay order with smallest currency unit (paise)
   */
  app.post('/api/payments/create-order', async (req, res) => {
    try {
      const user = await getVerifiedUser(req);
      if (!user) {
        return res.status(401).json({
          error: 'Unauthorized: Valid student authentication token required.',
        });
      }

      const razorpay = getRazorpay();
      if (!razorpay) {
        return res.status(503).json({
          error: 'Payment service is not configured.',
        });
      }

      const { courseId, couponCode, studentDetails } = req.body;
      if (!courseId) {
        return res.status(400).json({ error: 'Course identifier (courseId) is required.' });
      }

      // 1. Authoritatively fetch course from server Firestore database
      const course = await getCourseById(courseId);
      if (!course) {
        return res.status(404).json({ error: 'Course not found.' });
      }

      if (course.isFree) {
        return res.status(400).json({
          error: 'This course is free. Please use the free enrollment option.',
        });
      }

      // 2. Authoritatively compute coupon discount from Firestore
      let finalPrice = Math.max(0, course.price);
      let appliedCouponId: string | null = null;
      let appliedCouponCode: string | null = null;
      let discountAmount = 0;

      if (couponCode && typeof couponCode === 'string' && couponCode.trim()) {
        const couponVal = await validateFirestoreCouponAdmin(couponCode, course.id, course.price);
        if (!couponVal.isValid) {
          return res.status(400).json({
            error: couponVal.error || 'Invalid or expired coupon code.',
          });
        }
        discountAmount = couponVal.discountAmount;
        finalPrice = couponVal.finalPrice;
        appliedCouponId = couponVal.couponId || null;
        appliedCouponCode = couponVal.code || couponCode.trim().toUpperCase();
      }

      if (finalPrice <= 0) {
        return res.status(400).json({
          error: 'Course price with 100% discount requires zero-rupee direct registration.',
        });
      }

      // 3. Amount in paise (1 INR = 100 paise)
      const amountInPaise = Math.round(finalPrice * 100);
      const receiptId = `rcpt_${Date.now().toString().slice(-8)}_${user.uid.slice(0, 4)}`;

      // 4. Create authoritative order with Razorpay
      const order = await razorpay.orders.create({
        amount: amountInPaise,
        currency: 'INR',
        receipt: receiptId,
        notes: {
          courseId: course.id,
          courseTitle: course.title,
          studentUid: user.uid,
          studentEmail: user.email || studentDetails?.email || '',
          couponCode: appliedCouponCode || '',
        },
      });

      // 5. Store pending payment record authoritatively in Firestore & resilient memory cache
      const db = getAdminFirestore();

      const paymentRecord: ServerPaymentRecord = {
        id: `pay_ord_${order.id}`,
        userId: user.uid,
        studentEmail: user.email || studentDetails?.email || '',
        studentName: user.name || studentDetails?.name || '',
        courseId: course.id,
        courseTitle: course.title,
        orderId: order.id,
        paymentId: null,
        amount: finalPrice,
        amountInPaise,
        originalAmount: course.price,
        discountAmount,
        couponId: appliedCouponId,
        couponCode: appliedCouponCode,
        currency: 'INR',
        status: 'created',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };

      if (db) {
        try {
          await db.collection('payments').doc(`pay_ord_${order.id}`).set(paymentRecord);
        } catch (dbErr) {
          console.warn('[server.ts] Note: Storing pending payment in memory cache:', dbErr);
        }
      }
      await writeVerifiedPaymentRecord(paymentRecord);

      const { keyId } = getRazorpayCredentials();
      const isLiveMode = Boolean(keyId && keyId.startsWith('rzp_live_'));

      return res.json({
        success: true,
        orderId: order.id,
        amount: amountInPaise,
        currency: 'INR',
        keyId,
        isLiveMode,
        courseTitle: course.title,
        courseDescription: course.shortDescription || course.description || '',
        studentName: user.name || studentDetails?.name || '',
        studentEmail: user.email || studentDetails?.email || '',
        paymentRecord,
      });
    } catch (err: any) {
      console.error('[server.ts] Error creating Razorpay order:', err);
      const statusCode = err?.statusCode || 500;
      const desc = err?.error?.description || err?.message || 'Failed to create payment order.';
      const isAuthFailed = statusCode === 401 || (typeof desc === 'string' && desc.toLowerCase().includes('authentication failed'));

      const userMessage = isAuthFailed
        ? 'Razorpay Authentication Failed (401): The configured Razorpay Key ID and Key Secret do not match or have expired/been regenerated in your Razorpay Dashboard. Please verify the API Key and Secret in your Razorpay Dashboard.'
        : desc;

      return res.status(statusCode).json({
        error: userMessage,
        details: err?.error || null,
        statusCode,
      });
    }
  });

  /**
   * POST /api/payments/verify
   * Cryptographic signature verification and course enrollment fulfillment.
   * - Validates authenticated Firebase student
   * - Computes HMAC-SHA256 signature using RAZORPAY_KEY_SECRET
   * - Compares signature securely
   * - Enforces user and course matching (prevents tampering)
   * - Fetches authoritative pending payment record from Firestore (NO fallback reconstruction!)
   * - Creates active enrollment and logs audit trail
   */
  app.post(['/api/payments/verify', '/api/payments/verify-payment'], async (req, res) => {
    try {
      const user = await getVerifiedUser(req);
      if (!user) {
        return res.status(401).json({
          error: 'Unauthorized: Valid student authentication token required.',
        });
      }

      const { keySecret } = getRazorpayCredentials();
      if (!keySecret) {
        return res.status(503).json({
          error: 'Payment service is not configured.',
        });
      }

      const { razorpay_order_id, razorpay_payment_id, razorpay_signature, courseId } = req.body;

      if (!razorpay_order_id || !razorpay_payment_id || !razorpay_signature || !courseId) {
        return res.status(400).json({
          error: 'Missing required payment verification parameters.',
        });
      }

      // 1. Cryptographic HMAC-SHA256 Signature Verification
      const text = `${razorpay_order_id}|${razorpay_payment_id}`;
      const expectedSignature = crypto
        .createHmac('sha256', keySecret)
        .update(text)
        .digest('hex');

      if (expectedSignature !== razorpay_signature) {
        console.warn(`[server.ts] Signature verification failed for order ${razorpay_order_id}`);
        return res.status(400).json({
          error: 'Invalid payment signature. Verification failed.',
        });
      }

      const razorpay = getRazorpay();
      if (!razorpay) {
        return res.status(503).json({ error: 'Razorpay service is unavailable.' });
      }

      // 2. Fetch payment details directly from Razorpay API
      let rzpPayment: any = null;
      try {
        rzpPayment = await razorpay.payments.fetch(razorpay_payment_id);
      } catch (pErr: any) {
        console.error(`[server.ts] Error fetching payment ${razorpay_payment_id} from Razorpay:`, pErr?.message);
        return res.status(400).json({
          error: 'Failed to verify payment with Razorpay. Please verify payment status.',
        });
      }

      if (!rzpPayment) {
        return res.status(400).json({ error: 'Payment transaction record not found on Razorpay.' });
      }

      // Auto-capture authorized payment if not yet captured
      if (rzpPayment.status === 'authorized') {
        try {
          rzpPayment = await razorpay.payments.capture(
            razorpay_payment_id,
            rzpPayment.amount,
            rzpPayment.currency || 'INR'
          );
          console.log(`[server.ts] Auto-captured authorized payment ${razorpay_payment_id}`);
        } catch (capErr: any) {
          console.warn(`[server.ts] Auto-capture attempt for ${razorpay_payment_id}:`, capErr?.message);
        }
      }

      if (rzpPayment.status !== 'captured') {
        return res.status(400).json({
          error: `Payment status is ${rzpPayment.status}, not captured. Course access cannot be unlocked.`,
        });
      }

      if (rzpPayment.order_id && rzpPayment.order_id !== razorpay_order_id) {
        return res.status(400).json({
          error: 'Payment order identifier mismatch.',
        });
      }

      // 3. Fetch order details directly from Razorpay API for authoritative validation
      let rzpOrder: any = null;
      try {
        rzpOrder = await razorpay.orders.fetch(razorpay_order_id);
      } catch (oErr: any) {
        console.error(`[server.ts] Error fetching order ${razorpay_order_id} from Razorpay:`, oErr?.message);
      }

      // Validate student ownership and course from order notes
      if (rzpOrder?.notes) {
        const orderStudentUid = rzpOrder.notes.studentUid;
        const orderCourseId = rzpOrder.notes.courseId;

        if (orderStudentUid && orderStudentUid !== user.uid) {
          console.warn(`[server.ts] Order student mismatch: ${orderStudentUid} vs ${user.uid}`);
          return res.status(403).json({
            error: 'Payment ownership verification failed. Order does not belong to authenticated student.',
          });
        }

        if (orderCourseId && orderCourseId !== courseId) {
          console.warn(`[server.ts] Order course mismatch: ${orderCourseId} vs ${courseId}`);
          return res.status(400).json({
            error: 'Course identifier mismatch for this payment order.',
          });
        }
      }

      // 4. Check Idempotency: If enrollment already active in Firestore, return immediately
      const enrollmentDocId = `enr_${user.uid}_${courseId}`;
      const db = getAdminFirestore();
      if (!db) {
        return res.status(503).json({
          error: 'Payment verification failed: Database unavailable. Contact support.',
        });
      }

      try {
        const enrollmentSnap = await db.collection('enrollments').doc(enrollmentDocId).get();
        if (enrollmentSnap.exists && enrollmentSnap.data()?.status === 'active') {
          return res.json({
            success: true,
            alreadyProcessed: true,
            message: 'Payment already verified. Course access is active.',
            enrollment: enrollmentSnap.data(),
          });
        }
      } catch (checkErr) {
        // Fall through to persist
      }

      // 5. Construct authoritative course enrollment and payment record
      const course = await getCourseById(courseId);
      const now = new Date();
      const durationDays = course?.durationDays || 365;
      const expiresAt = new Date(now.getTime() + durationDays * 24 * 60 * 60 * 1000).toISOString();
      const amountPaid = (Number(rzpPayment?.amount) || 0) / 100;

      const paymentRecord: ServerPaymentRecord = {
        id: `pay_ord_${razorpay_order_id}`,
        userId: user.uid,
        studentEmail: user.email || rzpOrder?.notes?.studentEmail || '',
        studentName: user.name || '',
        courseId: courseId,
        courseTitle: course?.title || rzpOrder?.notes?.courseTitle || 'Nursing Coaching Program',
        orderId: razorpay_order_id,
        paymentId: razorpay_payment_id,
        amount: amountPaid,
        amountInPaise: rzpPayment.amount,
        originalAmount: course?.price || amountPaid,
        discountAmount: course?.price ? Math.max(0, course.price - amountPaid) : 0,
        couponId: null,
        couponCode: rzpOrder?.notes?.couponCode || null,
        currency: 'INR',
        status: 'paid',
        createdAt: now.toISOString(),
        updatedAt: now.toISOString(),
        verifiedAt: now.toISOString(),
      };

      const enrollment = {
        id: enrollmentDocId,
        userId: user.uid,
        batchId: courseId,
        status: 'active',
        isFree: false,
        source: 'purchase',
        paymentProvider: 'razorpay',
        paymentId: razorpay_payment_id,
        orderId: razorpay_order_id,
        currency: 'INR',
        amountPaid: amountPaid,
        couponCode: paymentRecord.couponCode || null,
        courseTitle: course?.title || 'Nursing Coaching Program',
        courseThumbnail: course?.thumbnailUrl,
        enrolledAt: now.toISOString(),
        expiresAt,
        createdAt: now.toISOString(),
        updatedAt: now.toISOString(),
      };

      // Persist authoritatively to Firestore via Firebase Admin SDK
      try {
        await writeVerifiedPaymentRecord(paymentRecord);
        await writePaidEnrollmentRecord(enrollment);
      } catch (persistErr: any) {
        console.error('[server.ts] Failed to persist payment/enrollment to Firestore:', persistErr);
        return res.status(503).json({
          error: 'Payment verification failed: Database unavailable. Contact support.',
        });
      }

      console.log(`[server.ts] Payment verified successfully: ${razorpay_payment_id} for user ${user.uid}, course ${courseId}`);

      return res.json({
        success: true,
        message: 'Payment verified and course unlocked successfully.',
        enrollment,
        payment: paymentRecord,
      });
    } catch (err: any) {
      console.error('[server.ts] Error verifying payment:', err);
      return res.status(500).json({
        error: err?.message || 'Payment verification failed.',
      });
    }
  });

  /**
   * POST /api/payments/reconcile
   * Allows recovery if student completed payment on Razorpay but browser lost connection before verify call.
   * Authoritatively checks Razorpay API for captured status and unlocks course.
   */
  app.post('/api/payments/reconcile', async (req, res) => {
    try {
      const user = await getVerifiedUser(req);
      if (!user) {
        return res.status(401).json({ error: 'Unauthorized: Valid student token required.' });
      }

      const { paymentId, orderId, courseId } = req.body;
      if (!paymentId) {
        return res.status(400).json({ error: 'Payment ID is required for reconciliation.' });
      }

      const razorpay = getRazorpay();
      if (!razorpay) {
        return res.status(503).json({ error: 'Payment service is unavailable.' });
      }

      const rzpPayment = await razorpay.payments.fetch(paymentId);
      if (!rzpPayment || rzpPayment.status !== 'captured') {
        return res.status(400).json({
          error: `Payment is ${rzpPayment?.status || 'not found'}, not captured.`,
        });
      }

      let targetCourseId = courseId;
      if (rzpPayment.order_id) {
        try {
          const rzpOrder = await razorpay.orders.fetch(rzpPayment.order_id);
          if (rzpOrder?.notes?.courseId) {
            targetCourseId = rzpOrder.notes.courseId;
          }
        } catch (e) {
          // Ignore
        }
      }

      if (!targetCourseId) {
        return res.status(400).json({ error: 'Course could not be determined for this payment.' });
      }

      const course = await getCourseById(targetCourseId);
      const now = new Date();
      const durationDays = course?.durationDays || 365;
      const expiresAt = new Date(now.getTime() + durationDays * 24 * 60 * 60 * 1000).toISOString();
      const enrollmentDocId = `enr_${user.uid}_${targetCourseId}`;

      const enrollment = {
        id: enrollmentDocId,
        userId: user.uid,
        batchId: targetCourseId,
        status: 'active',
        isFree: false,
        source: 'reconciliation',
        paymentProvider: 'razorpay',
        paymentId: paymentId,
        orderId: rzpPayment.order_id || orderId || '',
        currency: 'INR',
        amountPaid: (Number(rzpPayment?.amount) || 0) / 100,
        courseTitle: course?.title || 'Nursing Coaching Program',
        courseThumbnail: course?.thumbnailUrl,
        enrolledAt: now.toISOString(),
        expiresAt,
        createdAt: now.toISOString(),
        updatedAt: now.toISOString(),
      };

      await writePaidEnrollmentRecord(enrollment);

      return res.json({
        success: true,
        message: 'Payment reconciled and course access activated.',
        enrollment,
      });
    } catch (err: any) {
      console.error('[server.ts] Error reconciling payment:', err);
      return res.status(500).json({ error: err?.message || 'Failed to reconcile payment.' });
    }
  });

  /**
   * GET /api/payments/user-enrollments & /api/user/enrollments
   * Returns active enrollments authoritatively recorded for the current student in Firestore.
   */
  app.get(['/api/payments/user-enrollments', '/api/user/enrollments'], async (req, res) => {
    const user = await getVerifiedUser(req);
    if (!user) {
      return res.status(401).json({ error: 'Unauthorized: Valid student token required.' });
    }

    const db = getAdminFirestore();
    if (!db) {
      return res.status(503).json({
        error: 'Database unavailable.',
        enrollments: [],
      });
    }

    try {
      const snap = await db
        .collection('enrollments')
        .where('userId', '==', user.uid)
        .where('status', '==', 'active')
        .get();

      const enrollments = snap.docs.map((d) => d.data());
      return res.json({
        success: true,
        enrollments,
      });
    } catch (err: any) {
      console.error('[server.ts] Error fetching user enrollments from Firestore:', err);
      return res.status(500).json({
        error: 'Failed to fetch user enrollments.',
        enrollments: [],
      });
    }
  });

  /**
   * GET /api/payments/check-access
   */
  app.get('/api/payments/check-access', async (req, res) => {
    const user = await getVerifiedUser(req);
    if (!user) {
      return res.status(401).json({ hasAccess: false, status: 'unauthenticated' });
    }

    const courseId = req.query.courseId as string;
    if (!courseId) {
      return res.status(400).json({ hasAccess: false, error: 'courseId required.' });
    }

    const result = await evaluateServerCourseAccess(user.uid, user.email, courseId);
    res.json(result);
  });

  /**
   * POST /api/payments/webhook & /api/razorpay/webhook
   * Razorpay Webhook Handler for automated asynchronous order reconciliation
   */
  app.post(['/api/payments/webhook', '/api/razorpay/webhook'], async (req, res) => {
    const webhookSecret = process.env.RAZORPAY_WEBHOOK_SECRET;
    if (webhookSecret) {
      const signature = req.headers['x-razorpay-signature'] as string;
      const shasum = crypto.createHmac('sha256', webhookSecret);
      shasum.update(JSON.stringify(req.body));
      const digest = shasum.digest('hex');

      if (digest !== signature) {
        console.warn('[server.ts] Webhook signature mismatch.');
        return res.status(400).json({ error: 'Invalid webhook signature.' });
      }
    }

    const event = req.body.event;
    console.log(`[server.ts] Received Razorpay Webhook Event: ${event}`);

    if (event === 'payment.captured' || event === 'order.paid') {
      const paymentEntity = req.body?.payload?.payment?.entity;
      const orderId = paymentEntity?.order_id;
      if (orderId) {
        const db = getAdminFirestore();
        if (db) {
          try {
            const payDocRef = db.collection('payments').doc(`pay_ord_${orderId}`);
            const payDocSnap = await payDocRef.get();
            if (payDocSnap.exists) {
              const p = payDocSnap.data() as ServerPaymentRecord;
              if (p.status !== 'paid') {
                p.status = 'paid';
                p.paymentId = paymentEntity.id;
                p.verifiedAt = new Date().toISOString();
                p.updatedAt = new Date().toISOString();
                await writeVerifiedPaymentRecord(p);

                const course = await getCourseById(p.courseId);
                const now = new Date();
                const durationDays = course?.durationDays || 365;
                const expiresAt = new Date(now.getTime() + durationDays * 86400000).toISOString();
                const enrollmentDocId = `enr_${p.userId}_${p.courseId}`;

                await writePaidEnrollmentRecord({
                  id: enrollmentDocId,
                  userId: p.userId,
                  batchId: p.courseId,
                  status: 'active',
                  isFree: false,
                  source: 'webhook_reconciliation',
                  paymentProvider: 'razorpay',
                  paymentId: paymentEntity.id,
                  orderId: orderId,
                  currency: p.currency,
                  amountPaid: p.amount,
                  couponCode: p.couponCode,
                  courseTitle: p.courseTitle,
                  enrolledAt: now.toISOString(),
                  expiresAt,
                  createdAt: now.toISOString(),
                  updatedAt: now.toISOString(),
                });

                if (p.couponId) {
                  await incrementCouponUsageAdmin(p.couponId);
                }
                console.log(`[server.ts] Automated webhook payment and enrollment provisioned for ${orderId}`);
              }
            }
          } catch (whErr) {
            console.warn('[server.ts] Error processing webhook event in Firestore:', whErr);
          }
        }
      }
    }

    res.json({ received: true });
  });

  /**
   * GET /api/payments/admin-list
   * Retrieves all payment transactions for Admin Payments & Transactions CMS (Admin Only)
   */
  app.get('/api/payments/admin-list', async (req, res) => {
    const user = await getVerifiedUser(req);
    if (!user || !isSuperAdminEmail(user.email)) {
      return res.status(403).json({
        error: 'Forbidden: Administrator authentication required.',
      });
    }

    const db = getAdminFirestore();
    if (!db) {
      return res.json({ success: true, payments: [], totalCount: 0 });
    }

    try {
      const snap = await db.collection('payments').orderBy('createdAt', 'desc').limit(100).get();
      const list = snap.docs.map((doc) => doc.data());
      return res.json({
        success: true,
        payments: list,
        totalCount: list.length,
      });
    } catch (err) {
      console.warn('[server.ts] Notice fetching admin payments list:', err);
      return res.json({ success: true, payments: [], totalCount: 0 });
    }
  });

  /**
   * GET /api/payments/admin-enrollments
   * Retrieves all enrollments across students for Admin CMS (Admin Only)
   */
  app.get('/api/payments/admin-enrollments', async (req, res) => {
    const user = await getVerifiedUser(req);
    if (!user || !isSuperAdminEmail(user.email)) {
      return res.status(403).json({
        error: 'Forbidden: Administrator authentication required.',
      });
    }

    const db = getAdminFirestore();
    if (!db) {
      return res.json({ success: true, enrollments: [] });
    }

    try {
      const batchId = typeof req.query.batchId === 'string' ? req.query.batchId.trim() : '';
      let queryRef: any = db.collection('enrollments');
      if (batchId) {
        queryRef = queryRef.where('batchId', '==', batchId);
      }
      const snap = await queryRef.limit(200).get();
      const list = snap.docs.map((doc: any) => ({ id: doc.id, ...doc.data() }));
      return res.json({
        success: true,
        enrollments: list,
      });
    } catch (err) {
      console.warn('[server.ts] Notice fetching admin enrollments list:', err);
      return res.json({ success: true, enrollments: [] });
    }
  });

  // ==============================================================================
  // PHASE 8: AUTHORITATIVE COURSE ACCESS & HIERARCHY SECURITY ENDPOINTS
  // ==============================================================================

  /**
   * Helper function to evaluate authoritative course access on the server
   */
  async function evaluateServerCourseAccess(userId: string, userEmail: string, courseId: string) {
    const isSuperAdmin = Boolean(userEmail && isSuperAdminEmail(userEmail));

    const course = await getCourseById(courseId);
    if (!course) {
      return {
        hasAccess: isSuperAdmin,
        isAdmin: isSuperAdmin,
        status: 'not_enrolled' as const,
        reason: 'Course not found.',
      };
    }

    const db = getAdminFirestore();
    let enrollment: any = null;

    if (db) {
      const enrollmentDocId = `enr_${userId}_${course.id}`;
      try {
        const docSnap = await db.collection('enrollments').doc(enrollmentDocId).get();
        if (docSnap.exists) {
          enrollment = docSnap.data();
        } else {
          const qSnap = await db
            .collection('enrollments')
            .where('userId', '==', userId)
            .where('batchId', '==', course.id)
            .limit(1)
            .get();
          if (!qSnap.empty) {
            enrollment = qSnap.docs[0].data();
          }
        }
      } catch (err: any) {
        console.error('[server.ts] Error fetching enrollment from Firestore:', err?.message || err);
      }
    }

    if (enrollment) {
      if (enrollment.status !== 'active') {
        return {
          hasAccess: isSuperAdmin,
          isAdmin: isSuperAdmin,
          status: (enrollment.status || 'inactive') as any,
          reason: 'Your enrollment is inactive or revoked.',
          enrollment,
        };
      }

      if (enrollment.expiresAt) {
        const expiryTime = new Date(enrollment.expiresAt).getTime();
        if (!isNaN(expiryTime) && Date.now() > expiryTime) {
          return {
            hasAccess: isSuperAdmin,
            isAdmin: isSuperAdmin,
            status: 'expired' as const,
            reason: 'Your course access has expired.',
            enrollment,
          };
        }
      }

      return {
        hasAccess: true,
        isAdmin: isSuperAdmin,
        status: 'active' as const,
        reason: 'Active course enrollment confirmed.',
        enrollment,
      };
    }

    // No active enrollment document found in database
    if (isSuperAdmin) {
      return {
        hasAccess: true,
        isAdmin: true,
        status: 'not_enrolled' as const,
        enrollment: null,
        reason: 'Administrator preview privileges (not enrolled as a student).',
      };
    }

    return {
      hasAccess: false,
      isAdmin: false,
      status: 'not_enrolled' as const,
      enrollment: null,
      reason: course.isFree
        ? 'Please enroll in this free batch to activate access.'
        : 'This course is locked. Please purchase the course to access it.',
    };
  }

  /**
   * GET /api/courses/:courseId/access
   * Authoritative access check endpoint for course access.
   */
  app.get('/api/courses/:courseId/access', async (req, res) => {
    const user = await getVerifiedUser(req);
    if (!user) {
      return res.status(401).json({
        hasAccess: false,
        status: 'unauthenticated',
        error: 'Please login to continue.',
      });
    }

    const { courseId } = req.params;
    if (!courseId) {
      return res.status(400).json({
        hasAccess: false,
        error: 'Course identifier is required.',
      });
    }

    const result = await evaluateServerCourseAccess(user.uid, user.email, courseId);
    return res.json(result);
  });

  /**
   * POST /api/access/verify-course
   * Server-authoritative verification of student course enrollment.
   */
  app.post('/api/access/verify-course', async (req, res) => {
    const user = await getVerifiedUser(req);
    if (!user) {
      return res.status(401).json({
        allowed: false,
        status: 'unauthenticated',
        error: 'Please login to continue.',
      });
    }

    const { courseId } = req.body;
    if (!courseId) {
      return res.status(400).json({
        allowed: false,
        error: 'Course identifier is required.',
      });
    }

    const result = await evaluateServerCourseAccess(user.uid, user.email, courseId);
    if (!result.hasAccess) {
      return res.status(403).json({
        allowed: false,
        status: result.status,
        error: result.reason,
        code: result.status === 'expired' ? 'course_expired' : 'course_locked',
      });
    }

    res.json({
      allowed: true,
      status: result.status,
      isAdmin: result.isAdmin,
      enrollment: result.enrollment,
    });
  });

  /**
   * POST /api/access/verify-hierarchy
   * Validates that requested sub-resources (Subject, Chapter, Class, Unit MCQ, Weekly Warrior)
   * strictly belong to the specified course and that student holds active access.
   */
  app.post('/api/access/verify-hierarchy', async (req, res) => {
    const user = await getVerifiedUser(req);
    if (!user) {
      return res.status(401).json({
        allowed: false,
        error: 'Please login to continue.',
        code: 'unauthenticated',
      });
    }

    const { courseId, subjectId, chapterId, classId, testId, testType } = req.body;
    if (!courseId) {
      return res.status(400).json({
        allowed: false,
        error: 'Course identifier is required.',
      });
    }

    // 1. Authoritative course access validation
    const access = await evaluateServerCourseAccess(user.uid, user.email, courseId);
    if (!access.hasAccess) {
      return res.status(403).json({
        allowed: false,
        status: access.status,
        error: access.reason,
        code: access.status === 'expired' ? 'course_expired' : 'course_locked',
      });
    }

    // 2. Strict Subject Hierarchy Validation
    const db = getAdminFirestore();
    if (subjectId && db) {
      try {
        const sSnap = await db.collection('subjects').doc(subjectId).get();
        if (sSnap.exists) {
          const subject = sSnap.data();
          if (subject && subject.batchId !== courseId) {
            return res.status(403).json({
              allowed: false,
              error: 'You do not have permission to access this resource.',
              code: 'hierarchy_violation',
            });
          }
        }
      } catch (err) {
        console.warn('[server.ts] Error checking subject hierarchy:', err);
      }
    }

    // 3. Strict Chapter Hierarchy Validation
    if (chapterId && db) {
      try {
        const cSnap = await db.collection('chapters').doc(chapterId).get();
        if (cSnap.exists) {
          const chapter = cSnap.data();
          if (chapter && subjectId && chapter.subjectId !== subjectId) {
            return res.status(403).json({
              allowed: false,
              error: 'You do not have permission to access this resource.',
              code: 'hierarchy_violation',
            });
          }
        }
      } catch (err) {
        console.warn('[server.ts] Error checking chapter hierarchy:', err);
      }
    }

    // 4. Strict Class Lecture Hierarchy Validation
    if (classId && db) {
      try {
        const clSnap = await db.collection('classes').doc(classId).get();
        if (clSnap.exists) {
          const classItem = clSnap.data();
          if (classItem) {
            if (classItem.batchId !== courseId || (chapterId && classItem.chapterId && classItem.chapterId !== chapterId)) {
              return res.status(403).json({
                allowed: false,
                error: 'You do not have permission to access this resource.',
                code: 'hierarchy_violation',
              });
            }
          }
        }
      } catch (err) {
        console.warn('[server.ts] Error checking class hierarchy:', err);
      }
    }

    // 5. Strict Test Hierarchy Validation
    if (testId && db) {
      try {
        if (testType === 'weekly-warrior') {
          const tSnap = await db.collection('weeklyWarriorTests').doc(testId).get();
          if (tSnap.exists) {
            const ww = tSnap.data();
            if (ww && ww.batchId !== courseId) {
              return res.status(403).json({
                allowed: false,
                error: 'You do not have permission to access this resource.',
                code: 'hierarchy_violation',
              });
            }
          }
        } else if (testType === 'unit-test') {
          const tSnap = await db.collection('unitTests').doc(testId).get();
          if (tSnap.exists) {
            const ut = tSnap.data();
            if (ut && (ut.batchId !== courseId || (chapterId && ut.chapterId && ut.chapterId !== chapterId))) {
              return res.status(403).json({
                allowed: false,
                error: 'You do not have permission to access this resource.',
                code: 'hierarchy_violation',
              });
            }
          }
        }
      } catch (err) {
        console.warn('[server.ts] Error checking test hierarchy:', err);
      }
    }

    res.json({
      allowed: true,
      hierarchyValid: true,
      status: access.status,
    });
  });

  /**
   * POST /api/access/verify-test
   * Authoritative access check before test initialization (Unit MCQ or Weekly Warrior)
   */
  app.post('/api/access/verify-test', async (req, res) => {
    const user = await getVerifiedUser(req);
    if (!user) {
      return res.status(401).json({
        allowed: false,
        error: 'Please login to continue.',
        code: 'unauthenticated',
      });
    }

    const { testType, testId } = req.body;
    if (!testType || !testId) {
      return res.status(400).json({
        allowed: false,
        error: 'Test type and test identifier are required.',
      });
    }

    if (user.email && isSuperAdminEmail(user.email)) {
      return res.json({ allowed: true, isAdmin: true });
    }

    let batchId = '';
    let isPublished = false;

    const db = getAdminFirestore();
    if (db) {
      try {
        if (testType === 'weekly-warrior') {
          const snap = await db.collection('weeklyWarriorTests').doc(testId).get();
          if (snap.exists) {
            const ww = snap.data();
            batchId = ww?.batchId || '';
            isPublished = Boolean(ww?.isPublished);
          }
        } else {
          const snap = await db.collection('unitTests').doc(testId).get();
          if (snap.exists) {
            const ut = snap.data();
            batchId = ut?.batchId || '';
            isPublished = Boolean(ut?.isPublished);
          }
        }
      } catch (err) {
        console.warn('[server.ts] Error fetching test for verification:', err);
      }
    }

    if (batchId) {
      if (!isPublished) {
        return res.status(403).json({
          allowed: false,
          error: 'This test is not currently available.',
          code: 'test_unpublished',
        });
      }

      const access = await evaluateServerCourseAccess(user.uid, user.email, batchId);
      if (!access.hasAccess) {
        return res.status(403).json({
          allowed: false,
          status: access.status,
          error: access.reason,
          code: access.status === 'expired' ? 'course_expired' : 'course_locked',
        });
      }
    }

    res.json({
      allowed: true,
      batchId,
    });
  });

  /**
   * POST /api/access/verify-result
   * Validates student ownership of test attempts and results (prevents inspecting other students' scores)
   */
  app.post('/api/access/verify-result', async (req, res) => {
    const user = await getVerifiedUser(req);
    if (!user) {
      return res.status(401).json({
        allowed: false,
        error: 'Please login to continue.',
        code: 'unauthenticated',
      });
    }

    const isSuperAdmin = Boolean(user.email && isSuperAdminEmail(user.email));
    if (isSuperAdmin) {
      return res.json({ allowed: true, isAdmin: true });
    }

    const { studentId, attemptId } = req.body;

    if (studentId && studentId !== user.uid) {
      return res.status(403).json({
        allowed: false,
        error: "You do not have permission to view another student's test scorecard.",
        code: 'unauthorized_student_access',
      });
    }

    if (attemptId && typeof attemptId === 'string') {
      const parts = attemptId.split('_');
      const suffix = parts[parts.length - 1];
      if (suffix && suffix.length >= 4 && !user.uid.startsWith(suffix)) {
        return res.status(403).json({
          allowed: false,
          error: "You do not have permission to view another student's test scorecard.",
          code: 'unauthorized_attempt_access',
        });
      }
    }

    res.json({
      allowed: true,
      studentId: user.uid,
    });
  });

  // ==============================================================================
  // PHASE 9: SECURE TEST QUESTION DELIVERY & AUTHORITATIVE SCORING
  // ==============================================================================

  // In-memory caches for test attempts and authoritative test results
  const serverTestResultsStore = new Map<string, any>();
  const serverTestAttemptsStore = new Map<string, any>();

  /**
   * Helper: Retrieve all raw questions for a test (Weekly Warrior or Unit Test)
   */
  async function getRawTestQuestions(testType: string, testId: string): Promise<any[]> {
    const db = getAdminFirestore();
    const collectionName = testType === 'weekly-warrior' ? 'weeklyWarriorQuestions' : 'unitTestQuestions';

    if (db) {
      try {
        const snap = await db.collection(collectionName).where('testId', '==', testId).get();
        if (!snap.empty) {
          const questions = snap.docs.map((d) => ({ id: d.id, ...d.data() }));
          questions.sort((a: any, b: any) => (a.order || 0) - (b.order || 0));
          return questions;
        }
      } catch (err) {
        console.warn(`[server.ts] Error fetching ${collectionName} from Firestore:`, err);
      }
    }

    return [];
  }

  /**
   * GET /api/tests/:testType/:testId/questions
   * SECURE TEST DELIVERY: Strips correctOptionId, explanation, and answers before sending to client!
   */
  app.get('/api/tests/:testType/:testId/questions', async (req, res) => {
    try {
      const user = await getVerifiedUser(req);
      if (!user) {
        return res.status(401).json({ error: 'Please login to access this assessment.' });
      }

      const { testType, testId } = req.params;
      if (testType !== 'weekly-warrior' && testType !== 'unit-test') {
        return res.status(400).json({ error: 'Invalid test type specified.' });
      }

      // 1. Fetch test details to get batchId
      let batchId = '';
      let isPublished = false;

      const db = getAdminFirestore();
      if (db) {
        try {
          if (testType === 'weekly-warrior') {
            const tSnap = await db.collection('weeklyWarriorTests').doc(testId).get();
            if (tSnap.exists) {
              const ww = tSnap.data();
              batchId = ww?.batchId || '';
              isPublished = Boolean(ww?.isPublished);
            }
          } else {
            const tSnap = await db.collection('unitTests').doc(testId).get();
            if (tSnap.exists) {
              const ut = tSnap.data();
              batchId = ut?.batchId || '';
              isPublished = Boolean(ut?.isPublished);
            }
          }
        } catch (err) {
          console.warn('[server.ts] Error fetching test details for question delivery:', err);
        }
      }

      // Check course access
      if (batchId) {
        const access = await evaluateServerCourseAccess(user.uid, user.email, batchId);
        if (!access.hasAccess) {
          return res.status(403).json({
            error: access.reason || 'You are not enrolled in this course.',
            code: access.status === 'expired' ? 'course_expired' : 'course_locked',
          });
        }
      }

      // 2. Fetch raw questions
      const rawQuestions = await getRawTestQuestions(testType, testId);

      // 3. SECURE SANITIZATION: Strip answers and rationales
      const sanitizedQuestions = rawQuestions.map((q) => ({
        id: q.id,
        testId: q.testId,
        batchId: q.batchId,
        questionText: q.questionText,
        questionImageUrl: q.questionImageUrl || null,
        options: (q.options || []).map((opt: any) => ({
          id: opt.id,
          text: opt.text,
          imageUrl: opt.imageUrl || null,
        })),
        marks: Number(q.marks) || 1,
        negativeMarks: Number(q.negativeMarks) || 0.25,
        order: Number(q.order) || 0,
        subjectTag: q.subjectTag || null,
        // STRICT SECURITY: correctOptionId and explanation are completely excluded!
      }));

      return res.json({
        success: true,
        testId,
        testType,
        totalQuestions: sanitizedQuestions.length,
        questions: sanitizedQuestions,
      });
    } catch (err: any) {
      console.error('[server.ts] Error delivering sanitized questions:', err);
      return res.status(500).json({ error: 'Failed to deliver test questions.' });
    }
  });

  /**
   * POST /api/tests/:testType/:testId/submit
   * SERVER-AUTHORITATIVE SCORING: Calculates score securely on backend and writes result.
   */
  app.post('/api/tests/:testType/:testId/submit', async (req, res) => {
    try {
      const user = await getVerifiedUser(req);
      if (!user) {
        return res.status(401).json({ error: 'Please login to submit this assessment.' });
      }

      const { testType, testId } = req.params;
      const { attemptId, answers = {}, timeSpentSeconds = 0 } = req.body;

      if (!attemptId) {
        return res.status(400).json({ error: 'Attempt identifier is required for submission.' });
      }

      // 1. Fetch authoritative questions with correct answers
      const rawQuestions = await getRawTestQuestions(testType, testId);
      if (!rawQuestions || rawQuestions.length === 0) {
        return res.status(404).json({ error: 'Assessment questions not found.' });
      }

      // 2. Perform authoritative scoring
      let totalMarks = 0;
      let score = 0;
      let correctCount = 0;
      let incorrectCount = 0;
      let unattemptedCount = 0;
      const subjectMap: Record<string, { total: number; correct: number; incorrect: number }> = {};

      for (const q of rawQuestions) {
        const qMarks = Number(q.marks) || 1;
        const qNegative = Number(q.negativeMarks) || 0.25;
        totalMarks += qMarks;

        const subjectKey = q.subjectTag || 'General Nursing';
        if (!subjectMap[subjectKey]) {
          subjectMap[subjectKey] = { total: 0, correct: 0, incorrect: 0 };
        }
        subjectMap[subjectKey].total += 1;

        const studentOptionId = answers[q.id];
        if (!studentOptionId) {
          unattemptedCount += 1;
        } else if (studentOptionId === q.correctOptionId) {
          correctCount += 1;
          score += qMarks;
          subjectMap[subjectKey].correct += 1;
        } else {
          incorrectCount += 1;
          score -= qNegative;
          subjectMap[subjectKey].incorrect += 1;
        }
      }

      const finalScore = Math.max(0, Math.round(score * 100) / 100);
      const passingMarks = Math.round(totalMarks * 0.5 * 10) / 10;
      const isPassed = finalScore >= passingMarks;
      const attemptedCount = correctCount + incorrectCount;
      const accuracyPercentage = attemptedCount > 0 ? Math.round((correctCount / attemptedCount) * 100) : 0;

      const breakdownBySubject = Object.entries(subjectMap).map(([subject, stats]) => ({
        subject,
        totalQuestions: stats.total,
        correctCount: stats.correct,
        incorrectCount: stats.incorrect,
        score: Math.max(0, stats.correct - stats.incorrect * 0.25),
      }));

      const now = new Date().toISOString();
      const resultDocId = `res_${testType === 'weekly-warrior' ? 'ww' : 'ut'}_${attemptId}`;

      const result = {
        id: resultDocId,
        attemptId,
        testId,
        batchId: rawQuestions[0]?.batchId || '',
        studentId: user.uid,
        studentName: user.name || 'Student',
        studentEmail: user.email || '',
        score: finalScore,
        totalMarks,
        passingMarks,
        totalQuestions: rawQuestions.length,
        correctCount,
        incorrectCount,
        unattemptedCount,
        accuracyPercentage,
        accuracy: accuracyPercentage,
        timeTakenSeconds: timeSpentSeconds,
        timeSpentSeconds,
        isPassed,
        submittedAt: now,
        breakdownBySubject,
        answers,
      };

      // Save to memory stores
      serverTestResultsStore.set(resultDocId, result);
      serverTestResultsStore.set(attemptId, result);

      const completedAttempt = {
        id: attemptId,
        testId,
        studentId: user.uid,
        status: 'completed',
        score: finalScore,
        correctCount,
        incorrectCount,
        unattemptedCount,
        totalQuestions: rawQuestions.length,
        timeTakenSeconds: timeSpentSeconds,
        submittedAt: now,
        completedAt: now,
        answers,
      };
      serverTestAttemptsStore.set(attemptId, completedAttempt);

      // Persist to Firestore via Admin SDK
      const db = getAdminFirestore();
      if (db) {
        try {
          const resultsCol = testType === 'weekly-warrior' ? 'weeklyWarriorResults' : 'unitTestResults';
          const attemptsCol = testType === 'weekly-warrior' ? 'weeklyWarriorAttempts' : 'unitTestAttempts';

          await db.collection(resultsCol).doc(resultDocId).set(result, { merge: true });
          await db.collection(attemptsCol).doc(attemptId).set(completedAttempt, { merge: true });
          console.log(`[server.ts] Assessment authoritative result saved to ${resultsCol}/${resultDocId}`);
        } catch (dbErr) {
          console.warn('[server.ts] Error persisting test result to Firestore:', dbErr);
        }
      }

      return res.json({
        success: true,
        message: 'Assessment evaluated and recorded successfully.',
        result,
      });
    } catch (err: any) {
      console.error('[server.ts] Error evaluating test submission:', err);
      return res.status(500).json({ error: 'Failed to submit and evaluate assessment.' });
    }
  });

  /**
   * GET /api/tests/:testType/:testId/review/:attemptId
   * POST-SUBMISSION REVIEW: Returns question explanations only after verified submission!
   */
  app.get('/api/tests/:testType/:testId/review/:attemptId', async (req, res) => {
    try {
      const user = await getVerifiedUser(req);
      if (!user) {
        return res.status(401).json({ error: 'Please login to access the test review.' });
      }

      const { testType, testId, attemptId } = req.params;

      // 1. Fetch attempt and result to verify completion and ownership
      let result = serverTestResultsStore.get(attemptId) || serverTestResultsStore.get(`res_${testType === 'weekly-warrior' ? 'ww' : 'ut'}_${attemptId}`);

      if (!result) {
        const db = getAdminFirestore();
        if (db) {
          try {
            const resultsCol = testType === 'weekly-warrior' ? 'weeklyWarriorResults' : 'unitTestResults';
            const snap = await db.collection(resultsCol).doc(`res_${testType === 'weekly-warrior' ? 'ww' : 'ut'}_${attemptId}`).get();
            if (snap.exists) {
              result = snap.data();
            }
          } catch (e) {
            // ignore
          }
        }
      }

      if (!result) {
        return res.status(404).json({ error: 'Completed test scorecard not found for this attempt.' });
      }

      // Check ownership
      const isSuperAdmin = Boolean(user.email && isSuperAdminEmail(user.email));
      if (!isSuperAdmin && result.studentId !== user.uid) {
        return res.status(403).json({ error: 'Unauthorized to view this scorecard.' });
      }

      // 2. Fetch authoritative questions
      const rawQuestions = await getRawTestQuestions(testType, testId);
      const studentAnswers = result.answers || {};

      const reviewItems = rawQuestions.map((q) => {
        const studentSelectedOptionId = studentAnswers[q.id] || null;
        const isCorrect = studentSelectedOptionId === q.correctOptionId;
        const isSkipped = !studentSelectedOptionId;

        return {
          questionId: q.id,
          questionText: q.questionText,
          questionImageUrl: q.questionImageUrl || null,
          options: q.options || [],
          correctOptionId: q.correctOptionId,
          studentSelectedOptionId,
          isCorrect,
          isSkipped,
          explanation: q.explanation || 'Detailed clinical rationale is available in full lecture series.',
          explanationImageUrl: q.explanationImageUrl || null,
          marks: q.marks || 1,
          negativeMarks: q.negativeMarks || 0.25,
          subjectTag: q.subjectTag || 'General Nursing',
        };
      });

      return res.json({
        success: true,
        reviewItems,
        result,
      });
    } catch (err: any) {
      console.error('[server.ts] Error generating test review:', err);
      return res.status(500).json({ error: 'Failed to generate test review.' });
    }
  });

  /**
   * GET /api/tests/:testType/:testId/results/:attemptId
   * Retrieves authoritative scorecard for completed attempt
   */
  app.get('/api/tests/:testType/:testId/results/:attemptId', async (req, res) => {
    try {
      const user = await getVerifiedUser(req);
      if (!user) {
        return res.status(401).json({ error: 'Please login to access this result.' });
      }

      const { testType, attemptId } = req.params;
      let result = serverTestResultsStore.get(attemptId) || serverTestResultsStore.get(`res_${testType === 'weekly-warrior' ? 'ww' : 'ut'}_${attemptId}`);

      if (!result) {
        const db = getAdminFirestore();
        if (db) {
          try {
            const resultsCol = testType === 'weekly-warrior' ? 'weeklyWarriorResults' : 'unitTestResults';
            const snap = await db.collection(resultsCol).doc(`res_${testType === 'weekly-warrior' ? 'ww' : 'ut'}_${attemptId}`).get();
            if (snap.exists) {
              result = snap.data();
            }
          } catch (e) {
            // ignore
          }
        }
      }

      if (!result) {
        return res.status(404).json({ error: 'Scorecard not found.' });
      }

      const isSuperAdmin = Boolean(user.email && isSuperAdminEmail(user.email));
      if (!isSuperAdmin && result.studentId !== user.uid) {
        return res.status(403).json({ error: 'Unauthorized to view this scorecard.' });
      }

      return res.json({ success: true, result });
    } catch (err: any) {
      console.error('[server.ts] Error retrieving test result:', err);
      return res.status(500).json({ error: 'Failed to retrieve test result.' });
    }
  });

  /**
   * POST /api/admin/purge-all-data
   * Complete clean-slate purge of all curriculum, assessments, enrollments, payments, and mock data.
   */
  app.post('/api/admin/purge-all-data', async (req, res) => {
    try {
      const user = await getVerifiedUser(req);
      const isSuperAdmin = Boolean(user && user.email && isSuperAdminEmail(user.email));

      // Clear all server in-memory stores & persisted catalog
      serverTestResultsStore.clear();
      serverTestAttemptsStore.clear();
      cloudCatalog = {
        batches: [],
        subjects: [],
        chapters: [],
        classes: [],
        pdfNotes: [],
        weeklyWarriorTests: [],
        weeklyWarriorQuestions: [],
        unitTests: [],
        unitTestQuestions: [],
        deletedIds: [],
        updatedAt: new Date().toISOString(),
      };
      try {
        if (fs.existsSync(CATALOG_FILE)) fs.unlinkSync(CATALOG_FILE);
      } catch {
        // ignore
      }

      const db = getAdminFirestore();
      let totalDeleted = 0;

      if (db) {
        const collectionsToPurge = [
          'batches',
          'courses',
          'subjects',
          'chapters',
          'classes',
          'lectures',
          'pdf_notes',
          'pdfNotes',
          'weeklyWarriorTests',
          'weeklyWarriorQuestions',
          'weeklyWarriorAttempts',
          'weeklyWarriorResults',
          'unitTests',
          'unitTestQuestions',
          'unitTestAttempts',
          'unitTestResults',
          'tests',
          'questions',
          'enrollments',
          'payments',
          'coupons',
        ];

        for (const coll of collectionsToPurge) {
          try {
            const snap = await db.collection(coll).get();
            if (!snap.empty) {
              const batch = db.batch();
              let countInBatch = 0;
              for (const doc of snap.docs) {
                batch.delete(doc.ref);
                countInBatch++;
                totalDeleted++;
                if (countInBatch >= 450) {
                  await batch.commit();
                  countInBatch = 0;
                }
              }
              if (countInBatch > 0) {
                await batch.commit();
              }
            }
          } catch (e: any) {
            console.warn(`[server.ts] Warning purging ${coll}:`, e?.message || e);
          }
        }
      }

      console.log(`[server.ts] Complete purge executed. Total documents purged: ${totalDeleted}`);
      return res.json({
        success: true,
        message: 'All real and fake data completely wiped from server and Firestore.',
        totalDeleted,
      });
    } catch (err: any) {
      console.error('[server.ts] Error purging all data:', err);
      return res.status(500).json({ error: 'Failed to execute clean slate purge.' });
    }
  });

  return app;
}

export const app = buildApp();

export async function startServer() {
  const PORT = 3000;

  // ==============================================================================
  // VITE MIDDLEWARE (Handles SPA routing and frontend asset serving)
  // ==============================================================================
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[Axon LMS Server] Running on http://localhost:${PORT}`);
  });
}

// In local dev and standard container deployments, start the HTTP server
if (process.env.VERCEL !== '1' && process.env.SERVERLESS !== '1' && !process.env.VERCEL_ENV) {
  startServer().catch((err) => {
    console.error('[Axon LMS Server] Fatal server startup error:', err);
    process.exit(1);
  });
}

export default app;
